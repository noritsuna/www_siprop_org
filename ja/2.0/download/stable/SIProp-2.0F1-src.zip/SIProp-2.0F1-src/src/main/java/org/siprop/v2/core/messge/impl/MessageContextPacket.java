/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.siprop.v2.core.messge.ControlMessage;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.Packet;
import org.siprop.v2.util.impl.Peer;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Packet for MessageContext.
 * 
 * @author noritsuna
 * 
 */
public class MessageContextPacket implements Packet {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = -1284218168786267359L;

	/**
	 * map of ControlMessage.
	 */
	private Map<String, ControlMessage> controlMessageMap = null;

	/**
	 * FlatMessage.
	 */
	private FlatMessage flatMessage = null;

	/**
	 * A source address of a received message or, a destination address of a
	 * message that will be sent.
	 */
	private Peer remotePeer = null;

	/**
	 * A destination address of a received message or, a source address of a
	 * message that will be sent.
	 */
	private Peer localPeer = null;

	/**
	 * Constructor.
	 * 
	 */
	private MessageContextPacket() {
	}

	/**
	 * create new MessageContextPacket.
	 * 
	 * @return new MessageContextPacket
	 */
	public static MessageContextPacket createMessageContextPacket() {
		MessageContextPacket mc = new MessageContextPacket();

		return mc;
	}

	/**
	 * copy MessageContextPacket.
	 * 
	 * @param me
	 *            MessageContextPacket for a copy
	 * @return Copied MessageContextPacket
	 */
	public static MessageContextPacket copyMessageContextPacket(
			MessageContextPacket me) {
		MessageContextPacket mc = new MessageContextPacket();
		mc.setControlMessageMap(me.getControlMessageMap());
		mc.setFlatMessage(me.getFlatMessage());

		return mc;
	}

	/**
	 * clone MessageContextPacket.
	 * 
	 * @param me
	 *            MessageContextPacket for a clone
	 * @return Cloned MessageContextPacket
	 */
	public static MessageContextPacket cloneMessageContextPacket(
			MessageContextPacket me) {
		throw new NotImplementedException();
	}

	/**
	 * get ControlMessage.
	 * 
	 * @param key
	 * @return ControlMessage
	 */
	public ControlMessage getControlMessage(String key) {
		if (controlMessageMap == null) {
			return null;
		}
		return this.controlMessageMap.get(key);
	}

	/**
	 * add ControlMessage.
	 * 
	 * @param key
	 * @param ctrlMessage
	 */
	public void addControlMessage(String key, ControlMessage ctrlMessage) {
		if (controlMessageMap == null) {
			controlMessageMap = Collections
					.synchronizedMap(new HashMap<String, ControlMessage>());
		}
		this.controlMessageMap.put(key, ctrlMessage);
	}

	/**
	 * get FlatMessage.
	 * 
	 * @return flatMessage
	 */
	public FlatMessage getFlatMessage() {
		return flatMessage;
	}

	/**
	 * set FlatMessage.
	 * 
	 * @param flatMessage
	 */
	public void setFlatMessage(FlatMessage flatMessage) {
		this.flatMessage = flatMessage;
	}

	/**
	 * get map of ControlMessage.
	 * 
	 * @return controlMessageMap
	 */
	public Map<String, ControlMessage> getControlMessageMap() {
		return controlMessageMap;
	}

	/**
	 * set map of ControlMessage.
	 * 
	 * @param controlMessageMap
	 */
	public void setControlMessageMap(
			Map<String, ControlMessage> controlMessageMap) {
		this.controlMessageMap = controlMessageMap;
	}

	/**
	 * get a local address and port
	 * 
	 * @return local peer
	 */
	public Peer getLocalPeer() {
		return this.localPeer;
	}

	/**
	 * get a remote address and port
	 * 
	 * @return remote peer
	 */
	public Peer getRemotePeer() {
		return this.remotePeer;
	}

	/**
	 * set a local address and port
	 * 
	 * @param localPeer
	 *            local peer
	 */
	public void setLocalPeer(Peer localPeer) {
		this.localPeer = localPeer;
	}

	/**
	 * set a remote address and port
	 * 
	 * @param remotePeer
	 *            remote peer
	 */
	public void setRemotePeer(Peer remotePeer) {
		this.remotePeer = remotePeer;
	}
}
