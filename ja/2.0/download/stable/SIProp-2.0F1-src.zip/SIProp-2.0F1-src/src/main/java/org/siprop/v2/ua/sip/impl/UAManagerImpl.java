/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.siprop.v2.core.DefaultManager;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.ua.UAContext;
import org.siprop.v2.ua.UAControlMessage;
import org.siprop.v2.ua.UAManager;
import org.siprop.v2.ua.impl.UAInterpreter;
import org.siprop.v2.ua.sip.context.impl.DefaultSIPUAContext;
import org.siprop.v2.ua.util.impl.CommandName;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.ManagerGarbageCollector;

/**
 * Manager for standard UA.
 * 
 * @author noritsuna
 * 
 */
public class UAManagerImpl extends DefaultManager implements UAManager {

	/**
	 * this instance is for singleton pattern.
	 */
	private static UAManagerImpl instance = null;

	/**
	 * map of UAContext instances.
	 */
	private Map<String, UAContext> uaMap = null;

	/**
	 * list is UAContext keys.
	 */
	private List<String> uaList = null;

	/**
	 * UAInterpreter.
	 */
	private UAInterpreter uaInterpreter = null;

	/**
	 * Service name.
	 */
	private String serviceName = "sip";

	/**
	 * instance of garbage collector
	 */
	private ManagerGarbageCollector garbageCollector = null;

	/**
	 * instance of garbage collector tread.
	 */
	private Thread gcThread = null;

	/**
	 * Constructor.
	 * 
	 */
	private UAManagerImpl() {
		this.uaMap = Collections
				.synchronizedMap(new HashMap<String, UAContext>());
		this.uaList = Collections.synchronizedList(new ArrayList<String>());

		/*
		 * create TransactionGarbageCollector and run it.
		 */
		this.garbageCollector = new ManagerGarbageCollector(this);
		this.gcThread = new Thread(this.garbageCollector);
		this.gcThread.start();

	}

	/**
	 * For singleton pattern.
	 * 
	 * @return this instance
	 */
	public static UAManagerImpl getInstance() {
		if (instance == null) {
			instance = new UAManagerImpl();
		}
		return instance;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.router.RouterListener#receive(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void receive(MessageContext messagecontext) {

		Logger.getGlobal().fine(messagecontext, "in UAManager.receive()");

		// Get UAInfo.
		String key = (String) getUniKeyGenerator().generateKey(messagecontext);
		UAContext uaContext = this.getUAContext(key);
		// UAInfo don'n find to route to B2BUA.
		if (uaContext == null) {
			Logger.getGlobal().fine(messagecontext, "Create new UAInfo.");
			// Create new UAInfo.
			uaContext = new DefaultSIPUAContext();
			this.setUAContext(key, uaContext);

			UAControlMessage controlMessage = new UAControlMessageImpl();
			CommandName commandName = new CommandName(serviceName,
					"do_Default_init");
			controlMessage.setExecMethod(commandName);

			messagecontext.getCurrentMessageContextPacket().addControlMessage(
					UAManagerImpl.getInstance().getControlMessageName(),
					controlMessage);
		}

		// Exec UACommand.
		synchronized (uaContext) {
			this.uaInterpreter.exec(messagecontext, uaContext);
		}

		// Send next layer.
		this.send(messagecontext);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.router.RouterListener#send(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void send(MessageContext messagecontext) {
		Logger.getGlobal().fine(messagecontext, "in UAManager.send()");
		this.getRouter().doRoute(messagecontext);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.DefaultManager#doProcess(java.lang.String,
	 *      java.lang.Object[])
	 */
	public void doProcess(String processName, Object[] param) {
		if (processName.equals(ManagerGarbageCollector.PROCESS_NAME)) {
			this.doGC();
		}
	}

	/**
	 * set UAInterpreter.
	 * 
	 * @param interpreter
	 */
	public void setUAInterpreter(UAInterpreter interpreter) {
		this.uaInterpreter = interpreter;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#setServiceName(java.lang.String)
	 */
	public void setServiceName(String name) {
		serviceName = name;
	}
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#getServiceName()
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * get UAContext by MessageContext.
	 * 
	 * @param messagecontext
	 * @return
	 */
	private UAContext getUAContext(MessageContext messagecontext) {
		String key = (String) this.getUniKeyGenerator().generateKey(
				messagecontext);
		return getUAContext(key);
	}

	/**
	 * Get UAContext by key.
	 * 
	 * @param key
	 * @return
	 */
	private UAContext getUAContext(String key) {

		if (this.uaMap.containsKey(key)) {
			return this.uaMap.get(key);
		} else {
			// UAInfo uaInfo = new DefaultUAInfo();
			// this.uaList.put(key, uaInfo);
			return null;
		}
	}

	/**
	 * set UAContext by MessageContext.
	 * 
	 * @param messageContext
	 * @param uaContext
	 */
	private void setUAContext(MessageContext messageContext, UAContext uaContext) {
		String key = (String) this.getUniKeyGenerator().generateKey(
				messageContext);
		this.setUAContext(key, uaContext);
	}

	/**
	 * set UAContext by key.
	 * 
	 * @param key
	 * @param uaContext
	 */
	private void setUAContext(String key, UAContext uaContext) {
		this.uaMap.put(key, uaContext);
		this.uaList.add(key);
	}

	/**
	 * delete UAContext by MessageContext.
	 * 
	 * @param messagecontext
	 */
	private void deleteUAContext(MessageContext messagecontext) {
		String key = (String) this.getUniKeyGenerator().generateKey(
				messagecontext);
		this.deleteUAContext(key);
	}

	/**
	 * delete UAContext by key.
	 * 
	 * @param key
	 */
	private void deleteUAContext(String key) {
		this.uaList.remove(key);
		this.uaMap.remove(key);
	}

	/**
	 * Execute GC.<BR>
	 * Delete to save B2BUAModule by delete Flag.
	 */
	private void doGC() {

		for (String key : this.uaList) {
			UAContext ua = this.uaMap.get(key);
			if (ua == null || ua.getDeleteFlag()) {
				this.deleteUAContext(key);
			}
		}

	}

}
