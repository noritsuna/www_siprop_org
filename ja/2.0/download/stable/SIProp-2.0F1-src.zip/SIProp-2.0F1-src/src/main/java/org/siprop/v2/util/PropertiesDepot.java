/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util;

/**
 * Abstract class for property.
 * 
 * @author noritsuna
 * 
 */
public interface PropertiesDepot {

	/**
	 * load property.
	 * 
	 * @param propertyPath
	 */
	public void loadProperties(String propertyPath);

	/**
	 * set property.
	 * 
	 * @param propertyName
	 * @param propertyValue
	 */
	public void setProperty(String propertyName, String propertyValue);

	/**
	 * get property.
	 * 
	 * @param property
	 * @return matching property
	 */
	public String getProperty(String property);

	/**
	 * delete property.
	 * 
	 */
	public void storeProperties();

	/**
	 * rebuild property.
	 * 
	 * @param propertyPath
	 */
	public void processNewProperties(String propertyPath);

	/**
	 * setup propertyDepot class.
	 * 
	 * @param prop
	 */
	public void setup(PropertiesDepot prop);
}
