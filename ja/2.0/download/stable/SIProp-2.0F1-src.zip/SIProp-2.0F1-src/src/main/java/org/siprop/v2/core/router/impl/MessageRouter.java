/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.router.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.messge.impl.MessageContextPacket;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * This class is a router for MessageContext. 
 * 
 * @author nisato
 * 
 */
public class MessageRouter implements Router {

	/**
	 * this instance is for singleton pattern.
	 */
	private static MessageRouter singleinstance = null;
	
	/**
	 * list of RouterInfo.
	 */
	private List<RouterInfo> routerinfolist = null;

	/**
	 * number of threads.
	 */
	private Integer threadpoolnum;
	
	/**
	 * ExecutorService for routing.
	 */
	private ExecutorService routeingthreadexecutor;

	/**
	 * base name of StackControlMessageImpl
	 */
	public static final String CONTROLMESSAGE_BASENAME = "MessageRouterControlMessage";


	/**
	 * Constructor.
	 * 
	 */
	private MessageRouter() {
		// default thread number.
		threadpoolnum = 10;
		routerinfolist = Collections.synchronizedList(new ArrayList<RouterInfo>());
	}
	

	/**
	 * For singleton pattern.
	 * 
	 * @return this instance
	 */
	public static MessageRouter getInstance() {
		if(singleinstance == null) {
			singleinstance = new MessageRouter();
		}		
		return singleinstance;
	}



	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#start()
	 */
	public void start() {
		// set threads.
		this.routeingthreadexecutor = Executors
				.newFixedThreadPool(threadpoolnum);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#stop()
	 */
	public void stop() {
		throw new NotImplementedException();
	}

	/**
	 * @param count
	 */
	public void setThreadPoolCount(int count) {
		this.threadpoolnum = count;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#addRoute(org.siprop.v2.core.router.RouterInfo)
	 */
	public void addRoute(RouterInfo routerinfo) {
		this.routerinfolist.add(routerinfo);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#doRoute(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void doRoute(MessageContext messagecontext) {
		// thread pool run
		Logger.getGlobal().finest(messagecontext, "in doRoute.");
		submitNewThread(messagecontext);
		Logger.getGlobal().finest(messagecontext, "out doRoute.");
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#getRouterInfo(org.siprop.v2.core.router.RouteKey)
	 */
	public RouterInfo getRouterInfo(RouteKey routekey) {
		for (RouterInfo routerinfo : routerinfolist) {
			if (routerinfo.getRouteKey().getRouteid() == routekey.getRouteid())
				return routerinfo;
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#removeRoute(org.siprop.v2.core.router.RouteKey)
	 */
	public void removeRoute(RouteKey routekey) {
		for (RouterInfo routerinfo : routerinfolist) {
			if (routerinfo.getRouteKey().getRouteid() == routekey.getRouteid())
				routerinfolist.remove(routerinfo);
		}
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#removeRoute(org.siprop.v2.core.router.RouterInfo)
	 */
	public void removeRoute(RouterInfo routerinfo) {
		for (RouterInfo irouterinfo : routerinfolist) {
			if (irouterinfo.getRouteKey().getRouteid() == routerinfo
					.getRouteKey().getRouteid())
				routerinfolist.remove(routerinfo);
		}
	}

	/**
	 * create & submit new thread.
	 * 
	 * @param messagecontext
	 */
	private void submitNewThread(MessageContext messagecontext) {
		this.routeingthreadexecutor.submit(new DoRouterCallableImpl(this, messagecontext));
	}

	/**
	 * do routing thread.
	 */
	private class DoRouterCallableImpl implements Callable {

		/**
		 * sending MessageContext.
		 */
		private MessageContext messagecontext;
		
		/**
		 * sending Router.
		 */
		private Router router;

		/**
		 * Constructor.
		 * 
		 * @param router sending Router
		 * @param messagecontext sending MessageContext
		 */
		public DoRouterCallableImpl(Router router, MessageContext messagecontext) {
			this.messagecontext = messagecontext;
			this.router = router;
		}

		/* (non-Javadoc)
		 * @see java.util.concurrent.Callable#call()
		 */
		public Object call() {

			// create new MessageContext.
			MessageContext newContext = MessageContext
					.copyMessageContext(messagecontext);
			MessageContextPacket packet = newContext.getMessageContextInfo()
					.getMessageContextPacket(true);
			
			// check MessageContextPacket.
			if (packet == null) {
				Logger.getGlobal().fine(newContext,
						"Next packet doesn't defined: discarded");
				return null;
			}

			// check next MessageContextPacket.
			if (!newContext.isPacketEnd()) {
				MessageContext nextSubmitContext = MessageContext
						.copyMessageContext(newContext);
				router.doRoute(nextSubmitContext);
			}

			// set Current MessageContext.
			newContext.setCurrentMessageContextPacket(packet);
			
			// get send to key.
			SendToKey sendToKey = (SendToKey) LayerRoutingResolver
					.getInstance().resolve(newContext);
			if (sendToKey == null) {
				/*
				 * There is no LayerKey
				 */
				Logger.getGlobal().fine(newContext,
						"Next Layer doesn't defined: discarded");
				return null;
			}

			RouteKey nextSendTo = sendToKey.getSendTo();
			if (nextSendTo == null) {
				/*
				 * next layer doesn't defined
				 */
				Logger.getGlobal().fine(newContext,
						"Next Layer doesn't defined: discarded");
				return null;
			}

			Logger.getGlobal().finest(
					newContext,
					"A destination of this message is "
							+ nextSendTo.getRouteid().toString());

			// send next Listener.
			for (RouterInfo rtrinfo : routerinfolist) {
				String infoSendTo = (String) rtrinfo.getRouteKey().getRouteid();
				if (infoSendTo.equals((String) nextSendTo.getRouteid())) {
					Logger.getGlobal().finest(
							newContext,
							"The message is forwarded to "
									+ nextSendTo.getRouteid().toString());
					rtrinfo.getListener().receive(newContext);
					return null;
				}
			}

			// not found next Listener.
			Logger.getGlobal().warning(newContext,
					"No valid Next Layer is found: discarded");

			return null;
		}
	}

}
