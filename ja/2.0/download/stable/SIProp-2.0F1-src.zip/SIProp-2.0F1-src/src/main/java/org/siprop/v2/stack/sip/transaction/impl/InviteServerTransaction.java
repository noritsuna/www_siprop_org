/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.stack.StackControlMessage;
import org.siprop.v2.stack.sip.impl.StackControlMessageImpl;
import org.siprop.v2.stack.sip.transaction.SIPTimer;
import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.TransactionInfo;
import org.siprop.v2.stack.sip.transaction.TransactionState;
import org.siprop.v2.stack.sip.transaction.TransactionType;
import org.siprop.v2.transport.sip.impl.TransportManagerImpl;
import org.siprop.v2.util.impl.Logger;

/**
 * The state machine for INVITE Server Transaction<BR>
 * According to RFC3261 Figure 7: INVITE server transaction
 * 
 * <PRE>
 * 
 * |INVITE |pass INV to TU INVITE V send 100 if TU won't in 200ms send
 * response+-----------+ +--------| |--------+101-199 from TU | | Proceeding|
 * |send response +-------&gt;| |&lt;-------+ | | Transport Err. | | Inform TU |
 * |---------------&gt;+ +-----------+ | 300-699 from TU | |2xx from TU | send
 * response | |send response | | +------------------&gt;+ | | INVITE V Timer G
 * fires | send response+-----------+ send response | +--------| |--------+ | | |
 * Completed | | | +-------&gt;| |&lt;-------+ | +-----------+ | | | | ACK | | | - |
 * +------------------&gt;+ | Timer H fires | V or Transport Err.| +-----------+
 * Inform TU | | | | | Confirmed | | | | | +-----------+ | | | |Timer I fires | |- | | |
 * V | +-----------+ | | | | | Terminated|&lt;---------------+ | | +-----------+
 * 
 * </PRE>
 * 
 * @author masaxmasa
 * 
 */
public class InviteServerTransaction implements TransactionEntry {

	/**
	 * state of this transaction
	 */
	private TransactionState state = null;

	/**
	 * Next expire time, if timer is running. 0 means that there is no timer in
	 * current state.
	 */
	private long tStamp = 0;

	/**
	 * The lifetime for this transaction
	 */
	private long tExpire = 0;

	/**
	 * counter for response transmitted.
	 */
	private int nTransmit = 0;

	/**
	 * max number of transmitting response message.
	 */
	private int maxTransmit = 0;

	/**
	 * value of Timer G
	 */
	private long timerG = 0;

	/**
	 * value of Timer T2
	 */
	private long timerT2 = 0;

	/**
	 * Is reliable transport or not.
	 */
	private boolean isReliable = false;

	/**
	 * type of transaction
	 */
	private final TransactionType type = TransactionType.TRANSACTIONTYPE_INV_UAS;

	/**
	 * parent Transactio object of this entry
	 */
	private TransactionController parentTransaction = null;
	
	/**
	 * TransactionInfo.
	 */
	private TransactionInfo transactionInfo = null;
	

	/**
	 * Constructor. set Initial Transaction State.
	 * 
	 * @param isReliable
	 *            Using reliable transport or not.
	 */
	public InviteServerTransaction(TransactionController parent, boolean isReliable) {
		// set Initial State
		this.state = TransactionState.NONE;
		this.tStamp = 0;
		this.isReliable = isReliable;
		this.timerG = SIPTimer.getG();
		long timerH = SIPTimer.getH();
		this.timerT2 = SIPTimer.getT2();
		this.maxTransmit = 1;
		this.parentTransaction = parent;

		/*
		 * calculate max number of transmit
		 */
		while (timerH > 0) {
			long intval = this.timerG;
			for (int i = 0; i < this.maxTransmit; i++) {
				intval *= 2;
			}

			if (intval > this.timerT2) {
				intval = this.timerT2;
			}

			timerH -= intval;
			this.maxTransmit++;
		}
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#doProcess(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void doProcess(MessageContext msg) {
		Logger.getGlobal().fine(msg,
				"INVITE Server Transaction: [" + this.state.toString() + "]");
		switch (this.state) {
		case NONE:
			onNONEState(msg);
			break;
		case PROCEEDING:
			onPROCEEDINGState(msg);
			break;
		case COMPLETED:
			onCOMPLETEDState(msg);
			break;
		case CONFIRMED:
			// do nothing
			break;
		case TERMINATED:
			// do nothing
			break;
		default:
			/*
			 * Invalid transaction state
			 */
			moveToTERMINATEDState();
			break;
		}
	}

	/**
	 * Initial state, move to PROCEEDING state
	 * 
	 * @param msg
	 */
	private void onNONEState(MessageContext msg) {
		/*
		 * Check SIP INVITE request message or not.
		 */
		if ((msg.getCurrentMessageContextPacket().getFlatMessage().getMessage() instanceof SIPRequest) == false) {
			/*
			 * This message is not SIP request message.
			 */
			moveToDELETEState();
			return;
		}

		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		if (SIPRequest.INVITE.equals(sipReq.getMethod()) == false) {
			/*
			 * This message is not INVITE request message.
			 */
			moveToDELETEState();
			return;
		}

		/*
		 * Store parameters
		 */
		if(this.getTransactionInfo() == null) {
			this.setTransactionInfo(new TransactionInfoImpl(msg));
		}

		// To tag
		this.getTransactionInfo().setTagTo(sipReq.getToTag());

		// send 100 Trying
		MessageContext trying = null;
		try {
			trying = this.parentTransaction.getTU().getStackManager().createResponse(msg,
					SIPResponse.TRYING);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Logger.getGlobal().warning(msg, "Can't send 100 Trying message.");
		}

		if (trying != null) {
			SendToKey tryingLayerKey = new SendToKey(parentTransaction.getTU()
					.getStackManager().getRouteKey(),
					TransportManagerImpl.getInstance().getRouteKey());
			StackControlMessage tryingCtrlMsg = new StackControlMessageImpl();
			tryingCtrlMsg.setSendToKey(tryingLayerKey);
			trying.getCurrentMessageContextPacket().addControlMessage(
					parentTransaction.getTU().getStackManager()
							.getControlMessageName(), tryingCtrlMsg);
			this.parentTransaction.getTU().send(trying);
		}

		moveToPROCEEDINGState();
		this.getTransactionInfo().setOriginalMessage(msg);
	}

	/**
	 * The process in PROCEEDING state.
	 * 
	 * @param msg
	 */
	private void onPROCEEDINGState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();

		if (sipMsg instanceof SIPRequest) {
			/*
			 * SIP request message
			 */
			SIPRequest sipReq = (SIPRequest) sipMsg;
			if (sipReq.INVITE.equals(sipReq.getMethod())) {
				/*
				 * This INVITE message is re-transmitted. Stay in PROCEEDING
				 * state.
				 */
			} else {
				/*
				 * Other request message was received. Move to TERMINATED state.
				 */
				moveToTERMINATEDState();
				return;
			}
		} else {
			/*
			 * SIP response message
			 */
			SIPResponse sipRsp = (SIPResponse) sipMsg;
			switch (sipRsp.getStatusCode() / 100) {
			case 0:
				/*
				 * XXX invalid response message was sent. ignore it.
				 */
				break;
			case 1:
				/*
				 * 1XX response message was sent. Stay in PROCEEDING state
				 */
				break;
			case 2:
				/*
				 * 2XX response message was sent. Move to TERMINATED state
				 */
				moveToTERMINATEDState();
				break;
			default:
				/*
				 * 3XX-6XX response message was sent. Move to COMPLETED state
				 */
				moveToCOMPLETEDState();
				break;
			}
		}
	}

	/**
	 * The process of COMPLETED state.
	 * 
	 * @param msg
	 */
	private void onCOMPLETEDState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();

		if (sipMsg instanceof SIPRequest) {
			/*
			 * SIP request message
			 */
			SIPRequest sipReq = (SIPRequest) sipMsg;
			if (SIPRequest.INVITE.equals(sipReq.getMethod())) {
				/*
				 * INVITE request message was received. Stay in COMPLETED state
				 */

				// TODO send SIP response message
			} else if (SIPRequest.ACK.equals(sipReq.getMethod())) {
				/*
				 * ACK request message was received. Move to CONFIRMED state.
				 */
				moveToCONFIRMEDState();
			}
		} else {
			/*
			 * SIP response message un-expect message. Ignore it.
			 */
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.core.transaction.TransactionEntry#fireTimer()
	 */
	public void fireTimer() {
		Logger.getGlobal().fine(
				null,
				"INVITE Server Transaction: Timer Expired ["
						+ this.state.toString() + "]");
		switch (this.state) {
		case PROCEEDING:
			/*
			 * SIProp hack
			 */
			firePROCEEDINGState();
			break;
		case COMPLETED:
			fireCOMPLETEDState();
			break;
		case CONFIRMED:
			fireCONFIRMEDState();
			break;
		case TERMINATED:
			/*
			 * SIProp hack.
			 */
			fireTERMINATEDState();
			break;
		case NONE:
		default:
			break;
		}

	}

	/**
	 * SIProp hack. The timer (Timer C) in PROCEDING state is expired.
	 */
	private void firePROCEEDINGState() {

		/*
		 * TODO send CANCEL request to Next Layer.
		 */

		moveToTERMINATEDState();
		return;
	}

	/**
	 * The timer (Timer G or TimerH) in COMPLETED state is expired.
	 * 
	 */
	private void fireCOMPLETEDState() {
		if (this.tStamp >= this.tExpire || this.isReliable == true
				|| this.nTransmit >= this.maxTransmit) {
			/*
			 * Timer H was fired. Move to TERMINATED state.
			 */
			moveToTERMINATEDState();
			return;
		}

		/*
		 * Timer G was expired. Re-transmit request message.
		 */
		this.nTransmit++;

		// Update Timer
		long intval = this.timerG;
		for (int i = 0; i < this.maxTransmit; i++) {
			intval *= 2;
		}

		if (intval > this.timerT2) {
			intval = this.timerT2;
		}

		this.tStamp = System.currentTimeMillis() + intval;
	}

	/**
	 * The timer (Timer I) in CONFIRMED state is expired. Move to TERMINATE
	 * state.
	 * 
	 */
	private void fireCONFIRMEDState() {
		moveToTERMINATEDState();
	}

	/**
	 * SIProp hack. The timer (Timer D) in TERMINATED state is expired. Move to
	 * DELETE state. This behavior is not defined in RFC3261.
	 * 
	 */
	private void fireTERMINATEDState() {
		moveToDELETEState();
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#onError()
	 */
	public void onError() {
		Logger.getGlobal().fine(
				null,
				"INVITE Server Transaction: Error Occured ["
						+ this.state.toString() + "]");
		switch (this.state) {
		case NONE:
			break;
		case PROCEEDING:
			onPROCEEDINGError();
			break;
		case COMPLETED:
			onCOMPLETEDError();
			break;
		case CONFIRMED:
			break;
		case TERMINATED:
			break;
		default:
			break;
		}
	}

	/**
	 * An error is happened. Inform it to TU and move to TERMINATED state.
	 * 
	 */
	private void onPROCEEDINGError() {
		// TODO Inform an error to TU and send log message
		moveToTERMINATEDState();
	}

	/**
	 * An error is happend. Inform it to TU and move to TERMINATED state.
	 * 
	 */
	private void onCOMPLETEDError() {
		// TODO Inform an error to TU and send log message
		moveToTERMINATEDState();
	}

	/**
	 * Change to PROCEEDING state and set Timer B
	 * 
	 */
	private void moveToPROCEEDINGState() {
		this.state = TransactionState.PROCEEDING;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getB();
		Logger.getGlobal().fine(
				null,
				"INVITE Server Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * Change to COMPLATED state and Timer G
	 * 
	 */
	private void moveToCOMPLETEDState() {
		this.state = TransactionState.COMPLETED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getG();
		Logger.getGlobal().fine(
				null,
				"INVITE Server Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * Change to COMFIRMED state and set Timer I
	 * 
	 */
	private void moveToCONFIRMEDState() {
		this.state = TransactionState.CONFIRMED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getI();
		Logger.getGlobal().fine(
				null,
				"INVITE Server Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * SIProp hack. Change to TERMINATED state and set Timer D This behavior is
	 * not defined in RFC3261.
	 * 
	 */
	private void moveToTERMINATEDState() {
		this.state = TransactionState.TERMINATED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getD();
		Logger.getGlobal().fine(
				null,
				"INVITE Server Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * SIProp hack. Change to DELETE state and reset timer. This state is not
	 * defined in RFC3261.
	 * 
	 */
	private void moveToDELETEState() {
		this.state = TransactionState.DELETE;
		this.tStamp = 0;
		Logger.getGlobal().fine(
				null,
				"INVITE Server Transaction: move to [" + this.state.toString()
						+ "]");
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#isTimerExpired(long)
	 */
	public boolean isTimerExpired(long currentTime) {
		if (this.tStamp == 0) {
			// There is no timer running.
			return false;
		} else if (currentTime >= this.tStamp) {
			// The Timer was expired.
			return true;
		} else {
			// Stay this state.
			return false;
		}
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionState()
	 */
	public TransactionState getTransactionState() {
		return this.state;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionType()
	 */
	public TransactionType getTransactionType() {
		return this.type;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getParentTransaction()
	 */
	public TransactionController getParentTransaction() {
		return this.parentTransaction;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionInfo()
	 */
	public TransactionInfo getTransactionInfo() {
		return this.transactionInfo;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#setTransactionInfo(org.siprop.v2.stack.sip.transaction.TransactionInfo)
	 */
	public void setTransactionInfo(TransactionInfo transactionInfo) {
		this.transactionInfo = transactionInfo;
	}

}
