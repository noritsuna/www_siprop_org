/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.sip.transaction.SIPTimer;
import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.TransactionInfo;
import org.siprop.v2.stack.sip.transaction.TransactionState;
import org.siprop.v2.stack.sip.transaction.TransactionType;
import org.siprop.v2.util.impl.Logger;

/**
 * The state machine for Non-INVITE Server Transaction<BR>
 * According to RFC3261 Firgure 8: non-INVITE server transaction
 * 
 * <PRE>
 *                                |Request received
 *                                |pass to TU
 *                                V
 *                          +-----------+
 *                          |           |
 *                          | Trying    |-------------+
 *                          |           |             |
 *                          +-----------+             |200-699 from TU
 *                                |                   |send response
 *                                |1xx from TU        |
 *                                |send response      |
 *                                |                   |
 *             Request            V      1xx from TU  |
 *             send response+-----------+send response|
 *                 +--------|           |--------+    |
 *                 |        | Proceeding|        |    |
 *                 +-------&gt;|           |&lt;-------+    |
 *          +&lt;--------------|           |             |
 *          |Trnsprt Err    +-----------+             |
 *          |Inform TU            |                   |
 *          |                     |                   |
 *          |                     |200-699 from TU    |
 *          |                     |send response      |
 *          |  Request            V                   |
 *          |  send response+-----------+             |
 *          |      +--------|           |             |
 *          |      |        | Completed |&lt;------------+
 *          |      +-------&gt;|           |
 *          +&lt;--------------|           |
 *          |Trnsprt Err    +-----------+
 *          |Inform TU            |
 *          |                     |Timer J fires
 *          |                     |-
 *          |                     |
 *          |                     V
 *          |               +-----------+
 *          |               |           |
 *          +--------------&gt;| Terminated|
 *                          |           |
 *                          +-----------+
 * </PRE>
 * 
 * @author masaxmasa
 * 
 */
public class NonInviteServerTransaction implements TransactionEntry {

	/**
	 * state of this transaction
	 */
	private TransactionState state = null;

	/**
	 * Next expire time, if timer is running. 0 means that there is no timer in
	 * current state.
	 */
	private long tStamp = 0;

	/**
	 * Is reliable transport or not.
	 */
	private boolean isReliable = false;

	/**
	 * Type of transaction
	 */
	private final TransactionType type = TransactionType.TRANSACTIONTYPE_NONINV_UAS;

	/**
	 * parent Transaction object of this entry
	 */
	private TransactionController parentTransaction = null;

	/**
	 * TransactionInfo.
	 */
	private TransactionInfo transactionInfo = null;


	/**
	 * Constructor. Set Initial Transaction State
	 * 
	 * @param isReliable
	 *            Using reliable transport or not.
	 */
	public NonInviteServerTransaction(TransactionController parent, boolean isReliable) {
		// set Initial State
		this.state = TransactionState.NONE;
		this.tStamp = 0;
		this.isReliable = isReliable;
		this.parentTransaction = parent;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#doProcess(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void doProcess(MessageContext msg) {
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: [" + this.state.toString()
						+ "]");

		switch (this.state) {
		case NONE:
			onNONEState(msg);
			break;
		case TRYING:
			onTRYINGState(msg);
			break;
		case PROCEEDING:
			onPROCEEDINGState(msg);
			break;
		case COMPLETED:
			onCOMPLETEDState(msg);
			break;
		case TERMINATED:
			// do nothing
			break;
		default:
			/*
			 * Invalid transaction state
			 */
			moveToTERMINATEDState();
			break;
		}
	}

	/**
	 * Initial state. Move to TRYING state
	 * 
	 * @param msg
	 */
	private void onNONEState(MessageContext msg) {
		/*
		 * Check INVITE request message or not.
		 */
		if ((msg.getCurrentMessageContextPacket().getFlatMessage().getMessage() instanceof SIPRequest) == false) {
			/*
			 * This message is not SIP request message.
			 */
			moveToDELETEState();
			return;
		}

		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		if (SIPRequest.INVITE.equals(sipReq.getMethod()) == false) {
			/*
			 * This message is not INVITE request message.
			 */
			moveToDELETEState();
			return;
		} else if (SIPRequest.INVITE.equals(sipReq.getMethod()) == false) {
			/*
			 * SIProp hack The transaction doesn't handle ACK Request message.
			 */
			moveToDELETEState();
			return;
		}

		/*
		 * Store parameters
		 */
		if(this.getTransactionInfo() == null) {
			this.setTransactionInfo(new TransactionInfoImpl(msg));
		}

		// To tag
		this.getTransactionInfo().setTagTo(sipReq.getToTag());

		moveToTRYINGState();
		this.getTransactionInfo().setOriginalMessage(msg);
	}

	/**
	 * The process in TRYING state.
	 * 
	 * @param msg
	 */
	private void onTRYINGState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();

		if (sipMsg instanceof SIPResponse) {
			/*
			 * SIP response message
			 */
			SIPResponse sipRsp = (SIPResponse) sipMsg;

			switch (sipRsp.getStatusCode() / 100) {
			case 0:
				/*
				 * XXX invalid response message was sent. ignore it.
				 */
				break;
			case 1:
				/*
				 * 1XX response was sent. Move to PROCEEDING state.
				 */
				moveToPROCEEDINGState();
				break;
			default:
				/*
				 * 2XX-6XX response was sent. Move to COMPLETED state.
				 */
				moveToCOMPLETEDState();
				break;
			}
		} else {
			/*
			 * SIP request message.
			 */
			moveToTERMINATEDState();
		}
	}

	/**
	 * The process in PROCEEDING state. TODO error handling
	 * 
	 * @param msg
	 */
	private void onPROCEEDINGState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();

		if (sipMsg instanceof SIPResponse) {
			/*
			 * SIP response message
			 */
			SIPResponse sipRsp = (SIPResponse) msg
					.getCurrentMessageContextPacket().getFlatMessage()
					.getMessage();
			switch (sipRsp.getStatusCode() / 100) {
			case 0:
				/*
				 * invalid response message was sent. ignore it.
				 */
				break;
			case 1:
				/*
				 * 1XX response was sent Stay in PROCEEDING state.
				 */
				break;
			default:
				/*
				 * 2XX-6XX response was sent Move to COMPLETED state.
				 */
				moveToCOMPLETEDState();
				break;
			}
		} else {
			/*
			 * Re-transmitted request message was received. Stay in PROCEEDING
			 * state.
			 */

			// TODO send response
		}
	}

	/**
	 * The process in COMPLETED state. TODO error handling
	 * 
	 * @param msg
	 */
	private void onCOMPLETEDState(MessageContext msg) {

	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#fireTimer()
	 */
	public void fireTimer() {
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: Timer Expired ["
						+ this.state.toString() + "]");

		switch (this.state) {
		case NONE:
			break;
		case TRYING:
			/*
			 * SIProp hack
			 */
			fireTRYINGState();
			break;
		case PROCEEDING:
			/*
			 * SIProp hack
			 */
			firePROCEEDINGState();
			break;
		case COMPLETED:
			fireCOMPLETEDState();
			break;
		case TERMINATED:
			/*
			 * SIProp hack
			 */
			fireTERMINATEDState();
			break;
		default:
			break;
		}

	}

	/**
	 * SIProp hack. The timer (Timer F) in TRYING state is expired. Move to
	 * TERMINATED state. This behavior is not defined in RFC3261.
	 * 
	 */
	private void fireTRYINGState() {
		moveToTERMINATEDState();
	}

	/**
	 * SIProp hack. The timer (Timer F) in PROCEEDING state is expired. Move to
	 * TERMINATED state. This behavior is not defined in RFC3261.
	 * 
	 */
	private void firePROCEEDINGState() {
		moveToTERMINATEDState();
	}

	/**
	 * The timer (Timer J) in COMPLETED state is expired Move to TERMINATED
	 * state.
	 * 
	 */
	private void fireCOMPLETEDState() {
		moveToTERMINATEDState();
	}

	/**
	 * SIProp hack. The timer (Timer D) in TERMINATED state is expired. Move to
	 * DELETE state. This behaivor is not defined in RFC3261.
	 * 
	 */
	private void fireTERMINATEDState() {
		moveToDELETEState();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#onError()
	 */
	public void onError() {
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: Error Occured ["
						+ this.state.toString() + "]");

		switch (this.state) {
		case NONE:
			break;
		case TRYING:
			break;
		case PROCEEDING:
			onPROCEEDINGError();
			break;
		case COMPLETED:
			onCOMPLETEDError();
			break;
		case TERMINATED:
			break;
		default:
			break;
		}
	}

	/**
	 * An error is happened. Inform it to TU and move to TERMINATED state
	 * 
	 */
	private void onPROCEEDINGError() {
		// Inform an error to TU and send log message
		moveToTERMINATEDState();
	}

	/**
	 * An error is happened. Inform it to TU and move to TERMINATED state
	 * 
	 */
	private void onCOMPLETEDError() {
		// Inform an error to TU and send log message
		moveToTERMINATEDState();
	}

	/**
	 * SIProp hack. Change to TRYING state and set Timer F. This behaivor is not
	 * defined in RFC3261.
	 * 
	 */
	private void moveToTRYINGState() {
		this.state = TransactionState.TRYING;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getF();
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * SIProp hack. Change to PROCEEDING state and set Timer F. This behaivor is
	 * not defined in RFC3261.
	 * 
	 */
	private void moveToPROCEEDINGState() {
		this.state = TransactionState.PROCEEDING;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getF();
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * Change to COMPLETED state and set Timer J.
	 * 
	 */
	private void moveToCOMPLETEDState() {
		this.state = TransactionState.COMPLETED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getJ();
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * SIProp hack. Change to TERMINATED state and set Timer D. This behaivor is
	 * not defined in RFC3261.
	 * 
	 */
	private void moveToTERMINATEDState() {
		this.state = TransactionState.TERMINATED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getD();
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * SIProp hack. Change to DELETE state and reset a timer. This state is not
	 * defined in RFC3261.
	 * 
	 */
	private void moveToDELETEState() {
		this.state = TransactionState.DELETE;
		this.tStamp = 0;
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Server Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#isTimerExpired(long)
	 */
	public boolean isTimerExpired(long currentTime) {
		if (this.tStamp == 0) {
			// There is no timer running.
			return false;
		} else if (currentTime >= this.tStamp) {
			// The Timer was expired.
			return true;
		} else {
			// Stay this state.
			return false;
		}
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionState()
	 */
	public TransactionState getTransactionState() {
		return this.state;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionType()
	 */
	public TransactionType getTransactionType() {
		return this.type;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getParentTransaction()
	 */
	public TransactionController getParentTransaction() {
		return this.parentTransaction;
	}
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionInfo()
	 */
	public TransactionInfo getTransactionInfo() {
		return this.transactionInfo;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#setTransactionInfo(org.siprop.v2.stack.sip.transaction.TransactionInfo)
	 */
	public void setTransactionInfo(TransactionInfo transactionInfo) {
		this.transactionInfo = transactionInfo;
	}


}
