/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.impl;

import org.siprop.v2.core.messge.impl.DefaultControlMessage;
import org.siprop.v2.ua.UAControlMessage;
import org.siprop.v2.ua.util.impl.CommandName;

/**
 * ControlMessage for standard UA.
 * 
 * @author noritsuna
 * 
 */
public class UAControlMessageImpl extends DefaultControlMessage implements UAControlMessage {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = -7824350935503702928L;

	/**
	 * execMethodName
	 */
	private CommandName execCommandName = null;

	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAControlMessage#getExecMethod()
	 */
	public CommandName getExecMethod() {
		return execCommandName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAControlMessage#setExecMethod(org.siprop.v2.ua.impl.CommandName)
	 */
	public void setExecMethod(CommandName commandName) {
		this.execCommandName = commandName;
	}

}
