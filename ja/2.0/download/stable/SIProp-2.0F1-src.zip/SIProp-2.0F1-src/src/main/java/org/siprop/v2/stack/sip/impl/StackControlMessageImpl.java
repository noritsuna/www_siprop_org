/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.impl;

import org.siprop.v2.core.messge.impl.DefaultControlMessage;
import org.siprop.v2.stack.StackControlMessage;

/**
 * A control message for SIProp stack.
 * 
 * @author masaxmasa
 * 
 */
public class StackControlMessageImpl extends DefaultControlMessage implements StackControlMessage {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = 9003529158559024412L;

	/**
	 * UAC flag.
	 */
	private boolean isUAC;

	/**
	 * constructor
	 * 
	 */
	public StackControlMessageImpl() {
		this.isUAC = false;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.StackControlMessage#setIsUAC(boolean)
	 */
	public void setIsUAC(boolean uac) {
		this.isUAC = uac;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.StackControlMessage#getIsUAC()
	 */
	public boolean getIsUAC() {
		return this.isUAC;
	}

}
