/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction;

/**
 * This enum indicates status of SIP transaction.
 * 
 * @author masaxmasa
 * 
 */
public enum TransactionState {
	NONE, // no statement. This state is not defined in RFC
	TRYING, // Trying state
	CALLING, // Calling state
	PROCEEDING, // Proceeding state
	COMPLETED, // Completed state
	CONFIRMED, // Confirmed state
	TERMINATED, // Terminated state
	DELETE, // to be deleted. This state is not defined in RFC.
}
