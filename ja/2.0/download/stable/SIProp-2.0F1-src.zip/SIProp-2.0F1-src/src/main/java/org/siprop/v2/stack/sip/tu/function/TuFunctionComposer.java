/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu.function;

import java.util.LinkedList;
import java.util.List;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;

/**
 * Composer for TuFunction.
 * 
 * @author noritsuna
 * 
 */
public class TuFunctionComposer implements TuFunction {

	/**
	 * list of function.
	 */
	private List<TuFunction> functions = new LinkedList<TuFunction>();

	
	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#doProcess(org.siprop.v2.core.messge.impl.MessageContext, org.siprop.v2.stack.sip.transaction.TransactionEntry)
	 */
	public MessageContext doProcess(MessageContext msg, TransactionEntry trnsct) {
		MessageContext rspMsg = null;

		for (TuFunction function : functions) {
			rspMsg = function.doProcess(msg, trnsct);
			if (rspMsg != null) {
				return rspMsg;
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#addFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void addFunction(TuFunction function) throws SIPropException {
		if (function == null) {
			throw new NullPointerException();
		}
		this.functions.add(function);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#removeFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void removeFunction(TuFunction function) throws SIPropException {
		this.functions.remove(function);
	}

}
