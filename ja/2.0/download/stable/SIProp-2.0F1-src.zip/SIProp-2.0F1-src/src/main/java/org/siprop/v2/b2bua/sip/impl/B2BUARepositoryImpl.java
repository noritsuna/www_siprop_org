/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip.impl;

import java.util.ArrayList;
import java.util.List;

import org.siprop.v2.b2bua.B2BUAManager;
import org.siprop.v2.b2bua.sip.module.impl.AsteriskB2BUA;
import org.siprop.v2.b2bua.sip.util.impl.B2BUAModuleDiscriminator;
import org.siprop.v2.core.Manager;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.core.router.impl.LayerEnum;
import org.siprop.v2.core.router.impl.MessageRouteKey;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.core.router.impl.MessageRouterInfo;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

/**
 * Repository for B2BUA.
 * 
 * @author noritsuna
 * 
 */
public class B2BUARepositoryImpl implements Repository {

	/**
	 * PropertiesDepot.
	 */
	private PropertiesDepot prop = null;

	/**
	 * Manager.
	 */
	private Manager manager = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.repository.Repository#setup(org.siprop.v2.util.PropertiesDepot)
	 */
	public void setup(PropertiesDepot prop) {
		this.prop = prop;

		// Init B2BUA.
		B2BUAManager b2buaManager = B2BUAManagerImpl.getInstance();
		this.manager = b2buaManager;

		// set UniKey Discriminator.
		this.manager.setUniKeyGenerator(new B2BUAModuleDiscriminator());

		// set ControlMessageName.
		this.manager.setControlMessageName("B2BUAControlMessageImpl");

		// set LayerRoutingResolver.
		this.manager.setLayerResolver(LayerRoutingResolver.getInstance());

		// set service name.
		b2buaManager.setServiceName("sip");

		// set b2bua module.
		List<String> moduleList = new ArrayList<String>();
		moduleList.add(AsteriskB2BUA.MODULE_NAME);
		b2buaManager.createModuleList(moduleList);

		// set router.
		RouteKey key = new MessageRouteKey();
		key.setRouteid("B2BUAManager");
		key.setRoutetype(LayerEnum.B2BUA);

		RouterInfo routerInfo = new MessageRouterInfo();
		routerInfo.setRouteKey(key);
		routerInfo.addListener(manager);

		MessageRouter.getInstance().addRoute(routerInfo);

		this.manager.setRouteKey(key);
		this.manager.setRouter(MessageRouter.getInstance());

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.repository.Repository#getManager()
	 */
	public Manager getManager() {
		return this.manager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.repository.Repository#getRepository(org.siprop.v2.core.repository.RepositoryKey)
	 */
	public Repository getRepository(RepositoryKey key) {
		return this;
	}

}
