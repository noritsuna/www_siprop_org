/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua;

import org.siprop.v2.core.messge.Info;
import org.siprop.v2.core.messge.impl.MessageContextPacket;

/**
 * This interface holds the packet about a B2BUA.
 * 
 * @author noritsuna
 * 
 */
public interface B2BUAInfo extends Info {
	
	/**
	 * set new MessageContextPacket.
	 * 
	 * @param newMessageContextPacket
	 *            new MessageContextPacket.
	 */
	public void setNewMessageContextPacket(
			MessageContextPacket newMessageContextPacket);

	/**
	 * get MessageContextPacket of previous.
	 * 
	 * @return MessageContextPacket of previous.
	 */
	public MessageContextPacket getPreviousMessageContextPacket();

	/**
	 * get MessageContextPacket of current.
	 * 
	 * @return MessageContextPacket of current.
	 */
	public MessageContextPacket getCurrentMessageContextPacket();

}
