/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction;

/**
 * This class has values of SIP Timers Accroding to RFC3261 Appendix A Timer
 * Value Meaning
 * ---------------------------------------------------------------------- T1
 * 500ms default RTT Estimate T2 4s The maximum retransmit interval for
 * non-INVITE requests and INVITE responses T4 5s Maximum duration a message
 * will remain in the network Timer A initially T1 INVITE request retransmit
 * interval, for UDP only Timer B 64*T1 INVITE transaction timeout timer Timer C >
 * 3min proxy INVITE transaction timeout Timer D > 32s for UDP Wait time for
 * response retransmits 0s for TCP/SCTP Timer E initially T1 non-INVITE request
 * retransmit interval, UDP only Timer F 64*T1 non-INVITE transaction timeout
 * timer Timer G initially T1 INVITE response retransmit interval Timer H 64*T1
 * Wait time for ACK receipt Timer I T4 for UDP Wait time for ACK retransmits 0s
 * for TCP/SCTP Timer J 64*T1 for UDP Wait time for non-INVITE request
 * retransmits 0s for TCP/SCTP Timer K T4 for UDP Wait time for response
 * retransmits 0s for TCP/SCTP
 * 
 * @author masaxmasa
 * 
 */
public class SIPTimer {

	/**
	 * Timer T1
	 */
	static private long T1 = 500;

	/**
	 * Timer T2
	 */
	static private long T2 = 4000;

	/**
	 * Timer T4
	 */
	static private long T4 = 5000;

	/**
	 * Timer A
	 */
	static private long A = T1;

	/**
	 * Timer B
	 */
	static private long B = T1 * 64;

	/**
	 * Timer C
	 */
	static private long C = 180000;

	/**
	 * Timer D
	 */
	static private long D = 32000;

	/**
	 * Timer E
	 */
	static private long E = T1;

	/**
	 * Timer F
	 */
	static private long F = T1 * 64;

	/**
	 * Timer G
	 */
	static private long G = T1;

	/**
	 * Timer H
	 */
	static private long H = T1 * 64;

	/**
	 * Timer I
	 */
	static private long I = T4;

	/**
	 * Timer J
	 */
	static private long J = T1 * 64;

	/**
	 * Timer K
	 */
	static private long K = T4;

	/**
	 * get Timer A
	 * 
	 * @return Timer A
	 */
	public static long getA() {
		return A;
	}

	/**
	 * get Timer B
	 * 
	 * @return Timer B
	 */
	public static long getB() {
		return B;
	}

	/**
	 * get Timer C
	 * 
	 * @return Timer C
	 */
	public static long getC() {
		return C;
	}

	/**
	 * get Timer D
	 * 
	 * @return Timer D
	 */
	public static long getD() {
		return D;
	}

	/**
	 * get Timer E
	 * 
	 * @return Timer E
	 */
	public static long getE() {
		return E;
	}

	/**
	 * get Timer F
	 * 
	 * @return Timer F
	 */
	public static long getF() {
		return F;
	}

	/**
	 * get Timer G
	 * 
	 * @return Timer G
	 */
	public static long getG() {
		return G;
	}

	/**
	 * get Timer H
	 * 
	 * @return Timer H
	 */
	public static long getH() {
		return H;
	}

	/**
	 * get Timer I
	 * 
	 * @return Timer I
	 */
	public static long getI() {
		return I;
	}

	/**
	 * get Timer J
	 * 
	 * @return Timer J
	 */
	public static long getJ() {
		return J;
	}

	/**
	 * get Timer K
	 * 
	 * @return Timer K
	 */
	public static long getK() {
		return K;
	}

	/**
	 * get Timer T1
	 * 
	 * @return Timer T1
	 */
	public static long getT1() {
		return T1;
	}

	/**
	 * get Timer T2
	 * 
	 * @return Timer T2
	 */
	public static long getT2() {
		return T2;
	}

	/**
	 * get Timer T4
	 * 
	 * @return Timer T4
	 */
	public static long getT4() {
		return T4;
	}

	/**
	 * set Timer A
	 * 
	 * @param a
	 *            Timer A
	 */
	public static void setA(long a) {
		A = a;
	}

	/**
	 * set Timer B
	 * 
	 * @param b
	 *            Timer B
	 */
	public static void setB(long b) {
		B = b;
	}

	/**
	 * set Timer C
	 * 
	 * @param c
	 *            Timer C
	 */
	public static void setC(long c) {
		C = c;
	}

	/**
	 * set Timer D
	 * 
	 * @param d
	 *            Timer D
	 */
	public static void setD(long d) {
		D = d;
	}

	/**
	 * set Timer E
	 * 
	 * @param e
	 *            Timer E
	 */
	public static void setE(long e) {
		E = e;
	}

	/**
	 * set Timer F
	 * 
	 * @param f
	 *            Timer F
	 */
	public static void setF(long f) {
		F = f;
	}

	/**
	 * set Timer G
	 * 
	 * @param g
	 *            Timer G
	 */
	public static void setG(long g) {
		G = g;
	}

	/**
	 * set Timer H
	 * 
	 * @param h
	 *            Timer H
	 */
	public static void setH(long h) {
		H = h;
	}

	/**
	 * set Timer I
	 * 
	 * @param i
	 *            Timer I
	 */
	public static void setI(long i) {
		I = i;
	}

	/**
	 * set TImer J
	 * 
	 * @param j
	 *            Timer J
	 */
	public static void setJ(long j) {
		J = j;
	}

	/**
	 * set Timer K
	 * 
	 * @param k
	 *            Timer K
	 */
	public static void setK(long k) {
		K = k;
	}

	/**
	 * set Timer T1<BR>
	 * Re-calculate timers related T1
	 * 
	 * @param t1
	 *            Timer T1
	 */
	public static void setT1(long t1) {
		T1 = t1;

		setA(T1);
		setB(T1 * 64);
		setE(T1);
		setF(T1 * 64);
		setG(T1);
		setJ(T1 * 64);
	}

	/**
	 * set Timer T2
	 * 
	 * @param t2
	 */
	public static void setT2(long t2) {
		T2 = t2;
	}

	/**
	 * set Timer T4<BR>
	 * Re-calculate timers related T4
	 * 
	 * @param t4
	 */
	public static void setT4(long t4) {
		T4 = t4;

		setK(T4);
		setI(T4);
	}

}
