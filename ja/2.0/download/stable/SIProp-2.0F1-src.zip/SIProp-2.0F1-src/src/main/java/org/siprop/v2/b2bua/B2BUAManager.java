/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua;

import java.util.List;

import org.siprop.v2.core.Manager;
import org.siprop.v2.core.messge.impl.MessageContext;

/**
 * Manager interface for B2BUA.
 * 
 * @author noritsuna
 * 
 */
public interface B2BUAManager extends Manager {

	/**
	 * get service name.
	 * 
	 * @return service name.
	 */
	public String getServiceName();
	
	/**
	 * set service name.
	 * 
	 * @param serviceName
	 *            service name.
	 */
	public void setServiceName(String serviceName);
	
	/**
	 * create B2BUAModule.
	 * 
	 * @param doModuleName
	 * @return created B2BUAModule
	 */
	public B2BUAModule createB2BUAModule(String doModuleName);
	
	/**
	 * create B2BUAModule list.
	 * 
	 * @param moduleList
	 */
	public void createModuleList(List<String> moduleList);
	
	/**
	 * Delete to save B2BUAModule.
	 * 
	 * @param messageContext
	 */
	public void deleteB2BUAModule(MessageContext messageContext);

	/**
	 * Delete to save B2BUAModule.
	 * 
	 * @param key
	 *            B2BUAModule key
	 */
	public void deleteB2BUAModule(String key);

	/**
	 * Get B2BUAModule.
	 * 
	 * @param messageContext
	 * @return B2BUAModule
	 */
	public B2BUAModule getB2BUAModule(MessageContext messageContext);

	/**
	 * Get B2BUAModule.
	 * 
	 * @param key
	 *            B2BUAModule key
	 * @return B2BUAModule
	 */
	public B2BUAModule getB2BUAModule(String key);

	/**
	 * Add B2BUAModule.
	 * 
	 * @param messageContext
	 * @param b2bua
	 */
	public void addB2UAModule(MessageContext messageContext, B2BUAModule b2bua);

}
