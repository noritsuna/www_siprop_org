/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.resolver.impl;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.messge.impl.MessageContextPacket;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.core.router.impl.MessageRouterControlMessage;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.util.resolver.Resolver;
import org.siprop.v2.util.resolver.ResolverKey;

/**
 * Returned to layer param.
 * 
 * @author noritsuna
 * 
 */
public class LayerRoutingResolver implements Resolver {

	/**
	 * instance.
	 */
	private static LayerRoutingResolver INSTANCE = null;

	/**
	 * Constructor.
	 * 
	 */
	private LayerRoutingResolver() {
	};

	/**
	 * get informations for message routing
	 */
	public ResolverKey resolve(MessageContext message) {
		MessageRouterControlMessage rtrCtrlMsg = (MessageRouterControlMessage) message
				.getCurrentMessageContextPacket().getControlMessage(
						MessageRouter.CONTROLMESSAGE_BASENAME);
		if (rtrCtrlMsg == null) {
			return null;
		}

		return rtrCtrlMsg.getSendToKey();
	}

	/**
	 * set a routing information for specified a SIP message
	 * 
	 * @param message
	 *            a SIP message
	 * @param key
	 *            a routing key for SIP message
	 */
	public void setKey(MessageContextPacket message, SendToKey key) {
		MessageRouterControlMessage rtrCtrlMsg = (MessageRouterControlMessage) message
				.getControlMessage(MessageRouter.CONTROLMESSAGE_BASENAME);
		if (rtrCtrlMsg == null) {
			rtrCtrlMsg = new MessageRouterControlMessage();
			message.addControlMessage(MessageRouter.CONTROLMESSAGE_BASENAME,
					rtrCtrlMsg);
		}

		rtrCtrlMsg.setSendToKey(key);
	}

	/**
	 * get instance.
	 * 
	 * @return this instance
	 */
	public static LayerRoutingResolver getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new LayerRoutingResolver();
		}
		return INSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.resolver.Resolver#setResolverKey(org.siprop.v2.util.resolver.ResolverKey)
	 */
	public void setResolverKey(ResolverKey resolverKey) {

		
	}

}
