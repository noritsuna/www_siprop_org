/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.codec.impl;

import java.util.Set;

import javax.sip.message.Message;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;
import org.apache.mina.filter.codec.demux.MessageEncoder;

/**
 * SipMessageEncoder Encode Message and send to session IO.
 * used by mina.
 * 
 * @author nisato
 * 
 */
public class SipMessageEncoder implements MessageEncoder {


	/* (non-Javadoc)
	 * @see org.apache.mina.filter.codec.demux.MessageEncoder#encode(org.apache.mina.common.IoSession, java.lang.Object, org.apache.mina.filter.codec.ProtocolEncoderOutput)
	 */
	public void encode(IoSession session, Object message,
			ProtocolEncoderOutput out) throws Exception {
		// 
		Message msg = (Message) message;
		ByteBuffer buf = ByteBuffer.allocate(256);
		buf.setAutoExpand(true);
		buf.put(msg.getRawContent());
		out.write(buf);
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.filter.codec.demux.MessageEncoder#getMessageTypes()
	 */
	public Set getMessageTypes() {
		// TODO: ここで、INVITE, ACK, BYE, MESSAGE, CANCEL, SUBSCRIBE, REGIST,
		// NOTIFY...etc
		// のメッセージ形式を解析した方が良いかな(まぁとりあえずいいか)
		return null;
	}

}
