/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.resolver.impl;

import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.ResolverKey;

/**
 * ResolverKey for Peer.
 * 
 * @author noritsuna
 *
 */
public class PeerKey implements ResolverKey {

	/**
	 * resolverKey.
	 */
	private Peer resolveKey = null;

	/**
	 * Constructor.
	 * 
	 * @param peer
	 */
	public PeerKey(Peer peer) {
		this.resolveKey = peer;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.resolver.ResolverKey#getRoutingKey()
	 */
	public Object getRoutingKey() {
		return this.resolveKey;
	}

}
