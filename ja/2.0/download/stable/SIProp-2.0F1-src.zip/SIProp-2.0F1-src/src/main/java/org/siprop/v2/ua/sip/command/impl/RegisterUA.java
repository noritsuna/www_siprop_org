/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.command.impl;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.ua.UACommand;
import org.siprop.v2.ua.UAContext;
import org.siprop.v2.util.impl.Logger;

/**
 * UACommand of Register.
 * 
 * @author noritsuna
 * 
 */
public class RegisterUA implements UACommand {

	/**
	 * UACommand name.
	 */
	public static final String UA_COMMAND_NAME = "Register";

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.ua.UACommand#getUACommandName()
	 */
	public String getUACommandName() {
		return UA_COMMAND_NAME;
	}

	/**
	 * Initial command.
	 * 
	 * @param messageContext
	 * @param uaInfo
	 */
	public void do_Register_init(MessageContext messageContext, UAContext uaInfo) {
		Logger.getGlobal().fine(messageContext, "exec do_initRegister.");
	}

	/**
	 * send REGISTER message.
	 * 
	 * @param messageContext
	 * @param uaInfo
	 */
	public void do_Register_send(MessageContext messageContext, UAContext uaInfo) {
		Logger.getGlobal().fine(messageContext, "exec do_sendRegister.");
	}

	/**
	 * Receive 401 Response and processing.
	 * 
	 * @param messageContext
	 * @param uaInfo
	 */
	public void do_Register_receive401(MessageContext messageContext,
			UAContext uaInfo) {
		Logger.getGlobal().fine(messageContext, "exec do_receive401.");

	}

	/**
	 * send REGISTER message with Auth.
	 * 
	 * @param messageContext
	 * @param uaInfo
	 */
	public void do_Register_sendWithAuth(MessageContext messageContext,
			UAContext uaInfo) {
		Logger.getGlobal()
				.fine(messageContext, "exec do_sendRegisterWithAuth.");

	}

	/**
	 * Receive 200 Response and processing.
	 * 
	 * @param messageContext
	 * @param uaInfo
	 */
	public void do_Register_receive200(MessageContext messageContext,
			UAContext uaInfo) {
		Logger.getGlobal().fine(messageContext, "exec do_receive200.");

	}

	/**
	 * send UnREGISTER message with Auth.
	 * 
	 * @param messageContext
	 * @param uaInfo
	 */
	public void do_Register_sendUnRegister(MessageContext messageContext,
			UAContext uaInfo) {
		Logger.getGlobal().fine(messageContext, "exec do_sendUnRegister.");

	}

}
