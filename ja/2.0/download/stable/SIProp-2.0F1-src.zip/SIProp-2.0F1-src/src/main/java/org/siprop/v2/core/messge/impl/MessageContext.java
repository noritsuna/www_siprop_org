/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge.impl;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.util.impl.Peer;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * This class is Context used for routing.
 * 
 * @author noritsuna
 * 
 */
public class MessageContext implements Context {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = 486093981903719657L;

	/**
	 * Current MessageContextPacket.
	 */
	protected MessageContextPacket currentMessageContextPacket = null;

	/**
	 * MessageContextInfo.
	 */
	protected MessageContextInfo messageContextInfo = null;

	/**
	 * Constructor
	 * 
	 */
	private MessageContext() {
	}

	/**
	 * create new MessageContext.
	 * 
	 * @return new MessageContext
	 */
	public static MessageContext createMessageContext() {
		return createMessageContext(null);
	}

	/**
	 * create new new MessageContext. <BR>
	 * However, MessageContextPacket copies.
	 * 
	 * @param orignalPacket
	 *            MessageContextPacket for a copy
	 * @return Copied MessageContextPacket
	 */
	public static MessageContext createMessageContext(
			MessageContextPacket orignalPacket) {
		MessageContext mc = new MessageContext();
		mc.messageContextInfo = new MessageContextInfo();
		mc.messageContextInfo.setOriginalMessageContextPacket(orignalPacket);

		return mc;
	}

	/**
	 * copy MessageContext.
	 * 
	 * @param me
	 *            MessageContextPacket for a copy
	 * @return Copied MessageContext
	 */
	public static MessageContext copyMessageContext(MessageContext me) {
		MessageContext mc = new MessageContext();
		mc.setMessageContextInfo(me.getMessageContextInfo());

		return mc;
	}

	/**
	 * clone MessageContext.
	 * 
	 * @param me
	 *            MessageContext for a clone
	 * @return Cloned MessageContext
	 */
	public static MessageContext cloneMessageContext(MessageContext me) {
		throw new NotImplementedException();
	}

	/**
	 * set MessageContextPacket. set for this.currentMessageContextPacket &
	 * MessageContextInfo.addMessageContextPacket().
	 * 
	 * @param messageContextPacket
	 */
	public void setMessageContextPacket(
			MessageContextPacket messageContextPacket) {
		this.currentMessageContextPacket = messageContextPacket;
		this.messageContextInfo.addMessageContextPacket(messageContextPacket);
	}

	/**
	 * get current MessageContextPacket.
	 * 
	 * @return current MessageContextPacket
	 */
	public MessageContextPacket getCurrentMessageContextPacket() {
		return this.currentMessageContextPacket;
	}

	/**
	 * set current MessageContextPacket.
	 * 
	 * @param currentMessageContextPacket
	 *            MessageContextPacket
	 */
	public void setCurrentMessageContextPacket(
			MessageContextPacket currentMessageContextPacket) {
		this.currentMessageContextPacket = currentMessageContextPacket;
	}

	/**
	 * get MessageContextInfo.
	 * 
	 * @return MessageContextInfo
	 */
	public MessageContextInfo getMessageContextInfo() {
		return messageContextInfo;
	}

	/**
	 * set MessageContextInfo.
	 * 
	 * @param messageContextInfo
	 *            MessageContextInfo
	 */
	public void setMessageContextInfo(MessageContextInfo messageContextInfo) {
		this.messageContextInfo = messageContextInfo;
	}

	/**
	 * get a local address and port
	 * 
	 * @return local peer
	 */
	public Peer getLocalPeer() {
		if (this.currentMessageContextPacket == null) {
			return null;
		}
		return this.currentMessageContextPacket.getLocalPeer();
	}

	/**
	 * get a remote address and port
	 * 
	 * @return remote peer
	 */
	public Peer getRemotePeer() {
		if (this.currentMessageContextPacket == null) {
			return null;
		}
		return this.currentMessageContextPacket.getRemotePeer();
	}

	/**
	 * Are all the Packet(s) ending with transmitting or not?
	 * 
	 * @return end is true
	 */
	public boolean isPacketEnd() {
		return this.messageContextInfo.isPacketEnd();
	}
}
