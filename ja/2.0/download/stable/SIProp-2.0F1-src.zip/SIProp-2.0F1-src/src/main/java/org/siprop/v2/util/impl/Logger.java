/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.impl;

import javax.sip.message.Message;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.v2.core.messge.impl.MessageContext;

/**
 * Logger's rapper class.<BR>
 * 
 * @author noritsuna
 * 
 */
public class Logger {

	/**
	 * Logger instance.
	 */
	private static Logger instance = new Logger();

	/**
	 * Constructor.
	 * 
	 */
	private Logger() {
	}

	/**
	 * get global instance.
	 * 
	 * @return global instance
	 */
	static public Logger getGlobal() {
		return instance;
	}

	/**
	 * get Logger.
	 * 
	 * @return logger
	 */
	private java.util.logging.Logger getLogger() {
		/*
		 * Must use for Java6. return getLogger(Logger.GLOBAL_LOGGER_NAME);
		 */
		return java.util.logging.Logger.global;
	}

	/**
	 * Override method.
	 * 
	 * @param packet
	 * @param errorMessage
	 */
	public void severe(Object packet, String errorMessage) {
		getLogger().severe(defaultMessage(packet) + " " + errorMessage);
	}

	/**
	 * Override method.
	 * 
	 * @param packet
	 * @param errorMessage
	 */
	public void warning(Object packet, String errorMessage) {
		getLogger().warning(defaultMessage(packet) + " " + errorMessage);
	}

	/**
	 * Override method.
	 * 
	 * @param packet
	 * @param errorMessage
	 */
	public void info(Object packet, String errorMessage) {
		getLogger().info(defaultMessage(packet) + " " + errorMessage);
	}

	/**
	 * Override method.
	 * 
	 * @param packet
	 * @param errorMessage
	 */
	public void config(Object packet, String errorMessage) {
		getLogger().config(defaultMessage(packet) + " " + errorMessage);
	}

	/**
	 * Override method.
	 * 
	 * @param packet
	 * @param errorMessage
	 */
	public void fine(Object packet, String errorMessage) {
		getLogger().fine(defaultMessage(packet) + " " + errorMessage);
	}

	/**
	 * Override method.
	 * 
	 * @param packet
	 * @param errorMessage
	 */
	public void finer(Object packet, String errorMessage) {
		getLogger().finer(defaultMessage(packet) + " " + errorMessage);
	}

	/**
	 * Override method.
	 * 
	 * @param packet
	 * @param errorMessage
	 */
	public void finest(Object packet, String errorMessage) {
		getLogger().finest(defaultMessage(packet) + " " + errorMessage);
	}

	/**
	 * create default message.
	 * 
	 * @param packet
	 * @return created log message
	 */
	protected String defaultMessage(Message packet) {

		StringBuilder sb = new StringBuilder();
		sb.append(" ");
		if (packet instanceof SIPRequest) {
			sb.append(((SIPRequest) packet).getMethod() + " ");
		} else if (packet instanceof SIPResponse){
			// SIP Response Message
			sb.append(((SIPResponse) packet).getStatusCode() + "-"
					+ ((SIPResponse) packet).getCSeq().getMethod() + " ");

		}
		if(packet instanceof SIPMessage)
			sb.append("Call-ID:" + ((SIPMessage) packet).getCallId().getCallId());
		
		return sb.toString();

	}

	/**
	 * create default message.
	 * 
	 * @param packet
	 * @return created log message
	 */
	protected String defaultMessage(Object packet) {

		if (packet == null) {
			return "";
		}
		if (packet instanceof MessageContext) {

			MessageContext msgContext = (MessageContext) packet;
			if (msgContext.getCurrentMessageContextPacket() != null
					&& msgContext.getCurrentMessageContextPacket()
							.getFlatMessage() != null
					&& msgContext.getCurrentMessageContextPacket()
							.getFlatMessage().getMessage() != null) {

				if (msgContext.getCurrentMessageContextPacket()
						.getFlatMessage().getMessage() instanceof SIPMessage) {
					StringBuilder sb = new StringBuilder();
					Peer remotePeer = msgContext.getRemotePeer();
					if (remotePeer != null) {
						sb.append(remotePeer.getAddress().getHostAddress()
								+ "." + remotePeer.getPort());
					}
					sb.append(defaultMessage((SIPMessage) msgContext
							.getCurrentMessageContextPacket().getFlatMessage()
							.getMessage()));
					return sb.toString();
				}
			}

		} else if (packet instanceof SIPMessage) {
			return defaultMessage((Message) packet);
		}
		return "";
	}

}
