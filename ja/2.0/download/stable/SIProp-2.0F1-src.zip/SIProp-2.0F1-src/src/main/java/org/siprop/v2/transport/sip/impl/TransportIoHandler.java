/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.impl;

import java.net.InetSocketAddress;

import javax.sip.message.Message;

import org.apache.mina.common.IdleStatus;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.siprop.v2.core.Manager;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.impl.FlatSIPMessage;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.messge.impl.MessageContextPacket;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.stack.sip.impl.StackManagerImpl;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

/**
 * Transport IO Handler
 * 
 * @author nisato
 * 
 */
/**
 * @author noritsuna
 *
 */
public class TransportIoHandler extends IoHandlerAdapter {

	/**
	 * Manager.
	 */
	private Manager manager = null;

	/**
	 * Constructor.
	 * 
	 * @param manager
	 */
	public TransportIoHandler(Manager manager) {
		this.manager = manager;
	}

	/**
	 * set manager.
	 * 
	 * @param manager
	 */
	public void setManager(Manager manager) {
		this.manager = manager;
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.common.IoHandlerAdapter#sessionOpened(org.apache.mina.common.IoSession)
	 */
	public void sessionOpened(IoSession session) {
		// TCP Only
		// session.setIdleTime( IdleStatus.BOTH_IDLE, 60 );
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.common.IoHandlerAdapter#messageReceived(org.apache.mina.common.IoSession, java.lang.Object)
	 */
	public void messageReceived(IoSession session, Object message) {
		Message msg = (Message) message;

		// get remote sock.
		InetSocketAddress remotesock = (InetSocketAddress) session
				.getRemoteAddress();
		InetSocketAddress localsock = (InetSocketAddress) session
				.getLocalAddress();

		// TODO check transport protocol
		Peer remotePeer = new Peer(0, remotesock.getAddress(), remotesock
				.getPort());
		Peer localPeer = new Peer(0, localsock.getAddress(), localsock
				.getPort());

		MessageContext messagecontext = MessageContext.createMessageContext();

		// XXX The messages are always forwarded to Stack Layer
		MessageContextPacket newPacket = MessageContextPacket
				.createMessageContextPacket();
		FlatMessage flatmessage = new FlatSIPMessage();
		flatmessage.setMessage(msg);
		newPacket.setFlatMessage(flatmessage);
		newPacket.setLocalPeer(localPeer);
		newPacket.setRemotePeer(remotePeer);

		LayerRoutingResolver layerResolver = LayerRoutingResolver.getInstance();
		SendToKey layerKey = new SendToKey(TransportManagerImpl.getInstance()
				.getRouteKey(), StackManagerImpl.getInstance().getRouteKey());
		layerResolver.setKey(newPacket, layerKey);

		messagecontext.setMessageContextPacket(newPacket);

		Logger.getGlobal().info(messagecontext, msg.toString());
		this.manager.receive(messagecontext);
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.common.IoHandlerAdapter#sessionIdle(org.apache.mina.common.IoSession, org.apache.mina.common.IdleStatus)
	 */
	public void sessionIdle(IoSession session, IdleStatus status) {
		Logger.getGlobal().info(null, "Disconnecting the idle:");
		session.close();
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.common.IoHandlerAdapter#exceptionCaught(org.apache.mina.common.IoSession, java.lang.Throwable)
	 */
	public void exceptionCaught(IoSession session, Throwable cause) {
		Logger.getGlobal().warning(null,
				"IO Exception Caught:" + cause.getMessage());
		session.close();
	}

}
