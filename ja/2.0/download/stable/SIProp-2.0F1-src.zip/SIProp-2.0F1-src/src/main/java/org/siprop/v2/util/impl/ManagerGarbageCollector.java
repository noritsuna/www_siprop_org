/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.impl;

import org.siprop.v2.core.Manager;

/**
 * This class is GarbageCollector for managers. 
 * 
 * @author noritsuna
 *
 */
public class ManagerGarbageCollector implements Runnable {

	/**
	 * Polling interval
	 */
	private long intval = 500;

	/**
	 * a flag to stop loop
	 */
	private boolean isTerminate = false;

	/**
	 * manager.
	 */
	private Manager manager = null;

	/**
	 * process name.
	 */
	public static final String PROCESS_NAME = "GC";

	/**
	 * constructor
	 * 
	 * @param manager
	 */
	public ManagerGarbageCollector(Manager manager) {
		this.intval = 2000;
		this.manager = manager;
	}
	/**
	 * constructor
	 * 
	 * @param manager
	 * @param interval [ms]
	 */
	public ManagerGarbageCollector(Manager manager, int interval) {
		this.intval = interval;
		this.manager = manager;
	}

	/**
	 * Poll the list of transactions. If transaction that has "delete" state,
	 * notify it to TU.
	 */
	public void run() {
		this.isTerminate = false;
		Logger.getGlobal().fine(null,
				"start Garbage Collection for managers interval=" + intval);

		while (true) {

			// call manager method.
			this.manager.doProcess(PROCESS_NAME, null);

			try {
				Thread.sleep(this.intval);
			} catch (InterruptedException e) {
				Logger.getGlobal().fine(null, e.getMessage());
			}

			/*
			 * stop process
			 */
			if (this.isTerminate == true) {
				Logger.getGlobal().fine(null,
						"Terminating the garbage collector for managers.");
				break;
			}

		}
	}

	/**
	 * Stop polling process
	 * 
	 */
	public void stop() {
		this.isTerminate = true;
	}

}
