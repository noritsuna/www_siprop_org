/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.siprop.SIPropException;
import org.siprop.v2.core.DefaultManager;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.impl.FlatSIPMessage;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.messge.impl.MessageContextPacket;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.stack.StackControlMessage;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.tu.TransactionUser;
import org.siprop.v2.stack.sip.tu.function.TuFunction;
import org.siprop.v2.stack.sip.tu.function.TuFunctionComposer;
import org.siprop.v2.stack.sip.tu.function.impl.CancelHandlerImpl;
import org.siprop.v2.stack.sip.tu.function.impl.MaxForwardsHandlerImpl;
import org.siprop.v2.stack.sip.tu.function.impl.ViaHandlerImpl;
import org.siprop.v2.stack.sip.tu.impl.TransactionUserImpl;
import org.siprop.v2.stack.sip.tu.util.impl.TransactionUserKeyDiscriminator;
import org.siprop.v2.transport.sip.impl.TransportManagerImpl;
import org.siprop.v2.ua.sip.impl.UAManagerImpl;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.ManagerGarbageCollector;

/**
 * This class manages TUs. This class has entry point of SIP stack.
 * 
 * @author masaxmasa
 * 
 */
public class StackManagerImpl extends DefaultManager implements StackManager {

	/**
	 * instance of this class.
	 */
	private static StackManagerImpl instance = null;

	/**
	 * to search TU from Call-ID
	 */
	private Map<String, TransactionUser> mapTU = null;

	/**
	 * to search TU from Call-ID
	 */
	private List<TransactionUser> listTU = null;

	/**
	 * TuFunctionComposer.
	 */
	private TuFunctionComposer tuFunctionComposer = null;
	
	
	/**
	 * Constructor.
	 * 
	 */
	private StackManagerImpl() {
		super();
		this.mapTU = Collections.synchronizedMap(new HashMap<String, TransactionUser>());
		this.listTU = Collections.synchronizedList(new LinkedList<TransactionUser>());
		this.uniKeyGenerator = new TransactionUserKeyDiscriminator();
	}

	/**
	 * Get Instance of TUManager. If TUManager is not exist, create new instance
	 * of TUManager and return it.
	 * 
	 * @return instance of TUManager
	 */
	public static StackManagerImpl getInstance() {
		if (instance == null) {
			instance = new StackManagerImpl();
		}
		return instance;
	}

	/**
	 * Create new TU and register it to own list.
	 * 
	 * @param messageContext
	 * @param tu
	 */
	private void addTU(MessageContext messageContext, TransactionUser tu) {
		this.addTU((String)this.uniKeyGenerator.generateKey(messageContext), tu);
	}
	/**
	 * Create new TU and register it to own list.
	 * 
	 * @param key
	 * @param tu
	 */
	private void addTU(String key, TransactionUser tu) {
		this.mapTU.put(key, tu);
		this.listTU.add(tu);
	}
	
	/**
	 * get UA by MessageContext.
	 * 
	 * @param messageContext
	 * @return
	 */
	private TransactionUser getTU(MessageContext messageContext) {
		return this.mapTU.get((String)this.uniKeyGenerator.generateKey(messageContext));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.util.RouterListener#receive(org.siprop.message.MessageContext)
	 */
	public void receive(MessageContext msg) {

		Logger.getGlobal().finest(msg, "TuManager received a message");

		StackControlMessage stackCtrlMsg = (StackControlMessageImpl) msg
				.getCurrentMessageContextPacket().getControlMessage(
						getControlMessageName());
		boolean createdCtrlMsg = false;
		if (stackCtrlMsg == null) {
			stackCtrlMsg = new StackControlMessageImpl();
			createdCtrlMsg = true;
		} else {
			/* Initialization */
			stackCtrlMsg.setSendToKey(null);
		}

		/*
		 * Initialize LayerKey
		 */
		stackCtrlMsg.setSendToKey(new SendToKey(null, null));

		/*
		 * Check previous layer
		 */
		SendToKey sendTOKey = (SendToKey) this.getLayerResolver().resolve(msg);
		if (sendTOKey == null) {
			Logger.getGlobal().info(msg,
					"There is no Layer information: discarded");
			return;
		}

		RouteKey recvFromKey = sendTOKey.getRecvFrom();
		switch (recvFromKey.getRoutetype()) {
		case TRANSPORT:
			stackCtrlMsg.getSendToKey().setRecvFrom(recvFromKey);
			stackCtrlMsg.setIsUAC(msg.getCurrentMessageContextPacket()
					.getFlatMessage().getMessage() instanceof SIPResponse);
			break;
		case UA:
		case STACK:
			stackCtrlMsg.getSendToKey().setRecvFrom(recvFromKey);
			stackCtrlMsg.setIsUAC(msg.getCurrentMessageContextPacket()
					.getFlatMessage().getMessage() instanceof SIPRequest);
			break;
		default:
			Logger.getGlobal().info(msg,
					"A message was received from unexpected layer.");
			break;
		}

		if (createdCtrlMsg == true) {
			msg.getCurrentMessageContextPacket().addControlMessage(
					getControlMessageName(), stackCtrlMsg);
		}

		/*
		 * Check valid SIP message or not.
		 */
		if (isValidSIPMsg(msg) == false) {
			/*
			 * discard this message
			 */
			Logger.getGlobal().info(msg,
					"Invalid message was received: Discarded");
			return;
		}

		TransactionUser tu = selectTU(msg);
		if (tu != null) {
			Logger.getGlobal().finest(msg,
					"This message will be sent to " + tu.getClass().toString());
			tu.receive(msg);
		} else {
			Logger.getGlobal().warning(msg, "There is no valid TU Object.");
		}
	}

	/**
	 * Is valid SIP message or not.
	 * 
	 * @param msg
	 *            message to validate
	 * @return true: valid, false: invalid
	 */
	private boolean isValidSIPMsg(MessageContext msg) {
		SIPMessage sipMsg = null;
		try {
			sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
					.getFlatMessage().getMessage();
		} catch (ClassCastException e) {
			Logger.getGlobal().fine(msg, "This message isn't SIPMessage.");
			return false;
		}

		/*
		 * Check From, To, Call-ID and CSeq header are presented or not.
		 */
		if (sipMsg.hasHeader("From") == false
				|| sipMsg.hasHeader("To") == false
				|| sipMsg.hasHeader("Call-ID") == false
				|| sipMsg.hasHeader("CSeq") == false) {
			Logger.getGlobal().fine(msg,
					"This message has no (From/To/Call-ID/CSeq) headers");
			return false;
		}

		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.util.RouterListener#send(org.siprop.message.MessageContext)
	 */
	public void send(MessageContext msg) {
		// next layer selection
		selectNextLayer(msg);

		Logger.getGlobal().finest(
				msg,
				"TuManager sends a message. Next Layer is "
						+ ((StackControlMessageImpl) msg
								.getCurrentMessageContextPacket()
								.getControlMessage(getControlMessageName()))
								.getSendToKey().getSendTo().getRouteid()
								.toString());
		this.getRouter().doRoute(msg);
	}

	/**
	 * select TU to process a message
	 * 
	 * @param msg
	 *            message
	 * @return TU object
	 */
	private TransactionUser selectTU(MessageContext msg) {
		TransactionUser targetTU = null;

		targetTU = this.getTU(msg);
		if (targetTU == null) {
			targetTU = new TransactionUserImpl(this, (String)this.getUniKeyGenerator().generateKey(msg));
			if(tuFunctionComposer == null) {
				tuFunctionComposer = this.createFunctions(this);
			}
			targetTU.setTuFunctionComposer(tuFunctionComposer);
			this.addTU(msg, targetTU);
		}

		return targetTU;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.StackManager#registerTransaction(java.lang.String, org.siprop.v2.stack.sip.tu.impl.TransactionUserImpl)
	 */
	public void registerTransactionUser(String transactionKey, TransactionUser tu) {
		this.addTU(transactionKey, tu);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.StackManager#unregisterTransaction(java.lang.String)
	 */
	public void unregisterTransactionUser(String transactionKey) {
		TransactionUser tu = this.mapTU.remove(transactionKey);
		if(tu != null) {
			this.listTU.remove(tu);
		}
	}

	/**
	 * select next layer
	 * 
	 * @param msg
	 *            SIP message that will be forwarded
	 */
	private void selectNextLayer(MessageContext msg) {
		StackControlMessage stackCtrlMsg = (StackControlMessageImpl) msg
				.getCurrentMessageContextPacket().getControlMessage(
						getControlMessageName());
		if (stackCtrlMsg.getSendToKey().getSendTo() == null) {
			// TODO call some resolver
			switch (stackCtrlMsg.getSendToKey().getRecvFrom().getRoutetype()) {
			case TRANSPORT:
				stackCtrlMsg.getSendToKey().setSendTo(
						UAManagerImpl.getInstance().getRouteKey());
				break;
			case STACK:
			case UA: /* fall through */
			case B2BUA:
				stackCtrlMsg.getSendToKey().setSendTo(
						TransportManagerImpl.getInstance().getRouteKey());
				break;
			default:
				// Invalid statement
				Logger.getGlobal().fine(msg,
						"This message is received from an unexpected Layer");
				break;
			}
		}

		/* set message routing information */
		MessageContextPacket newPacket = MessageContextPacket
				.copyMessageContextPacket(msg.getCurrentMessageContextPacket());
		SendToKey sendToKey = new SendToKey(getRouteKey(), stackCtrlMsg
				.getSendToKey().getSendTo());
		this.getLayerResolver().setKey(newPacket, sendToKey);
		Logger.getGlobal().finest(
				msg,
				"set " + sendToKey.getSendTo().getRouteid().toString()
						+ " as a next layer");

		msg.getMessageContextInfo().addMessageContextPacket(newPacket);

		// TODO append some routing informations, if need
		return;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#doProcess(java.lang.String, java.lang.Object[])
	 */
	public void doProcess(String processName, Object[] param) {
		if (processName.equals(ManagerGarbageCollector.PROCESS_NAME)) {
			;;;
		}
	}
	

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.StackManager#createResponse(org.siprop.v2.core.messge.impl.MessageContext, int)
	 */
	public MessageContext createResponse(MessageContext reqMsg, int statusCode)
			throws SIPropException {
		if (reqMsg == null
				|| (reqMsg.getCurrentMessageContextPacket().getFlatMessage()
						.getMessage() instanceof SIPRequest) == false) {
			SIPropException e = new SIPropException("Invalid Argment");
			throw e;
		}

		MessageContext rspMsg = MessageContext.createMessageContext();
		MessageContextPacket rspPacket = MessageContextPacket
				.createMessageContextPacket();
		FlatMessage flatMsg = new FlatSIPMessage();

		SIPRequest sipReq = (SIPRequest) reqMsg
				.getCurrentMessageContextPacket().getFlatMessage().getMessage();
		SIPResponse sipRsp = sipReq.createResponse(statusCode);

		flatMsg.setMessage(sipRsp);
		rspPacket.setFlatMessage(flatMsg);
		rspPacket.setLocalPeer(reqMsg.getLocalPeer());
		rspPacket.setRemotePeer(reqMsg.getRemotePeer());
		rspMsg.setMessageContextPacket(rspPacket);

		return rspMsg;
	}
	
	
	/**
	 * make up the behavior of this TU
	 * 
	 * @param repository
	 *            configuration
	 */
	private TuFunctionComposer createFunctions(StackManager stackManager) {
		TuFunctionComposer tuFuncs = new TuFunctionComposer();

		Logger.getGlobal().fine(null, "creating TU's functions");

		// XXX create function set
		TuFunction function1 = new MaxForwardsHandlerImpl(stackManager, 70);
		try {
			tuFuncs.addFunction(function1);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.getGlobal().fine(null, "creating a Max-Forwards header handler");

		TuFunction function2 = new ViaHandlerImpl(stackManager);
		
		
		try {
			tuFuncs.addFunction(function2);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.getGlobal().fine(null, "creating a Via header handler");

		// KEEP LAST
		TuFunction function3 = new CancelHandlerImpl(stackManager);
		try {
			tuFuncs.addFunction(function3);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.getGlobal().fine(null, "creating a Cancel method handler");
		return tuFuncs;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.StackManager#getTransactionUserList()
	 */
	public List<TransactionUser> getTransactionUserList() {
		return this.listTU;
	}

}
