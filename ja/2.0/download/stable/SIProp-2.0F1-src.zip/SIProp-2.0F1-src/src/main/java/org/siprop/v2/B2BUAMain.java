/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.LogManager;

import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.Provider;
import org.siprop.v2.util.impl.PropertiesDepotProp;

/**
 * main class
 * 
 * @author noritsuna
 * 
 */
public class B2BUAMain {

	/**
	 * Default property config name.
	 */
	private final static String DEFAULT_PROPERTY_NAME = "logger.properties";
	private final static String DEFAULT_CONFIGFILE = "./conf/logger.properties";

	/**
	 * main method.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Load Logger.
		InputStream inputStream;
		try {
			inputStream = new FileInputStream(System.getProperty(
					DEFAULT_PROPERTY_NAME, DEFAULT_CONFIGFILE));
			LogManager logManager = LogManager.getLogManager();
			logManager.readConfiguration(inputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}

		// Load Properties.(for file)
		PropertiesDepot prop = new PropertiesDepotProp();

		// Call init function.
		Provider provider = new ProviderImpl();
		provider.setup(prop);

	}

}
