/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.util.impl;

/**
 * This class is which holds and generates a command name.
 * 
 * @author noritsuna
 * 
 */
public class CommandName {

	/**
	 * This is a name of the method showing a command.
	 */
	private String methodName = null;

	/**
	 * Service name is a thing near a package name.
	 */
	private String serviceName = null;

	/**
	 * Command name.
	 */
	private String commandName = null;

	/**
	 * Constructor
	 * 
	 * @param serviceName
	 *            service name
	 * @param methodName
	 */
	public CommandName(String serviceName, String methodName) {
		this.methodName = methodName;
		this.serviceName = serviceName;

		this.commandName = serviceName + "_" + methodName;
	}

	/**
	 * get method name.
	 * 
	 * @return method name
	 */
	public String getMethodName() {
		return methodName;
	}

	/**
	 * get service name.
	 * 
	 * @return service name
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * get command name.
	 * 
	 * @return command name
	 */
	public String getCommandName() {
		return commandName;
	}

}
