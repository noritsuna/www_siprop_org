/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge.impl;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.siprop.v2.core.messge.Info;

/**
 * Info for MessageContext.
 * 
 * @author noritsuna
 * 
 */
public class MessageContextInfo implements Info {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = -3336729108560263939L;

	/**
	 * list of MessageContextPacket.
	 */
	private List<MessageContextPacket> packetList = null;

	/**
	 * original MessageContextPacket.
	 */
	private MessageContextPacket originalMessageContextPacket = null;

	/**
	 * Constructor.
	 * 
	 */
	public MessageContextInfo() {
		this.packetList = Collections
				.synchronizedList(new LinkedList<MessageContextPacket>());
	}

	/**
	 * get MessageContextPacket.<BR>
	 * isNextStep In the case of true , gotten MessageContextPacket is deleted
	 * from list.
	 * 
	 * @param isNextStep
	 * @return current MessageContextPacket
	 */
	public MessageContextPacket getMessageContextPacket(boolean isNextStep) {
		MessageContextPacket messagePakcet = null;
		if (isNextStep) {
			messagePakcet = this.packetList.remove(0);
		} else {
			messagePakcet = this.packetList.get(0);
		}
		return messagePakcet;
	}

	/**
	 * add MessageContextPacket.
	 * 
	 * @param messageContextPacket
	 */
	public void addMessageContextPacket(
			MessageContextPacket messageContextPacket) {
		this.packetList.add(messageContextPacket);
	}

	/**
	 * set original MessageContextPacket.
	 * 
	 * @param orignalPacket
	 *            original MessageContextPacket
	 */
	public void setOriginalMessageContextPacket(
			MessageContextPacket orignalPacket) {
		this.originalMessageContextPacket = orignalPacket;
	}

	/**
	 * get original MessageContextPacket.
	 * 
	 * @return original MessageContextPacket
	 */
	public MessageContextPacket getOriginalMessageCOntextPacket() {
		return this.originalMessageContextPacket;
	}

	/**
	 * Are all the Packet(s) ending with transmitting or not?
	 * 
	 * @return end is true
	 */
	public boolean isPacketEnd() {
		return this.packetList.isEmpty();
	}
}
