/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu.function.impl;

import gov.nist.javax.sip.header.MaxForwards;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import javax.sip.InvalidArgumentException;
import javax.sip.header.MaxForwardsHeader;
import javax.sip.header.TooManyHopsException;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.StackControlMessage;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.tu.function.TuFunction;
import org.siprop.v2.transport.sip.impl.TransportManagerImpl;
import org.siprop.v2.util.impl.Logger;

/**
 * This class handles Max-Forwards header. In UAC case, append Max-Forwards
 * header if needed. In UAS case, decreament value of Max-Forwards.
 * 
 * @author masaxmasa
 * 
 */
public class MaxForwardsHandlerImpl implements TuFunction {
	/**
	 * value of Max-Forwards
	 */
	private int forwards = 0;

	/**
	 * StackManager.
	 */
	private StackManager stackManager = null;

	/**
	 * Constructor
	 * 
	 */
	public MaxForwardsHandlerImpl(
			StackManager stackManager, int maxForwards) {
		this.forwards = maxForwards;
		this.stackManager = stackManager;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#doProcess(org.siprop.v2.core.messge.impl.MessageContext, org.siprop.v2.stack.sip.transaction.TransactionEntry)
	 */
	public MessageContext doProcess(MessageContext msg, TransactionEntry trnsct) {
		if (msg.getCurrentMessageContextPacket().getFlatMessage().getMessage() instanceof SIPRequest) {
			/*
			 * SIP request message
			 */
			return doSIPreqProcess(msg, trnsct);
		} else {
			/*
			 * SIP response message
			 */
			return doSIPrspProcess(msg);
		}
	}

	/**
	 * Max-Forwards handler for SIP request message
	 * 
	 * @param msg
	 *            SIP request message
	 * @param trnsct
	 *            transaction related SIP request message
	 * @param pType
	 *            process type of TU
	 * @return If some error is occured, return SIP response code.
	 */
	private MessageContext doSIPreqProcess(MessageContext msg,
			TransactionEntry trnsct) {
		switch (trnsct.getTransactionType()) {
		case TRANSACTIONTYPE_INV_UAC:
		case TRANSACTIONTYPE_NONINV_UAC:
			return doSIPreqUACProcess(msg, trnsct);
			/* NOTREACHED */
		case TRANSACTIONTYPE_INV_UAS:
		case TRANSACTIONTYPE_NONINV_UAS:
			return doSIPreqUASProcess(msg, trnsct);
			/* NOTREACHED */
		default:
			break;
		}

		/*
		 * XXX Invalid statement.
		 */

		return null;
	}

	/**
	 * Max-Forwards handler in UAC. If Max-Forwards header is not appeared,
	 * append it with default value.
	 * 
	 * @param msg
	 *            SIP Reqeust message to be sending
	 * @param trnsct
	 *            the transaction related this SIP Reqeust message
	 * @return If some error is occured, return SIP response code.
	 */
	private MessageContext doSIPreqUACProcess(MessageContext msg,
			TransactionEntry trnsct) {
		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		MaxForwardsHeader hdr = sipReq.getMaxForwards();

		if (hdr == null) {
			/*
			 * SIP Request MUST include Max-Forwards header.
			 */
			switch (((StackControlMessage) msg.getCurrentMessageContextPacket()
					.getControlMessage(
							stackManager.getControlMessageName()))
					.getSendToKey().getRecvFrom().getRoutetype()) {
			case STACK:
				/*
				 * SIProp hack In Proxy process, append the Max-Forwards header.
				 */
				Logger
						.getGlobal()
						.info(
								msg,
								sipReq.getMethod()
										+ "Append the Max-Forwards header in the proxy process.");
				break;
			case UA:
			default:
				break;
			}

			try {
				MaxForwardsHeader maxForwards = new MaxForwards(this.forwards);
				sipReq.addHeader(maxForwards);
			} catch (InvalidArgumentException e) {
				Logger.getGlobal().fine(
						msg,
						"Invalid valud of Max-Forwards was specified: "
								+ this.forwards);
			}

			return null;
		}

		return null;
	}

	/**
	 * Max-Forwards handler in UAS. This method decrements value of
	 * Max-Forwards.
	 * 
	 * @param msg
	 *            SIP request message
	 * @param trnsct
	 *            transaction related SIP request message
	 * @return If Max-Forwards can't decrease, return SIP 481 (TOO MAY HOPS)
	 *         response code.
	 */
	private MessageContext doSIPreqUASProcess(MessageContext msg,
			TransactionEntry trnsct) {
		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		MaxForwardsHeader hdr = sipReq.getMaxForwards();

		if (hdr == null) {
			Logger.getGlobal().warning(
					msg,
					sipReq.getMethod()
							+ "This message has no Max-Forwards header.");
			return null;
		}

		if (((StackControlMessage) msg.getCurrentMessageContextPacket()
				.getControlMessage(
						stackManager.getControlMessageName()))
				.getSendToKey().getRecvFrom().getRoutetype() == TransportManagerImpl
				.getInstance().getRouteKey().getRoutetype()) {
			try {
				hdr.decrementMaxForwards();
			} catch (TooManyHopsException e) {
				Logger.getGlobal().warning(msg,
						"Too Many Hops. " + sipReq.getMergeId());

				MessageContext rspMsg = null;
				try {
					rspMsg = this.stackManager.createResponse(msg,
							SIPResponse.TOO_MANY_HOPS);
					// TODO determin destination layer
				} catch (SIPropException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return rspMsg;
			}
		}

		return null;
	}

	/**
	 * The process for SIP response message.
	 * 
	 * @param msg
	 *            The SIP response message will be processed.
	 * @param pType
	 *            received the message from Transaction or UA.
	 * @return always return 0
	 */
	private MessageContext doSIPrspProcess(MessageContext msg) {
		SIPResponse sipRsp = (SIPResponse) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		MaxForwardsHeader hdr = sipRsp.getMaxForwards();

		if (hdr == null) {
			/*
			 * There is no Max-Forwards header
			 */
			return null;
		}

		/*
		 * There is Max-Forwards header. Them remove it.
		 */
		sipRsp.removeHeader(MaxForwardsHeader.NAME);

		return null;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#addFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void addFunction(TuFunction function) throws SIPropException {
		throw new SIPropException("NotImplementedException");
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#removeFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void removeFunction(TuFunction function) throws SIPropException {
		throw new SIPropException("NotImplementedException");
	}

}
