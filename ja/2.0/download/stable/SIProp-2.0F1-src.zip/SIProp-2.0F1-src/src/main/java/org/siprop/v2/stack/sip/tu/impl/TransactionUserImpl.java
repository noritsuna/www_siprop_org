/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.impl.TransactionControllerImpl;
import org.siprop.v2.stack.sip.transaction.util.impl.TransactionControllerKeyDiscriminator;
import org.siprop.v2.stack.sip.tu.TransactionGarbageCollector;
import org.siprop.v2.stack.sip.tu.TransactionUser;
import org.siprop.v2.stack.sip.tu.function.TuFunctionComposer;
import org.siprop.v2.util.Discriminator;
import org.siprop.v2.util.impl.Logger;

/**
 * This class is core of TU.
 * 
 * @author masaxmasa
 * 
 */
public class TransactionUserImpl implements TransactionUser {

	/**
	 * list of transactions for garbage collection
	 */
	private List<TransactionController> listTrnsct = null;

	/**
	 * hash map for searching transactions
	 */
	private Map<String, TransactionController> mapTrnsct = null;

	/**
	 * Functions for TU
	 */
	private TuFunctionComposer tuFuncs = null;

	/**
	 * instance of garbage collector
	 */
	private TransactionGarbageCollector garbageCollector = null;

	/**
	 * instance of garbage collector tread.
	 */
	private Thread gcThread = null;

	/**
	 * ACK behavior
	 */
	private boolean sendACK = false;

	/**
	 * StackManager.
	 */
	private StackManager stackManager = null;
	
	/**
	 * UniKey generator.
	 */
	private Discriminator tranCtrlUniKeyGenerator = null;
	
	/**
	 * Unique key.
	 */
	private String uniKey = null;

	/**
	 * Constructor
	 * 
	 * @param stackManager
	 *            StackManager for this TU
	 * @param uniKey unique key of this instance
	 */
	public TransactionUserImpl(StackManager stackManager, String uniKey) {
		this.listTrnsct = Collections
				.synchronizedList(new LinkedList<TransactionController>());
		this.mapTrnsct = Collections
				.synchronizedMap(new HashMap<String, TransactionController>());
		this.stackManager = stackManager;
		this.sendACK = false;
		this.tranCtrlUniKeyGenerator = new TransactionControllerKeyDiscriminator();
		this.uniKey = uniKey;

		/*
		 * create TransactionGarbageCollector and run it.
		 */
		this.garbageCollector = new TransactionGarbageCollector(this);
		this.gcThread = new Thread(this.garbageCollector);
		this.gcThread.start();

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#getStackManager()
	 */
	public StackManager getStackManager() {
		return stackManager;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#setTuFunctionComposer(org.siprop.v2.stack.sip.tu.function.TuFunctionComposer)
	 */
	public void setTuFunctionComposer(TuFunctionComposer functions) {
		this.tuFuncs = functions;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#send(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void send(MessageContext msg) {
		this.stackManager.send(msg);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#receive(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void receive(MessageContext msg) {
		Logger.getGlobal().finest(msg, "TU received a message");
		/*
		 * SIP stack process
		 */
		if (playSIP(msg) == false) {
			/*
			 * Stack doesn't need forward message to next layer.
			 */
			return;
		}

		/*
		 * send message to next layer
		 */
		send(msg);
	}



	/**
	 * Search a transaction related SIP message. If a transaction is not exist,
	 * create new transaction.
	 * 
	 * @param msg
	 *            SIP message
	 * @return transaction entry
	 */
	private TransactionEntry searchTransaction(MessageContext msg) {
		/*
		 * search transaction set
		 */
		TransactionController trnsct = this.getTransactionController(msg);
		if (trnsct == null) {
			/*
			 * This is new call
			 */
			Logger.getGlobal().fine(msg, "This is a new transaction.");

			/*
			 * SIP request message or not ?
			 */
			SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
			.getFlatMessage().getMessage();
			if (sipMsg instanceof SIPRequest == false) {
				Logger
						.getGlobal()
						.fine(msg,
								"This message isn't SIP request message, then its' discarded.");
				return null;
			}

			/*
			 * add new transaction
			 */
			Logger.getGlobal().fine(msg,
					"creating a new transaction set. transactionUserUniKey=" + getUniKeyGenerator().generateKey(msg));
			trnsct = addNewTransaction(msg);
		}

		/*
		 * search TransactionEntry
		 */
		TransactionEntry entryTrnsct = trnsct.searchTransaction(msg);

		if (entryTrnsct == null) {
			return null;
		}

		return entryTrnsct;
	}

	/**
	 * SIP stack process
	 * 
	 * @param msg
	 *            SIP message
	 * @return transaction entry
	 */
	private boolean playSIP(MessageContext msg) {
		TransactionEntry entryTrnsct = searchTransaction(msg);

		/*
		 * Some problem has happend
		 */
		if (entryTrnsct == null) {
			Logger.getGlobal()
					.fine(msg, "There is no valid transaction entry.");
			return false;
		}

		/*
		 * Update the SIP transaction status
		 */
		Logger.getGlobal().finest(msg, "The transaction process starts");
		entryTrnsct.doProcess(msg);

		/*
		 * do TU process
		 */
		MessageContext sndMsg = null;
		Logger.getGlobal().finest(msg, "Processes of TU's functions start");
		sndMsg = this.tuFuncs.doProcess(msg, entryTrnsct);
		if (sndMsg != null) {
			send(sndMsg);
			return false;
		}

		if (this.sendACK == true) {
			/*
			 * If the statck terminates ACK request message, it MUST NOT forward
			 * ACK request message.
			 */
			return false;
		}

		return true;
	}


	private void setIsSendAck(boolean flag) {
		this.sendACK = flag;
	}

	/**
	 * add new Transaction entry and register it to TUManager
	 * 
	 * @param messageContext
	 *            MessageContext
	 */
	private TransactionController addNewTransaction(MessageContext messageContext) {		

		/*
		 * register new entry to local linked list and hashed map.
		 */
		String key = (String)this.getUniKeyGenerator().generateKey(messageContext);
		TransactionController trnsct = new TransactionControllerImpl(this, key);
		this.addTransactionController(key, trnsct);
		synchronized (this.garbageCollector) {
			this.garbageCollector.notifyAll();
		}

		/*
		 * register to TUManager
		 */
		String transactionUserUniKey = (String)this.stackManager.getUniKeyGenerator().generateKey(messageContext);
		this.stackManager.registerTransactionUser(transactionUserUniKey, this);

		return trnsct;
	}
	
	/**
	 * add TransactionController.
	 * 
	 * @param messageContext
	 * @param trnsct
	 */
	private void addTransactionController(MessageContext messageContext, TransactionController trnsct) {
		String transKey = (String)this.getUniKeyGenerator().generateKey(messageContext);
		this.addTransactionController(transKey, trnsct);
	}
	private void addTransactionController(String transKey, TransactionController trnsct) {
		this.listTrnsct.add(trnsct);
		this.mapTrnsct.put(transKey, trnsct);
	}
	
	/**
	 * delete TransactionController.
	 */
	private void deleteTransactionController(MessageContext messageContext) {
		String transKey = (String)this.getUniKeyGenerator().generateKey(messageContext);
		this.deleteTransactionController(transKey);
	}
	private void deleteTransactionController(String transKey) {
		TransactionController trans= getTransactionController(transKey);
		
		if( trans != null ) {
			this.listTrnsct.remove(trans);
			this.mapTrnsct.remove(transKey);
		}
		
	}
	
	/**
	 * get TransactionController.
	 * 
	 * @param messageContext
	 * @return
	 */
	private TransactionController getTransactionController(MessageContext messageContext) {
		String transKey = (String)this.getUniKeyGenerator().generateKey(messageContext);
		return getTransactionController(transKey);
	}
	/**
	 * get TransactionController.
	 * 
	 * @param transKey
	 * @return
	 */
	private TransactionController getTransactionController(String transKey) {
		return this.mapTrnsct.get(transKey);
	}
	

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#getTransactionControllerList()
	 */
	public List<TransactionController> getTransactionControllerList() {
		return this.listTrnsct;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#getUniKeyGenerator()
	 */
	public Discriminator getUniKeyGenerator() {
		return this.tranCtrlUniKeyGenerator;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#setUniKeyGenerator(org.siprop.v2.util.Discriminator)
	 */
	public void setUniKeyGenerator(Discriminator uniKeyGenerator) {
		this.tranCtrlUniKeyGenerator = uniKeyGenerator;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#setUniKey(java.lang.String)
	 */
	public void setUniKey(String uniKey) {
		this.uniKey = uniKey;		
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.TransactionUser#getUniKey()
	 */
	public String getUniKey() {
		return uniKey;
	}

}
