/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.StackControlMessage;
import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.TransactionType;
import org.siprop.v2.stack.sip.transaction.util.impl.TransactionEntryKeyDiscriminator;
import org.siprop.v2.stack.sip.tu.TransactionUser;
import org.siprop.v2.util.Discriminator;
import org.siprop.v2.util.impl.Logger;

/**
 * This class has set of transactions. Each transaction has same Call-ID value.
 * 
 * @author masaxmasa
 *
 */
public class TransactionControllerImpl implements TransactionController {

	/**
	 * Transaction List
	 */
	private List<TransactionEntry> listTrnsct = null;

	/**
	 * Called TU
	 */
	private TransactionUser tu = null;

	/**
	 * initial flag
	 */
	private boolean isInitialState;
	
	/**
	 * UniKey generator.
	 */
	private Discriminator uniKeyGenerator = null;
	
	/**
	 * unikey of this instance.
	 */
	private String uniKey = null;

	/**
	 * Constructor.
	 * 
	 * @param tu called tu
	 * @param uniKey unique key of this instance
	 */
	public TransactionControllerImpl(TransactionUser tu, String uniKey) {
		this.listTrnsct = Collections
				.synchronizedList(new LinkedList<TransactionEntry>());
		this.isInitialState = true;
		this.tu = tu;
		this.uniKeyGenerator = new TransactionEntryKeyDiscriminator();
		this.uniKey = uniKey;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#getTransacitonList()
	 */
	public List<TransactionEntry> getTransacitonList() {
		return this.listTrnsct;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#searchTransaction(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public TransactionEntry searchTransaction(MessageContext msg) {
		Logger.getGlobal().finest(msg, "searching transaction entries.");
		TransactionEntry entry = null;
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		StackControlMessage stackCtrlMsg = (StackControlMessage) msg
				.getCurrentMessageContextPacket().getControlMessage(
						this.tu.getStackManager().getControlMessageName());

		for (TransactionEntry entry0 : this.listTrnsct) {
			// Check UAC or UAS
			TransactionType trnsctType = entry0.getTransactionType();
			if (stackCtrlMsg.getIsUAC() == true) {
				if (trnsctType == TransactionType.TRANSACTIONTYPE_INV_UAS
						|| trnsctType == TransactionType.TRANSACTIONTYPE_NONINV_UAS) {
					continue;
				}
			} else {
				if (trnsctType == TransactionType.TRANSACTIONTYPE_INV_UAC
						|| trnsctType == TransactionType.TRANSACTIONTYPE_NONINV_UAC) {
					continue;
				}
			}
			
			/**
			 * check Original Message.
			 */
			if(entry0.getTransactionInfo() == null) {
				continue;
			}

			/*
			 * Check CSeq header
			 */
			// CSeq number
			if (sipMsg.getCSeq().getSeqNumber() != entry0.getTransactionInfo().getCSeqNumber()) {
				continue;
			}

			// CSeq method
			if (SIPRequest.ACK.equals(sipMsg.getCSeq().getMethod()) == true) {
				switch (entry0.getTransactionState()) {
				case NONE:
				case TRYING:
				case CALLING:
					continue;
				case PROCEEDING:
				case COMPLETED:
				case CONFIRMED:
					// matched ??
					break;
				case DELETE:
				case TERMINATED:
				default:
					continue;
				}
			} else if (sipMsg.getCSeq().getMethod().equals(
					entry0.getTransactionInfo().getMethod()) == false) {
				continue;
			}

			// TODO Do we need checking branch value ?

			/*
			 * Check Tags
			 */
			// From Tag
			if (sipMsg.getFromTag().equals(entry0.getTransactionInfo().getTagFrom()) == false) {
				continue;
			}

			// To Tag
			if ((sipMsg.hasToTag() == true && (entry0.getTransactionInfo().getTagTo() == null || entry0
					.getTransactionInfo().getTagTo().equals(sipMsg.getToTag()) == false))) {
				continue;
			}

			if (sipMsg instanceof SIPRequest) {
				/* SIP Request message */
				if (sipMsg.hasToTag() == false && entry0.getTransactionInfo().getTagTo() != null) {
					continue;
				}
			} else {
				/* SIP Response message */
				if (sipMsg.hasToTag() && entry0.getTransactionInfo().getTagTo() != null
						&& entry0.getTransactionInfo().getTagTo().equals(sipMsg.getToTag()) == false) {
					TransactionEntry newEntry = null;
					if ((newEntry = doFork(msg, entry0)) != null) {
						entry = newEntry;
						break;
					}
				}

			}

			entry = entry0;
			break;
		}

		if (entry == null) {
			/*
			 * This is new Transaction, create new one.
			 */

			Logger.getGlobal().fine(msg, "This is a new transaction.");

			/*
			 * SIP Request message or not ?
			 */
			if (sipMsg instanceof SIPRequest == false) {
				Logger.getGlobal().fine(stackCtrlMsg,
						"This message isn't a SIP request message: discarded");
				return null;
			}

			SIPRequest sipReq = (SIPRequest) msg
					.getCurrentMessageContextPacket().getFlatMessage()
					.getMessage();
			if (SIPRequest.INVITE.equals(sipReq.getMethod()) == true) {
				/*
				 * INVITE transaction
				 */
				switch (stackCtrlMsg.getSendToKey().getRecvFrom()
						.getRoutetype()) {
				case TRANSPORT:
					/*
					 * XXX INVITE server transaction
					 */
					Logger.getGlobal().finer(msg,
							"creating an INVITE Server Transaction");
					entry = new InviteServerTransaction(this, false);
					break;
				case UA:
				case STACK:
					/*
					 * XXX INVITE client transaction
					 */
					Logger.getGlobal().finer(msg,
							"creating an INVITE Client Transaction");
					entry = new InviteClientTransaction(this, false);
					break;
				default:
					break;
				}
			} else {
				/*
				 * non-INVITE transaction
				 */
				switch (stackCtrlMsg.getSendToKey().getRecvFrom()
						.getRoutetype()) {
				case TRANSPORT:
					/*
					 * XXX non-INVITE server transaction
					 */
					Logger.getGlobal().finer(msg,
							"creating a Non-INVITE Server Transaction");
					entry = new NonInviteServerTransaction(this, false);
					break;
				case UA:
				case STACK:
					/*
					 * XXX INVITE client transaction
					 */
					Logger.getGlobal().finer(msg,
							"creating a Non-INVITE Client Transaction");
					entry = new NonInviteClientTransaction(this, false);
					if (SIPRequest.CANCEL.equals(sipReq.getMethod()) == true) {
						/*
						 * This is CANCEL request message. Search transaction
						 * that will be canceled, first.
						 */
						Logger
								.getGlobal()
								.fine(msg,
										"This message is CANCEL message: search a transaction that will be canceled.");
						TransactionEntry canceled = searchCancelTransaction(sipReq);
						if (canceled != null) {
							/*
							 * copy branch value of Via header
							 */
							entry.getTransactionInfo().setViaBranch(canceled.getTransactionInfo().getViaBranch());
						}
					}
					break;
				default:
					break;
				}
			}

			if (entry != null) {
				this.listTrnsct.add(entry);
			}

		}

		if (entry != null) {
			this.isInitialState = false;
		}
		return entry;
	}

	/**
	 * call forking
	 * 
	 * @param msg
	 *            SIP Response message
	 * @param entry0
	 *            original call
	 * @return forked call
	 */
	private TransactionEntry doFork(MessageContext msg, TransactionEntry entry0) {
		TransactionEntry newEntry = null;

		// XXX currently, this stack doesn't support forking
		if (true) {
			return null;
		}

		/*
		 * TODO Not completed yet.
		 */

		SIPResponse sipRsp = (SIPResponse) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		if ((sipRsp.getStatusCode() / 100) != 1) {
			/*
			 * This SIP response is final response.
			 */
			return null;
		}

		return newEntry;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#searchCancelTransaction(gov.nist.javax.sip.message.SIPRequest)
	 */
	public TransactionEntry searchCancelTransaction(SIPRequest cancel) {
		TransactionEntry entry = null;

		for (TransactionEntry entry0 : this.listTrnsct) {
			/*
			 * check INVITE transaction or not
			 */
			switch (entry0.getTransactionType()) {
			case TRANSACTIONTYPE_INV_UAC:
			case TRANSACTIONTYPE_INV_UAS:
				break;
			case TRANSACTIONTYPE_NONINV_UAC:
			case TRANSACTIONTYPE_NONINV_UAS:
			default:
				continue;
			}
			
			/**
			 * check Original message.
			 */
			if(entry0.getTransactionInfo() == null) {
				continue;
			}

			/*
			 * check number of CSeq
			 */
			if (cancel.getCSeq().getSeqNumber() != entry0.getTransactionInfo().getCSeqNumber()) {
				continue;
			}

			/*
			 * check From Tag
			 */
			if (cancel.getFromTag().equals(entry0.getTransactionInfo().getTagFrom()) == false) {
				continue;
			}

			entry = entry0;
		}

		return entry;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#isInitialState()
	 */
	public boolean isInitialState() {
		return this.isInitialState;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#getTU()
	 */
	public TransactionUser getTU() {
		return this.tu;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#getUniKeyGenerator()
	 */
	public Discriminator getUniKeyGenerator() {
		return this.uniKeyGenerator;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#setUniKeyGenerator(org.siprop.v2.util.Discriminator)
	 */
	public void setUniKeyGenerator(Discriminator uniKeyGenerator) {
		this.uniKeyGenerator = uniKeyGenerator;		
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#setUniKey(java.lang.String)
	 */
	public void setUniKey(String uniKey) {
		this.uniKey = uniKey;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionController#getUniKey()
	 */
	public String getUniKey() {
		return uniKey;
	}

}
