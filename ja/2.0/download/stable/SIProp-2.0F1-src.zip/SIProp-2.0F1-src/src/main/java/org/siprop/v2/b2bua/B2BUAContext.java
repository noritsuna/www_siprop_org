/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua;

import java.util.List;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.impl.MessageContext;

/**
 * This interface the dialog about a B2BUA.
 * 
 * @author noritsuna
 * 
 */
public interface B2BUAContext extends Context {

	/**
	 * get opposed UAInfo list.
	 * 
	 * @param messageContext
	 * @return opposed UAInfo list
	 */
	public List<B2BUAInfo> getOpposeUAInfos(MessageContext messageContext);

	/**
	 * get self UAInfo list.
	 * 
	 * @param messageContext
	 * @return self UAInfo list
	 */
	public List<B2BUAInfo> getSelfUAInfos(MessageContext messageContext);

	/**
	 * set UAInfo.
	 * 
	 * @param key
	 * @param uaSet
	 */
	public void setUAInfo(String key, B2BUAInfo uaSet);
	
	/**
	 * get UAInfo.
	 * 
	 * @param key 
	 * @return B2BUAInfo
	 */
	public B2BUAInfo getUAInfo(String key);

}
