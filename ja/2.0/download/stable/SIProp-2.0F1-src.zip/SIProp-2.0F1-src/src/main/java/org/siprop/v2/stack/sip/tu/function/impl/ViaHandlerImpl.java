/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu.function.impl;

import gov.nist.core.Host;
import gov.nist.javax.sip.Utils;
import gov.nist.javax.sip.header.SIPHeader;
import gov.nist.javax.sip.header.Via;
import gov.nist.javax.sip.header.ViaList;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.Iterator;

import javax.sip.InvalidArgumentException;
import javax.sip.header.ProxyAuthorizationHeader;
import javax.sip.header.ProxyRequireHeader;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.StackControlMessage;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.tu.function.TuFunction;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.impl.BindingResolver;
import org.siprop.v2.util.resolver.impl.PeerKey;

/**
 * Via header handler.
 * 
 * @author masaxmasa
 * 
 */
public class ViaHandlerImpl implements TuFunction {
	/**
	 * Loop detection is optional function.
	 */
	private boolean isDetectLoop;

	/**
	 * BindingResolver
	 */
	private BindingResolver bindResolver = null;

	/**
	 * The branch ID inserted by an element compliant with this specification
	 * MUST always begin with the characters "z9hG4bK".
	 */
	private static final String MAGIC_COOKIE = "z9hG4bK";

	/**
	 * StackManger.
	 */
	private StackManager stackManager = null;

	/**
	 * Constructor
	 * 
	 */
	public ViaHandlerImpl(StackManager stackManager) {
		this.isDetectLoop = true;
		this.bindResolver = (BindingResolver) BindingResolver.getInstance();
		this.stackManager = stackManager;

	}

	/**
	 * set BindingResolver.
	 * 
	 * @param bindingResolver
	 */
	public void setBindingResolver(BindingResolver bindingResolver) {
		this.bindResolver = bindingResolver;
	}
	/**
	 * set detect loop flag.
	 * 
	 * @param flag
	 */
	public void setIsDetectLoop(boolean flag) {
		this.isDetectLoop = flag;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#doProcess(org.siprop.v2.core.messge.impl.MessageContext, org.siprop.v2.stack.sip.transaction.TransactionEntry)
	 */
	public MessageContext doProcess(MessageContext msg, TransactionEntry trnsct) {

		if (msg.getCurrentMessageContextPacket().getFlatMessage().getMessage() instanceof SIPRequest) {
			return doSIPRequestProcess(msg, trnsct);
		} else {
			return doSIPResponseProcess(msg, trnsct);
		}
	}

	/**
	 * Via handler for SIP request messages. After loop detection, instert Via
	 * header.
	 * 
	 * @param msg
	 *            SIP request message
	 * @param trnsct
	 *            transaction related SIP request message
	 * @param pType
	 *            process type of TU
	 * @return If loop detected, return SIP 482 (LOOP DETECTED) response code.
	 */
	private MessageContext doSIPRequestProcess(MessageContext msg,
			TransactionEntry trnsct) {

		/*
		 * check type of transaction
		 */
		switch (trnsct.getTransactionType()) {
		case TRANSACTIONTYPE_INV_UAC:
		case TRANSACTIONTYPE_NONINV_UAC:
			break;
		case TRANSACTIONTYPE_INV_UAS:
		case TRANSACTIONTYPE_NONINV_UAS:
		default:
			/*
			 * do nothing
			 */
			return null;
		}

		StackControlMessage stackCtrlMsg = (StackControlMessage) msg
				.getCurrentMessageContextPacket().getControlMessage(
						stackManager.getControlMessageName());

		/*
		 * check where is the message from.
		 */
		switch (stackCtrlMsg.getSendToKey().getRecvFrom().getRoutetype()) {
		case STACK:
		case UA:
			break;
		case TRANSPORT:
		default:
			/*
			 * do nothing
			 */
			return null;
		}

		/*
		 * Loop detection
		 */
		if (isLoop(msg, trnsct) == true) {
			MessageContext rspMsg = null;

			try {
				rspMsg = this.stackManager.createResponse(msg,
						SIPResponse.LOOP_DETECTED);
				// TODO determin destination layer
			} catch (SIPropException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return rspMsg;
		}

		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();

		/*
		 * Calculate branch value
		 */
		String branch = null;
		if(trnsct.getTransactionInfo() != null) {
			branch = trnsct.getTransactionInfo().getViaBranch();
			if (branch == null) {
				if (SIPRequest.ACK.equals(sipReq.getMethod()) == true) {
					// ACK
	
				}
				branch = calculateBranch(sipReq);
				trnsct.getTransactionInfo().setViaBranch(branch);
			}
		}

		// TODO set protocol, address, port
		Via via = new Via();

		Peer localPeer = (Peer) ((PeerKey) this.bindResolver.resolve(msg))
				.getRoutingKey();
		// set address
		try {
			Host viaHost = new Host();
			viaHost.setAddress(localPeer.getAddress().getHostAddress());
			via.setHost(localPeer.getAddress().toString());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// set port number
		try {
			via.setPort(localPeer.getPort());
		} catch (InvalidArgumentException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			via.setBranch(branch);
		} catch (ParseException e) {
			// TODO logging
		}

		/*
		 * Put new VIA header to first of VIA header list.
		 */
		ViaList viaList = sipReq.getViaHeaders();
		viaList.addFirst(via);

		return null;
	}

	/**
	 * Via handler for SIP response message. Own Via Header is presented, remove
	 * it from SIP response message.
	 * 
	 * @param msg
	 *            SIP response message
	 * @param trnsct
	 *            transaction related SIP response message
	 * @param pType
	 *            proces type of TU
	 * @return always return 0
	 */
	private MessageContext doSIPResponseProcess(MessageContext msg,
			TransactionEntry trnsct) {

		StackControlMessage stackCtrlMsg = (StackControlMessage) msg
				.getCurrentMessageContextPacket().getControlMessage(
						stackManager.getControlMessageName());
		switch (stackCtrlMsg.getSendToKey().getRecvFrom().getRoutetype()) {
		case TRANSPORT:
			break;
		case STACK:
		case UA:
			/*
			 * This message was sent by our UA or Proxy
			 */
		default:
			return null;
		}

		boolean hasBranch = false;
		SIPResponse sipRsp = (SIPResponse) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		ViaList viaList = sipRsp.getViaHeaders();
		Iterator itr = viaList.iterator();

		while (itr.hasNext()) {
			Via via = (Via) itr.next();
			if (trnsct.getTransactionInfo() != null 
				&& via.getBranch().equals(trnsct.getTransactionInfo().getViaBranch()) == true) {
				hasBranch = true;

				/*
				 * remove own Via header
				 */
				viaList.remove(via);
				break;
			}
		}

		if (hasBranch == false) {
			/*
			 * TODO Logging
			 */
		}

		return null;
	}

	/**
	 * Check this SIP request includes own Via header or not. If isDetectLoop is
	 * false, doesn't check message loop.
	 * 
	 * @param msg
	 *            SIP Request message
	 * @param trnsct
	 *            transaction related SIP Request message
	 * @return If loop detected, return true.
	 */
	private boolean isLoop(MessageContext msg, TransactionEntry trnsct) {

		if (this.isDetectLoop == false) {
			/*
			 * Checking for forwarding loops is disabled.
			 */
			return false;
		}

		/*
		 * If the transaction has no branch value, this message is not
		 * forwarded.
		 */
		if (trnsct.getTransactionInfo() == null || trnsct.getTransactionInfo().getViaBranch() == null) {
			return false;
		}

		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		ViaList viaList = sipReq.getViaHeaders();
		Iterator itr = viaList.iterator();

		while (itr.hasNext()) {
			Via via = (Via) itr.next();
			if (via.getBranch().equals(trnsct.getTransactionInfo().getViaBranch()) == true) {
				/*
				 * XXX need more check ??
				 */
				return true;
			}
		}

		return false;
	}

	/**
	 * Calculate branch value.<BR>
	 * A common way to create this value is to compute a<BR>
	 * cryptographic hash of the To tag, From tag, Call-ID header<BR>
	 * field, the Request-URI of the request received (before<BR>
	 * translation), the topmost Via header, and the sequence number<BR>
	 * from the CSeq header field, in addition to any Proxy-Require<BR>
	 * and Proxy-Authorization header fields that may be present.
	 * 
	 * @param sipReq
	 * @return branch value
	 */
	private String calculateBranch(SIPRequest sipReq) {
		byte branch[] = null;
		MessageDigest md5 = null;
		try {
			md5 = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			// TODO Logger.getGlobal().
			return null;
		}

		// Call-ID
		md5.update(sipReq.getCallId().getCallId().getBytes());

		// From tag
		md5.update(sipReq.getFromTag().getBytes());

		// To tag
		md5.update(sipReq.getToTag().getBytes());

		// Request URI
		md5.update(sipReq.getRequestURI().toString().getBytes());

		// topmost Via Header
		SIPHeader firstVia = sipReq.getViaHeaders().getFirst();
		if (firstVia != null) {
			md5.update(firstVia.toString().getBytes());
		}

		// sequence number of CSeq
		md5.update(Long.toString(sipReq.getCSeq().getSeqNumber()).getBytes());

		// Proxy-Require Header
		ProxyRequireHeader pReqHdr = (ProxyRequireHeader) sipReq
				.getHeader("Proxy-Require");
		if (pReqHdr != null) {
			md5.update(pReqHdr.getOptionTag().getBytes());
		}

		// Proxy-Authorization Header
		ProxyAuthorizationHeader pAuthHdr = (ProxyAuthorizationHeader) sipReq
				.getHeader("Proxy-Authorization");
		if (pAuthHdr != null) {
			md5.update(pAuthHdr.toString().getBytes());
		}

		branch = md5.digest();

		return ViaHandlerImpl.MAGIC_COOKIE + Utils.toHexString(branch);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#addFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void addFunction(TuFunction function) throws SIPropException {
		throw new SIPropException("NotImplementedException");
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#removeFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void removeFunction(TuFunction function) throws SIPropException {
		throw new SIPropException("NotImplementedException");
	}
}
