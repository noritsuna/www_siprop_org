/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction;

import gov.nist.javax.sip.message.SIPRequest;

import java.util.List;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.sip.tu.TransactionUser;
import org.siprop.v2.util.Discriminator;

/**
 * This class has set of transactions. Each transaction has same Call-ID value.
 * 
 * @author masaxmasa
 *
 */
public interface TransactionController {

	/**
	 * get the list of transactions related this transaction set.
	 * 
	 * @return the list of transactions
	 */
	public List<TransactionEntry> getTransacitonList();

	/**
	 * Search a transaction related SIP message. If a transaction is not exist,
	 * create new transaction entry
	 * 
	 * @param msg
	 *            SIP Message
	 * @return transaction entry
	 */
	public TransactionEntry searchTransaction(MessageContext msg);

	/**
	 * Search a transaction that will be canceled by the CANCEL message If the
	 * transaction isn't exist return null.
	 * 
	 * @param cancel
	 *            CANCEL request message
	 * @return transaction
	 */
	public TransactionEntry searchCancelTransaction(SIPRequest cancel);

	/**
	 * check Initial state or not.
	 * 
	 * @return Initial state or not
	 */
	public boolean isInitialState();

	/**
	 * get called tu.
	 * 
	 * @return called tu
	 */
	public TransactionUser getTU();
	
	/**
	 * get unique key.
	 * 
	 * @return unique key of this instance
	 */
	public String getUniKey();

	/**
	 * set unique key.
	 * 
	 * @param uniKey unique key of this instance
	 */
	public void setUniKey(String uniKey);

	/**
	 * get Discriminator of unique key for itself manage list.
	 * 
	 * @return key generator
	 */
	public Discriminator getUniKeyGenerator();

	/**
	 * set Discriminator of unique key for itself manage list.
	 * 
	 * @param uniKeyGenerator key generator
	 */
	public void setUniKeyGenerator(Discriminator uniKeyGenerator);

}
