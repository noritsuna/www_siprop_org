/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.impl;

import org.siprop.v2.core.Manager;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.core.router.impl.LayerEnum;
import org.siprop.v2.core.router.impl.MessageRouteKey;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.core.router.impl.MessageRouterInfo;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

/**
 * Repository for Stack.
 * 
 * @author noritsuna
 *
 */
public class StackRepositoryImpl implements Repository {

	/**
	 * PropertiesDepot.
	 */
	private PropertiesDepot prop = null;

	/**
	 * Stack Manager.
	 */
	private Manager manager = null;

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#setup(org.siprop.v2.util.PropertiesDepot)
	 */
	public void setup(PropertiesDepot prop) {

		this.prop = prop;

		StackManager stackManager = StackManagerImpl.getInstance();
		this.manager = stackManager;

		// set ControlMessageName.
		this.manager.setControlMessageName("StackControlMessageImpl");

		// set LayerRoutingResolver.
		this.manager.setLayerResolver(LayerRoutingResolver.getInstance());

		// add router.
		RouteKey rtrKey = new MessageRouteKey();
		rtrKey.setRouteid("StackManager");
		rtrKey.setRoutetype(LayerEnum.STACK);

		RouterInfo rtrInfo = new MessageRouterInfo();
		rtrInfo.setRouteKey(rtrKey);
		rtrInfo.addListener(stackManager);

		Router router = MessageRouter.getInstance();
		router.addRoute(rtrInfo);

		this.manager.setRouteKey(rtrKey);
		this.manager.setRouter(router);

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getRepository(org.siprop.v2.core.repository.RepositoryKey)
	 */
	public Repository getRepository(RepositoryKey key) {
		return this;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getManager()
	 */
	public Manager getManager() {
		return this.manager;
	}

}
