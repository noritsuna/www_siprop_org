/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction.impl;

import gov.nist.javax.sip.header.To;
import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.impl.FlatSIPMessage;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.messge.impl.MessageContextPacket;
import org.siprop.v2.stack.StackControlMessage;
import org.siprop.v2.stack.sip.impl.StackControlMessageImpl;
import org.siprop.v2.stack.sip.transaction.SIPTimer;
import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.TransactionInfo;
import org.siprop.v2.stack.sip.transaction.TransactionState;
import org.siprop.v2.stack.sip.transaction.TransactionType;
import org.siprop.v2.transport.sip.impl.TransportManagerImpl;
import org.siprop.v2.util.impl.Logger;

/**
 * The state machine for INVITE Client Transaction<BR>
 * According to RFC3261 Figure 5: INVITE client transaction
 * 
 * <PRE>
 *                                |INVITE from TU
 *              Timer A fires     |INVITE sent
 *              Reset A,          V                      Timer B fires
 *              INVITE sent +-----------+                or Transport Err.
 *                +---------|           |---------------+inform TU
 *                |         |  Calling  |               |
 *                +--------&gt;|           |--------------&gt;|
 *                          +-----------+ 2xx           |
 *                             |  |       2xx to TU     |
 *                             |  |1xx                  |
 *     300-699 +---------------+  |1xx to TU            |
 *    ACK sent |                  |                     |
 * resp. to TU |  1xx             V                     |
 *             |  1xx to TU  -----------+               |
 *             |  +---------|           |               |
 *             |  |         |Proceeding |--------------&gt;|
 *             |  +--------&gt;|           | 2xx           |
 *             |            +-----------+ 2xx to TU     |
 *             |       300-699    |                     |
 *             |       ACK sent,  |                     |
 *             |       resp. to TU|                     |
 *             |                  |                     |      NOTE:
 *             |  300-699         V                     |
 *             |  ACK sent  +-----------+Transport Err. |  transitions
 *             |  +---------|           |Inform TU      |  labeled with
 *             |  |         | Completed |--------------&gt;|  the event
 *             |  +--------&gt;|           |               |  over the action
 *             |            +-----------+               |  to take
 *             |              &circ;   |                     |
 *             |              |   | Timer D fires       |
 *             +--------------+   | -                   |
 *                                |                     |
 *                                V                     |
 *                          +-----------+               |
 *                          |           |               |
 *                          | Terminated|&lt;--------------+
 *                          |           |
 *                          +-----------+
 * </PRE>
 * 
 * @author masaxmasa
 * 
 */
public class InviteClientTransaction implements TransactionEntry {

	/**
	 * state of this transaction
	 */
	private TransactionState state = null;

	/**
	 * Next expire time, if timer is running. 0 means that there is no timer in
	 * current state.
	 */
	private long tStamp = 0;

	/**
	 * The lifetime for this transaction
	 */
	private long tExpire = 0;

	/**
	 * counter for INVITE transmited
	 */
	private int nTransmit = 0;

	/**
	 * max number of transmitting INVITE.
	 */
	private int maxTransmit = 0;

	/**
	 * Value of Timer A
	 */
	private long timerA = 0;

	/**
	 * Is reliable transport or not.
	 */
	private boolean isReliable = false;

	/**
	 * type of transaction
	 */
	private final TransactionType type = TransactionType.TRANSACTIONTYPE_INV_UAC;

	/**
	 * parent Transaction object of this entry
	 */
	private TransactionController parentTransaction = null;
	
	/**
	 * TransactionInfo.
	 */
	private TransactionInfo transactionInfo = null;
	

	/**
	 * Constructor. Set Initial Transation State
	 * 
	 * @param isReliable
	 *            Using reliable transport or not.
	 */
	public InviteClientTransaction(TransactionController parent, boolean isReliable) {
		// set Initial State
		this.state = TransactionState.NONE;
		this.tStamp = 0;
		this.isReliable = isReliable;
		this.maxTransmit = 1;
		this.timerA = SIPTimer.getA();
		long timerB = SIPTimer.getB();
		this.parentTransaction = parent;

		while (timerB > 0) {
			long intval = this.timerA;
			for (int i = 0; i < this.maxTransmit; i++) {
				intval *= 2;
			}
			timerB -= intval;
			this.maxTransmit++;
		}
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#doProcess(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void doProcess(MessageContext msg) {
		Logger.getGlobal().finest(msg,
				"INVITE Client Transaction: [" + this.state.toString() + "]");
		
		// Store TransactionInfo.
		if( this.getTransactionInfo() == null ) {
			this.setTransactionInfo(new TransactionInfoImpl(msg));
		}

		// Store To tag
		if (this.getTransactionInfo().getTagTo() == null) {
			SIPMessage sipMsg = (SIPMessage) msg
					.getCurrentMessageContextPacket().getFlatMessage()
					.getMessage();
			this.getTransactionInfo().setTagTo(sipMsg.getToTag());
			Logger.getGlobal().finer(
					msg,
					"INVITE Client Transaction: To tag is stored ("
							+ this.getTransactionInfo().getTagTo() + ")");
		}

		switch (this.state) {
		case NONE:
			onNONEState(msg);
			break;
		case CALLING:
			onCALLINGState(msg);
			break;
		case PROCEEDING:
			onPROCEEDINGState(msg);
			break;
		case COMPLETED:
			// do nothing
			break;
		case TERMINATED:
			// do nothing
			break;
		default:
			/*
			 * Invalid transaction state
			 */
			moveToTERMINATEDState();
			break;
		}

	}

	/**
	 * Initial state, move to CALLING state
	 * 
	 * @param msg
	 */
	private void onNONEState(MessageContext msg) {
		/*
		 * Check SIP INVITE request message or not.
		 */
		if ((msg.getCurrentMessageContextPacket().getFlatMessage().getMessage() instanceof SIPRequest) == false) {
			/*
			 * This message is not SIP request message.
			 */
			moveToDELETEState();
			return;
		}

		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		if (SIPRequest.INVITE.equals(sipReq.getMethod()) == false) {
			/*
			 * This message is not INVITE request message.
			 */
			moveToDELETEState();
			return;
		}

		this.nTransmit++;
		if (this.isReliable == false) {
			this.tStamp = System.currentTimeMillis() + this.timerA;
			this.tExpire = System.currentTimeMillis() + SIPTimer.getB();
		} else {
			this.tExpire = this.tStamp = System.currentTimeMillis()
					+ SIPTimer.getB();
		}

		/*
		 * Move to CALLING state
		 */
		moveToCALLINGState();
	}

	/**
	 * The process in CALLING state.
	 * 
	 * @param msg
	 */
	private void onCALLINGState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		if (sipMsg instanceof SIPRequest) {
			/*
			 * SIP request message
			 */
			SIPRequest sipReq = (SIPRequest) sipMsg;
			if (SIPRequest.INVITE.equals(sipReq.getMethod())) {
				/*
				 * This INVITE message is re-transmited. Stay in CALLING state.
				 */

			} else {
				/*
				 * other SIP reqeust message received
				 */
				moveToTERMINATEDState();
			}
		} else {
			/*
			 * SIP response message
			 */
			SIPResponse sipRsp = (SIPResponse) sipMsg;
			switch (sipRsp.getStatusCode() / 100) {
			case 0:
				/*
				 * XXX invalid response message was received. ignore it.
				 */
				break;
			case 1:
				/*
				 * 1XX response message was received. Move to PROCEEDING state.
				 */
				moveToPROCEEDINGState();
				break;
			case 2:
				/*
				 * 2XX response message was received. Move to TERMINATED state.
				 */
				moveToTERMINATEDState();
				break;
			default:
				/*
				 * 3XX-6XX response message was received. Move to COMPLETED
				 * state, and send ACK request message.
				 */
				moveToCOMPLETEDState();

				sendACKRequest(msg);
				break;
			}
		}
	}

	/**
	 * The process of PROCEEDING state.
	 * 
	 * @param msg
	 */
	private void onPROCEEDINGState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		if (sipMsg instanceof SIPResponse) {
			SIPResponse sipRsp = (SIPResponse) sipMsg;
			switch (sipRsp.getStatusCode() / 100) {
			case 0:
				/*
				 * XXX invalid response message was received. ignore it.
				 */
				break;
			case 1:
				/*
				 * 1XX response message was received. Stay in PROCEEDING state.
				 */
				break;
			case 2:
				/*
				 * 2XX response message was received. Move to TERMINATED state.
				 */
				moveToTERMINATEDState();
				break;
			default:
				/*
				 * 3XX-6XX response message was received. Move to COMPLETED
				 * state, and send ACK request message.
				 */
				moveToCOMPLETEDState();

				sendACKRequest(msg);
				break;
			}
		} else {
			/*
			 * XXX SIP request message
			 */
			moveToTERMINATEDState();
		}
	}

	/*
	 * Timer
	 */

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#fireTimer()
	 */
	public void fireTimer() {
		Logger.getGlobal().fine(
				null,
				"INVITE Client Transaction Timer Expired ["
						+ this.state.toString() + "]");

		switch (this.state) {
		case CALLING:
			fireCALLINGState();
			break;
		case PROCEEDING:
			firePROCEEDINGState();
			break;
		case COMPLETED:
			fireCOMPLETEDState();
			break;
		case TERMINATED:
			/*
			 * SIProp hack.
			 */
			fireTERMINATEDState();
			break;
		case NONE:
		default:
			break;
		}
	}

	/**
	 * The timer (Timer A) in CALLING state is expired. Re-Transmit INVITE
	 * request message.
	 * 
	 */
	private void fireCALLINGState() {
		if (this.isReliable == true || this.nTransmit >= this.maxTransmit) {
			/*
			 * Timer B was fired. Move to TERMINATED state.
			 */
			moveToTERMINATEDState();
			return;
		}

		// Re-Transmit INVITE
		this.nTransmit++;

		// Update Timer
		long intval = this.timerA;
		for (int i = 0; i < this.nTransmit; i++) {
			intval *= 2;
		}
		this.tStamp = System.currentTimeMillis() + intval;
	}

	/**
	 * The timer (Timer B) in PROCEEDING state is expired. Move to TERMINATED
	 * state. This behavior is not defined in RFC.
	 * 
	 */
	private void firePROCEEDINGState() {
		moveToTERMINATEDState();
	}

	/**
	 * The timer (Timer D) in COMPLETED state is expired. Move to TERMINATED
	 * state.
	 * 
	 */
	private void fireCOMPLETEDState() {
		moveToTERMINATEDState();
	}

	/**
	 * SIProp hack. The timer (Timer D) in TERMINATED state is expired. Move to
	 * DELETE state. This behavior is not defined in RFC3261.
	 * 
	 */
	private void fireTERMINATEDState() {
		moveToDELETEState();
	}

	/*
	 * Error Handling
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.core.transaction.TransactionEntry#onError()
	 */
	public void onError() {
		Logger.getGlobal().fine(
				null,
				"INVITE Client Transaction Error Occured ["
						+ this.state.toString() + "]");

		switch (this.state) {
		case NONE:
			break;
		case CALLING:
			onCALLINGError();
			break;
		case PROCEEDING:
			break;
		case COMPLETED:
			onCOMPLETEDError();
			break;
		case TERMINATED:
			break;
		default:
			break;
		}
	}

	/**
	 * An error is happened. Inform it to TU and move to TERMINATED state.
	 * 
	 */
	private void onCALLINGError() {
		// TODO Inform an error to TU, and send log message
		moveToTERMINATEDState();
	}

	/**
	 * An error is happened. Inform it to TU and move to TERMINATED state.
	 * 
	 */
	private void onCOMPLETEDError() {
		// TODO Inform an error to TU and send log message
		moveToTERMINATEDState();
	}

	/*
	 * Changing a state of transaction.
	 */

	/**
	 * Change to CALLING state The timer MUST be set at outside this method.
	 */
	private void moveToCALLINGState() {
		this.state = TransactionState.CALLING;
		Logger.getGlobal().fine(
				null,
				"INVITE Client Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * Change to PROCEEDING state and set Timer.
	 */
	private void moveToPROCEEDINGState() {
		Logger.getGlobal().fine(null,
				"INVITE Client Transaction: move to [PROCEEDING]");
		this.state = TransactionState.PROCEEDING;
		this.tStamp = this.tExpire;
		Logger.getGlobal().fine(
				null,
				"INVITE Client Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * Change to COMPLETED state and set Timer D.
	 */
	private void moveToCOMPLETEDState() {
		this.state = TransactionState.COMPLETED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getD();
		Logger.getGlobal().fine(
				null,
				"INVITE Client Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * SIProp hack. Change to TERMINATED state and set TimerD This behavior is
	 * not defined in RFC3261.
	 */
	private void moveToTERMINATEDState() {
		this.state = TransactionState.TERMINATED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getD();
		Logger.getGlobal().fine(
				null,
				"INVITE Client Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/**
	 * SIProp hack. Change to DELETE state and reset Timer. This state is not
	 * defined in RFC3261.
	 */
	private void moveToDELETEState() {
		this.state = TransactionState.DELETE;
		this.tStamp = 0;
		Logger.getGlobal().fine(
				null,
				"INVITE Client Transaction: move to [" + this.state.toString()
						+ "]");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.core.transaction.TransactionEntry#isTimerExpired(long)
	 */
	public boolean isTimerExpired(long currentTime) {
		if (this.tStamp == 0) {
			// There is no timer running.
			return false;
		} else if (currentTime >= this.tStamp) {
			// The Timer was expired.
			return true;
		} else {
			// Stay this state.
			return false;
		}
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionState()
	 */
	public TransactionState getTransactionState() {
		return this.state;
	}
	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionType()
	 */
	public TransactionType getTransactionType() {
		return this.type;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.core.transaction.TransactionEntry#getTransaction()
	 */
	public TransactionController getParentTransaction() {
		return this.parentTransaction;
	}

	/**
	 * send ACK request message if needed
	 * 
	 * @param msg
	 */
	private void sendACKRequest(MessageContext msg) {
		// TODO check sending ACK request or not.
		if (true) {
			// XXX currently, ACK request will not sent.
			return;
		}

		MessageContext ackReq = null;
		try {
			ackReq = this.createACK(
					msg,
					(SIPRequest) this.getTransactionInfo().getOriginalMessage()
							.getCurrentMessageContextPacket().getFlatMessage()
							.getMessage());
			if (ackReq == null) {
				return;
			}

			// TODO determin next layer
			StackControlMessage stackCtrlMsg = (StackControlMessage) ackReq
					.getCurrentMessageContextPacket().getControlMessage(
							getParentTransaction().getTU().getStackManager().getControlMessageName());
			if (stackCtrlMsg == null) {
				stackCtrlMsg = new StackControlMessageImpl();
			}
			stackCtrlMsg.getSendToKey().setSendTo(
					TransportManagerImpl.getInstance().getRouteKey());
			ackReq.getCurrentMessageContextPacket().addControlMessage(
					getParentTransaction().getTU().getStackManager().getControlMessageName(),
					stackCtrlMsg);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		this.parentTransaction.getTU().send(ackReq);
	}
	
	/**
	 * create SIP ACK request message from SIP response message and original SIP
	 * request messsage
	 * 
	 * @param rspMsg
	 *            SIP response message
	 * @param origReq
	 *            the original SIP Request message
	 * @return SIP ACK request message
	 * @throws SIPropException
	 */
	public MessageContext createACK(MessageContext rspMsg, SIPRequest origReq)
			throws SIPropException {
		if (rspMsg == null
				|| (rspMsg.getCurrentMessageContextPacket().getFlatMessage()
						.getMessage() instanceof SIPResponse) == false) {
			SIPropException e = new SIPropException("Invalid Argment");
			throw e;
		}

		MessageContext ackMsg = MessageContext.createMessageContext();
		MessageContextPacket rspPacket = MessageContextPacket
				.createMessageContextPacket();
		FlatMessage flatMsg = new FlatSIPMessage();

		SIPResponse sipRsp = (SIPResponse) rspMsg
				.getCurrentMessageContextPacket().getFlatMessage().getMessage();
		SIPRequest sipAck = origReq.createAckRequest((To) sipRsp.getTo());

		rspPacket.setFlatMessage(flatMsg);
		flatMsg.setMessage(sipAck);
		ackMsg.setMessageContextPacket(rspPacket);
		return ackMsg;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionInfo()
	 */
	public TransactionInfo getTransactionInfo() {
		return this.transactionInfo;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#setTransactionInfo(org.siprop.v2.stack.sip.transaction.TransactionInfo)
	 */
	public void setTransactionInfo(TransactionInfo transactionInfo) {
		this.transactionInfo = transactionInfo;
	}

}
