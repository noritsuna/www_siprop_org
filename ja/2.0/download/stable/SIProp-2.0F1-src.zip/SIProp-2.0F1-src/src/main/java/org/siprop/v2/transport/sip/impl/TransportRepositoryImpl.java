/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.impl;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.support.BaseIoAcceptorConfig;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.DatagramAcceptor;
import org.apache.mina.transport.socket.nio.DatagramAcceptorConfig;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;
import org.siprop.v2.core.Manager;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.core.router.impl.LayerEnum;
import org.siprop.v2.core.router.impl.MessageRouteKey;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.core.router.impl.MessageRouterInfo;
import org.siprop.v2.transport.sip.codec.impl.SipProtocolCodecFactory;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

/**
 * Repository for Transport.
 * 
 * @author noritsuna
 *
 */
public class TransportRepositoryImpl implements Repository {

	/**
	 * manager.
	 */
	private Manager manager = null;

	/**
	 * default binding IP address. "" means NULL binding
	 */
	private String localAddress = "0.0.0.0";

	/**
	 * default port number
	 */
	private int localPort = 5060;

	/**
	 * default transport protocol
	 */
	private int protocol = Peer.IPPROTO_UDP;

	/**
	 * Is IPv6 enable or not.
	 */
	private boolean enableIPv6 = true;

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#setup(org.siprop.v2.util.PropertiesDepot)
	 */
	public void setup(PropertiesDepot prop) {
		Logger.getGlobal().finest(null, "in TransportRepositoryImpl.create.");

		TransportManagerImpl transportManager = TransportManagerImpl.getInstance();
		this.manager = transportManager;

		// set ControlMessageName.
		this.manager.setControlMessageName("TransportControlMessage");

		// set LayerRoutingResolver.
		this.manager.setLayerResolver(LayerRoutingResolver.getInstance());

		// set UniKeyGenerator.
		this.manager.setUniKeyGenerator(null);

		// set router.
		RouteKey rtrKey = new MessageRouteKey();
		rtrKey.setRouteid("TransportManager");
		rtrKey.setRoutetype(LayerEnum.TRANSPORT);

		RouterInfo rtrInfo = new MessageRouterInfo();
		rtrInfo.setRouteKey(rtrKey);
		rtrInfo.addListener(transportManager);

		Router router = MessageRouter.getInstance();
		router.addRoute(rtrInfo);

		this.manager.setRouteKey(rtrKey);
		this.manager.setRouter(router);

		// create peer.
		String localAddress = this.getLocalAddress();
		Peer localPeer = null;

		try {
			localPeer = new Peer(this.getTransportProtocol(), InetAddress
					.getByName(localAddress), this.getLocalPort());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		// add IoAcceptor.
		IoAcceptor io = this.createTransportIo(localPeer, this.manager);
		if (io != null) {
			// Peer
			transportManager.addIoAcceptor(localPeer, io);
		}

	}

	/**
	 * create Transport IO(mina io handler version)
	 * 
	 * @param peer
	 */
	public IoAcceptor createTransportIo(Peer peer, Manager manager) {
		IoAcceptor acceptor = null;
		try {
			// TCP or UDP ?(tcp protocol number is 6. other UDP)
			acceptor = peer.getProtocol() == Peer.IPPROTO_TCP ? new SocketAcceptor()
					: new DatagramAcceptor();

			BaseIoAcceptorConfig cfg = peer.getProtocol() == Peer.IPPROTO_TCP ? new SocketAcceptorConfig()
					: new DatagramAcceptorConfig();

			// if necessary
			// cfg.setReuseAddress( true );
			cfg.getFilterChain().addLast("protocolFilter",
					new ProtocolCodecFilter(new SipProtocolCodecFactory()));

			// bind
			acceptor.bind(new InetSocketAddress(peer.getAddress(), peer
					.getPort()), new TransportIoHandler(manager), cfg);

			Logger.getGlobal().fine(
					null,
					"binding " + peer.getAddress().getHostAddress() + ":"
							+ peer.getPort());
		} catch (Exception ex) {
			Logger.getGlobal().warning(null, ex.getMessage());
		}
		return acceptor;
	}

	/**
	 * register start point of Transport to the MessageRouter
	 * 
	 * @param repository
	 *            configuration
	 */
	public void addRouter(Repository repository) {

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getRepository(org.siprop.v2.core.repository.RepositoryKey)
	 */
	public Repository getRepository(RepositoryKey key) {
		return this;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getManager()
	 */
	public Manager getManager() {
		return this.manager;
	}

	/**
	 * get local binding address
	 */
	public String getLocalAddress() {
		return this.localAddress;
	}

	/**
	 * get local port number
	 * 
	 * @return local port number
	 */
	public int getLocalPort() {
		return this.localPort;
	}

	/**
	 * get transport protocol
	 */
	public int getTransportProtocol() {
		return this.protocol;
	}

	/**
	 * check enable IPv6 or not.
	 * 
	 * @return enable IPv6 or not.
	 */
	public boolean isEnableIPv6() {
		return this.enableIPv6;
	}
}
