/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua;

import org.siprop.v2.core.messge.ControlMessage;
import org.siprop.v2.ua.util.impl.CommandName;

/**
 * ControlMessage for UA.
 * 
 * @author noritsuna
 * 
 */
public interface UAControlMessage extends ControlMessage {


	/**
	 * get key for message routing.
	 * 
	 * @return exec method
	 */
	public CommandName getExecMethod();

	/**
	 * set key for routing a message.
	 * 
	 * @param commandName command name
	 */
	public void setExecMethod(CommandName commandName);

}
