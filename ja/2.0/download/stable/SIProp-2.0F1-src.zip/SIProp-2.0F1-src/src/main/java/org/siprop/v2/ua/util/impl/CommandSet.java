/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.util.impl;

import java.lang.reflect.Method;

import org.siprop.v2.ua.UACommand;

/**
 * This class is which holds information required for a command as a group.
 * 
 * @author noritsuna
 * 
 */
public class CommandSet {

	/**
	 * instance of UACommand method.
	 */
	private Method commandMethod;

	/**
	 * instance of UACommand class.
	 */
	private UACommand uaCommandClass;

	/**
	 * Constructor
	 * 
	 */
	public CommandSet() {
	}

	/**
	 * get UACommand Method.
	 * 
	 * @return UACommand Method
	 */
	public Method getCommandMethod() {
		return commandMethod;
	}

	/**
	 * set UACommand Method.
	 * 
	 * @param commandMethod
	 *            UACommand Method
	 */
	public void setCommandMethod(Method commandMethod) {
		this.commandMethod = commandMethod;
	}

	/**
	 * get UACommand class.
	 * 
	 * @return UACommand class
	 */
	public UACommand getUaCommandClass() {
		return uaCommandClass;
	}

	/**
	 * set UACommand class.
	 * 
	 * @param uaCommandClass
	 *            UACommand class
	 */
	public void setUaCommandClass(UACommand uaCommandClass) {
		this.uaCommandClass = uaCommandClass;
	}

}
