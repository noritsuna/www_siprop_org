/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge.impl;

import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.header.Contact;
import gov.nist.javax.sip.header.HeaderFactoryImpl;
import gov.nist.javax.sip.header.RecordRoute;
import gov.nist.javax.sip.header.RecordRouteList;
import gov.nist.javax.sip.header.RouteList;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;
import gov.nist.javax.sip.parser.StringMsgParser;

import java.text.ParseException;
import java.util.Iterator;

import javax.sip.header.ContactHeader;
import javax.sip.header.ContentTypeHeader;
import javax.sip.header.Header;
import javax.sip.header.HeaderFactory;
import javax.sip.header.RecordRouteHeader;

import org.siprop.SIPropException;
import org.siprop.v2.util.impl.Logger;

/**
 * This class is a factory class for SIPMessage.
 * 
 * @author noritsuna
 * 
 */
public class SIPMessageFactory {

	/**
	 * message parser.
	 */
	private StringMsgParser sipParser = new StringMsgParser();

	/**
	 * header factory.
	 */
	private HeaderFactory headerFactory = new HeaderFactoryImpl();

	/**
	 * create RouteSet.
	 * 
	 * @param origRequest
	 * @param recordRouteList
	 * @param routeList
	 * @param contactURI
	 */
	public void createRouteSet(SIPRequest origRequest,
			RecordRouteList recordRouteList, RouteList routeList,
			SipUri contactURI) {

		recordRouteList = origRequest.getRecordRouteHeaders();
		if (recordRouteList != null) {
			// create contact header.
			ContactHeader contact = (Contact) origRequest.getContactHeaders()
					.getFirst();
			contactURI = (SipUri) contact.getAddress().getURI();

			// create route headers.
			for (Iterator iter = recordRouteList.iterator(); iter.hasNext();) {
				RecordRouteHeader record = (RecordRoute) iter.next();
				routeList.addFirst(this.headerFactory.createRouteHeader(record
						.getAddress()));
			}
		}
	}

	/**
	 * create new REGISTER request.
	 * 
	 * @param requestURI
	 * @param callID
	 * @param from
	 * @param to
	 * @param cseq
	 * @param branchid
	 * @param contact
	 * @param auth
	 * @param listenPeerStr
	 * @return new REGISTER request
	 * @throws SIPropException
	 */
	public SIPRequest createNewREGISTERRequest(String requestURI,
			String callID, String from, String to, Integer cseq,
			String branchid, String contact, String auth, String listenPeerStr)
			throws SIPropException {

		StringBuffer sb = new StringBuffer();

		sb.append("REGISTER ").append(requestURI).append(" SIP/2.0\r\n");
		sb.append("Call-ID: ").append(callID).append("\r\n");
		sb.append("Cseq: ").append(++cseq).append(" REGISTER\r\n");
		sb.append("Via: SIP/2.0/UDP ").append(listenPeerStr)
		// .append(";received=").append(messageContext.getListenPeerStr())
				.append(";branch=").append(branchid).append("\r\n");

		sb.append(from);
		sb.append(to);

		sb.append(contact);

		// create auth headers.
		if (auth != null && !auth.equals("")) {
			sb.append(auth);
		}

		// sb.append("Allow: ").append("INVITE,ACK,CANCEL,BYE\r\n");
		sb.append("Max-Forwards: 70\r\n");
		// sb.append("Content-Type: application/sdp\r\n");
		sb.append("Content-Length: ").append("0\r\n\r\n");

		try {
			return (SIPRequest) sipParser.parseSIPMessage(sb.toString());
		} catch (ParseException e) {
			throw new SIPropException(e);
		}

	}

	/**
	 * create new INVITE request.
	 * 
	 * @param requestURI
	 * @param callID
	 * @param from
	 * @param to
	 * @param cseq
	 * @param branchid
	 * @param contact
	 * @param auth
	 * @param listenPeerStr
	 * @param sdp
	 * @return new INVITE request
	 * @throws SIPropException
	 */
	public SIPRequest createNewINVITERequest(String requestURI, String callID,
			String from, String to, Integer cseq, String branchid,
			String contact, String auth, String listenPeerStr, String sdp)
			throws SIPropException {
		StringBuffer sb = new StringBuffer();

		sb.append("INVITE ").append(requestURI).append(" SIP/2.0\r\n");
		sb.append("Call-ID: ").append(callID).append("\r\n");
		sb.append("Cseq: ").append(++cseq).append(" INVITE\r\n");
		sb.append("Via: SIP/2.0/UDP ").append(listenPeerStr).append(";branch=")
				.append(branchid).append("\r\n");

		sb.append(from);
		sb.append(to);

		sb.append(contact);

		// 認証
		if (auth != null && !auth.equals("")) {
			sb.append(auth);
		}

		sb.append("Allow: ").append("INVITE,ACK,CANCEL,BYE\r\n");
		sb.append("Max-Forwards: 70\r\n");
		sb.append("Content-Type: application/sdp\r\n");
		sb.append(sdp);

		try {
			return (SIPRequest) sipParser.parseSIPMessage(sb.toString());
		} catch (ParseException e) {
			throw new SIPropException(e);
		}
	}

	/**
	 * create ACK request.
	 * 
	 * @param baseRequest
	 * @return ACK request
	 * @throws SIPropException
	 */
	public SIPRequest createACKRequest(SIPRequest baseRequest)
			throws SIPropException {

		SIPRequest sipRequest = baseRequest.createACKRequest();
		return sipRequest;
	}

	/**
	 * create CANCEL request.
	 * 
	 * @param baseRequest
	 * @return CANCEL request
	 * @throws SIPropException
	 */
	public SIPRequest createCANCLERequest(SIPRequest baseRequest)
			throws SIPropException {

		SIPRequest sipRequest = baseRequest.createCancelRequest();
		return sipRequest;
	}

	/**
	 * create BYE request.
	 * 
	 * @param baseRequest
	 * @param isUAC
	 * @return BYE request
	 * @throws SIPropException
	 */
	public SIPRequest createBYERequest(SIPRequest baseRequest, boolean isUAC)
			throws SIPropException {

		SIPRequest sipRequest = baseRequest.createBYERequest(!isUAC);
		return sipRequest;
	}

	/**
	 * create 100 Response.
	 * 
	 * @param baseRequest
	 * @return 100 Response
	 * @throws SIPropException
	 */
	public SIPResponse create100Renponse(SIPRequest baseRequest)
			throws SIPropException {
		return baseRequest.createResponse(100, "Trying");
	}

	/**
	 * create 1xx Response.
	 * 
	 * @param baseRequest
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param sdpBody
	 * @return 1xx Response
	 * @throws SIPropException
	 */
	public SIPResponse create1xxRenponse(SIPRequest baseRequest,
			int rensponseCode, String reasonPhrase, String sdpBody)
			throws SIPropException {

		SIPResponse sipResponse = baseRequest.createResponse(rensponseCode,
				reasonPhrase);

		// create SDP
		if (sdpBody != null) {
			ContentTypeHeader contentType;
			try {
				contentType = headerFactory.createContentTypeHeader(
						"application", "sdp");
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
			try {
				sipResponse.setContent(sdpBody, contentType);
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
		}
		return sipResponse;
	}

	/**
	 * create 2xx Response.
	 * 
	 * @param baseRequest
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param sdpBody
	 * @return 2xx Response
	 * @throws SIPropException
	 */
	public SIPResponse create2xxRenponse(SIPRequest baseRequest,
			int rensponseCode, String reasonPhrase, String sdpBody)
			throws SIPropException {

		SIPResponse sipResponse = baseRequest.createResponse(rensponseCode,
				reasonPhrase);

		// create SDP
		if (sdpBody != null) {
			ContentTypeHeader contentType;
			try {
				contentType = headerFactory.createContentTypeHeader(
						"application", "sdp");
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
			try {
				sipResponse.setContent(sdpBody, contentType);
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
		}

		return sipResponse;
	}

	/**
	 * create 4xx Response.
	 * 
	 * @param baseRequest
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param auth
	 * @return 4xx Response
	 * @throws SIPropException
	 */
	public SIPResponse create4xxRenponse(SIPRequest baseRequest,
			int rensponseCode, String reasonPhrase, Header auth)
			throws SIPropException {

		SIPResponse sipResponse = baseRequest.createResponse(rensponseCode,
				reasonPhrase);
		sipResponse.addHeader(auth);

		return sipResponse;
	}

	/**
	 * generate tag.
	 * 
	 * @return new tag.
	 */
	public String generateTag() {
		return SIPMessageFactory.generateUniID();
	}

	/**
	 * generate Call-ID.
	 * 
	 * @param host
	 *            host name
	 * @return new call-ID
	 */
	public String generateCallID(String host) {
		StringBuffer sb = new StringBuffer();
		sb.append(SIPMessageFactory.generateUniID());
		sb.append("@");
		sb.append(host);
		Logger.getGlobal().fine(null, "generateCallID:" + sb.toString());
		return sb.toString();
	}

	/**
	 * generate unique ID.
	 * 
	 * @return new Unique ID
	 */
	public static synchronized String generateUniID() {
		try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return String.valueOf(System.currentTimeMillis());
	}

}
