/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.router.impl;

import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.core.router.RouterListener;

/**
 * This info for MessageContext. 
 * 
 * @author nisato
 */
public class MessageRouterInfo implements RouterInfo {

	/**
	 * RouteKey.
	 */
	private RouteKey routekey;
	
	/**
	 * Listener.
	 */
	private RouterListener routerlistener;

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.RouterInfo#addListener(org.siprop.v2.core.router.RouterListener)
	 */
	public void addListener(RouterListener routerlistener) {
		this.routerlistener = routerlistener;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.RouterInfo#getRouteKey()
	 */
	public RouteKey getRouteKey() {
		return routekey;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.RouterInfo#setRouteKey(org.siprop.v2.core.router.RouteKey)
	 */
	public void setRouteKey(RouteKey routekey) {
		this.routekey = routekey;

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.RouterInfo#getListener()
	 */
	public RouterListener getListener() {
		return routerlistener;
	}

}
