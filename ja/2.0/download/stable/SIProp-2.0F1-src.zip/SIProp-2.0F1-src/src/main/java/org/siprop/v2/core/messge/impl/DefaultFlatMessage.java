package org.siprop.v2.core.messge.impl;

import org.siprop.v2.core.messge.FlatMessage;

/**
 * Default of FlatMessage.
 * 
 * @author noritsuna
 * 
 */
public abstract class DefaultFlatMessage implements FlatMessage {

	/**
	 * message object.
	 */
	Object message = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.messge.FlatMessage#getMessage()
	 */
	public Object getMessage() {
		return message;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.messge.FlatMessage#setMessage(java.lang.Object)
	 */
	public void setMessage(Object message) {
		this.message = message;
	}

}
