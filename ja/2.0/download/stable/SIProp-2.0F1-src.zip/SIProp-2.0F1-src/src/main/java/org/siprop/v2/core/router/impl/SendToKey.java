/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.router.impl;

import java.io.Serializable;

import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.util.resolver.ResolverKey;

/**
 * The key for message routing.
 * 
 * @author masaxmasa
 * 
 */
public class SendToKey implements ResolverKey, Serializable {

	/**
	 * This member indicates where the message was sent from.
	 */
	private RouteKey recvFrom = null;

	/**
	 * This member indicates where the message will be sent to.
	 */
	private RouteKey sendTo = null;

	/**
	 * Constructor.
	 * 
	 */
	public SendToKey() {
	}

	/**
	 * Constructor.
	 * 
	 * @param from　RouteKey indicating From
	 * @param to RouteKey indicating To
	 */
	public SendToKey(RouteKey from, RouteKey to) {
		this.recvFrom = from;
		this.sendTo = to;
	}

	/**
	 * get RouteKey indicating From.
	 * 
	 * @return from key
	 */
	public RouteKey getRecvFrom() {
		return this.recvFrom;
	}

	/**
	 * get RouteKey indicating To.
	 * 
	 * @return to key
	 */
	public RouteKey getSendTo() {
		return this.sendTo;
	}

	/**
	 * set RouteKey indicating From.
	 * 
	 * @param recvFrom from key
	 */
	public void setRecvFrom(RouteKey recvFrom) {
		this.recvFrom = recvFrom;
	}

	/**
	 * set RouteKey indicating To.
	 * 
	 * @param sendTo to key
	 */
	public void setSendTo(RouteKey sendTo) {
		this.sendTo = sendTo;
	}

	
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.util.resolver.ResolverKey#getRoutingKey()
	 */
	public Object getRoutingKey() {
		return sendTo;
	}

}
