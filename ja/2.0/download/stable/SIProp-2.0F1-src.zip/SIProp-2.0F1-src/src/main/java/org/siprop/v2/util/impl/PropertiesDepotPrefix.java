/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.impl;

import org.siprop.v2.util.PropertiesDepot;

/**
 * Add prefix for PropertiesDepot of getter,setter.
 * 
 * @author noritsuna
 * 
 */
public class PropertiesDepotPrefix implements PropertiesDepot {

	/**
	 * base PropertiesDepot.
	 */
	private PropertiesDepot prop = null;
	
	/**
	 * prefix.
	 */
	private String prefix = null;

	
	/**
	 * Constructor.
	 * 
	 * @param prop base PropertiesDepot
	 * @param prefix prefix
	 */
	public PropertiesDepotPrefix(PropertiesDepot prop, String prefix) {
		this.prop = prop;
		this.prefix = prefix;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#loadProperties(java.lang.String)
	 */
	public void loadProperties(String propertyPath) {
		this.prop.loadProperties(propertyPath);

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#setProperty(java.lang.String, java.lang.String)
	 */
	public void setProperty(String propertyName, String propertyValue) {
		this.prop.setProperty(prefix + "." + propertyName, propertyValue);

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#getProperty(java.lang.String)
	 */
	public String getProperty(String property) {
		return this.prop.getProperty(prefix + "." + property);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#storeProperties()
	 */
	public void storeProperties() {
		this.prop.storeProperties();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#processNewProperties(java.lang.String)
	 */
	public void processNewProperties(String propertyPath) {
		this.prop.processNewProperties(propertyPath);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#setup(org.siprop.v2.util.PropertiesDepot)
	 */
	public void setup(PropertiesDepot prop) {
	}

}
