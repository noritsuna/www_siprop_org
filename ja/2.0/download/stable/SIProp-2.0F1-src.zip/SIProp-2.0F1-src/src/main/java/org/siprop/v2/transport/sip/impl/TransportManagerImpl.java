/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.impl;

import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.IoSession;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.siprop.v2.core.DefaultManager;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.router.impl.LayerEnum;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.transport.TransportManager;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

/**
 * Transport manager (setup/auto create)
 * 
 * @author nisato
 * 
 */
public class TransportManagerImpl extends DefaultManager implements TransportManager {
	
	/**
	 * map of IoAcceptor.
	 */
	private Map<Peer, IoAcceptor> ioMap = null;
	
	/**
	 * instance.
	 */
	private static TransportManagerImpl instance = null;

	/**
	 * Constructor (Singlton design pattern)
	 * 
	 */
	private TransportManagerImpl() {
		super();
		this.ioMap = Collections
				.synchronizedMap(new HashMap<Peer, IoAcceptor>());
	}

	/**
	 * get instance of TransportManager
	 * 
	 * @return instance of TransportManager
	 */
	public static TransportManagerImpl getInstance() {
		if (instance == null) {
			instance = new TransportManagerImpl();
		}

		return instance;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.transport.TransportManager#addIoAcceptor(org.siprop.v2.util.impl.Peer, org.apache.mina.common.IoAcceptor)
	 */
	public void addIoAcceptor(Peer peer, IoAcceptor io) {
		if (!this.isBindingTransportIo(peer)) {
			this.ioMap.put(peer, io);
		}
	}

	/**
	 * binding peer or not? 
	 * 
	 * @param peer
	 * @return
	 */
	private boolean isBindingTransportIo(Peer peer) {
		if (ioMap.get(peer) == null) {
			return false;
		} else {
			return true;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.util.RouterListener#receive(org.siprop.message.MessageContext)
	 */
	public void receive(MessageContext messagecontext) {

		LayerRoutingResolver layerResolver = LayerRoutingResolver.getInstance();
		SendToKey sendKey = (SendToKey) layerResolver.resolve(messagecontext);

		if (sendKey == null) {
			Logger.getGlobal()
					.warning(messagecontext, "Don't get routing key.");
			return;
		}

		if (sendKey.getSendTo().getRoutetype() == LayerEnum.TRANSPORT) {
			this.sendNextPeer(messagecontext);
		} else {
			this.send(messagecontext);
		}

	}

	/**
	 * send to next peer.
	 * 
	 * @param messagecontext
	 */
	private void sendNextPeer(MessageContext messagecontext) {
		// どのTransportを使うかについては、MessageContextから取れる
		Peer remotepeer = messagecontext.getRemotePeer();
		Peer transpeer = messagecontext.getLocalPeer();

		if (transpeer == null) {
			/* TODO use default transport */
		}

		if (remotepeer == null) {
			/* TODO call some resolver */
		}

		IoAcceptor acceptor = (IoAcceptor) ioMap.get(transpeer);
		IoSession session = null;

		// TODO: 必要なトランスポートが見つからない場合は、createTransportIoして新しく作る
		if (acceptor == null) {
		}

		// TCPの場合、既にあるTCPセッションから取得
		if (acceptor instanceof SocketAcceptor) {
			session = (IoSession) acceptor
					.getManagedSessions(new InetSocketAddress(remotepeer
							.getAddress(), remotepeer.getPort()));

			// UDPの場合、新しく作る
		} else {
			session = acceptor.newSession(new InetSocketAddress(remotepeer
					.getAddress(), remotepeer.getPort()),
					new InetSocketAddress(transpeer.getAddress(), transpeer
							.getPort()));
		}

		if (session != null)
			session.write(messagecontext.getCurrentMessageContextPacket()
					.getFlatMessage()); // To Encoder
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.transport.TransportManager#tearDown(org.siprop.v2.util.impl.Peer)
	 */
	public void tearDown(Peer peer) {
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.RouterListener#send(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void send(MessageContext messagecontext) {
		this.getRouter().doRoute(messagecontext);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#doProcess(java.lang.String, java.lang.Object[])
	 */
	public void doProcess(String processName, Object[] param) {
	}

}
