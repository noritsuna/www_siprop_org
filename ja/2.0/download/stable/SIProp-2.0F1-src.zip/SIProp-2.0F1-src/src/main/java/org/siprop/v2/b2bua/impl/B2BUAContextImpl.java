package org.siprop.v2.b2bua.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.siprop.v2.b2bua.B2BUAContext;
import org.siprop.v2.b2bua.B2BUAInfo;
import org.siprop.v2.core.messge.impl.MessageContext;

/**
 * This class the dialog about a B2BUA.
 * 
 * @author noritsuna
 * 
 */
public class B2BUAContextImpl implements B2BUAContext {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4283476420959708229L;
	
	
	/**
	 * This list holds UAInfos.
	 */
	private List<B2BUAInfo> uaInfoList = Collections
			.synchronizedList(new ArrayList<B2BUAInfo>());
	/**
	 * This map holds UAInfos.
	 */
	private Map<String, B2BUAInfo> uaInfoMap = Collections
			.synchronizedMap(new HashMap<String, B2BUAInfo>());

	private List<B2BUAInfo> innerUAList = Collections
			.synchronizedList(new ArrayList<B2BUAInfo>());

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAContext#getOpposeUAInfos(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public List<B2BUAInfo> getOpposeUAInfos(MessageContext messageContext) {
		// TODO ちゃんと実装する。
		return this.innerUAList;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAContext#getSelfUAInfos(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public List<B2BUAInfo> getSelfUAInfos(MessageContext messageContext) {
		// TODO ちゃんと実装する。
		return this.innerUAList;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAContext#setUAInfo(java.lang.String, org.siprop.v2.b2bua.B2BUAInfo)
	 */
	public void setUAInfo(String key, B2BUAInfo uaSet) {
		B2BUAInfo ua = this.uaInfoMap.get(key);
		if (ua != null) {
			uaInfoList.remove(ua);
		}
		uaInfoMap.put(key, uaSet);
		uaInfoList.add(uaSet);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAContext#getUAInfo(java.lang.String)
	 */
	public B2BUAInfo getUAInfo(String key) {
		return this.uaInfoMap.get(key);
	}
	
}
