/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.codec.impl;

import gov.nist.javax.sip.parser.StringMsgParser;

import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.sip.message.Message;

import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.IoSession;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;
import org.apache.mina.filter.codec.demux.MessageDecoder;
import org.apache.mina.filter.codec.demux.MessageDecoderResult;

/**
 * MessageDecoder for SIP.<BR>
 * used by mina.
 * 
 * @author noritsuna
 *
 */
public class SipMessageDecoder implements MessageDecoder {

	/**
	 * Regex pattern for Content-Length.
	 */
	private static Pattern RegexContentLengthPattern = Pattern.compile("Content-Length\\s*:\\s*(\\d+)");
	
	/**
	 * Default CharsetDecoder.
	 */
	private CharsetDecoder decoder = Charset.defaultCharset().newDecoder();

	/**
	 * Constructor.
	 * 
	 */
	public SipMessageDecoder() {
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.filter.codec.demux.MessageDecoder#decodable(org.apache.mina.common.IoSession, org.apache.mina.common.ByteBuffer)
	 */
	public MessageDecoderResult decodable(IoSession session, ByteBuffer in) {
		try {
			return messageComplete(in) ? MessageDecoderResult.OK
					: MessageDecoderResult.NEED_DATA;
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return MessageDecoderResult.NOT_OK;
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.filter.codec.demux.MessageDecoder#decode(org.apache.mina.common.IoSession, org.apache.mina.common.ByteBuffer, org.apache.mina.filter.codec.ProtocolDecoderOutput)
	 */
	public MessageDecoderResult decode(IoSession session, ByteBuffer in,
			ProtocolDecoderOutput out) throws Exception {
		try {
			StringMsgParser parser = new StringMsgParser();
			Message msg = parser.parseSIPMessage(in.getString(decoder));
			out.write(msg);
		} catch (Exception exp) {
			System.out.println(exp.getMessage());
			return MessageDecoderResult.NOT_OK;
		}
		return MessageDecoderResult.OK;
	}

	/* (non-Javadoc)
	 * @see org.apache.mina.filter.codec.demux.MessageDecoder#finishDecode(org.apache.mina.common.IoSession, org.apache.mina.filter.codec.ProtocolDecoderOutput)
	 */
	public void finishDecode(IoSession arg0, ProtocolDecoderOutput arg1)
			throws Exception {
	}

	/**
	 * check end of Packet.
	 * 
	 * @param in Stream
	 * @return Packet complete is true.
	 * @throws Exception
	 */
	private boolean messageComplete(ByteBuffer in) throws Exception {
		int last = in.remaining();
		String msg = in.getString(decoder);

		// check "\r\n\r\n".
		int headp = msg.indexOf("\r\n\r\n");
		if (headp < 0)
			return false;

		// search Content-Length header.
		Matcher match = this.RegexContentLengthPattern.matcher(msg);
		int remains = 0;
		if (match.find()) {
			remains = Integer.parseInt(match.group(1));
		} else {
			return false;
		}

		// check Content-Length numbers.
		// remains + (\r\n\r\n).length + headp == last
		if (last == remains + 4 + headp)
			return true;
		
		return false;
	}

}
