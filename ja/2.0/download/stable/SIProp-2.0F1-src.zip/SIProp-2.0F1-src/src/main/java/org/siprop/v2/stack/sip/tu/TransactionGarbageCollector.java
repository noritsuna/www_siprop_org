/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu;

import java.util.List;

import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.TransactionState;
import org.siprop.v2.util.impl.Logger;

/**
 * This class check entire transactions. If the transaction has "delete"
 * statement, remove it.
 * 
 * @author masaxmasa
 * 
 */
public class TransactionGarbageCollector implements Runnable {

	/**
	 * instance of TU
	 */
	private TransactionUser tu = null;

	/**
	 * Polling interval
	 */
	private long intval = 0;

	/**
	 * list of Transactions
	 */
	private List<TransactionController> listTransactionCntroller = null;

	/**
	 * a flag to stop loop
	 */
	private boolean isTerminate = false;

	/**
	 * Constructor. Register instance of TUManager to notice remove event.
	 * 
	 * @param tu
	 *            nofify point of remove events.
	 */
	public TransactionGarbageCollector(TransactionUser tu) {
		this.tu = tu;
		this.intval = 500;
		this.listTransactionCntroller = this.tu.getTransactionControllerList();
	}

	/**
	 * Poll the list of transactions. If transaction that has "delete" state,
	 * notify it to TU.
	 */
	public void run() {
		this.isTerminate = false;
		Logger.getGlobal().fine(null,
				"start Garbage Collection for transactions interval=" + intval);

		while (true) {
			synchronized (this) {
				if (this.listTransactionCntroller.size() == 0) {
					Logger.getGlobal().fine(null,
							"There is no transaction entry: waiting...");
					try {
						wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Logger
							.getGlobal()
							.fine(null,
									"A new transaction entry is registered: start polling");
				}
			}

			try {
				Thread.sleep(this.intval);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			/*
			 * stop process
			 */
			if (this.isTerminate == true) {
				Logger.getGlobal().fine(null,
						"Terminating the garbage collector's process.");
				break;
			}

			long currentTime = System.currentTimeMillis();

			for (TransactionController trnsct : this.listTransactionCntroller) {
				List<TransactionEntry> childTrnsct = trnsct
						.getTransacitonList();
				if (childTrnsct == null || childTrnsct.size() == 0) {
					/*
					 * This transaction set has no transaction.
					 */
					if (trnsct.isInitialState() == false) {
						/*
						 * Because all child transactions are already deleted,
						 * this transaction will be deleted
						 */

						Logger.getGlobal().fine(
								null,
								"remove a transaction group getTransactionKey="
										+ trnsct.getUniKey());
						
						//TODO bat implement. key must be TransactionUser.getUniKey()!!!!
						tu.getStackManager().unregisterTransactionUser(trnsct.getUniKey());
						this.listTransactionCntroller.remove(trnsct);
					}
					continue;
				}

				for (TransactionEntry trnsctEntry : childTrnsct) {
					if (trnsctEntry.getTransactionState() == TransactionState.DELETE) {
						/*
						 * This Transaction Entry will be deleted.
						 */

						Logger.getGlobal().fine(
								null,
								"remove a transaction entry UniKey()="
										+ trnsct.getUniKey() + " Method="
										+ trnsctEntry.getTransactionInfo().getMethod());
						childTrnsct.remove(trnsctEntry);
					} else if (trnsctEntry.isTimerExpired(currentTime)) {
						/*
						 * The timer was fired.
						 */
						Logger.getGlobal().fine(
								null,
								"timer expired: UniKey()=" + trnsct.getUniKey()
										+ " Method="
										+ trnsctEntry.getTransactionInfo().getMethod());
						trnsctEntry.fireTimer();
					}
				}
			}
		}
	}

	/**
	 * Stop polling process
	 * 
	 */
	public void stop() {
		this.isTerminate = true;
	}

}
