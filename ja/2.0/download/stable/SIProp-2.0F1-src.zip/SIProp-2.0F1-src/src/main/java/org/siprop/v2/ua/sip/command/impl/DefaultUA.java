/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.command.impl;

import org.siprop.v2.b2bua.B2BUAControlMessage;
import org.siprop.v2.b2bua.sip.impl.B2BUAControlMessageImpl;
import org.siprop.v2.b2bua.sip.impl.B2BUAManagerImpl;
import org.siprop.v2.b2bua.sip.module.impl.AsteriskB2BUA;
import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.messge.impl.MessageContextPacket;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.ua.UACommand;
import org.siprop.v2.ua.UAContext;
import org.siprop.v2.ua.sip.impl.UAManagerImpl;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

/**
 * UACommand of Default.
 * 
 * @author noritsuna
 * 
 */
public class DefaultUA implements UACommand {

	/**
	 * UACommand name.
	 */
	public static final String UA_COMMAND_NAME = "Default";

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.ua.UACommand#getUACommandName()
	 */
	public String getUACommandName() {
		return UA_COMMAND_NAME;
	}

	/**
	 * Initial command.
	 * 
	 * @param messageContext
	 * @param uaContext
	 */
	public void do_Default_init(MessageContext messageContext,
			UAContext uaContext) {
		Logger.getGlobal().fine(messageContext,
				"in DefaultUA.do_Default_init().");

		MessageContextPacket newPacket = MessageContextPacket
				.copyMessageContextPacket(messageContext
						.getCurrentMessageContextPacket());

		SendToKey sendToKey = new SendToKey(UAManagerImpl.getInstance()
				.getRouteKey(), B2BUAManagerImpl.getInstance().getRouteKey());
		LayerRoutingResolver.getInstance().setKey(newPacket, sendToKey);

		B2BUAControlMessage b2bctrl = new B2BUAControlMessageImpl();
		b2bctrl.setDoModuleName(AsteriskB2BUA.MODULE_NAME);
		newPacket.addControlMessage(B2BUAManagerImpl.DEFAULT_MODULE_NAME, b2bctrl);

		messageContext.setMessageContextPacket(newPacket);

	}
}
