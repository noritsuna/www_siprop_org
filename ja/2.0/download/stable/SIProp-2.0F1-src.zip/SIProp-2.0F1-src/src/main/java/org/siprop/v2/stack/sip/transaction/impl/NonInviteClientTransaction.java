/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.sip.transaction.SIPTimer;
import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.TransactionInfo;
import org.siprop.v2.stack.sip.transaction.TransactionState;
import org.siprop.v2.stack.sip.transaction.TransactionType;
import org.siprop.v2.util.impl.Logger;

/**
 * The state machine for Non-INVITE Client Transaction<BR>
 * According to RFC3261 Figure 6: non-INVITE client transaction
 * 
 * <PRE>
 *                           |Request from TU
 *                           |send request
 *       Timer E             V
 *       send request  +-----------+
 *           +---------|           |-------------------+
 *           |         |  Trying   |  Timer F          |
 *           +--------&gt;|           |  or Transport Err.|
 *                     +-----------+  inform TU        |
 *        200-699         |  |                         |
 *        resp. to TU     |  |1xx                      |
 *        +---------------+  |resp. to TU              |
 *        |                  |                         |
 *        |   Timer E        V       Timer F           |
 *        |   send req +-----------+ or Transport Err. |
 *        |  +---------|           | inform TU         |
 *        |  |         |Proceeding |------------------&gt;|
 *        |  +--------&gt;|           |-----+            
 *        |            +-----------+     |1xx          |
 *        |              |      &circ;        |resp to TU   |
 *        | 200-699      |      +--------+             |
 *        | resp. to TU  |                             |
 *        |              |                             |
 *        |              V                             |
 *        |            +-----------+                   |
 *        |            |           |                   |
 *        |            | Completed |                   |
 *        |            |           |                   |
 *        |            +-----------+                   |
 *        |              &circ;   |                         |
 *        |              |   | Timer K                 |
 *        +--------------+   | -                       |
 *                           |                         |
 *                           V                         |
 *     NOTE:           +-----------+                   |
 *                     |           |                   |
 * transitions         | Terminated|&lt;------------------+
 * labeled with        |           |
 * the event           +-----------+
 * over the action
 * to take
 * </PRE>
 * 
 * @author masaxmasa
 * 
 */
public class NonInviteClientTransaction implements TransactionEntry {

	/**
	 * state of this transaction
	 */
	private TransactionState state = null;

	/**
	 * Next expire time, if timer is running. 0 means that there is no timer in
	 * current state.
	 */
	private long tStamp = 0;

	/**
	 * The lifetime for this transaction.
	 */
	private long tExpire = 0;

	/**
	 * counter for the request message transmited.
	 */
	private int nTransmit = 0;

	/**
	 * max number of transmitting the request message.
	 */
	private int maxTransmit = 0;

	/**
	 * Value of Timer E
	 */
	private long timerE = 0;

	/**
	 * Value of Timer T2
	 */
	private long timerT2 = 0;

	/**
	 * Is reliable transport or not.
	 */
	private boolean isReliable = false;

	/**
	 * Type of transaction
	 */
	private final TransactionType type = TransactionType.TRANSACTIONTYPE_NONINV_UAC;

	/**
	 * parent Transaction object of this entry
	 */
	private TransactionController parentTransaction = null;
	
	/**
	 * TransactionInfo.
	 */
	private TransactionInfo transactionInfo = null;

	/**
	 * Constructor. Set Initial Transaction State
	 * 
	 * @param isReliable
	 *            Using reliable transport or not.
	 */
	public NonInviteClientTransaction(TransactionController parent, boolean isReliable) {
		// set Initial State
		this.state = TransactionState.NONE;
		this.tStamp = 0;
		this.isReliable = isReliable;
		this.maxTransmit = 1;
		this.timerE = SIPTimer.getE();
		this.timerT2 = SIPTimer.getT2();
		long timerF = SIPTimer.getF();
		this.parentTransaction = parent;

		while (timerF > 0) {
			long intval = 0;
			if (this.maxTransmit < 3) {
				intval = this.timerE * this.maxTransmit;
				if (intval > this.timerT2) {
					intval = this.timerT2;
				}
			} else {
				intval = this.timerE * 4;
				if (intval > this.timerT2) {
					intval = this.timerT2;
				}
			}

			timerF -= intval;
			this.maxTransmit++;
		}
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#doProcess(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void doProcess(MessageContext msg) {
		Logger.getGlobal().finest(
				msg,
				"Non-INVITE Client Transaction: [" + this.state.toString()
						+ "]");

		switch (this.state) {
		case NONE:
			onNONEState(msg);
			break;
		case TRYING:
			onTRYINGState(msg);
			break;
		case PROCEEDING:
			onPROCEEDINGState(msg);
			break;
		case COMPLETED:
			// do nothing
			break;
		case TERMINATED:
			// do nothing
			break;
		default:
			/*
			 * Invalid transaction state
			 */
			moveToTERMINATEDState();
			break;
		}
	}

	/**
	 * Initial state, move to TRYING state
	 * 
	 * @param msg
	 */
	private void onNONEState(MessageContext msg) {
		/*
		 * Check SIP request message or not.
		 */
		if ((msg.getCurrentMessageContextPacket().getFlatMessage().getMessage() instanceof SIPRequest) == false) {
			/*
			 * This message is not SIP request message.
			 */
			moveToDELETEState();
			return;
		}

		SIPRequest sipReq = (SIPRequest) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();
		if (SIPRequest.INVITE.equals(sipReq.getMethod()) == true) {
			/*
			 * This message is INVITE request message.
			 */
			moveToDELETEState();
			return;
		} else if (SIPRequest.ACK.equals(sipReq.getMethod()) == true) {
			/*
			 * SIProp hack The transaction doesn't handle ACK Request message.
			 */
			moveToDELETEState();
			return;
		}

		this.nTransmit++;
		if (this.isReliable == false) {
			this.tStamp = System.currentTimeMillis() + this.timerE
					* this.nTransmit;
			this.tExpire = System.currentTimeMillis() + SIPTimer.getF();
		} else {
			this.tExpire = this.tStamp = System.currentTimeMillis()
					+ SIPTimer.getF();
		}

		/*
		 * Store parameters
		 */
		if(this.getTransactionInfo() == null) {
			this.setTransactionInfo(new TransactionInfoImpl(msg));
		}

		// To tag
		this.getTransactionInfo().setTagTo(sipReq.getToTag());

		moveToTRYINGState();
	}

	/**
	 * the process in TRYING state.
	 * 
	 * @param msg
	 */
	private void onTRYINGState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();

		if (sipMsg instanceof SIPResponse) {
			/*
			 * SIP response message
			 */
			SIPResponse sipRsp = (SIPResponse) sipMsg;
			switch (sipRsp.getStatusCode() / 100) {
			case 0:
				/*
				 * XXX invalid response message was received. ignore it.
				 */
				break;
			case 1:
				/*
				 * 1XX response message was received. Move to PROCEEDING state.
				 */
				moveToPROCEEDINGState();
				break;
			case 2:
				/*
				 * 2XX response message was received. Move to COMPLETED state
				 */
				moveToCOMPLETEDState();
				break;
			default:
			}
		} else {
			/*
			 * re-transmitted SIP request message
			 */
		}
	}

	/**
	 * the process in PROCEEDING state.
	 * 
	 * @param msg
	 */
	private void onPROCEEDINGState(MessageContext msg) {
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage();

		if (sipMsg instanceof SIPResponse) {
			/*
			 * SIP response message
			 */
			SIPResponse sipRsp = (SIPResponse) sipMsg;
			switch (sipRsp.getStatusCode() / 100) {
			case 0:
				/*
				 * XXX invalid response message was received. ignore it.
				 */
				break;
			case 1:
				/*
				 * 1XX response message was received. Stay in PROCEEDING state.
				 */
				this.tStamp = this.tExpire;
				break;
			default:
				/*
				 * Final response message was received. Move to COMPLETED state.
				 */
				moveToCOMPLETEDState();
				break;
			}
		} else {
			/*
			 * SIP request message
			 */
		}
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#fireTimer()
	 */
	public void fireTimer() {
		Logger.getGlobal().finest(
				null,
				"Non-INVITE Client Transaction: Timer Expired ["
						+ this.state.toString() + "]");

		switch (this.state) {
		case TRYING:
			fireTRYINGState();
			break;
		case PROCEEDING:
			firePROCEEINGState();
			break;
		case COMPLETED:
			fireCOMPLETEDState();
			break;
		case TERMINATED:
			/*
			 * SIProp hack.
			 */
			fireTERMINATEDState();
			break;
		case NONE:
		default:
			break;
		}

	}

	/**
	 * The timer (Timer E) in TRYING state is expired. Re-Transmit request
	 * message.
	 */
	private void fireTRYINGState() {
		if (this.nTransmit > this.maxTransmit) {
			/*
			 * Timer F wqs fired. Move to TERMINATED state.
			 */
			moveToTERMINATEDState();
			return;
		}

		/*
		 * Timer E was expired. Re-transmit request message.
		 */
		this.nTransmit++;

		// Update Timer
		long intval = 0;
		if (this.nTransmit < 3) {
			intval = this.timerE * this.nTransmit;
		} else {
			intval = this.timerE * 4;
		}

		if (this.timerT2 > intval) {
			this.tStamp = System.currentTimeMillis() + intval;
		} else {
			this.tStamp = System.currentTimeMillis() + this.timerT2;
		}
	}

	/**
	 * The timer (Timer E or Timer F) in PROCEEDING state is expired.
	 * 
	 */
	private void firePROCEEINGState() {
		if (this.tStamp >= this.tExpire || this.isReliable == true
				|| this.nTransmit >= this.maxTransmit) {
			/*
			 * Timer F was fired. Move to TERMINATED state.
			 */
			moveToTERMINATEDState();
			return;
		}

		/*
		 * Timer E was expired. Re-transmit request message.
		 */
		this.nTransmit++;

		// Update Timer
		long intval = 0;
		if (this.nTransmit < 3) {
			intval = this.timerE * this.nTransmit;
		} else {
			intval = this.timerE * 4;
		}

		if (intval > this.timerT2) {
			intval = this.timerT2;
		}
		this.tStamp = System.currentTimeMillis() + intval;
	}

	/**
	 * The timer (Timer K) in COMPLETED state is expired. Move to TERMINATED
	 * state.
	 */
	private void fireCOMPLETEDState() {
		moveToTERMINATEDState();
	}

	/**
	 * SIProp hack. The timer (Timer D) in TERMINATE state is expired. Move to
	 * DELETE state. This behavior is not defined in RFC3261.
	 */
	private void fireTERMINATEDState() {
		moveToDELETEState();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.core.transaction.TransactionEntry#onError()
	 */
	public void onError() {
		Logger.getGlobal().finest(
				null,
				"Non-INVITE Client Transaction: Error Occured ["
						+ this.state.toString() + "]");

		switch (this.state) {
		case NONE:
			break;
		case TRYING:
			break;
		case PROCEEDING:
			onPROCEEDINGError();
			break;
		case COMPLETED:
			onCOMPLETEDError();
			break;
		case TERMINATED:
			break;
		default:
			break;
		}
	}

	/**
	 * An error is happened. Inform it to TU and move to TERMINATED state.
	 * 
	 */
	private void onPROCEEDINGError() {
		// TODO Inform an error to TU and send log message
		moveToTERMINATEDState();
	}

	/**
	 * An error is happened. Inform it to TU and move to TERMINATED state.
	 * 
	 */
	private void onCOMPLETEDError() {
		// TODO Inform an error to TU and send log message
		moveToTERMINATEDState();
	}

	/**
	 * Change to TRYING state. The timer MUST be set at outside this method.
	 */
	private void moveToTRYINGState() {
		this.state = TransactionState.TRYING;
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Client Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * Change to PROCEEDING state. The timer MUST be set at outside this method.
	 * 
	 */
	private void moveToPROCEEDINGState() {
		this.state = TransactionState.PROCEEDING;
		this.tStamp = this.timerE;
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Client Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * Change to COMPLETED state and set Timer K.
	 * 
	 */
	private void moveToCOMPLETEDState() {
		this.state = TransactionState.COMPLETED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getK();
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Client Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * SIProp hack. Change to TERMINATED state and set Timer D. This behavior is
	 * not defined in RFC3261.
	 * 
	 */
	private void moveToTERMINATEDState() {
		this.state = TransactionState.TERMINATED;
		this.tStamp = System.currentTimeMillis() + SIPTimer.getD();
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Client Transaction: move to ["
						+ this.state.toString() + "]");
	}

	/**
	 * SIProp hack. Change to DELETE state and reset a timer. This state is not
	 * defined in RFC3261.
	 * 
	 */
	private void moveToDELETEState() {
		this.state = TransactionState.DELETE;
		this.tStamp = 0;
		Logger.getGlobal().fine(
				null,
				"Non-INVITE Client Transaction: move to ["
						+ this.state.toString() + "]");
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#isTimerExpired(long)
	 */
	public boolean isTimerExpired(long currentTime) {
		if (this.tStamp == 0) {
			// There is no timer running.
			return false;
		} else if (currentTime >= this.tStamp) {
			// The timer was expired.
			return true;
		} else {
			// Stay this state.
			return false;
		}
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionState()
	 */
	public TransactionState getTransactionState() {
		return this.state;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionType()
	 */
	public TransactionType getTransactionType() {
		return this.type;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getParentTransaction()
	 */
	public TransactionController getParentTransaction() {
		return this.parentTransaction;
	}
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#getTransactionInfo()
	 */
	public TransactionInfo getTransactionInfo() {
		return this.transactionInfo;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionEntry#setTransactionInfo(org.siprop.v2.stack.sip.transaction.TransactionInfo)
	 */
	public void setTransactionInfo(TransactionInfo transactionInfo) {
		this.transactionInfo = transactionInfo;
	}


}
