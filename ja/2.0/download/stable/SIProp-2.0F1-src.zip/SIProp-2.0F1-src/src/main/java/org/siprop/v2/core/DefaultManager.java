/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core;

import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.util.Discriminator;
import org.siprop.v2.util.resolver.impl.LayerRoutingResolver;

/**
 * Interface of Router entry point.
 * 
 * @author noritsuna
 * 
 */
public abstract class DefaultManager implements Manager {

	/**
	 * send & recv router.
	 */
	protected Router router = null;

	/**
	 * Uni key generator.
	 */
	protected Discriminator uniKeyGenerator = null;

	/**
	 * LayerRoutingResolver
	 */
	protected LayerRoutingResolver layerResolver = null;

	/**
	 * controlMessageName
	 */
	protected String controlMessageName = null;

	/**
	 * RouteKey
	 */
	protected RouteKey routeKey = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setRouter(org.siprop.v2.core.router.Router)
	 */
	public void setRouter(Router router) {
		this.router = router;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getUniKeyGenerator()
	 */
	public Discriminator getUniKeyGenerator() {
		return uniKeyGenerator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setUniKeyGenerator(org.siprop.v2.util.Discriminator)
	 */
	public void setUniKeyGenerator(Discriminator uniKeyGenerator) {
		this.uniKeyGenerator = uniKeyGenerator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getLayerResolver()
	 */
	public LayerRoutingResolver getLayerResolver() {
		return layerResolver;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setLayerResolver(org.siprop.v2.util.resolver.impl.LayerRoutingResolver)
	 */
	public void setLayerResolver(LayerRoutingResolver layerResolver) {
		this.layerResolver = layerResolver;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getRouter()
	 */
	public Router getRouter() {
		return router;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getControlMessageName()
	 */
	public String getControlMessageName() {
		return controlMessageName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setControlMessageName(java.lang.String)
	 */
	public void setControlMessageName(String controlMessageName) {
		this.controlMessageName = controlMessageName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getRouteKey()
	 */
	public RouteKey getRouteKey() {
		return routeKey;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setRouteKey(org.siprop.v2.core.router.RouteKey)
	 */
	public void setRouteKey(RouteKey routeKey) {
		this.routeKey = routeKey;
	}

}
