package org.siprop.v2.stack.sip.transaction.impl;

import gov.nist.javax.sip.message.SIPRequest;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.stack.sip.transaction.TransactionInfo;

/**
 * This class holds the packet about a Transaction.
 * 
 * @author noritsuna
 * 
 */
public class TransactionInfoImpl implements TransactionInfo {

	/**
	 * serialize key.
	 */
	private static final long serialVersionUID = -3523639417741177851L;

	/**
	 * The message originated this transaction.
	 */
	private MessageContext originalMsg = null;

	/**
	 * Via branch value
	 */
	private String branch;

	/**
	 * To tag value
	 */
	private String tagTo = null;

	
	/**
	 * Constructor.
	 * 
	 * @param originalMessage
	 */
	public TransactionInfoImpl(MessageContext originalMessage) {
		this.originalMsg = originalMessage;
		
	}
	

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#setViaBranch(java.lang.String)
	 */
	public void setViaBranch(String branch) {
		this.branch = branch;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getViaBranch()
	 */
	public String getViaBranch() {
		return this.branch;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getTagFrom()
	 */
	public String getTagFrom() {
		if (this.originalMsg == null) {
			return null;
		}

		return ((SIPRequest) (this.originalMsg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage())).getFromTag();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getTagTo()
	 */
	public String getTagTo() {
		return this.tagTo;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getCSeqNumber()
	 */
	public long getCSeqNumber() {
		if (this.originalMsg == null) {
			return -1;
		}

		return ((SIPRequest) (this.originalMsg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage())).getCSeq().getSeqNumber();
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#setTagTo(java.lang.String)
	 */
	public void setTagTo(String tag) {
		this.tagTo = tag;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getMethod()
	 */
	public String getMethod() {
		if (this.originalMsg == null) {
			return null;
		}

		return ((SIPRequest) (this.originalMsg.getCurrentMessageContextPacket()
				.getFlatMessage().getMessage())).getCSeq().getMethod();
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getOriginalMessage()
	 */
	public MessageContext getOriginalMessage() {
		return this.originalMsg;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#setOriginalMessage(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public void setOriginalMessage(MessageContext messageContext) {
		this.originalMsg = messageContext;		
	}

}
