/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.infoimpl;

import org.siprop.v2.ua.UAInfo;

/**
 * Default UAInfo for SIP.
 * 
 * @author noritsuna
 * 
 */
public class DefaultSIPUAInfo implements UAInfo {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = -5322768209928956427L;

}
