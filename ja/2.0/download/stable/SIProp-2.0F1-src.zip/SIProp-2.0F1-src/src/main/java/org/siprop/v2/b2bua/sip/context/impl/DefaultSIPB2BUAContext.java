/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip.context.impl;

import org.siprop.v2.b2bua.impl.B2BUAContextImpl;

/**
 * Default B2BUAContext for SIP.
 * 
 * @author noritsuna
 * 
 */
public class DefaultSIPB2BUAContext extends B2BUAContextImpl {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = 3735404818895346846L;

}
