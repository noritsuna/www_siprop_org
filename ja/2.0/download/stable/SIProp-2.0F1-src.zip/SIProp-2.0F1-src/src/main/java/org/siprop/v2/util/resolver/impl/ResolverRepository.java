/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.resolver.impl;

import java.util.ArrayList;
import java.util.List;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.util.Discriminator;
import org.siprop.v2.util.resolver.Resolver;
import org.siprop.v2.util.resolver.ResolverKey;

/**
 * Repository for Resolver.
 * 
 * @author noritsuna
 * 
 */
public class ResolverRepository implements Resolver {

	/**
	 * instance.
	 */
	private static Resolver INSTANCE = null;

	/**
	 * Discriminator of register IP address.
	 */
	private Discriminator regiDisc = new IPAddressDiscriminator();
	
	/**
	 * list of servers.
	 */
	private List<String> serverList = new ArrayList<String>();

	/**
	 * Constructor.
	 * 
	 */
	private ResolverRepository() {
	};

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.resolver.Resolver#resolve(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public ResolverKey resolve(MessageContext message) {
		return null;
	}

	/**
	 * set up.
	 * 
	 * @param repository
	 */
	public void setup(Repository repository) {

		Object[] keyList = new Object[3];

		regiDisc.generateKey(keyList);

	}

	/**
	 * get keys.
	 * 
	 * @return keys
	 */
	public List<String> getKeys() {
		return this.serverList;
	}

	/**
	 * get instance.
	 * 
	 * @return this instance
	 */
	public static Resolver getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new ResolverRepository();
		}
		return INSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.resolver.Resolver#setResolverKey(org.siprop.v2.util.resolver.ResolverKey)
	 */
	public void setResolverKey(ResolverKey resolverKey) {
		// TODO Auto-generated method stub
		
	}

}
