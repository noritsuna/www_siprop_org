/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.impl;

import java.io.Serializable;
import java.net.InetAddress;

/**
 * IP address, port, and protocol name.
 * 
 * @author noritsuna
 * 
 */
public class Peer implements Serializable {
	

	/**
	 * Serializable key.
	 */
	private static final long serialVersionUID = 2810453090595622407L;
	
	/**
	 * Protocol number.
	 */
	private int protocol;
	
	/**
	 * host address.
	 */
	private InetAddress host;
	
	/**
	 * port number.
	 */
	private int port;
	
	/**
	 * inner flag.
	 */
	private boolean isInner;

	/**
	 * Protocol number for TCP.
	 */
	public static final int IPPROTO_TCP = 6;
	
	/**
	 * Protocol number for UDP.
	 */
	public static final int IPPROTO_UDP = 17;

	/**
	 * Constructor.
	 * 
	 * @param protocol
	 * @param host
	 * @param port
	 */
	public Peer(int protocol, InetAddress host, int port) {
		this.protocol = protocol;
		this.host = host;
		this.port = port;
	}

	/**
	 * get hostname.
	 * 
	 * @return host information
	 */
	public InetAddress getHost() {
		return host;
	}

	/**
	 * get ip address.
	 * 
	 * @return ip address
	 */
	public InetAddress getAddress() {
		return host;
	}

	/**
	 * get port.
	 * 
	 * @return port number
	 */
	public int getPort() {
		return port;
	}

	/**
	 * get protocol number.
	 * 
	 * @return protocol number
	 */
	public int getProtocol() {
		return protocol;
	}

	/**
	 * check connection oriented protocol.
	 * 
	 * @return connection oriented protocol is true
	 */
	public boolean isConnectionOrientedProtocol() {
		switch (getProtocol()) {
		// case Transport.PROTO_TCP : return true;
		}
		return false;
	}

	/**
	 * get hash code.
	 * 
	 * @return hash code
	 */
	public int hashCode() {
		String host = "";
		if (getAddress() != null)
			host = getAddress().getHostAddress();

		String s = host + String.valueOf(getPort())
				+ String.valueOf(getProtocol());
		return s.hashCode();
	}

	/**
	 * equals.
	 * 
	 * @return equal is true
	 */
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof Peer))
			return false;

		Peer p = (Peer) obj;
		try {
			if (getAddress() == null && p.getAddress() == null) {
				return (getPort() == p.getPort() & getProtocol() == p
						.getProtocol());
			} else {
				return (getAddress().equals(p.getAddress())
						& getPort() == p.getPort() & getProtocol() == p
						.getProtocol());
			}
		} catch (NullPointerException ex) {
			ex.printStackTrace();
		}
		return false;
	}

	/**
	 * to protocol string.
	 * 
	 * @return protocol string
	 */
	public String toString() {
		return "{ protocol : " + getProtocol() + ", host : " + getHost()
				+ ", port : " + getPort() + "}";
	}

	/**
	 * inner flag.
	 * 
	 * @return inner is true
	 */
	public boolean isInner() {
		return this.isInner;
	}

	/**
	 * set inner flag.
	 * 
	 * @param isInner inner is true
	 */
	public void setInner(boolean isInner) {
		this.isInner = isInner;
	}
}
