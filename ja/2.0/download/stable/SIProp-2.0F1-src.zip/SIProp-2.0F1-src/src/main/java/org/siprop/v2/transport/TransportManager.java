/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport;

import org.apache.mina.common.IoAcceptor;
import org.siprop.v2.core.Manager;
import org.siprop.v2.util.impl.Peer;

/**
 * This interfece is Manager for Transport.
 * 
 * @author noritsuna
 *
 */
public interface TransportManager extends Manager {

	/**
	 * Add IoAcceptor.
	 * @param peer binding peer.
	 * @param io IoAcceptor
	 */
	public void addIoAcceptor(Peer peer, IoAcceptor io);
	
	/**
	 * Down IO
	 * 
	 * @param peer
	 */
	public void tearDown(Peer peer);

}
