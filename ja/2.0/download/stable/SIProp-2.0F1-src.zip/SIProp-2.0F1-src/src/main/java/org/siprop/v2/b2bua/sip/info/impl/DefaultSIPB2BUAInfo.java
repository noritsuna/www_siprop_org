/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip.info.impl;

import org.siprop.v2.b2bua.B2BUAInfo;
import org.siprop.v2.core.messge.impl.MessageContextPacket;

/**
 * Default B2BUAInfo for SIP.
 * 
 * @author noritsuna
 * 
 */
public class DefaultSIPB2BUAInfo implements B2BUAInfo {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = 4072824295405232849L;

	/**
	 * MessageContextPacket of previous.
	 */
	private MessageContextPacket previousMessageContextPacket = null;

	/**
	 * MessageContextPacket of current.
	 */
	private MessageContextPacket currentMessageContextPacket = null;

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAInfo#setNewMessageContextPacket(org.siprop.v2.core.messge.impl.MessageContextPacket)
	 */
	public void setNewMessageContextPacket(
			MessageContextPacket newMessageContextPacket) {
		this.previousMessageContextPacket = this.currentMessageContextPacket;
		this.currentMessageContextPacket = newMessageContextPacket;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAInfo#getPreviousMessageContextPacket()
	 */
	public MessageContextPacket getPreviousMessageContextPacket() {
		return previousMessageContextPacket;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAInfo#getCurrentMessageContextPacket()
	 */
	public MessageContextPacket getCurrentMessageContextPacket() {
		return currentMessageContextPacket;
	}
}
