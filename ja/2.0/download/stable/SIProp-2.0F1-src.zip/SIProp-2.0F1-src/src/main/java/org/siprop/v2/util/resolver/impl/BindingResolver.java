/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.resolver.impl;

import java.net.InetAddress;

import org.siprop.v2.core.messge.impl.MessageContext;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.Resolver;
import org.siprop.v2.util.resolver.ResolverKey;

/**
 * Returned Binding IPAddress.
 * 
 * @author noritsuna
 * 
 */
public class BindingResolver implements Resolver {

	/**
	 * instance.
	 */
	private static Resolver INSTANCE = null;
	
	/**
	 * binding IP address.
	 */
	private ResolverKey bindingIP;

	/**
	 * Constructor.
	 */
	private BindingResolver() {
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.resolver.Resolver#resolve(org.siprop.v2.core.messge.impl.MessageContext)
	 */
	public ResolverKey resolve(MessageContext message) {
		return bindingIP;
	}

	/**
	 * get instance.
	 * 
	 * @return this instance
	 */
	public static Resolver getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new BindingResolver();
		}
		return INSTANCE;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.resolver.Resolver#setResolverKey(org.siprop.v2.util.resolver.ResolverKey)
	 */
	public void setResolverKey(ResolverKey resolverKey) {
		this.bindingIP = resolverKey;
	}
	
	
	
	/**
	 * TODO to move.
	 * 
	 * @return binding peer
	 */
	public ResolverKey getBindingPeer() {
		try {
			Peer peer = new Peer(2, InetAddress.getLocalHost(), 5060);
			ResolverKey peerKey = new PeerKey(peer);
			return peerKey;
		} catch (Exception e) {
			Logger.getGlobal().warning(null, "Binding ResolverKey error.");
		}
		return null;
	}

}
