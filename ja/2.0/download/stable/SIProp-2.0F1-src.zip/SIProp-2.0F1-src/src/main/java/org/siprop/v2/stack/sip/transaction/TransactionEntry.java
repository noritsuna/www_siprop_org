/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction;

import org.siprop.v2.core.messge.impl.MessageContext;

/**
 * This interface is base of Transaction.
 * 
 * @author masaxmasa
 *
 */
public interface TransactionEntry {

	/**
	 * Process transaction, if need.
	 * 
	 * @param message
	 */
	public void doProcess(MessageContext message);

	/**
	 * Get current transaction status
	 * 
	 * @return current transaction status
	 */
	public TransactionState getTransactionState();

	/**
	 * Check the timer is expired or not.
	 * 
	 * @param currentTime
	 *            Current Time (msec)
	 * @return true: The timer is expired, false: The timer isn't expired
	 */
	public boolean isTimerExpired(long currentTime);

	/**
	 * The timer is expired, then start expired process
	 * 
	 */
	public void fireTimer();

	/**
	 * An error is happend, then start error handling process
	 * 
	 */
	public void onError();

	/**
	 * Get parent Transaction object of this entry
	 */
	public TransactionController getParentTransaction();

	/**
	 * Get type of transaction
	 */
	public TransactionType getTransactionType();
	
	/**
	 * set TransactionInfo.
	 * 
	 * @param transactionInfo
	 */
	public void setTransactionInfo(TransactionInfo transactionInfo);
	
	/**
	 * get TransactionInfo.
	 * 
	 * @return transaction information
	 */
	public TransactionInfo getTransactionInfo();


//	/**
//	 * get unique key.
//	 * 
//	 * @return
//	 */
//	public String uniKey();
//
//	/**
//	 * set unique key.
//	 * 
//	 * @return
//	 */
//	public void setUniKey(String uniKey);
}
