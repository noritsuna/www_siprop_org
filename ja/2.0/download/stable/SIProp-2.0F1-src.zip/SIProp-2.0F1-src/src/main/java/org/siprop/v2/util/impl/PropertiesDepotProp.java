/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

import org.siprop.v2.util.PropertiesDepot;

/**
 * Implement PropertiesDepot of used Properties.
 * 
 * @author noritsuna
 * 
 */
public class PropertiesDepotProp implements PropertiesDepot {

	/**
	 * Property config name.
	 */
	private final static String DEFAULT_CONFIGFILE = "siprop.properties";

	/**
	 * Property.
	 */
	private static Properties DEFAULT_PROP = new Properties();

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#loadProperties(java.lang.String)
	 */
	public void loadProperties(String propertyPath) {
		File configfile = new File(System.getProperty(propertyPath,
				DEFAULT_CONFIGFILE));

		if (configfile.canRead()) {
			try {
				// propertiesの読み出し
				DEFAULT_PROP.load(new FileInputStream(configfile));
			} catch (IOException e) {
				Logger.global.warning("Not load config file: "
						+ DEFAULT_CONFIGFILE);
			}
		} else {
			Logger.global
					.warning("Not load config file: " + DEFAULT_CONFIGFILE);
		}

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#getProperty(java.lang.String)
	 */
	public String getProperty(String property) {
		return DEFAULT_PROP.getProperty(property, null);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#setProperty(java.lang.String, java.lang.String)
	 */
	public void setProperty(String propertyName, String propertyValue) {
		DEFAULT_PROP.setProperty(propertyName, propertyValue);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#storeProperties()
	 */
	public void storeProperties() {
		DEFAULT_PROP.clear();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#processNewProperties(java.lang.String)
	 */
	public void processNewProperties(String propertyPath) {
		this.storeProperties();
		this.loadProperties(propertyPath);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.PropertiesDepot#setup(org.siprop.v2.util.PropertiesDepot)
	 */
	public void setup(PropertiesDepot prop) {
	}

}
