/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua;

import org.siprop.v2.core.messge.Context;

/**
 * Sequence(scripting) processing is described to this interface.
 * 
 * @author noritsuna
 * 
 */
public interface B2BUAModule {

	/**
	 * receive message.
	 * 
	 * @param context
	 */
	public void receive(Context context);

	/**
	 * send message.
	 * 
	 * @param context
	 */
	public void send(Context context);

	/**
	 * set delete flag.
	 * 
	 * @param flag
	 *            GC flag
	 */
	public void setDeleteFlag(boolean flag);

	/**
	 * get delete flag.<BR>
	 * This is used by GC.
	 * 
	 * @return GC flag
	 */
	public boolean getDeleteFlag();

	/**
	 * get The name which shows this module.
	 * 
	 * @return module name
	 */
	public String getModuleName();

	/**
	 * get manager of the call-back point.
	 * 
	 * @return manager of the call-back point.
	 */
	public B2BUAManager getCallBackManager();

	/**
	 * set manager of the call-back point.
	 * 
	 * @param callBackManager
	 *            manager of the call-back point.
	 */
	public void setCallBackManager(B2BUAManager callBackManager);

}
