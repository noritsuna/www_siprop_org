/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.command.impl;

import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.MessageContextPacket;
import org.siprop.v2.core.messge.impl.FlatSIPMessage;
import org.siprop.v2.core.messge.impl.MessageContextPacketImpl;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.ua.UACommand;
import org.siprop.v2.ua.UAContext;

/**
 * UACommand of Invite.
 * 
 * @author noritsuna
 * 
 */
public class InviteUA implements UACommand {

	/**
	 * UACommand name.
	 */
	public static final String UA_COMMAND_NAME = "Invite";
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.ua.UACommand#getUACommandName()
	 */
	public String getUACommandName() {
		return UA_COMMAND_NAME;
	}

	/**
	 * Initial command.
	 * 
	 * @param context
	 * @param uaContext
	 */
	public void do_Invite_init(Context context, UAContext uaContext) {

	}

	/**
	 * Receive 200 Response and processing.
	 * 
	 * @param context
	 * @param uaContext
	 */
	public void do_Invite_resp_200(Context context, UAContext uaContext) {

		// create new packet.
		MessageContextPacket newPacket = MessageContextPacketImpl
				.createMessageContextPacket();

		// set 200 response in packet.
		SIPRequest req = (SIPRequest) context.getCurrentPacket()
				.getFlatMessage().getMessage();
		SIPResponse sendMsg = req.createResponse(200);

		FlatMessage newFlatMessage = new FlatSIPMessage();
		newFlatMessage.setMessage(sendMsg);
		newPacket.setFlatMessage(newFlatMessage);

		// set send to route.
		SendToKey sendToKey = new SendToKey(RouteKeyResolver
				.resolve(LayerEnum.UA), RouteKeyResolver
				.resolve(LayerEnum.STACK));
		newPacket.setSendToKey(sendToKey);

		context.addPacket(newPacket);

	}
	
}
