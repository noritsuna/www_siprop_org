/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu.function;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;

/**
 * Functions for TU.
 * 
 * @author noritsuna
 *
 */
public interface TuFunction {
	/**
	 * Execute TuFunction.
	 * 
	 * @param context
	 *            the message will be processed
	 * @param trnsct
	 *            type of transaction that related the message
	 * @return MessageContextImpl
	 */
	public Context doProcess(Context context, TransactionEntry trnsct);

	/**
	 * Add TuFunction.
	 * 
	 * @param function
	 * @throws SIPropException
	 */
	public void addFunction(TuFunction function) throws SIPropException;

	/**
	 * Remove TuFunction.
	 * 
	 * @param function
	 * @throws SIPropException
	 */
	public void removeFunction(TuFunction function) throws SIPropException;

}
