/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.context.impl;

import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.header.RecordRouteList;
import gov.nist.javax.sip.header.RouteList;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.ua.UAControlMessage;
import org.siprop.v2.ua.impl.UAContextImpl;

/**
 * Default UAContext for SIP.
 * 
 * @author noritsuna
 * 
 */
public class DefaultSIPUAContext extends UAContextImpl {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = -3887064226526404333L;

	/**
	 * list of RecordRoute headers.
	 */
	protected RecordRouteList recordRouteList;

	/**
	 * list of Route headers.
	 */
	protected RouteList routeList;

	/**
	 * to tag.
	 */
	protected String toTag;

	/**
	 * Contact header.
	 */
	protected SipUri contactURI;

	/**
	 * This is UAC or not?
	 */
	protected boolean isUAC;

	/**
	 * Cseq counter.
	 */
	protected Integer cseq;

	/**
	 * SIPResponse of previous.
	 */
	protected SIPResponse prevResponse;

	/**
	 * SIPRequest of previous.
	 */
	protected SIPRequest prevRequest;


	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.ua.UAContext#exec(org.siprop.v2.core.messge.Context)
	 */
	public void exec(Context context) {
		// Check ControlMessage.
		UAControlMessage ctrlMessage = (UAControlMessage) context
				.getCurrentPacket().getControlMessage();
		if (ctrlMessage == null) {
			// throw new SIPropException("Not Found RegisterUA.");
			return;
		}

	}

	/**
	 * get list of RecordRoute headers.
	 * 
	 * @return list of RecordRoute headers
	 */
	public RecordRouteList getRecordRouteList() {
		return this.recordRouteList;
	}

	/**
	 * This is Route or not?
	 * 
	 * @return Route or not
	 */
	public boolean isRoute() {
		if (recordRouteList == null) {
			return false;
		}
		return true;
	}

	/**
	 * This is UAC or not?
	 * 
	 * @return UAC is true.
	 */
	public boolean isUAC() {
		return isUAC;
	}

}
