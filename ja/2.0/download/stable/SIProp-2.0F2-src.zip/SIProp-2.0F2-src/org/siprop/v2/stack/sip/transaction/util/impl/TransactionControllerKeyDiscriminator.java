/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction.util.impl;

import gov.nist.javax.sip.message.SIPMessage;

import org.siprop.v2.core.messge.MessageContext;
import org.siprop.v2.core.messge.impl.MessageContextImpl;
import org.siprop.v2.util.Discriminator;

/**
 * Discriminator for TransactionController.
 * 
 * @author noritsuna
 * 
 */
public class TransactionControllerKeyDiscriminator implements Discriminator {

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.Discriminator#generateKey(java.lang.Object)
	 */
	public Object generateKey(Object obj) {
		MessageContext msg = (MessageContextImpl)obj;
		SIPMessage sipMsg = (SIPMessage) msg.getCurrentPacket()
		.getFlatMessage().getMessage();

		return sipMsg.getCallId().getCallId();
	}

}
