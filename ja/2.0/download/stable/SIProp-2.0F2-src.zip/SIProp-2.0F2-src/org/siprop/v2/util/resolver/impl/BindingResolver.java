/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.resolver.impl;

import java.net.InetAddress;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.ResolverKey;

/**
 * Returned Binding IPAddress.
 * 
 * @author noritsuna
 * 
 */
public class BindingResolver {

	/**
	 * binding IP address.
	 */
	private ResolverKey bindingIP;

	/**
	 * Constructor.
	 */
	public BindingResolver() {
	}

	/**
	 * resolve ResolverKey.
	 * 
	 * @param context
	 * @return ResolverKey
	 */
	public ResolverKey resolve(Context context) {
		return bindingIP;
	}

	/**
	 * set ResolverKey.
	 * 
	 * @param resolverKey
	 */
	public void setResolverKey(ResolverKey resolverKey) {
		this.bindingIP = resolverKey;
	}
	
	
	
	/**
	 * TODO to move.
	 * 
	 * @return binding peer
	 */
	public ResolverKey getBindingPeer() {
		try {
			Peer peer = new Peer(2, InetAddress.getLocalHost(), 5060);
			ResolverKey peerKey = new PeerKey(peer);
			return peerKey;
		} catch (Exception e) {
			Logger.getGlobal().warning(null, "Binding ResolverKey error.");
		}
		return null;
	}

}
