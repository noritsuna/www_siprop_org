/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge.impl;

import org.siprop.v2.core.messge.AbstractContext;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.MessageContext;
import org.siprop.v2.core.messge.MessageContextInfo;
import org.siprop.v2.util.impl.Peer;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * This class is Context used for routing.
 * 
 * @author noritsuna
 * 
 */
public class MessageContextImpl extends AbstractContext implements MessageContext {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = 486093981903719657L;

	
	/**
	 * remotePeer
	 */
	private Peer remotePeer = null;
	
	/**
	 * localPeer
	 */
	private Peer localPeer = null;
	

	/**
	 * Constructor
	 * 
	 */
	private MessageContextImpl() {
	}

	/**
	 * create new MessageContext.
	 * 
	 * @return new MessageContext
	 */
	public static MessageContext createNewMessageContext() {
		MessageContext mc = new MessageContextImpl();
		mc.setInfo(new MessageContextInfoImpl());
		return mc;
	}

	/**
	 * copy MessageContextImpl.
	 * 
	 * @param me
	 *            MessageContextPacketImpl for a copy
	 * @return Copied MessageContextImpl
	 */
	public static MessageContext copyMessageContext(MessageContext me) {
		MessageContext mc = new MessageContextImpl();
		mc.setInfo(me.getInfo());
		mc.setLocalPeer(me.getLocalPeer());
		mc.setRemotePeer(me.getRemotePeer());
		mc.setCurrentPacket(me.getCurrentPacket());
		mc.setOriginalPacket(me.getOriginalPacket());

		return mc;
	}

	/**
	 * clone MessageContext.
	 * 
	 * @param context
	 *            Context for a clone
	 * @return Cloned MessageContext
	 */
	public static MessageContext cloneMessageContext(Context context) {
		throw new NotImplementedException();
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.MessageContext#getLocalPeer()
	 */
	public Peer getLocalPeer() {
		return localPeer;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.MessageContext#getRemotePeer()
	 */
	public Peer getRemotePeer() {
		return remotePeer;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.MessageContext#setLocalPeer(org.siprop.v2.util.impl.Peer)
	 */
	public void setLocalPeer(Peer localPeer) {
		this.localPeer = localPeer;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.MessageContext#setRemotePeer(org.siprop.v2.util.impl.Peer)
	 */
	public void setRemotePeer(Peer remotePeer) {
		this.remotePeer = remotePeer;
	}
	

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.MessageContext#isPacketEnd()
	 */
	public boolean isPacketEnd() {
		if(this.info == null) {
			return true;
		}
		if(this.info instanceof MessageContextInfo) {
			return ((MessageContextInfo)this.info).isPacketEnd();
		} else {
			return true;
		}
	}

}
