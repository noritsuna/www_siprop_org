/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util.resolver.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.util.Discriminator;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.ResolverKey;

/**
 * Resolver for REGISTER method.
 * 
 * @author noritsuna
 * 
 */
public class RegisterResolver {

	/**
	 * map of servers.
	 */
	private Map<String, String> serverMap = new HashMap<String, String>();

	/**
	 * Discriminator of register IP address.
	 */
	private Discriminator regiDisc = new IPAddressDiscriminator();

	/**
	 * Constructor.
	 * 
	 */
	public  RegisterResolver() {
	};


	/**
	 * resolve.
	 * 
	 * @param context
	 * @return ResolverKey
	 */
	public ResolverKey resolve(Context context) {
		return null;
	}

	
	/**
	 * set up.
	 * 
	 * @param repository
	 */
	public void setup(Repository repository) {

		ResolverRepository resoRepo = (ResolverRepository) repository;
		for (String key : resoRepo.getKeys()) {
			this.serverMap.put(key, key);
		}

	}

	/**
	 * get key.
	 * 
	 * @param context
	 * @return this key
	 */
	private String getKey(Context context) {

		// TODO ちゃんとセット！！！
		ResolverKey key;
		Peer peer;
		try {
			peer = new Peer(1, InetAddress.getLocalHost(), 5060);
			key = new PeerKey(peer);
		} catch (UnknownHostException e) {
			return null;
		}
		return (String) this.regiDisc.generateKey(peer);

	}

	/**
	 * set resolve key.
	 */
	public void setResolverKey(ResolverKey resolverKey) {
		// TODO Auto-generated method stub
		
	}

}
