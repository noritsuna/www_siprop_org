/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.siprop.SIPropException;
import org.siprop.v2.core.AbstractManager;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.MessageContext;
import org.siprop.v2.core.messge.MessageContextPacket;
import org.siprop.v2.core.messge.impl.FlatSIPMessage;
import org.siprop.v2.core.messge.impl.MessageContextImpl;
import org.siprop.v2.core.messge.impl.MessageContextPacketImpl;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.stack.StackControlMessage;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.tu.TransactionUser;
import org.siprop.v2.stack.sip.tu.util.impl.TransactionUserKeyDiscriminator;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.ManagerGarbageCollector;

/**
 * This class manages TUs. This class has entry point of SIP stack.
 * 
 * @author masaxmasa
 * 
 */
public class StackManagerImpl extends AbstractManager implements StackManager {

	/**
	 * to search TU by Call-ID
	 */
	private Map<String, TransactionUser> mapTU = null;

	/**
	 * TU list
	 */
	private List<TransactionUser> listTU = null;

	/**
	 * service name.
	 */
	private String serviceName = "sip";
	

	/**
	 * Constructor.
	 * 
	 */
	public StackManagerImpl() {
		super();
		this.mapTU = Collections
				.synchronizedMap(new HashMap<String, TransactionUser>());
		this.listTU = Collections
				.synchronizedList(new LinkedList<TransactionUser>());
		this.uniKeyGenerator = new TransactionUserKeyDiscriminator();
	}

	/**
	 * Register a TransactionUser to own list.
	 * 
	 * @param tu
	 */
	public void addTU(TransactionUser tu) {
		this.listTU.add(tu);
	}

	/**
	 * get UA by Context.
	 * 
	 * @param context
	 * @return
	 */
	private TransactionUser getTU(Context context) {
		return this.mapTU.get((String) this.uniKeyGenerator
				.generateKey(context));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Listener#onReceive(org.siprop.v2.core.messge.impl.MessageContextImpl)
	 */
	public void onReceive(Context context) {

		Logger.getGlobal().finest(context, "StackManager received a message");

		StackControlMessage stackCtrlMsg = (StackControlMessageImpl) context
				.getCurrentPacket().getControlMessage();
		if (stackCtrlMsg == null) {
			stackCtrlMsg = new StackControlMessageImpl();
			context.getCurrentPacket().setControlMessage(stackCtrlMsg);
		}

		/*
		 * Check previous layer
		 */
		SendToKey sendTOKey = context.getCurrentPacket().getSendToKey();
		if (sendTOKey == null) {
			Logger.getGlobal().info(context,
					"There is no Layer information: discarded");
			return;
		}

		RouteKey recvFromKey = sendTOKey.getRecvFrom();
		switch (recvFromKey.getRoutetype()) {
		case TRANSPORT:
			stackCtrlMsg.setIsUAC(context.getCurrentPacket().getFlatMessage()
					.getMessage() instanceof SIPResponse);
			break;
		case UA:
		case STACK:
			stackCtrlMsg.setIsUAC(context.getCurrentPacket().getFlatMessage()
					.getMessage() instanceof SIPRequest);
			break;
		default:
			Logger.getGlobal().info(context,
					"A message was received from unexpected layer.");
			break;
		}

		/*
		 * Check valid SIP message or not.
		 */
		if (isValidSIPMsg(context) == false) {
			/*
			 * discard this message
			 */
			Logger.getGlobal().info(context,
					"Invalid message was received: Discarded");
			return;
		}

		TransactionUser tu = selectTU(context);
		if (tu != null) {
			Logger.getGlobal().finest(context,
					"This message will be sent to " + tu.getClass().toString());
			tu.receive(context);
		} else {
			Logger.getGlobal().warning(context, "There is no valid TU Object.");
		}
	}

	/**
	 * Is valid SIP message or not.
	 * 
	 * @param context
	 *            message to validate
	 * @return true: valid, false: invalid
	 */
	private boolean isValidSIPMsg(Context context) {
		SIPMessage sipMsg = null;
		try {
			sipMsg = (SIPMessage) context.getCurrentPacket().getFlatMessage()
					.getMessage();
		} catch (ClassCastException e) {
			Logger.getGlobal().fine(context, "This message isn't SIPMessage.");
			return false;
		}

		/*
		 * Check From, To, Call-ID and CSeq header are presented or not.
		 */
		if (sipMsg.hasHeader("From") == false
				|| sipMsg.hasHeader("To") == false
				|| sipMsg.hasHeader("Call-ID") == false
				|| sipMsg.hasHeader("CSeq") == false) {
			Logger.getGlobal().fine(context,
					"This message has no (From/To/Call-ID/CSeq) headers");
			return false;
		}

		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#send(org.siprop.v2.core.messge.impl.MessageContextImpl)
	 */
	@Override
	public void send(Context context) {
		// next layer selection
		selectNextLayer(context);

		Logger.getGlobal().finest(
				context,
				"StackManager sends a message. Next Layer is "
						+ context.getCurrentPacket().getSendToKey().getSendTo().getRouteid().toString());
		super.send(context);
	}

	/**
	 * select TU to process a message
	 * 
	 * @param context
	 *            message
	 * @return TU object
	 */
	private TransactionUser selectTU(Context context) {
		TransactionUser targetTU = null;

		targetTU = this.getTU(context);

		if (targetTU != null) {
			return targetTU;
		}

		for (TransactionUser candidate : this.listTU) {
			// XXX Currentrly, always use first TU entry
			targetTU = candidate;
			break;
		}

		return targetTU;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.stack.StackManager#registerTransaction(java.lang.String,
	 *      org.siprop.v2.stack.sip.tu.impl.TransactionUserImpl)
	 */
	public void registerTransactionUser(String transactionKey,
			TransactionUser tu) {
		this.mapTU.put(transactionKey, tu);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.stack.StackManager#unregisterTransaction(java.lang.String)
	 */
	public void unregisterTransactionUser(String transactionKey) {
		this.mapTU.remove(transactionKey);
	}

	/**
	 * select next layer
	 * 
	 * @param context
	 *            SIP message that will be forwarded
	 */
	private void selectNextLayer(Context context) {
		/* set message routing information */
		MessageContextPacket newPacket = MessageContextPacketImpl
				.copyMessageContextPacket((MessageContextPacket) context
						.getCurrentPacket());

		SendToKey sendToKey = null;
		// TODO call some resolver
		switch (context.getCurrentPacket().getSendToKey().getRecvFrom().getRoutetype()) {
		case TRANSPORT:
			sendToKey = new SendToKey(RouteKeyResolver.resolve(LayerEnum.STACK),
									  RouteKeyResolver.resolve(LayerEnum.UA));
			break;
		case STACK:
			sendToKey = context.getCurrentPacket().getSendToKey();
			break;
		case UA: /* fall through */
		case B2BUA:
			sendToKey = new SendToKey(RouteKeyResolver.resolve(LayerEnum.STACK),
					  RouteKeyResolver.resolve(LayerEnum.TRANSPORT));
			break;
		default:
			// Invalid statement
			Logger.getGlobal().fine(context,
					"This message is received from an unexpected Layer");
			break;
		}
		newPacket.setSendToKey(sendToKey);
		Logger.getGlobal().finest(
				context,
				"set " + sendToKey.getSendTo().getRouteid().toString()
						+ " as a next layer");

		context.addPacket(newPacket);

		// TODO append some routing informations, if need
		return;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#doProcess(java.lang.String,
	 *      java.lang.Object[])
	 */
	public void doProcess(String processName, Object[] param) {
		if (processName.equals(ManagerGarbageCollector.PROCESS_NAME)) {
			;
			;
			;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.stack.StackManager#createResponse(org.siprop.v2.core.messge.Context,
	 *      int)
	 */
	public Context createResponse(Context responseContext, int statusCode)
			throws SIPropException {
		if (responseContext == null
				|| (responseContext.getCurrentPacket().getFlatMessage()
						.getMessage() instanceof SIPRequest) == false) {
			SIPropException e = new SIPropException("Invalid Argment");
			throw e;
		}

		MessageContext rspMsg = MessageContextImpl.createNewMessageContext();
		MessageContextPacket rspPacket = MessageContextPacketImpl
				.createMessageContextPacket();
		FlatMessage flatMsg = new FlatSIPMessage();

		SIPRequest sipReq = (SIPRequest) responseContext.getCurrentPacket()
				.getFlatMessage().getMessage();
		SIPResponse sipRsp = sipReq.createResponse(statusCode);

		flatMsg.setMessage(sipRsp);
		rspPacket.setFlatMessage(flatMsg);
		rspMsg.setLocalPeer(((MessageContext) responseContext).getLocalPeer());
		rspMsg.setRemotePeer(((MessageContext) responseContext).getRemotePeer());
		rspMsg.addPacket(rspPacket);

		return rspMsg;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.stack.StackManager#getTransactionUserList()
	 */
	public List<TransactionUser> getTransactionUserList() {
		return this.listTU;
	}
	
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#getServiceName()
	 */
	public String getServiceName() {
		return serviceName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#setServiceName(java.lang.String)
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#start()
	 */
	public void start() {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#stop()
	 */
	public void stop() {
		// TODO Auto-generated method stub
		
	}


}
