/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge.impl;

import org.siprop.v2.core.messge.ControlMessage;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.MessageContextPacket;
import org.siprop.v2.core.router.impl.SendToKey;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Packet for MessageContextImpl.
 * 
 * @author noritsuna
 * 
 */
public class MessageContextPacketImpl implements MessageContextPacket {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = -1284218168786267359L;

	/**
	 * ControlMessage.
	 */
	protected ControlMessage controlMessage = null;

	/**
	 * FlatMessage.
	 */
	protected FlatMessage flatMessage = null;
	
	/**
	 * sendToKey.
	 */
	protected SendToKey sendToKey = null;


	/**
	 * Constructor.
	 * 
	 */
	private MessageContextPacketImpl() {
	}

	/**
	 * create new MessageContextPacket.
	 * 
	 * @return new MessageContextPacket
	 */
	public static MessageContextPacket createMessageContextPacket() {
		MessageContextPacket mc = new MessageContextPacketImpl();

		return mc;
	}

	/**
	 * copy MessageContextPacket.
	 * 
	 * @param me
	 *            MessageContextPacketImpl for a copy
	 * @return Copied MessageContextPacketImpl
	 */
	public static MessageContextPacket copyMessageContextPacket(
			MessageContextPacket me) {
		MessageContextPacket mc = new MessageContextPacketImpl();
		mc.setControlMessage(me.getControlMessage());
		mc.setFlatMessage(me.getFlatMessage());

		return mc;
	}

	/**
	 * clone MessageContextPacket.
	 * 
	 * @param me
	 *            MessageContextPacketImpl for a clone
	 * @return Cloned MessageContextPacketImpl
	 */
	public static MessageContextPacket cloneMessageContextPacket(
			MessageContextPacket me) {
		throw new NotImplementedException();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Packet#getControlMessage()
	 */
	public ControlMessage getControlMessage() {
		return controlMessage;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Packet#setControlMessage(org.siprop.v2.core.messge.ControlMessage)
	 */
	public void setControlMessage(ControlMessage ctrlMessage) {
		this.controlMessage = ctrlMessage;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Packet#getFlatMessage()
	 */
	public FlatMessage getFlatMessage() {
		return flatMessage;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Packet#setFlatMessage(org.siprop.v2.core.messge.FlatMessage)
	 */
	public void setFlatMessage(FlatMessage flatMessage) {
		this.flatMessage = flatMessage;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Packet#getSendToKey()
	 */
	public SendToKey getSendToKey() {
		return sendToKey;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Packet#setSendToKey(org.siprop.v2.core.router.impl.SendToKey)
	 */
	public void setSendToKey(SendToKey sendToKey) {
		this.sendToKey = sendToKey;
	}
}
