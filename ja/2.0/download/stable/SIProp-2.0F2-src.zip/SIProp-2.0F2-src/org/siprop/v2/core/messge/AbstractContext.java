/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge;

import org.siprop.v2.core.messge.impl.MessageContextInfoImpl;
import org.siprop.v2.core.router.impl.SendToKey;

/**
 * Abstract of Context.
 * 
 * @author noritsuna
 *
 */
public abstract class AbstractContext implements Context {

	/**
	 * ControlMessage.
	 */
	protected ControlMessage controlMessage = null;

	/**
	 * FlatMessage.
	 */
	protected FlatMessage flatMessage = null;
	
	/**
	 * sendToKey.
	 */
	protected SendToKey sendToKey = null;
	
	/**
	 * Info.
	 */
	protected Info info = null;
	
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Context#addPacket(org.siprop.v2.core.messge.Packet)
	 */
	public void addPacket(Packet packet) {
		setCurrentPacket(packet);
		getInfo().addPacket(packet);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Context#getCurrentPacket()
	 */
	public Packet getCurrentPacket() {
		return getInfo().getCurrentPacket();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Context#setCurrentPacket(org.siprop.v2.core.messge.Packet)
	 */
	public void setCurrentPacket(Packet currentPacket) {
		Info info = getInfo();
		info.setCurrentPacket(currentPacket);
		if(info.getOriginalPacket() == null) {
			info.setOriginalPacket(currentPacket);
		}
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Context#getInfo()
	 */
	public Info getInfo() {
		if(this.info == null) {
			this.info = new MessageContextInfoImpl();
		}
		return info;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Context#setInfo(org.siprop.v2.core.messge.Info)
	 */
	public void setInfo(Info info) {
		this.info = info;
	}
	
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Context#getOriginalPacket()
	 */
	public Packet getOriginalPacket() {
		return getInfo().getOriginalPacket();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Context#setOriginalPacket(org.siprop.v2.core.messge.Packet)
	 */
	public void setOriginalPacket(Packet originalPacket) {
		Info info = getInfo();
		info.setOriginalPacket(originalPacket);
		if(info.getCurrentPacket() == null) {
			info.setCurrentPacket(originalPacket);
		}
	}

}
