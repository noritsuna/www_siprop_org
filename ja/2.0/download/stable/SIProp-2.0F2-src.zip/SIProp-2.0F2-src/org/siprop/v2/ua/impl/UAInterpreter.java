/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.impl;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.ua.UACommand;
import org.siprop.v2.ua.UAContext;
import org.siprop.v2.ua.UAControlMessage;
import org.siprop.v2.ua.util.impl.CommandName;
import org.siprop.v2.ua.util.impl.CommandSet;
import org.siprop.v2.util.impl.Logger;

/**
 * This class is an interpreter for UACommand.
 * 
 * @author noritsuna
 * 
 */
public class UAInterpreter {

	/**
	 * This list is UACommand instances.
	 */
	private Map<String, CommandSet> uaCommandsList = null;

	/**
	 * Package name of pre.
	 */
	private static final String PACKAGE_UA_PRE = "org.siprop.v2.ua.";

	/**
	 * Package name of post.
	 */
	private static final String PACKAGE_UA_POST = ".command.impl.";

	/**
	 * Package name of ident.
	 */
	private static final String IDENT_UA = "UA";

	/**
	 * Command name of prefix.
	 */
	private static final String COMMAND_PREFIX = "do_";



	/**
	 * Constructor.
	 * 
	 */
	public UAInterpreter() {
		this.uaCommandsList = Collections
				.synchronizedMap(new HashMap<String, CommandSet>());
	}

	/**
	 * create list of UACommand.
	 * 
	 * @param commandList
	 * @param serviceName
	 */
	public void createCommandList(List<String> commandList, String serviceName) {

		for (String clazzBaseName : commandList) {
			Class clazz_UA = null;
			try {
				clazz_UA = ClassLoader.getSystemClassLoader().loadClass(
						PACKAGE_UA_PRE + serviceName + PACKAGE_UA_POST
								+ clazzBaseName + IDENT_UA);

				UACommand uaCommand = (UACommand) clazz_UA.newInstance();
				for (Method method : clazz_UA.getMethods()) {
					if (method.getName().startsWith(
							COMMAND_PREFIX + clazzBaseName)) {
						// regist commnad lists.
						CommandSet commandSet = new CommandSet();
						commandSet.setCommandMethod(method);
						commandSet.setUaCommandClass(uaCommand);

						this.uaCommandsList.put(serviceName + "_"
								+ method.getName(), commandSet);
						Logger.getGlobal().fine(
								null,
								"Add UACommand:" + serviceName + "_"
										+ method.getName());
					}
				}

			} catch (ClassCastException e) {
				Logger.getGlobal().warning(null,
						"UACommand load error. :" + e.getMessage());
			} catch (ClassNotFoundException e) {
				Logger.getGlobal().warning(null,
						"UACommand load error. :" + e.getMessage());
			} catch (InstantiationException e) {
				Logger.getGlobal().warning(null,
						"UACommand load error. :" + e.getMessage());
			} catch (IllegalAccessException e) {
				Logger.getGlobal().warning(null,
						"UACommand load error. :" + e.getMessage());
			}
		}
	}

	/**
	 * Execute interpreter.
	 * 
	 * @param context
	 * @param uaContext
	 */
	public void exec(Context context, UAContext uaContext) {

		UAControlMessage ctrlMessage = (UAControlMessage) context
				.getCurrentPacket().getControlMessage();
		CommandName commandName = ctrlMessage.getExecMethod();
		String key = commandName.getCommandName();

		CommandSet commandSet = null;
		if (this.uaCommandsList.containsKey(key)) {
			commandSet = this.uaCommandsList.get(key);
		} else {
			Logger.getGlobal().warning(context,
					"UACommand exec error. Not found method. :" + key);
			commandSet = this.uaCommandsList.get(commandName.getServiceName()
					+ "_" + "do_Error_notFoundMethod");
		}

		try {
			Logger.getGlobal().fine(context,
					"UAInterpreter exex() do:" + commandName.getCommandName());
			commandSet.getCommandMethod().invoke(
					commandSet.getUaCommandClass(),
					new Object[] { context, uaContext });
		} catch (Exception e) {
			Logger.getGlobal().warning(context,
					"UACommand exec error. :" + e.getMessage());
			commandSet = this.uaCommandsList.get("do_Error_notFoundMethod");
			try {
				commandSet.getCommandMethod().invoke(
						commandSet.getUaCommandClass(),
						new Object[] { context, uaContext });
			} catch (Exception e1) {
				Logger.getGlobal().warning(
						context,
						"UACommand error command exec error. :"
								+ e1.getMessage());
			}
		}
	}
}
