/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip.impl;

import org.siprop.v2.b2bua.B2BUAControlMessage;
import org.siprop.v2.core.messge.AbstractControlMessage;

/**
 * ControlMessage for standard B2BUA.
 * 
 * @author noritsuna
 * 
 */
public class B2BUAControlMessageImpl extends AbstractControlMessage implements B2BUAControlMessage {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = 4986972036703394935L;

	/**
	 * The name of the module for execution.
	 */
	private String doModuleName = null;

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAControlMessage#getDoModuleName()
	 */
	public String getDoModuleName() {
		return doModuleName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAControlMessage#setDoModuleName(java.lang.String)
	 */
	public void setDoModuleName(String doModuleName) {
		this.doModuleName = doModuleName;
	}

}
