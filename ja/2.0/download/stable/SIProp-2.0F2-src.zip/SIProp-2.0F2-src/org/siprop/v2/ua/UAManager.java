/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua;

import org.siprop.v2.core.Manager;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.ua.impl.UAInterpreter;

/**
 * Manager interface for UA.
 * 
 * @author noritsuna
 * 
 */
public interface UAManager extends Manager {

	/**
	 * get UA Interpreter.
	 * 
	 * @return UAInterpreter
	 */
	public UAInterpreter getUaInterpreter();

	/**
	 * set UA Interpreter.
	 * 
	 * @param uaInterpreter
	 */
	public void setUaInterpreter(UAInterpreter uaInterpreter);
	
	

	/**
	 * get UAContext by MessageContextImpl.
	 * 
	 * @param context
	 * @return UAContext
	 */
	public UAContext getUAContext(Context context);

	/**
	 * Get UAContext by key.
	 * 
	 * @param key
	 * @return UAContext
	 */
	public UAContext getUAContext(String key);

	/**
	 * set UAContext by Context.
	 * 
	 * @param context
	 * @param uaContext
	 */
	public void setUAContext(Context context, UAContext uaContext);

	/**
	 * set UAContext by key.
	 * 
	 * @param key
	 * @param uaContext
	 */
	public void setUAContext(String key, UAContext uaContext);

	/**
	 * delete UAContext by Context.
	 * 
	 * @param context
	 */
	public void deleteUAContext(Context context);

	/**
	 * delete UAContext by key.
	 * 
	 * @param key
	 */
	public void deleteUAContext(String key);


}
