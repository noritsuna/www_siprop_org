/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge;


/**
 * This interface holds the message about a packet.
 * 
 * @author noritsuna
 * 
 */
public interface Info extends Message {


	/**
	 * get Packet.<BR>
	 * isNextStep In the case of true , gotten Packet is deleted
	 * from list.
	 * 
	 * @param isNextStep
	 * @return current Packet
	 */
	public Packet getPacket(boolean isNextStep);

	/**
	 * add Packet.
	 * 
	 * @param packet
	 */
	public void addPacket(Packet packet);

	/**
	 * set original Packet.
	 * 
	 * @param originalPacket
	 *            original Packet
	 */
	public void setOriginalPacket(Packet originalPacket);

	/**
	 * get original Packet.
	 * 
	 * @return original Packet
	 */
	public Packet getOriginalPacket();
	
	
	/**
	 * get current Packet.
	 * 
	 * @return current Packet
	 */
	public Packet getCurrentPacket();
	
	/**
	 * set current Packet.
	 * 
	 * @param currentPacket
	 */
	public void setCurrentPacket(Packet currentPacket);

}
