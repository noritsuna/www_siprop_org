/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip.module.impl;

import gov.nist.javax.sip.message.SIPRequest;

import org.siprop.v2.b2bua.sip.AbstractSIPB2BUAModule;
import org.siprop.v2.b2bua.sip.impl.B2BUAManagerImpl;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.MessageContextPacket;
import org.siprop.v2.core.messge.impl.MessageContextPacketImpl;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.ua.UAControlMessage;
import org.siprop.v2.ua.sip.impl.UAControlMessageImpl;
import org.siprop.v2.ua.util.impl.CommandName;
import org.siprop.v2.util.impl.Logger;

/**
 * AbstractSIPB2BUAModule for Asterisk.
 * 
 * @author noritsuna
 * 
 */
public class AsteriskB2BUA extends AbstractSIPB2BUAModule {

	/**
	 * The name which shows this module.
	 */
	public static String MODULE_NAME = "Asterisk";

	/**
	 * Constructor
	 */
	public AsteriskB2BUA() {
		super();
		this.setModuleName(MODULE_NAME);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAModule#receive(org.siprop.v2.core.messge.Context)
	 */
	public void receive(Context context) {
		Logger.getGlobal().fine(context, "in AsteriskB2BUA.receive().");

		/*
		 * TODO B2BUA作成編 B2BUAManagerにおいて。
		 * Inner側とOuter側のMessageContext、どちかからでも、同じB2BUAModuleが取得できなくては、ならない。
		 * 
		 * 
		 * B2BUAModuleにおいて。 ここは、スクリプト処理に専念できるようにする。
		 * 
		 * 
		 * B2BUAContext&B2BUAInfoにおいて。
		 * MessageContextに対して、対向となるB2BUAInfoの情報をやりとりする。
		 * このときに、以前のSIPメッセージやオリジナルSIPメッセージなどがとれるとグッド？
		 * 前回の処理状況を取得できるようにするべき。B2BUAControlMessageを残しておくべき。
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * Outer側を新規作成するときのCall-IDは、B2BUAが作成する。 そして、その情報のみを、UAModuleに引き渡す。
		 * 
		 * UAControlMessageに、UniKeyを作る。 （これが、取得できない場合は、UAModule内にて作成する。)
		 * 
		 * 
		 * 
		 * この新規作成した場合は、B2BUAManagerに、自分自身をこの新しいKeyで登録する。
		 * 
		 * 
		 */

		// どこのUAから来たかを判別する。(inner or outer)
		UAControlMessage uaCtrlMessage = (UAControlMessage) context
				.getCurrentPacket().getControlMessage();
		
		if (uaCtrlMessage == null) {
			// throw new SIPropException("Not Found UA.");
			return;
		}
		Logger.getGlobal().fine(
				context,
				"AsteriskB2BUA.receive() uaCtrlMessage.getExecMethod()="
						+ uaCtrlMessage.getExecMethod().getMethodName());

		if (uaCtrlMessage.getExecMethod().getMethodName().equals(
				"do_Default_init")) {
			SIPRequest req = (SIPRequest) context.getCurrentPacket()
					.getFlatMessage().getMessage();

			MessageContextPacket newPakcet = MessageContextPacketImpl
					.createMessageContextPacket();
			newPakcet.setFlatMessage(context.getCurrentPacket()
					.getFlatMessage());

			if (req.getMethod().equals(SIPRequest.INVITE)) {
				Logger.getGlobal().fine(context,
						"AsteriskB2BUA.receive() in INVITE process.");

				UAControlMessageImpl controlMessage = new UAControlMessageImpl();
				CommandName commandName = new CommandName(getCallBackManager().getServiceName(),
														  "do_Invite_resp_200");
				controlMessage.setExecMethod(commandName);
				newPakcet.setControlMessage(controlMessage);

				context.addPacket(newPakcet);

				SendToKey layerKey = new SendToKey(RouteKeyResolver
						.resolve(LayerEnum.B2BUA), RouteKeyResolver
						.resolve(LayerEnum.UA));
				newPakcet.setSendToKey(layerKey);

			} else if (req.getMethod().equals(SIPRequest.REGISTER)) {
				Logger.getGlobal().fine(context,
						"AsteriskB2BUA.receive() in REGISTER process.");

				UAControlMessageImpl controlMessage = new UAControlMessageImpl();
				CommandName commandName = new CommandName(getCallBackManager().getServiceName(), 
														  "do_Register_resp_200");
				controlMessage.setExecMethod(commandName);
				newPakcet.setControlMessage(controlMessage);

				context.addPacket(newPakcet);

				SendToKey layerKey = new SendToKey(RouteKeyResolver
						.resolve(LayerEnum.B2BUA), RouteKeyResolver
						.resolve(LayerEnum.UA));
				newPakcet.setSendToKey(layerKey);

			} else {

			}

		}

		// TODO Managerに、自分自身を登録する。
		this.getCallBackManager().doProcess(B2BUAManagerImpl.PROCESS_NAME_ADDMODULE,
				new Object[] { context, this });

		this.send(context);
	}

}
