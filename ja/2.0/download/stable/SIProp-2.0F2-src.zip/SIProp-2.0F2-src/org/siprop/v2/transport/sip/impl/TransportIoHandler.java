/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.impl;

import java.net.InetSocketAddress;

import javax.sip.message.Message;

import org.apache.mina.common.IdleStatus;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import org.apache.mina.common.TransportType;
import org.siprop.v2.core.Listener;
import org.siprop.v2.core.MessageException;
import org.siprop.v2.core.messge.FlatMessage;
import org.siprop.v2.core.messge.MessageContext;
import org.siprop.v2.core.messge.MessageContextPacket;
import org.siprop.v2.core.messge.impl.FlatSIPMessage;
import org.siprop.v2.core.messge.impl.MessageContextImpl;
import org.siprop.v2.core.messge.impl.MessageContextPacketImpl;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;

/**
 * Transport IO Handler
 * 
 * @author nisato
 * 
 */
public class TransportIoHandler extends IoHandlerAdapter {

	/**
	 * Listener.
	 */
	private Listener listener = null;

	/**
	 * Constructor.
	 */
	public TransportIoHandler() {
	}

	/**
	 * Constructor.
	 * 
	 * @param listener Listener
	 */
	public TransportIoHandler(Listener listener) {
		this.listener = listener;
	}

	/**
	 * set listener.
	 * 
	 * @param listener Listener
	 */
	public void setListener(Listener listener) {
		this.listener = listener;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.mina.common.IoHandlerAdapter#sessionOpened(org.apache.mina.common.IoSession)
	 */
	public void sessionOpened(IoSession session) {
		// TCP Only
		// session.setIdleTime( IdleStatus.BOTH_IDLE, 60 );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.mina.common.IoHandlerAdapter#messageReceived(org.apache.mina.common.IoSession,
	 *      java.lang.Object)
	 */
	public void messageReceived(IoSession session, Object message) {
		Message msg = (Message) message;

		// get remote sock.
		InetSocketAddress remotesock = (InetSocketAddress) session
				.getRemoteAddress();
		InetSocketAddress localsock = (InetSocketAddress) session
				.getLocalAddress();

		int protocol = getProtocol(session);

		Peer remotePeer = new Peer(protocol, remotesock.getAddress(),
				remotesock.getPort());
		Peer localPeer = new Peer(protocol, localsock.getAddress(), localsock
				.getPort());

		MessageContext messagecontext = MessageContextImpl.createNewMessageContext();

		// XXX The messages are always forwarded to Stack Layer
		MessageContextPacket newPacket = MessageContextPacketImpl
				.createMessageContextPacket();
		FlatMessage flatmessage = new FlatSIPMessage();
		flatmessage.setMessage(msg);
		newPacket.setFlatMessage(flatmessage);
		messagecontext.setLocalPeer(localPeer);
		messagecontext.setRemotePeer(remotePeer);

		SendToKey layerKey = new SendToKey(RouteKeyResolver
				.resolve(LayerEnum.TRANSPORT), RouteKeyResolver
				.resolve(LayerEnum.STACK));
		newPacket.setSendToKey(layerKey);

		messagecontext.addPacket(newPacket);

		Logger.getGlobal().info(messagecontext, msg.toString());
		try {
			this.listener.onReceive(messagecontext);
		} catch (MessageException e) {
			Logger.getGlobal().severe(messagecontext, "messageReceived error." + e.getMessage());
			e.printStackTrace();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.mina.common.IoHandlerAdapter#sessionIdle(org.apache.mina.common.IoSession,
	 *      org.apache.mina.common.IdleStatus)
	 */
	public void sessionIdle(IoSession session, IdleStatus status) {
		Logger.getGlobal().info(null, "Disconnecting the idle:");
		session.close();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.mina.common.IoHandlerAdapter#exceptionCaught(org.apache.mina.common.IoSession,
	 *      java.lang.Throwable)
	 */
	public void exceptionCaught(IoSession session, Throwable cause) {
		Logger.getGlobal().warning(null,
				"IO Exception Caught:" + cause.getMessage());
		session.close();
	}

	/**
	 * get a transport protocol
	 * 
	 * @param session
	 *            target session
	 * @return TCP: 6, UDP: 17
	 */
	private int getProtocol(IoSession session) {
		int protocol = 0;

		if (session.getTransportType() == TransportType.DATAGRAM) {
			protocol = Peer.IPPROTO_UDP;
		} else if (session.getTransportType() == TransportType.SOCKET) {
			protocol = Peer.IPPROTO_TCP;
		}

		return protocol;
	}

}
