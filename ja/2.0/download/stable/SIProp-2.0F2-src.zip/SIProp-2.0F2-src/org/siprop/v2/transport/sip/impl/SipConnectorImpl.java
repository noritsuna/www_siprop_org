/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.impl;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.support.BaseIoAcceptorConfig;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.DatagramAcceptor;
import org.apache.mina.transport.socket.nio.DatagramAcceptorConfig;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;
import org.siprop.v2.transport.SipConnector;
import org.siprop.v2.transport.sip.codec.impl.SipProtocolCodecFactory;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;

/**
 * Implement of SipConnector.
 * 
 * @author yusuke
 * 
 */
public class SipConnectorImpl implements SipConnector {

	/**
	 * local IP Address.
	 */
	private String localAddress = "0.0.0.0";

	/**
	 * local port.
	 */
	private int localPort = 5060;
	
	/**
	 * local Peer.
	 */
	private Peer localPeer;

	/**
	 * protocol type.
	 */
	private int protocol = Peer.IPPROTO_UDP;

	/**
	 * TransportIoHandler.
	 */
	private TransportIoHandler handler;

	/**
	 * IoAcceptor.
	 */
	private IoAcceptor acceptor;



	/* (non-Javadoc)
	 * @see org.siprop.v2.transport.SipConnector#getAcceptor()
	 */
	public IoAcceptor getAcceptor() {
		return acceptor;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.transport.SipConnector#getLocalPeer()
	 */
	public Peer getLocalPeer() {
		return localPeer;
	}

	/**
	 * set TransportIoHandler.
	 * 
	 * @param handler
	 */
	public void setHandler(TransportIoHandler handler) {
		this.handler = handler;
	}

	/**
	 * set local IP Address.
	 * 
	 * @param localAddress
	 */
	public void setLocalAddress(String localAddress) {
		this.localAddress = localAddress;
	}

	/**
	 * set local port.
	 * 
	 * @param localPort
	 */
	public void setLocalPort(int localPort) {
		this.localPort = localPort;
	}

	/**
	 * set Protocol type.
	 * 
	 * @param protocol
	 */
	public void setProtocol(int protocol) {
		this.protocol = protocol;
	}

	/**
	 * Called when the Component is initialized
	 * 
	 */
	public void init() {

		try {
			localPeer = new Peer(protocol, InetAddress.getByName(localAddress),
					localPort);
		} catch (UnknownHostException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		acceptor = createTransportIo(localPeer);

	}

	/**
	 * create IoAcceptor & bind local port.
	 * 
	 * @param peer
	 * @return IoAcceptor
	 */
	public IoAcceptor createTransportIo(Peer peer) {
		IoAcceptor acceptor = null;
		try {
			// TCP or UDP ?(tcp protocol number is 6. other UDP)
			acceptor = peer.getProtocol() == Peer.IPPROTO_TCP ? new SocketAcceptor()
					: new DatagramAcceptor();

			BaseIoAcceptorConfig cfg = peer.getProtocol() == Peer.IPPROTO_TCP ? new SocketAcceptorConfig()
					: new DatagramAcceptorConfig();

			// if necessary
			// cfg.setReuseAddress( true );
			cfg.getFilterChain().addLast("protocolFilter",
					new ProtocolCodecFilter(new SipProtocolCodecFactory()));

			// bind
			acceptor.bind(new InetSocketAddress(peer.getAddress(), peer
					.getPort()), handler, cfg);

			Logger.getGlobal().fine(
					null,
					"binding " + peer.getAddress().getHostAddress() + ":"
							+ peer.getPort());
		} catch (Exception ex) {
			Logger.getGlobal().warning(null, ex.getMessage());
		}
		return acceptor;
	}

}
