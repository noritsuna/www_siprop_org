/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.impl;

import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.IoSession;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.siprop.v2.core.AbstractManager;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.MessageContext;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.transport.SipConnector;
import org.siprop.v2.transport.TransportManager;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;

/**
 * Transport manager (setup/auto create)
 * 
 * @author nisato
 * 
 */
public class TransportManagerImpl extends AbstractManager implements
		TransportManager {

	/**
	 * map of IoAcceptor.
	 */
	private Map<Peer, SipConnector> ioMap = null;

	/**
	 * service name.
	 */
	private String serviceName = "sip";

	/**
	 * Constructor (Singlton design pattern)
	 * 
	 */
	public TransportManagerImpl() {
		super();
		this.ioMap = Collections
				.synchronizedMap(new HashMap<Peer, SipConnector>());
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.transport.TransportManager#addConnector(org.siprop.v2.transport.SipConnector)
	 */
	public void addConnector(SipConnector connector) {
		if ( ! isBindingTransportIo(connector.getLocalPeer()) ) {
			ioMap.put(connector.getLocalPeer(), connector);
		}
	}
	
	/**
	 * binding peer or not?
	 * 
	 * @param peer
	 * @return
	 */
	private boolean isBindingTransportIo(Peer peer) {
		if (ioMap.get(peer) == null) {
			return false;
		} else {
			return true;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Listener#onReceive(org.siprop.v2.core.messge.Context)
	 */
	public void onReceive(Context context) {

		SendToKey sendKey = context.getCurrentPacket().getSendToKey();

		if (sendKey == null) {
			Logger.getGlobal().warning(context, "Don't get routing key.");
			return;
		}

		if (sendKey.getSendTo().getRoutetype() == LayerEnum.TRANSPORT) {
			this.sendNextPeer(context);
		} else {
			this.send(context);
		}

	}

	/**
	 * send to next peer.
	 * 
	 * @param context
	 */
	private void sendNextPeer(Context context) {
		// どのTransportを使うかについては、MessageContextから取れる
		Peer remotepeer = ((MessageContext) context).getRemotePeer();
		Peer transpeer = ((MessageContext) context).getLocalPeer();

		if (transpeer == null) {
			/* TODO use default transport */
		}

		if (remotepeer == null) {
			/* TODO call some resolver */
		}

		IoAcceptor acceptor = ioMap.get(transpeer).getAcceptor();
		IoSession session = null;

		// TODO: 必要なトランスポートが見つからない場合は、createTransportIoして新しく作る
		if (acceptor == null) {
		}

		// TCPの場合、既にあるTCPセッションから取得
		if (acceptor instanceof SocketAcceptor) {
			session = (IoSession) acceptor
					.getManagedSessions(new InetSocketAddress(remotepeer
							.getAddress(), remotepeer.getPort()));

			// UDPの場合、新しく作る
		} else {
			session = acceptor.newSession(new InetSocketAddress(remotepeer
					.getAddress(), remotepeer.getPort()),
					new InetSocketAddress(transpeer.getAddress(), transpeer
							.getPort()));
		}

		if (session != null)
			session.write(context.getCurrentPacket().getFlatMessage()); // To
		// Encoder
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.transport.TransportManager#tearDown(org.siprop.v2.util.impl.Peer)
	 */
	public void tearDown(Peer peer) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#doProcess(java.lang.String,
	 *      java.lang.Object[])
	 */
	public void doProcess(String processName, Object[] param) {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getServiceName()
	 */
	public String getServiceName() {
		return serviceName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setServiceName(java.lang.String)
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#start()
	 */
	public void start() {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#stop()
	 */
	public void stop() {
		// TODO Auto-generated method stub
		
	}

}
