/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.command.impl;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.ua.UACommand;
import org.siprop.v2.ua.UAContext;

/**
 * UACommand of Cancel.
 * 
 * @author noritsuna
 * 
 */
public class CancelUA implements UACommand {

	/**
	 * UACommand name.
	 */
	public static final String UA_COMMAND_NAME = "Cancel";
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.ua.UACommand#getUACommandName()
	 */
	public String getUACommandName() {
		return UA_COMMAND_NAME;
	}

	/**
	 * Initial command.
	 * 
	 * @param context
	 * @param uaContext
	 */
	public void do_Cancel_init(Context context, UAContext uaContext) {

	}

	
}
