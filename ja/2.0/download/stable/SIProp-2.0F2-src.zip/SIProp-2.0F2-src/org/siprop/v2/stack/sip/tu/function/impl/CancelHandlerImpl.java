/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu.function.impl;

import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;
import org.siprop.v2.stack.sip.transaction.TransactionType;
import org.siprop.v2.stack.sip.tu.function.TuFunction;
import org.siprop.v2.util.impl.Logger;

/**
 * CANCEL request message handler.
 * 
 * @author masaxmasa
 * 
 */
public class CancelHandlerImpl implements TuFunction {

	/**
	 * StackManager.
	 */
	private StackManager stackManager = null;

	/**
	 * Constructor.
	 * 
	 * @param stackManager
	 */
	public CancelHandlerImpl(StackManager stackManager) {
		this.stackManager = stackManager;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#doProcess(org.siprop.v2.core.messge.Context, org.siprop.v2.stack.sip.transaction.TransactionEntry)
	 */
	public Context doProcess(Context context, TransactionEntry trnsct) {
		
		Logger.getGlobal().finest(context, "start CancelHandlerImpl process");
		
		/*
		 * message for response
		 */
		Context rspMsg = null;

		/*
		 * Check SIP request message or not.
		 */
		if (context.getCurrentPacket().getFlatMessage().getMessage() instanceof SIPRequest == false) {
			return null;
		}

		SIPRequest sipReq = (SIPRequest) context.getCurrentPacket()
				.getFlatMessage().getMessage();
		if (SIPRequest.CANCEL.equals(sipReq.getMethod()) == false) {
			return null;
		}

		/*
		 * This is CANCEL request message. Search transaction that will be
		 * canceled, first.
		 */
		TransactionEntry canceled = trnsct.getParentTransaction()
				.searchCancelTransaction(sipReq);
		if (canceled == null) {
			/*
			 * If there is no transaction that be canceled, return "Call
			 * Leg/Transaction Does Not Exist".
			 */
			try {
				rspMsg = this.stackManager.createResponse(context,
						SIPResponse.CALL_OR_TRANSACTION_DOES_NOT_EXIST);
				// TODO determin destination layer
			} catch (SIPropException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return rspMsg;
		}

		/*
		 * If type of transaction is UAS INVITE transaction, Send CANCEL message
		 */
		if (trnsct.getTransactionType() != TransactionType.TRANSACTIONTYPE_INV_UAS) {
			return null;
		}

		/*
		 * XXX check Transaction state
		 */
		switch (canceled.getTransactionState()) {
		case PROCEEDING:
			// TODO send CANCEL request message
			break;
		case COMPLETED:
		case CONFIRMED:
		case TERMINATED:
			/*
			 * Race condition, ignore CANCEL request message
			 */
			break;
		case NONE:
		case CALLING:
		case TRYING:
		case DELETE:
		default:
			/*
			 * XXX unexpect statement, ignore CANCEL request message
			 */
			try {
				rspMsg = this.stackManager.createResponse(context,
						SIPResponse.CALL_OR_TRANSACTION_DOES_NOT_EXIST);
				// TODO determin destination layer
			} catch (SIPropException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return rspMsg;
		}

		// TODO create SIP response message

		try {
			rspMsg = this.stackManager.createResponse(context,
					SIPResponse.OK);
			// TODO determin destination layer
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rspMsg;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#addFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void addFunction(TuFunction function) throws SIPropException {
		throw new SIPropException("NotImplementedException");
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#removeFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void removeFunction(TuFunction function) throws SIPropException {
		throw new SIPropException("NotImplementedException");
	}

}
