/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge;

import java.io.Serializable;

/**
 * This interface holds the message about a dialog or session.
 * 
 * @author noritsuna
 * 
 */
public interface Context extends Serializable {

	/**
	 * add Packet. set for this.currentPacket & Info.addPacket().
	 * 
	 * @param packet
	 */
	public void addPacket(Packet packet);

	/**
	 * get current Packet.
	 * 
	 * @return current Packet
	 */
	public Packet getCurrentPacket();

	/**
	 * set current Packet.
	 * 
	 * @param currentPacket
	 */
	public void setCurrentPacket(Packet currentPacket);
	
	/**
	 * set original Packet.
	 * 
	 * @param originalPacket
	 */
	public void setOriginalPacket(Packet originalPacket);
	
	/**
	 * get original Packet.
	 * 
	 * @return original Packet
	 */
	public Packet getOriginalPacket();

	/**
	 * get Info.
	 * 
	 * @return Info
	 */
	public Info getInfo();

	/**
	 * set Info.
	 * 
	 * @param info
	 *            Info
	 */
	public void setInfo(Info info);
	
	
	
}
