/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.util.Discriminator;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.resolver.impl.BindingResolver;
import org.siprop.v2.util.resolver.impl.RegisterResolver;

/**
 * Interface of Router entry point.
 * 
 * @author noritsuna
 * 
 */
public abstract class AbstractManager implements Manager {

	/**
	 * send & recv router.
	 */
	protected Router router = null;

	/**
	 * Uni key generator.
	 */
	protected Discriminator uniKeyGenerator = null;

	/**
	 * BindingResolver
	 */
	protected BindingResolver bindingResolver = null;
	
	/**
	 * BindingResolver
	 */
	protected RegisterResolver registerResolver = null;



	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setRouter(org.siprop.v2.core.router.Router)
	 */
	public void setRouter(Router router) {
		this.router = router;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getUniKeyGenerator()
	 */
	public Discriminator getUniKeyGenerator() {
		return uniKeyGenerator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#setUniKeyGenerator(org.siprop.v2.util.Discriminator)
	 */
	public void setUniKeyGenerator(Discriminator uniKeyGenerator) {
		this.uniKeyGenerator = uniKeyGenerator;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#getRouter()
	 */
	public Router getRouter() {
		return router;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#send(org.siprop.v2.core.messge.Context)
	 */
	public void send(Context context){
		Logger.getGlobal().fine(context, "send()");
		try {
			this.getRouter().doRoute(context);
		} catch (MessageException e) {
			Logger.getGlobal().severe(context, "send error." + e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#getBindingResolver()
	 */
	public BindingResolver getBindingResolver() {
		return bindingResolver;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#getRegisterResolver()
	 */
	public RegisterResolver getRegisterResolver() {
		return registerResolver;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#setBindingResolver(org.siprop.v2.util.resolver.impl.BindingResolver)
	 */
	public void setBindingResolver(BindingResolver bindingResolver) {
		this.bindingResolver = bindingResolver;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#setRegisterResolver(org.siprop.v2.util.resolver.impl.RegisterResolver)
	 */
	public void setRegisterResolver(RegisterResolver registerResolver) {
		this.registerResolver = registerResolver;
	}


}
