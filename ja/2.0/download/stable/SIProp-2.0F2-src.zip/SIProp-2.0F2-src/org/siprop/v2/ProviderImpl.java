/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.siprop.v2.b2bua.sip.impl.B2BUARepositoryImpl;
import org.siprop.v2.core.filter.Filter;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.DynamicRouter;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.stack.sip.impl.StackRepositoryImpl;
import org.siprop.v2.transport.sip.impl.TransportRepositoryImpl;
import org.siprop.v2.ua.sip.impl.UARepositoryImpl;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.Provider;
import org.siprop.v2.util.impl.PropertiesDepotPrefix;
import org.siprop.v2.util.resolver.impl.BindingResolver;
import org.siprop.v2.util.resolver.impl.RegisterResolver;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Initial all SIProp instances.<BR>
 * Default implement.
 * 
 * @author noritsuna
 * 
 */
public class ProviderImpl implements Provider {

	/**
	 * Repository.
	 */
	private Map<RepositoryKey, Repository> repositoryMap = new HashMap<RepositoryKey, Repository>();
	
	
	/**
	 * Resovler
	 */
	private Map<Class, Object> resolverMap = new HashMap<Class, Object>();

	/**
	 * Filter list.
	 */
	private List<Filter> filterList = new ArrayList<Filter>();

	/**
	 * Properties.
	 */
	private PropertiesDepot prop;

	/**
	 * Router
	 */
	private DynamicRouter router = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.util.Provider#setup(org.siprop.v2.util.PropertiesDepot)
	 */
	public void setup(PropertiesDepot prop) {
		// set prop.
		this.prop = prop;
		
		// setup Router.
		this.setupRouter(prop);
		
		// setup Resolver.
		this.setupResolvers(prop);



		// Initial Structure from Properties.
		this.setupRepository(prop);

		// setup Filter.(not impl)
		this.setupFilter(prop);

		// start B2BUA.
		this.start();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.util.Provider#start()
	 */
	public void start() {
		// start.
		this.router.start();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.util.Provider#stop()
	 */
	public void stop() {
		// stop.
		// this.router.stop();
		throw new NotImplementedException();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.util.Provider#getRepository(org.siprop.v2.core.repository.RepositoryKey)
	 */
	public Repository getRepository(RepositoryKey key) {
		return this.repositoryMap.get(key);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.util.Provider#getProperty()
	 */
	public PropertiesDepot getProperty() {
		return prop;
	}

	/**
	 * set Property.
	 * 
	 * @param prop
	 */
	public void setProperty(PropertiesDepot prop) {
		this.prop = prop;
	}

	/**
	 * Initial Resolver.
	 * 
	 * @param prop
	 */
	public void setupResolvers(PropertiesDepot prop) {
		BindingResolver bindingResolver = new BindingResolver();
		this.resolverMap.put(BindingResolver.class, bindingResolver);

		RegisterResolver registerResolver = new RegisterResolver();
		this.resolverMap.put(RegisterResolver.class, registerResolver);
	}

	/**
	 * Initial Resolver.
	 * 
	 * @param prop
	 */
	public void setupRepository(PropertiesDepot prop) {
		this.createTransportRepository(prop);
		this.createStackRepository(prop);
		this.createUAsRepository(prop);
		this.createB2BUARepository(prop);
	}

	/**
	 * Initial Router.
	 * 
	 * @param prop
	 */
	private void setupRouter(PropertiesDepot prop) {
		MessageRouter messageRouter = new MessageRouter();
		this.router = messageRouter;
		messageRouter.setThreadPoolCount(10);
	}

	/**
	 * Initial Filter.
	 * 
	 * @param prop
	 */

	private void setupFilter(PropertiesDepot prop) {
		return;
	}

	/**
	 * Initial B2BUA.
	 * 
	 * @param prop
	 */
	private void createB2BUARepository(PropertiesDepot prop) {

		Repository b2buaRepository = new B2BUARepositoryImpl();
		b2buaRepository.setup(prop, this);
		repositoryMap.put(RepositoryKey.B2BUA, b2buaRepository);

	}

	/**
	 * Initial UAs.
	 * 
	 * @param prop
	 */
	private void createUAsRepository(PropertiesDepot prop) {
		PropertiesDepot innerProp = new PropertiesDepotPrefix(prop, "INNER");
		this.createUARepository(innerProp);

		PropertiesDepot outerProp = new PropertiesDepotPrefix(prop, "OUTER");
		this.createUARepository(outerProp);

	}

	/**
	 * Initial UA.
	 * 
	 * @param prop
	 */
	private void createUARepository(PropertiesDepot prop) {
		Repository newRepository = new UARepositoryImpl();
		newRepository.setup(prop, this);
		repositoryMap.put(RepositoryKey.UA, newRepository);
	}

	/**
	 * Initial Stack.
	 * 
	 * @param prop
	 */
	private void createStackRepository(PropertiesDepot prop) {

		Repository stackRepository = new StackRepositoryImpl();
		stackRepository.setup(prop, this);
		repositoryMap.put(RepositoryKey.STACK, stackRepository);

	}

	/**
	 * Initial Transport.
	 * 
	 * @param prop
	 */
	private void createTransportRepository(PropertiesDepot prop) {

		Repository transportRepository = new TransportRepositoryImpl();
		transportRepository.setup(prop, this);
		repositoryMap.put(RepositoryKey.TRANSPORT, transportRepository);

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.Provider#getRouter()
	 */
	public Router getRouter() {
		return router;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.util.Provider#getResolvers()
	 */
	public Map<Class, Object> getResolvers() {
		return this.resolverMap;
	}

}
