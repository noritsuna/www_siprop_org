/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.router;

import java.io.Serializable;


/**
 * This interface is the key information for Router.
 * 
 * @author hirotaka.nisato
 * 
 */
public interface RouteKey extends Serializable {

	/**
	 * get Route ID.<BR>
	 * ex.Manager's service name.
	 * @return Route ID object
	 */
	public Object getRouteid();

	/**
	 * set Route ID.<BR>
	 * ex.Manager's service name.
	 * @param routeid
	 */
	public void setRouteid(Object routeid);

	/**
	 * get Route Type.<BR>
	 * ex.Layer type.
	 * @return Route Type
	 */
	public LayerEnum getRoutetype();

	/**
	 * set Route Type.
	 * ex.Layer type.
	 * @param routetype
	 */
	public void setRoutetype(LayerEnum routetype);

	/**
	 * set Route Type String.
	 * ex.Layer type.
	 * @param routetype
	 */
	public void setRoutetypeString(String routetype);

}
