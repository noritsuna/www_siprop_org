/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.siprop.v2.core.AbstractManager;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.ua.UAContext;
import org.siprop.v2.ua.UAControlMessage;
import org.siprop.v2.ua.UAManager;
import org.siprop.v2.ua.impl.UAInterpreter;
import org.siprop.v2.ua.sip.context.impl.DefaultSIPUAContext;
import org.siprop.v2.ua.util.impl.CommandName;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.ManagerGarbageCollector;

/**
 * Manager for standard UA.
 * 
 * @author noritsuna
 * 
 */
public class UAManagerImpl extends AbstractManager implements UAManager {

	/**
	 * map of UAContext instances.
	 */
	private Map<String, UAContext> uaMap = null;

	/**
	 * list is UAContext keys.
	 */
	private List<String> uaList = null;

	/**
	 * UAInterpreter.
	 */
	private UAInterpreter uaInterpreter = null;

	/**
	 * Service name.
	 */
	private String serviceName = "sip";

	/**
	 * instance of garbage collector
	 */
	private ManagerGarbageCollector garbageCollector = null;

	/**
	 * instance of garbage collector tread.
	 */
	private Thread gcThread = null;

	/**
	 * Constructor.
	 * 
	 */
	public UAManagerImpl() {
		this.uaMap = Collections
				.synchronizedMap(new HashMap<String, UAContext>());
		this.uaList = Collections.synchronizedList(new ArrayList<String>());

		/*
		 * create TransactionGarbageCollector and run it.
		 */
		this.garbageCollector = new ManagerGarbageCollector(this);
		this.gcThread = new Thread(this.garbageCollector);
		this.gcThread.start();

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Listener#onReceive(org.siprop.v2.core.messge.Context)
	 */
	public void onReceive(Context context) {

		Logger.getGlobal().fine(context, "in UAManager.receive()");

		// Get UAInfo.
		String key = (String) getUniKeyGenerator().generateKey(context);
		UAContext uaContext = this.getUAContext(key);
		// UAInfo don'n find to route to B2BUA.
		if (uaContext == null) {
			Logger.getGlobal().fine(context, "Create new UAInfo.");
			// Create new UAInfo.
			uaContext = new DefaultSIPUAContext();
			this.setUAContext(key, uaContext);

			UAControlMessage controlMessage = new UAControlMessageImpl();
			CommandName commandName = new CommandName(serviceName,
					"do_Default_init");
			controlMessage.setExecMethod(commandName);

			context.getCurrentPacket().setControlMessage(controlMessage);
		}

		// Exec UACommand.
		synchronized (uaContext) {
			this.uaInterpreter.exec(context, uaContext);
		}

		// Send next layer.
		this.send(context);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.AbstractManager#doProcess(java.lang.String,
	 *      java.lang.Object[])
	 */
	public void doProcess(String processName, Object[] param) {
		if (processName.equals(ManagerGarbageCollector.PROCESS_NAME)) {
			this.doGC();
		}
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#setServiceName(java.lang.String)
	 */
	public void setServiceName(String name) {
		serviceName = name;
	}
	
	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#getServiceName()
	 */
	public String getServiceName() {
		return serviceName;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#getUAContext(org.siprop.v2.core.messge.Context)
	 */
	public UAContext getUAContext(Context context) {
		String key = (String) this.getUniKeyGenerator().generateKey(
				context);
		return getUAContext(key);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#getUAContext(java.lang.String)
	 */
	public UAContext getUAContext(String key) {

		if (this.uaMap.containsKey(key)) {
			return this.uaMap.get(key);
		} else {
			// UAInfo uaInfo = new DefaultUAInfo();
			// this.uaList.put(key, uaInfo);
			return null;
		}
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#setUAContext(org.siprop.v2.core.messge.Context, org.siprop.v2.ua.UAContext)
	 */
	public void setUAContext(Context context, UAContext uaContext) {
		String key = (String) this.getUniKeyGenerator().generateKey(
				context);
		this.setUAContext(key, uaContext);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#setUAContext(java.lang.String, org.siprop.v2.ua.UAContext)
	 */
	public void setUAContext(String key, UAContext uaContext) {
		this.uaMap.put(key, uaContext);
		this.uaList.add(key);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#deleteUAContext(org.siprop.v2.core.messge.Context)
	 */
	public void deleteUAContext(Context context) {
		String key = (String) this.getUniKeyGenerator().generateKey(
				context);
		this.deleteUAContext(key);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#deleteUAContext(java.lang.String)
	 */
	public void deleteUAContext(String key) {
		this.uaList.remove(key);
		this.uaMap.remove(key);
	}

	/**
	 * Execute GC.<BR>
	 * Delete to save B2BUAModule by delete Flag.
	 */
	private void doGC() {

		for (String key : this.uaList) {
			UAContext ua = this.uaMap.get(key);
			if (ua == null || ua.getDeleteFlag()) {
				this.deleteUAContext(key);
			}
		}

	}

	
	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#getUaInterpreter()
	 */
	public UAInterpreter getUaInterpreter() {
		return uaInterpreter;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAManager#setUaInterpreter(org.siprop.v2.ua.impl.UAInterpreter)
	 */
	public void setUaInterpreter(UAInterpreter uaInterpreter) {
		this.uaInterpreter = uaInterpreter;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#start()
	 */
	public void start() {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#stop()
	 */
	public void stop() {
		// TODO Auto-generated method stub
		
	}


}
