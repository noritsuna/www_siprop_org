/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack;

import java.util.List;

import org.siprop.SIPropException;
import org.siprop.v2.core.Manager;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.stack.sip.tu.TransactionUser;

/**
 * Manager interface for Stack.
 * 
 * @author noritsuna
 * 
 */
public interface StackManager extends Manager {

	/**
	 * add new transaction to StackManager
	 * @param tu
	 */
	public void addTU(TransactionUser tu);
	
	/**
	 * add new map entry for specified Call-ID
	 * 
	 * @param transactionKey
	 *            transactionKey
	 * @param tu
	 *            TU
	 */
	void registerTransactionUser(String transactionKey, TransactionUser tu);

	/**
	 * delete map entry for specified transactionKey
	 */
	void unregisterTransactionUser(String transactionKey);
	
	/**
	 * get list of TransactionUser.
	 * 
	 * @return list of TransactionUser
	 */
	List<TransactionUser> getTransactionUserList();

	/**
	 * create SIP response message from SIP request message
	 * 
	 * @param reqMsg
	 *            SIP request message
	 * @param statusCode
	 *            status code of SIP response message
	 * @return SIP response message
	 * @throws SIPropException
	 */
	Context createResponse(Context reqMsg, int statusCode)
			throws SIPropException;
}
