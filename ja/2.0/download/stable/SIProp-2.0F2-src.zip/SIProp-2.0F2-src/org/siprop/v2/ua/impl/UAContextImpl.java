/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.impl;

import org.siprop.v2.core.messge.AbstractContext;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.ua.UAContext;

/**
 * This abstract class holds the message about a dialog or session for UA.
 * 
 * @author noritsuna
 * 
 */
public class UAContextImpl extends AbstractContext implements UAContext {

	/**
	 * delete flag.
	 */
	private boolean deleteFlag = false;

	
	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAContext#exec(org.siprop.v2.core.messge.Context)
	 */
	public void exec(Context context) {
		
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAContext#setDeleteFlag(boolean)
	 */
	public void setDeleteFlag(boolean flag) {
		this.deleteFlag = flag;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.ua.UAContext#getDeleteFlag()
	 */
	public boolean getDeleteFlag() {
		return this.deleteFlag;
	}

}
