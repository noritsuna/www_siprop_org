/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge;

import org.siprop.v2.core.router.impl.SendToKey;

/**
 * This interface expresses the message transmitted between layers.
 * 
 * @author noritsuna
 * 
 */
public interface Packet extends Message {

	/**
	 * get ControlMessage.
	 * 
	 * @return ControlMessage
	 */
	public ControlMessage getControlMessage();

	/**
	 * set ControlMessage.
	 * 
	 * @param ctrlMessage
	 */
	public void setControlMessage(ControlMessage ctrlMessage);

	/**
	 * get FlatMessage.
	 * 
	 * @return flatMessage
	 */
	public FlatMessage getFlatMessage();

	/**
	 * set FlatMessage.
	 * 
	 * @param flatMessage
	 */
	public void setFlatMessage(FlatMessage flatMessage);
	
	
	/**
	 * get SendToKey.
	 * 
	 * @return SendToKey
	 */
	public SendToKey getSendToKey();
	
	/**
	 * set SendToKey
	 * 
	 * @param sendToKey SendToKey
	 */
	public void setSendToKey(SendToKey sendToKey);

	
}
