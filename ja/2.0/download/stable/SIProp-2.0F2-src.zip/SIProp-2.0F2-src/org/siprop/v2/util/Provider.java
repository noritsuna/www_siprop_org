/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.util;

import java.util.Map;

import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.Router;

/**
 * Initial all SIProp instances.
 * 
 * @author noritsuna
 * 
 */
public interface Provider {

	/**
	 * setup SIProp.<BR>
	 * Initial all instances.
	 * 
	 * @param prop PropertiesDepot
	 */
	public void setup(PropertiesDepot prop);

	/**
	 * start SIProp.
	 */
	public void start();

	/**
	 * stop SIProp.
	 */
	public void stop();

	/**
	 * get Repository.
	 * 
	 * @param key RepositoryKey
	 * @return Repository
	 */
	public Repository getRepository(RepositoryKey key);
	
	/**
	 * get Resolver map.
	 * @return Resolver Map
	 */
	public Map<Class, Object> getResolvers();

	/**
	 * get Property.
	 * @return PropertiesDepot
	 */
	public PropertiesDepot getProperty();
	
	
	/**
	 * get router.
	 * @return Router
	 */
	public Router getRouter();

}
