/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction.impl;

import gov.nist.javax.sip.message.SIPRequest;

import org.siprop.v2.core.messge.AbstractInfo;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.stack.sip.transaction.TransactionInfo;

/**
 * This class holds the packet about a Transaction.
 * 
 * @author noritsuna
 * 
 */
public class TransactionInfoImpl extends AbstractInfo implements TransactionInfo {

	/**
	 * serialize key.
	 */
	private static final long serialVersionUID = -3523639417741177851L;

	/**
	 * The Context originated this transaction.
	 */
	private Context originalContext = null;

	/**
	 * Via branch value
	 */
	private String branch;

	/**
	 * To tag value
	 */
	private String tagTo = null;

	
	/**
	 * Constructor.
	 * 
	 * @param originalContext
	 */
	public TransactionInfoImpl(Context originalContext) {
		this.originalContext = originalContext;
		setOriginalPacket(originalContext.getOriginalPacket());
		setCurrentPacket(originalContext.getCurrentPacket());		
	}
	

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#setViaBranch(java.lang.String)
	 */
	public void setViaBranch(String branch) {
		this.branch = branch;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getViaBranch()
	 */
	public String getViaBranch() {
		return this.branch;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getTagFrom()
	 */
	public String getTagFrom() {
		if (this.originalContext == null) {
			return null;
		}

		return ((SIPRequest) (this.originalContext.getCurrentPacket()
				.getFlatMessage().getMessage())).getFromTag();
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getTagTo()
	 */
	public String getTagTo() {
		return this.tagTo;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getCSeqNumber()
	 */
	public long getCSeqNumber() {
		if (this.originalContext == null) {
			return -1;
		}

		return ((SIPRequest) (this.originalContext.getCurrentPacket()
				.getFlatMessage().getMessage())).getCSeq().getSeqNumber();
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#setTagTo(java.lang.String)
	 */
	public void setTagTo(String tag) {
		this.tagTo = tag;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getMethod()
	 */
	public String getMethod() {
		if (this.originalContext == null) {
			return null;
		}

		return ((SIPRequest) (this.originalContext.getCurrentPacket()
				.getFlatMessage().getMessage())).getCSeq().getMethod();
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#getOriginalContext()
	 */
	public Context getOriginalContext() {
		return this.originalContext;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.transaction.TransactionInfo#setOriginalContext(org.siprop.v2.core.messge.Context)
	 */
	public void setOriginalContext(Context context) {
		this.originalContext = context;		
	}

}
