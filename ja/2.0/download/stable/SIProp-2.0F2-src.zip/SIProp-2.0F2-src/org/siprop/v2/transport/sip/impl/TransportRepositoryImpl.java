/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.transport.sip.impl;

import org.siprop.v2.core.Manager;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.core.router.impl.MessageRouteKey;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.core.router.impl.MessageRouterInfo;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.Provider;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.Peer;
import org.siprop.v2.util.resolver.impl.BindingResolver;
import org.siprop.v2.util.resolver.impl.RegisterResolver;

/**
 * Repository for Transport.
 * 
 * @author noritsuna
 *
 */
public class TransportRepositoryImpl implements Repository {

	/**
	 * manager.
	 */
	private Manager manager = null;

	/**
	 * default binding IP address. "" means NULL binding
	 */
	private String localAddress = "0.0.0.0";

	/**
	 * default port number
	 */
	private int localPort = 5060;

	/**
	 * default transport protocol
	 */
	private int protocol = Peer.IPPROTO_UDP;

	/**
	 * Is IPv6 enable or not.
	 */
	private boolean enableIPv6 = true;

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#setup(org.siprop.v2.util.PropertiesDepot, org.siprop.v2.util.Provider)
	 */
	public void setup(PropertiesDepot prop, Provider provider) {
		Logger.getGlobal().finest(null, "in TransportRepositoryImpl.create.");

		TransportManagerImpl transportManager = new  TransportManagerImpl();
		this.manager = transportManager;

		// set BindingResolver.
		this.manager.setBindingResolver((BindingResolver)provider.getResolvers().get(BindingResolver.class));

		// set RegisterResolver.
		this.manager.setRegisterResolver((RegisterResolver)provider.getResolvers().get(RegisterResolver.class));


		// set UniKeyGenerator.
		this.manager.setUniKeyGenerator(null);

		// set router.
		RouteKey rtrKey = new MessageRouteKey();
		rtrKey.setRouteid("TransportManager");
		rtrKey.setRoutetype(LayerEnum.TRANSPORT);

		RouterInfo rtrInfo = new MessageRouterInfo();
		rtrInfo.setRouteKey(rtrKey);
		rtrInfo.addListener(this.manager);

		MessageRouter router = (MessageRouter)provider.getRouter();
		router.addRoute(rtrInfo);

		//this.manager.setRouteKey(rtrKey);
		RouteKeyResolver.register(LayerEnum.TRANSPORT, rtrKey);
		this.manager.setRouter(router);

		// create peer.
		String localAddress = this.getLocalAddress();		
		TransportIoHandler handler = new TransportIoHandler(manager);
		
		//SIPのポートオープン
		SipConnectorImpl sipConnectorImpl = new SipConnectorImpl();
		sipConnectorImpl.setLocalPort(localPort);
		sipConnectorImpl.setLocalAddress(localAddress);
		sipConnectorImpl.setProtocol(protocol);
		sipConnectorImpl.setHandler(handler);
		sipConnectorImpl.init();
		//登録しておく
		transportManager.addConnector(sipConnectorImpl);
		
	}


	/**
	 * register start point of Transport to the MessageRouter
	 * 
	 * @param repository
	 *            configuration
	 */
	public void addRouter(Repository repository) {

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getRepository(org.siprop.v2.core.repository.RepositoryKey)
	 */
	public Repository getRepository(RepositoryKey key) {
		return this;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getManager()
	 */
	public Manager getManager() {
		return this.manager;
	}

	/**
	 * get local binding address
	 */
	public String getLocalAddress() {
		return this.localAddress;
	}

	/**
	 * get local port number
	 * 
	 * @return local port number
	 */
	public int getLocalPort() {
		return this.localPort;
	}

	/**
	 * get transport protocol
	 */
	public int getTransportProtocol() {
		return this.protocol;
	}

	/**
	 * check enable IPv6 or not.
	 * 
	 * @return enable IPv6 or not.
	 */
	public boolean isEnableIPv6() {
		return this.enableIPv6;
	}
}
