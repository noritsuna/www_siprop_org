/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.siprop.v2.core.Manager;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.core.router.impl.MessageRouteKey;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.core.router.impl.MessageRouterInfo;
import org.siprop.v2.ua.impl.UAInterpreter;
import org.siprop.v2.ua.sip.util.impl.UAKeyDiscriminator;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.Provider;
import org.siprop.v2.util.resolver.impl.BindingResolver;
import org.siprop.v2.util.resolver.impl.RegisterResolver;

/**
 * Repository for UA.
 * 
 * @author noritsuna
 * 
 */
public class UARepositoryImpl implements Repository {

	/**
	 * PropertiesDepot.
	 */
	private PropertiesDepot prop = null;

	/**
	 * Manager.
	 */
	private Manager manager = null;

	/**
	 * list of UACommand.
	 */
	private List<String> commandUAs = null;

	/**
	 * list of service name.
	 */
	private List<String> serviceList = null;

	/**
	 * map of UACommand.
	 */
	private Map<String, List<String>> commandServiceMap = null;

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#setup(org.siprop.v2.util.PropertiesDepot, org.siprop.v2.util.Provider)
	 */
	public void setup(PropertiesDepot prop, Provider provider) {

		this.prop = prop;

		this.commandServiceMap = new HashMap<String, List<String>>();

		String serviceName = "sip";

		// Create UACommands.
		this.commandUAs = new ArrayList<String>();
		this.commandUAs.add("Default");
		this.commandUAs.add("Register");
		this.commandUAs.add("Invite");
		this.commandUAs.add("Cancel");
		this.commandUAs.add("Bye");
		this.commandUAs.add("Error");

		// Create service list.
		this.serviceList = new ArrayList<String>();
		this.serviceList.add(serviceName);
		this.commandServiceMap.put(serviceName, this.commandUAs);

		UAManagerImpl uaManager = new UAManagerImpl();
		this.manager = uaManager;

		// set BindingResolver.
		this.manager.setBindingResolver((BindingResolver)provider.getResolvers().get(BindingResolver.class));

		// set RegisterResolver.
		this.manager.setRegisterResolver((RegisterResolver)provider.getResolvers().get(RegisterResolver.class));


		// set Service Name.
		uaManager.setServiceName(serviceName);

		// Init Interpriter.
		UAInterpreter interpreter = new UAInterpreter();
		for (String serviceStr : this.getServices()) {
			interpreter.createCommandList(
					this.getCommandUAs(serviceStr), serviceStr);
		}
		uaManager.setUaInterpreter(interpreter);

		// set UniKey Discriminator.
		this.manager.setUniKeyGenerator(new UAKeyDiscriminator());

		// set router.
		RouteKey key = new MessageRouteKey();
		key.setRouteid("UAManager");
		key.setRoutetype(LayerEnum.UA);

		RouterInfo routerInfo = new MessageRouterInfo();
		routerInfo.setRouteKey(key);
		routerInfo.addListener(this.manager);

		MessageRouter router = (MessageRouter)provider.getRouter();
		router.addRoute(routerInfo);

		RouteKeyResolver.register(LayerEnum.UA, key);
		this.manager.setRouter(router);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.repository.Repository#getManager()
	 */
	public Manager getManager() {
		return this.manager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.repository.Repository#getRepository(org.siprop.v2.core.repository.RepositoryKey)
	 */
	public Repository getRepository(RepositoryKey key) {
		return this;
	}

	/**
	 * get list of service name.
	 * 
	 * @return service name list
	 */
	public List<String> getServices() {
		return this.serviceList;
	}

	/**
	 * get list of UACommand.
	 * 
	 * @param serviceName service name
	 * @return CommandUA list
	 */
	public List<String> getCommandUAs(String serviceName) {
		return this.commandServiceMap.get(serviceName);
	}

}
