/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.router;

/**
 * Interface of dynamic route Router.
 * 
 * @author noritsuna
 * 
 */
public interface DynamicRouter extends Router {

	/**
	 * add Route information.
	 * 
	 * @param routerinfo Route information
	 */
	public void addRoute(RouterInfo routerinfo);

	/**
	 * delete Route information by RouteKey.
	 * 
	 * @param routekey Route key
	 */
	public void removeRoute(RouteKey routekey);

	/**
	 * delete Route information by RouterInfo.
	 * 
	 * @param routerinfo Route information
	 */
	public void removeRoute(RouterInfo routerinfo);

	/**
	 * get RouterInfo.
	 * 
	 * @param routekey Route key
	 * @return Route information
	 */
	public RouterInfo getRouterInfo(RouteKey routekey);
	
	
	/**
	 * Start Router.
	 */
	public void start();

	/**
	 * Stop router.
	 */
	public void stop();

}
