/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.impl;

import org.siprop.SIPropException;
import org.siprop.v2.core.Manager;
import org.siprop.v2.core.repository.Repository;
import org.siprop.v2.core.repository.RepositoryKey;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.core.router.impl.MessageRouteKey;
import org.siprop.v2.core.router.impl.MessageRouter;
import org.siprop.v2.core.router.impl.MessageRouterInfo;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.tu.TransactionUser;
import org.siprop.v2.stack.sip.tu.function.TuFunction;
import org.siprop.v2.stack.sip.tu.function.TuFunctionComposer;
import org.siprop.v2.stack.sip.tu.function.impl.CancelHandlerImpl;
import org.siprop.v2.stack.sip.tu.function.impl.MaxForwardsHandlerImpl;
import org.siprop.v2.stack.sip.tu.function.impl.ViaHandlerImpl;
import org.siprop.v2.stack.sip.tu.impl.TransactionUserImpl;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.Provider;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.resolver.impl.BindingResolver;
import org.siprop.v2.util.resolver.impl.RegisterResolver;

/**
 * Repository for Stack.
 * 
 * @author noritsuna
 *
 */
public class StackRepositoryImpl implements Repository {

	/**
	 * PropertiesDepot.
	 */
	private PropertiesDepot prop = null;

	/**
	 * Stack Manager.
	 */
	private Manager manager = null;

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#setup(org.siprop.v2.util.PropertiesDepot, org.siprop.v2.util.Provider)
	 */
	public void setup(PropertiesDepot prop, Provider provider) {

		this.prop = prop;

		StackManager stackManager = new StackManagerImpl();
		this.manager = stackManager;

		// set BindingResolver.
		this.manager.setBindingResolver((BindingResolver)provider.getResolvers().get(BindingResolver.class));

		// set RegisterResolver.
		this.manager.setRegisterResolver((RegisterResolver)provider.getResolvers().get(RegisterResolver.class));


		// add router.
		RouteKey rtrKey = new MessageRouteKey();
		rtrKey.setRouteid("StackManager");
		rtrKey.setRoutetype(LayerEnum.STACK);

		RouterInfo rtrInfo = new MessageRouterInfo();
		rtrInfo.setRouteKey(rtrKey);
		rtrInfo.addListener(stackManager);

		MessageRouter router = (MessageRouter)provider.getRouter();
		router.addRoute(rtrInfo);

		RouteKeyResolver.register(LayerEnum.STACK, rtrKey);
		this.manager.setRouter(router);
		
		// create TU list
		createTUs();

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getRepository(org.siprop.v2.core.repository.RepositoryKey)
	 */
	public Repository getRepository(RepositoryKey key) {
		return this;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.repository.Repository#getManager()
	 */
	public Manager getManager() {
		return this.manager;
	}

	public void setManager(Manager manager) {
		this.manager = manager;
	}

	/**
	 * Create new TUs and register it to own list.
	 */
	public void createTUs() {
		// XXX create one default TU
		TransactionUser tu = createDefaultTU();
		((StackManager)this.manager).addTU(tu);
	}
	
	/**
	 * Create default TransactionUser and register function set 
	 * @return instance of the default Transaction User.
	 */
	public TransactionUser createDefaultTU() {
		TransactionUser tu = new TransactionUserImpl((StackManager)this.manager);
		TuFunctionComposer tuFuncs = createDefaultTUFunctions((StackManager)this.manager);
		tu.setTuFunctionComposer(tuFuncs);
		return tu;
	}
	
	/**
	 * make up the behavior of this TU
	 * 
	 * @param repository
	 *            configuration
	 */
	private TuFunctionComposer createDefaultTUFunctions(StackManager stackManager) {
		TuFunctionComposer tuFuncs = new TuFunctionComposer();

		Logger.getGlobal().fine(null, "creating functions for the default TU");

		// XXX create function set
		TuFunction function1 = new MaxForwardsHandlerImpl(stackManager, 70);
		try {
			tuFuncs.addFunction(function1);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.getGlobal().fine(null, "creating a Max-Forwards header handler");

		TuFunction function2 = new ViaHandlerImpl(stackManager);
		
		
		try {
			tuFuncs.addFunction(function2);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.getGlobal().fine(null, "creating a Via header handler");

		// KEEP LAST
		TuFunction function3 = new CancelHandlerImpl(stackManager);
		try {
			tuFuncs.addFunction(function3);
		} catch (SIPropException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Logger.getGlobal().fine(null, "creating a Cancel method handler");
		return tuFuncs;
	}
}
