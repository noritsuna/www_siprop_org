/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.util.Discriminator;
import org.siprop.v2.util.resolver.impl.BindingResolver;
import org.siprop.v2.util.resolver.impl.RegisterResolver;

/**
 * This interface is an object for management of each layer.
 * 
 * @author noritsuna
 * 
 */
public interface Manager extends Listener {

	/**
	 * get Router.
	 * 
	 * @return Router
	 */
	public Router getRouter();

	/**
	 * set Router.
	 * 
	 * @param router
	 */
	public void setRouter(Router router);

	/**
	 * get Discriminator of unique key.
	 * 
	 * @return Discriminator of unique key
	 */
	public Discriminator getUniKeyGenerator();

	/**
	 * set Discriminator of unique key.
	 * 
	 * @param uniKeyGenerator
	 *            Discriminator of unique key
	 */
	public void setUniKeyGenerator(Discriminator uniKeyGenerator);

	/**
	 * set BindingResolver.
	 * 
	 * @param bindingResolver
	 */
	public void setBindingResolver(BindingResolver bindingResolver);
	
	/**
	 * get BindingResolver.
	 * 
	 * @return BindingResolver
	 */
	public BindingResolver getBindingResolver();
	
	/**
	 * set RegisterResolver.
	 * 
	 * @param registerResolver
	 */
	public void setRegisterResolver(RegisterResolver registerResolver);
	
	/**
	 * get RegisterResolver.
	 * 
	 * @return RegisterResolver
	 */
	public RegisterResolver getRegisterResolver();
	
	/**
	 * get service name.
	 * 
	 * @return service name.
	 */
	public String getServiceName();
	
	/**
	 * set service name.
	 * 
	 * @param serviceName
	 *            service name.
	 */
	public void setServiceName(String serviceName);

	/**
	 * Execute process.
	 * 
	 * @param processName
	 *            name of a process to perform
	 * @param param
	 *            process's parameter
	 */
	public void doProcess(String processName, Object[] param);

	/**
	 * It sends to a router.
	 * 
	 * @param context
	 */
	public void send(Context context);
	

	/**
	 * Manager start.
	 */
	public void start();
	
	/**
	 * Manager stop.
	 */
	public void stop();

}
