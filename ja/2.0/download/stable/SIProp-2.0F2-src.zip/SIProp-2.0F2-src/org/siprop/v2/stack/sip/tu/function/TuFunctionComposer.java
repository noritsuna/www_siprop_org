/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu.function;

import java.util.LinkedList;
import java.util.List;

import org.siprop.SIPropException;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.stack.sip.transaction.TransactionEntry;

/**
 * Composer for TuFunction.
 * 
 * @author noritsuna
 * 
 */
public class TuFunctionComposer implements TuFunction {

	/**
	 * list of function.
	 */
	private List<TuFunction> functions = new LinkedList<TuFunction>();

	
	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#doProcess(org.siprop.v2.core.messge.Context, org.siprop.v2.stack.sip.transaction.TransactionEntry)
	 */
	public Context doProcess(Context context, TransactionEntry trnsct) {
		Context rspMsg = null;

		for (TuFunction function : functions) {
			rspMsg = function.doProcess(context, trnsct);
			if (rspMsg != null) {
				return rspMsg;
			}
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#addFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void addFunction(TuFunction function) throws SIPropException {
		if (function == null) {
			throw new NullPointerException();
		}
		this.functions.add(function);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.stack.sip.tu.function.TuFunction#removeFunction(org.siprop.v2.stack.sip.tu.function.TuFunction)
	 */
	public void removeFunction(TuFunction function) throws SIPropException {
		this.functions.remove(function);
	}

}
