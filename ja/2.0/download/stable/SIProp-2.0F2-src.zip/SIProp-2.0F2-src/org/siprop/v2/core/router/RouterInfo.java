/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.router;

import org.siprop.v2.core.Listener;

/**
 * This interface holds routing information. 
 * 
 * @author nisato
 * 
 */
public interface RouterInfo {
	
	/**
	 * add Listener.<BR>
	 * It is an instance of the call-back point. 
	 * 
	 * @param routerlistener
	 */
	public void addListener(Listener routerlistener);

	/**
	 * set Route key.<BR>
	 * It is the conditions for matching. 
	 * 
	 * @param routekey
	 */
	public void setRouteKey(RouteKey routekey);

	/**
	 * get Route key.
	 * 
	 * @return route key
	 */
	public RouteKey getRouteKey();

	/**
	 * get Listener.
	 * 
	 * @return listener
	 */
	public Listener getListener();
}
