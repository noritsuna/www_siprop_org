/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction;

/**
 * This enum indicates type of SIP transaction.
 * 
 * @author masaxmasa
 * 
 */
public enum TransactionType {
	TRANSACTIONTYPE_INV_UAC(), // INVITE Client Transaction
	TRANSACTIONTYPE_INV_UAS(), // UAS trasaction
	TRANSACTIONTYPE_NONINV_UAC(), // Non-INVITE Client Transaction
	TRANSACTIONTYPE_NONINV_UAS(), // Non-INVITE Client Transaction
}
