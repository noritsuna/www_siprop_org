/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip;

import org.siprop.v2.b2bua.B2BUAContext;
import org.siprop.v2.b2bua.B2BUAManager;
import org.siprop.v2.b2bua.B2BUAModule;
import org.siprop.v2.core.messge.Context;

/**
 * abstract B2BUAModul for SIP.
 * 
 * @author noritsuna
 * 
 */
public abstract class AbstractSIPB2BUAModule implements B2BUAModule {

	/**
	 * manager of the call-back point.
	 */
	protected B2BUAManager callBackManager = null;
	
	/**
	 * Context for processing.
	 */
	protected B2BUAContext uaContext = null;

	/**
	 * The name which shows this module.
	 */
	protected String moduleName = null;

	/**
	 * GC flag.
	 */
	protected boolean deleteFlag = false;

	/**
	 * Constructor.
	 */
	public AbstractSIPB2BUAModule() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAModule#send(org.siprop.v2.core.messge.Context)
	 */
	public void send(Context context) {
		this.getCallBackManager().send(context);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAModule#setDeleteFlag(boolean)
	 */
	public void setDeleteFlag(boolean flag) {
		this.deleteFlag = flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAModule#getDeleteFlag()
	 */
	public boolean getDeleteFlag() {
		return this.deleteFlag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAModule#getModuleName()
	 */
	public String getModuleName() {
		return moduleName;
	}

	/**
	 * set The name which shows this module.
	 * 
	 * @param moduleName
	 *            The name which shows this module.
	 */
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAModule#getCallBackManager()
	 */
	public B2BUAManager getCallBackManager() {
		return callBackManager;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAModule#setCallBackManager(org.siprop.v2.core.Manager)
	 */
	public void setCallBackManager(B2BUAManager callBackManager) {
		this.callBackManager = callBackManager;
	}
}
