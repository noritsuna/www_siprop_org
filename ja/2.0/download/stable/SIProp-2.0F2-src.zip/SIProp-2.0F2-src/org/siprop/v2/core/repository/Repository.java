/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.repository;

import org.siprop.v2.core.Manager;
import org.siprop.v2.util.PropertiesDepot;
import org.siprop.v2.util.Provider;

/**
 * Interface of Repository.<BR>
 * hold Property and instance.
 * 
 * @author noritsuna
 * 
 */
public interface Repository {

	/**
	 * Setup Layer modules.
	 * 
	 * @param prop
	 */
	public void setup(PropertiesDepot prop, Provider provider);

	/**
	 * get Lower layer Repository.
	 * 
	 * @param key
	 * @return Lower layer Repository
	 */
	public Repository getRepository(RepositoryKey key);

	/**
	 * get this layer Manager.
	 * 
	 * @return Manager
	 */
	public Manager getManager();

}
