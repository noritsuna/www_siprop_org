/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.ua.sip.command.impl;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.Packet;
import org.siprop.v2.core.messge.impl.MessageContextPacketImpl;
import org.siprop.v2.core.router.LayerEnum;
import org.siprop.v2.core.router.RouteKeyResolver;
import org.siprop.v2.core.router.impl.SendToKey;
import org.siprop.v2.ua.UACommand;
import org.siprop.v2.ua.UAContext;
import org.siprop.v2.util.impl.Logger;

/**
 * UACommand of Default.
 * 
 * @author noritsuna
 * 
 */
public class DefaultUA implements UACommand {

	/**
	 * UACommand name.
	 */
	public static final String UA_COMMAND_NAME = "Default";
	
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.ua.UACommand#getUACommandName()
	 */
	public String getUACommandName() {
		return UA_COMMAND_NAME;
	}

	/**
	 * Initial command.
	 * 
	 * @param context
	 * @param uaContext
	 */
	public void do_Default_init(Context context, UAContext uaContext) {
		Logger.getGlobal().fine(context, "in DefaultUA.do_Default_init().");

		Packet oldPacket = context.getCurrentPacket();
		
		Packet newPacket = MessageContextPacketImpl
				.copyMessageContextPacket((MessageContextPacketImpl) context
						.getCurrentPacket());

		SendToKey sendToKey = new SendToKey(RouteKeyResolver
				.resolve(LayerEnum.UA), RouteKeyResolver
				.resolve(LayerEnum.B2BUA));
		newPacket.setSendToKey(sendToKey);

		newPacket.setControlMessage(oldPacket.getControlMessage());

		context.addPacket(newPacket);

	}

}
