/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.router.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.siprop.v2.core.MessageException;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.MessageContext;
import org.siprop.v2.core.messge.Packet;
import org.siprop.v2.core.messge.impl.MessageContextImpl;
import org.siprop.v2.core.router.DynamicRouter;
import org.siprop.v2.core.router.RouteKey;
import org.siprop.v2.core.router.Router;
import org.siprop.v2.core.router.RouterInfo;
import org.siprop.v2.util.impl.Logger;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * This class is a router for MessageContextImpl. 
 * 
 * @author nisato
 * 
 */
public class MessageRouter implements DynamicRouter {

	/**
	 * list of RouterInfo.
	 */
	private List<RouterInfo> routerinfolist = null;

	/**
	 * number of threads.
	 */
	private Integer threadpoolnum;
	
	/**
	 * ExecutorService for routing.
	 */
	private ExecutorService routeingthreadexecutor;

	/**
	 * base name of StackControlMessageImpl
	 */
	public static final String CONTROLMESSAGE_BASENAME = "MessageRouterControlMessage";
	
	
	/**
	 * Constructor.
	 * 
	 */
	public MessageRouter() {
		// default thread number.
		threadpoolnum = 10;
		routerinfolist = Collections.synchronizedList(new ArrayList<RouterInfo>());
	}
	



	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.DynamicRouter#start()
	 */
	public void start() {
		// set threads.
		this.routeingthreadexecutor = Executors
				.newFixedThreadPool(threadpoolnum);
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.DynamicRouter#stop()
	 */
	public void stop() {
		throw new NotImplementedException();
	}

	/**
	 * @param count
	 */
	public void setThreadPoolCount(int count) {
		this.threadpoolnum = count;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.DynamicRouter#addRoute(org.siprop.v2.core.router.RouterInfo)
	 */
	public void addRoute(RouterInfo routerinfo) {
		this.routerinfolist.add(routerinfo);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.Router#doRoute(org.siprop.v2.core.messge.Context)
	 */
	public void doRoute(Context messagecontext) throws MessageException {
		// thread pool run
		Logger.getGlobal().finest(messagecontext, "in doRoute.");
		try {
			submitNewThread(messagecontext);
		} catch (Exception e) {
			throw new MessageException(e.getMessage(), e);
		}
		Logger.getGlobal().finest(messagecontext, "out doRoute.");
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.DynamicRouter#getRouterInfo(org.siprop.v2.core.router.RouteKey)
	 */
	public RouterInfo getRouterInfo(RouteKey routekey) {
		for (RouterInfo routerinfo : routerinfolist) {
			if (routerinfo.getRouteKey().getRouteid() == routekey.getRouteid())
				return routerinfo;
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.DynamicRouter#removeRoute(org.siprop.v2.core.router.RouteKey)
	 */
	public void removeRoute(RouteKey routekey) {
		for (RouterInfo routerinfo : routerinfolist) {
			if (routerinfo.getRouteKey().getRouteid() == routekey.getRouteid())
				routerinfolist.remove(routerinfo);
		}
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.router.DynamicRouter#removeRoute(org.siprop.v2.core.router.RouterInfo)
	 */
	public void removeRoute(RouterInfo routerinfo) {
		for (RouterInfo irouterinfo : routerinfolist) {
			if (irouterinfo.getRouteKey().getRouteid() == routerinfo
					.getRouteKey().getRouteid())
				routerinfolist.remove(routerinfo);
		}
	}

	/**
	 * create & submit new thread.
	 * 
	 * @param messagecontext
	 */
	private void submitNewThread(Context context) {
		this.routeingthreadexecutor.submit(new DoRouterCallableImpl(this, context));
	}

	/**
	 * do routing thread.
	 */
	private class DoRouterCallableImpl implements Callable {

		/**
		 * sending Context.
		 */
		private Context context;
		
		/**
		 * sending Router.
		 */
		private Router router;

		/**
		 * Constructor.
		 * 
		 * @param router sending Router
		 * @param messagecontext sending MessageContextImpl
		 */
		public DoRouterCallableImpl(Router router, Context context) {
			this.context = context;
			this.router = router;
		}

		/* (non-Javadoc)
		 * @see java.util.concurrent.Callable#call()
		 */
		public Object call() {

			// create new Context.
			MessageContext newContext = MessageContextImpl
					.copyMessageContext((MessageContextImpl)context);
			Packet packet = newContext.getInfo().getPacket(true);
			
			// check MessageContextPacketImpl.
			if (packet == null) {
				Logger.getGlobal().warning(newContext,
						"Next packet doesn't defined: discarded");
				return null;
			}

			// check next MessageContextPacketImpl.
			if (!newContext.isPacketEnd()) {
				MessageContext nextSubmitContext = MessageContextImpl
						.copyMessageContext(newContext);
				try {
					router.doRoute(nextSubmitContext);
				} catch (MessageException e) {
					Logger.getGlobal().severe(newContext,
					"doRoute exec error. MessageException.");
					e.printStackTrace();
				} catch (Exception e) {
					Logger.getGlobal().severe(newContext,
					"doRoute exec error.");
					e.printStackTrace();
				}
			}

			// set Current MessageContextImpl.
			newContext.setCurrentPacket(packet);
			
			// get send to key.
			SendToKey sendToKey = newContext.getCurrentPacket().getSendToKey();
			if (sendToKey == null) {
				/*
				 * There is no LayerKey
				 */
				Logger.getGlobal().warning(newContext,
						"Next Layer doesn't defined: discarded");
				return null;
			}

			RouteKey nextSendTo = sendToKey.getSendTo();
			if (nextSendTo == null) {
				/*
				 * next layer doesn't defined
				 */
				Logger.getGlobal().warning(newContext,
						"Next Layer doesn't defined: discarded");
				return null;
			}

			Logger.getGlobal().finest(
					newContext,
					"A destination of this message is "
							+ nextSendTo.getRouteid().toString());

			// send next Listener.
			for (RouterInfo rtrinfo : routerinfolist) {
				try {
					String infoSendTo = (String) rtrinfo.getRouteKey().getRouteid();
					if (infoSendTo.equals((String) nextSendTo.getRouteid())) {
						Logger.getGlobal().finest(
								newContext,
								"The message is forwarded to "
										+ nextSendTo.getRouteid().toString());
							rtrinfo.getListener().onReceive(newContext);
						return null;
					}
				} catch (MessageException e) {
					Logger.getGlobal().severe(newContext,
					"onReceive exec error. MessageException.");
					e.printStackTrace();
				} catch (Exception e) {
					Logger.getGlobal().severe(newContext,
					"onReceive exec error.");
					e.printStackTrace();
				}
			}

			// not found next Listener.
			Logger.getGlobal().warning(newContext,
					"No valid Next Layer is found: discarded");

			return null;
		}
	}
}
