/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.siprop.v2.b2bua.B2BUAControlMessage;
import org.siprop.v2.b2bua.B2BUAManager;
import org.siprop.v2.b2bua.B2BUAModule;
import org.siprop.v2.core.AbstractManager;
import org.siprop.v2.core.messge.Context;
import org.siprop.v2.util.impl.Logger;
import org.siprop.v2.util.impl.ManagerGarbageCollector;

/**
 * Manager for standard B2BUA.
 * 
 * @author noritsuna
 * 
 */
public class B2BUAManagerImpl extends AbstractManager implements B2BUAManager {

	/**
	 * map of B2BUAModule.
	 */
	private Map<String, B2BUAModule> b2buaMap = null;

	/**
	 * list of B2BUAModule Class.
	 */
	private Map<String, Class> b2buaModuleClazz = null;

	/**
	 * list of B2BUA keys.
	 */
	private List<String> b2buaKeyList = null;

	/**
	 * Service name.
	 */
	private String serviceName = "sip";
	

	/**
	 * Package name of pre.
	 */
	private static final String PACKAGE_B2BUA_PRE = "org.siprop.v2.b2bua.";

	/**
	 * Package name of post.
	 */
	private static final String PACKAGE_B2BUA_POST = ".module.impl.";

	/**
	 * Package name of ident.
	 */
	private static final String IDENT_B2BUA = "B2BUA";

	/**
	 * default module name.
	 */
	public static final String DEFAULT_MODULE_NAME = "Asterisk";

	/**
	 * doProcess() name.
	 */
	public static final String PROCESS_NAME_ADDMODULE = "ADD_MODULE";

	/**
	 * instance of garbage collector
	 */
	private ManagerGarbageCollector garbageCollector = null;

	/**
	 * instance of garbage collector tread.
	 */
	private Thread gcThread = null;

	/**
	 * Constructor.
	 * 
	 */
	public B2BUAManagerImpl() {
		this.b2buaMap = Collections
				.synchronizedMap(new HashMap<String, B2BUAModule>());
		this.b2buaKeyList = Collections
				.synchronizedList(new LinkedList<String>());

		this.b2buaModuleClazz = Collections
				.synchronizedMap(new HashMap<String, Class>());
		
		/*
		 * create TransactionGarbageCollector and run it.
		 */
		this.garbageCollector = new ManagerGarbageCollector(this);
		this.gcThread = new Thread(this.garbageCollector);
		this.gcThread.start();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Listener#onReceive(org.siprop.v2.core.messge.Context)
	 */
	public void onReceive(Context context) {
		Logger.getGlobal().fine(context, "in B2BUAManager.receive().");

		B2BUAModule b2bua = this.getB2BUAModule(context);
		if (b2bua == null) {
			Logger.getGlobal().warning(context, "Don't create B2BUAModule.");
			return;
		}
		synchronized (b2bua) {
			b2bua.receive(context);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAManager#getB2BUAModule(org.siprop.v2.core.messge.Context)
	 */
	public B2BUAModule getB2BUAModule(Context context) {

		B2BUAModule b2bua = this.getB2BUAModule((String) this
				.getUniKeyGenerator().generateKey(context));
		if (b2bua == null) {

//			B2BUAControlMessage b2buaCtrl = (B2BUAControlMessageImpl) context
//					.getCurrentPacket().getControlMessage();
			B2BUAControlMessage b2buaCtrl = null;

			//TODO ここは、サービスごとに1インスタンスとする？
			if (b2buaCtrl == null) {
				b2bua = this.createB2BUAModule(DEFAULT_MODULE_NAME);
			} else {
				b2bua = this.createB2BUAModule(b2buaCtrl.getDoModuleName());
			}
			if (b2bua == null) {
				return null;
			}
			this.addB2UAModule(context, b2bua);
		}

		return b2bua;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAManager#createB2BUAModule(java.lang.String)
	 */
	public B2BUAModule createB2BUAModule(String doModuleName) {
		try {
			B2BUAModule module = (B2BUAModule) this.b2buaModuleClazz.get(
					serviceName + doModuleName).newInstance();
			module.setCallBackManager(this);
			return module;
		} catch (InstantiationException e) {
			Logger.getGlobal().warning(null,
					"B2BUAModule load error. :" + e.getMessage());
		} catch (IllegalAccessException e) {
			Logger.getGlobal().warning(null,
					"B2BUAModule load error. :" + e.getMessage());
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAManager#createModuleList(java.util.List)
	 */
	public void createModuleList(List<String> moduleList) {

		for (String clazzBaseName : moduleList) {
			Class clazz_B2BUA = null;
			try {
				clazz_B2BUA = ClassLoader.getSystemClassLoader().loadClass(
						PACKAGE_B2BUA_PRE + serviceName + PACKAGE_B2BUA_POST
								+ clazzBaseName + IDENT_B2BUA);

				this.b2buaModuleClazz.put(serviceName + clazzBaseName,
						clazz_B2BUA);

			} catch (ClassCastException e) {
				Logger.getGlobal().warning(null,
						"B2BUAModule load error. :" + e.getMessage());
			} catch (ClassNotFoundException e) {
				Logger.getGlobal().warning(null,
						"B2BUAModule load error. :" + e.getMessage());
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAManager#getB2BUAModule(java.lang.String)
	 */
	public B2BUAModule getB2BUAModule(String key) {
		return this.b2buaMap.get(key);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAManager#addB2UAModule(org.siprop.v2.core.messge.Context,
	 *      org.siprop.v2.b2bua.B2BUAModule)
	 */
	public void addB2UAModule(Context context, B2BUAModule b2bua) {
		String key = (String) this.getUniKeyGenerator().generateKey(context);
		this.b2buaMap.put(key, b2bua);
		this.b2buaKeyList.add(key);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAManager#deleteB2BUAModule(org.siprop.v2.core.messge.Context)
	 */
	public void deleteB2BUAModule(Context context) {
		String key = (String) this.getUniKeyGenerator().generateKey(context);
		this.deleteB2BUAModule(key);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.b2bua.B2BUAManager#deleteB2BUAModule(java.lang.String)
	 */
	public void deleteB2BUAModule(String key) {
		this.b2buaKeyList.remove(key);
		this.b2buaMap.remove(key);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.siprop.v2.core.Manager#doProcess(java.lang.String,
	 *      java.lang.Object[])
	 */
	public void doProcess(String processName, Object[] param) {
		if (processName.equals(ManagerGarbageCollector.PROCESS_NAME)) {
			this.doGC();
		} else if (processName.equals(B2BUAManagerImpl.PROCESS_NAME_ADDMODULE)) {
			this.addB2UAModule((Context) param[0], (B2BUAModule) param[1]);
		}
	}

	/**
	 * Execute GC.<BR>
	 * Delete to save B2BUAModule by delete Flag.
	 */
	private void doGC() {

		for (String key : this.b2buaKeyList) {
			B2BUAModule b2bua = this.getB2BUAModule(key);
			if (b2bua == null || b2bua.getDeleteFlag()) {
				this.deleteB2BUAModule(key);
			}
		}

	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#getServiceName()
	 */
	public String getServiceName() {
		return serviceName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#setServiceName(java.lang.String)
	 */
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#start()
	 */
	public void start() {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.Manager#stop()
	 */
	public void stop() {
		// TODO Auto-generated method stub
		
	}


}
