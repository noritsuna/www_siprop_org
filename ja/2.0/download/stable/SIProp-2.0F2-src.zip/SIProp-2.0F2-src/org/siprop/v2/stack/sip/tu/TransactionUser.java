/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.tu;

import java.util.List;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.stack.StackManager;
import org.siprop.v2.stack.sip.transaction.TransactionController;
import org.siprop.v2.stack.sip.tu.function.TuFunctionComposer;
import org.siprop.v2.util.Discriminator;

/**
 * This interface manages Transaction.
 * 
 * @author noritsuna
 *
 */
public interface TransactionUser {
	
	/**
	 * get StackManager.
	 * 
	 * @return called StackManager
	 */
	public StackManager getStackManager();
	
	/**
	 * set TuFunctionComposer.
	 * 
	 * @param tuFunctions TuFunctionComposer
	 */
	public void setTuFunctionComposer(TuFunctionComposer tuFunctions);
	
	/**
	 * send message
	 * 
	 * @param context
	 *            Context
	 */
	public void send(Context context);
	
	/**
	 * receive message
	 * 
	 * @param context
	 *            received Context
	 */
	public void receive(Context context);
	
	/**
	 * get list of transactions
	 * 
	 * @return a Transaction list
	 */
	public List<TransactionController> getTransactionControllerList();

	/**
	 * get Discriminator of unique key for itself manage list.
	 * 
	 * @return key generator
	 */
	public Discriminator getUniKeyGenerator();

	/**
	 * set Discriminator of unique key for itself manage list.
	 * 
	 * @param uniKeyGenerator key generator
	 */
	public void setUniKeyGenerator(Discriminator uniKeyGenerator);
	
	
	/**
	 * get unique key.
	 * 
	 * @return unique key of this instance
	 */
	public String getUniKey();

	/**
	 * set unique key.
	 * 
	 * @param uniKey unique key of this instance
	 */
	public void setUniKey(String uniKey);
	


}
