/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.stack.sip.transaction;

import org.siprop.v2.core.messge.Context;
import org.siprop.v2.core.messge.Info;

/**
 * This interface holds the packet about a Transaction.
 * 
 * @author noritsuna
 * 
 */
public interface TransactionInfo extends Info {
	
	/**
	 * Set original Context.
	 * 
	 * @param context original Context.
	 */
	public void setOriginalContext(Context context);
	
	/**
	 * Get original Context.
	 * 
	 * @return Context original Context.
	 */
	public Context getOriginalContext();
	
	
	/**
	 * Get Via branch value related transaction
	 * 
	 * @return Via branch
	 */
	public String getViaBranch();

	/**
	 * Set Via branch value
	 * 
	 * @param branch
	 *            new Via branch
	 */
	public void setViaBranch(String branch);

	/**
	 * Get tag of From header
	 * 
	 * @return From Tag
	 */
	public String getTagFrom();

	/**
	 * Get tag of To header
	 * 
	 * @return To Tag
	 */
	public String getTagTo();
	

	/**
	 * Set tag of To header
	 * 
	 * @param tag String To Tag
	 */
	public void setTagTo(String tag);

	/**
	 * Get CSeq Number
	 * 
	 * @return CSeq number
	 */
	public long getCSeqNumber();
	
	/**
	 * Get CSeq Method
	 * 
	 * @return CSeq method
	 */
	public String getMethod();
	
}
