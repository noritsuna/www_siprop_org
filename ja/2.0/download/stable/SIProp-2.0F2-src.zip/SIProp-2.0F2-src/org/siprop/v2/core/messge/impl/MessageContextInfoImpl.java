/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.core.messge.impl;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.siprop.v2.core.messge.AbstractInfo;
import org.siprop.v2.core.messge.MessageContextInfo;
import org.siprop.v2.core.messge.Packet;

/**
 * Info for MessageContextImpl.
 * 
 * @author noritsuna
 * 
 */
public class MessageContextInfoImpl extends AbstractInfo implements MessageContextInfo {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = -3336729108560263939L;

	/**
	 * list of Packet.
	 */
	private List<Packet> packetList = null;


	/**
	 * Constructor.
	 * 
	 */
	public MessageContextInfoImpl() {
		this.packetList = Collections
				.synchronizedList(new LinkedList<Packet>());
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.impl.AbstractInfo#getPacket(boolean)
	 */
	@Override
	public Packet getPacket(boolean isNextStep) {
		Packet messagePakcet = null;
		if(this.packetList.size() == 0) {
			return messagePakcet;
		}
		if (isNextStep) {
			messagePakcet = this.packetList.remove(0);
		} else {
			messagePakcet = this.packetList.get(0);
		}
		return messagePakcet;
	}


	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.impl.AbstractInfo#addPacket(org.siprop.v2.core.messge.Packet)
	 */
	@Override
	public void addPacket(Packet packet) {
		this.packetList.add(packet);
		super.addPacket(packet);
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.MessageContextInfo#isPacketEnd()
	 */
	public boolean isPacketEnd() {
		return this.packetList.isEmpty();
	}
}
