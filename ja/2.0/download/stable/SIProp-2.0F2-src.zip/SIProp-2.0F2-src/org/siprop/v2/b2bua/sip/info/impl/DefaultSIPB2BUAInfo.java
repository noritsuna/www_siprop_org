/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.v2.b2bua.sip.info.impl;

import org.siprop.v2.b2bua.B2BUAInfo;
import org.siprop.v2.core.messge.AbstractInfo;
import org.siprop.v2.core.messge.Packet;

/**
 * Default B2BUAInfo for SIP.
 * 
 * @author noritsuna
 * 
 */
public class DefaultSIPB2BUAInfo extends AbstractInfo implements B2BUAInfo {

	/**
	 * The key for serialization.
	 */
	private static final long serialVersionUID = 4072824295405232849L;

	/**
	 * Packet of previous.
	 */
	private Packet previousPacket = null;


	/* (non-Javadoc)
	 * @see org.siprop.v2.b2bua.B2BUAInfo#getPreviousPacket()
	 */
	public Packet getPreviousPacket() {
		return previousPacket;
	}

	/* (non-Javadoc)
	 * @see org.siprop.v2.core.messge.Info#addPacket(org.siprop.v2.core.messge.Packet)
	 */
	public void addPacket(Packet packet) {
		this.previousPacket = getCurrentPacket();
		super.addPacket(packet);
	}

}
