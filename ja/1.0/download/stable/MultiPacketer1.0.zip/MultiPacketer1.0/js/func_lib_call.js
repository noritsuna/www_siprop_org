/**
 * ��{�I�ȃ��b�Z�[�W�̐����Ȃǂ��s���X�N���v�g�B
 */


/**
 * ���X�|���X����ACK�𐶐�����B
 */
function createACK(packet) {

	// 200OK ���X�|���X����A�w�b�_�[�����o���B
	jsEngine.setVariablesForSIPByPacket(packet);

	var str = "ACK sip:{REMOTE_IP} SIP/2.0\r\n" +
                       "{CALL-ID}" +
                       "{CSEQ}" +
                       "{VIA}" +
                       "{FROM}" +
                       "{TO}" +
                       "Contact:<sip:{LOCAL_IP}:{LOCAL_PORT}>\r\n" +
                       "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS,MESSAGE\r\n" +
                       "Max-Forwards:70\r\n" +
                       "Content-Type: application/sdp\r\n" +
                       "Content-Length:0\r\n\r\n";
                       
	return str;

}

/**
 * 100Trying�𐶐�����B
 */
function create100Trying() {

	var str = "SIP/2.0 100 Trying\r\n" +
                       "{CALL-ID}" +
                       "{CSEQ}" +
                       "{VIA}" +
                       "{FROM}" +
                       "{TO}" +
                       "Contact:<sip:{LOCAL_IP}:{LOCAL_PORT}>\r\n" +
                       "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS,MESSAGE\r\n" +
                       "Max-Forwards:70\r\n" +
                       "Content-Type: application/sdp\r\n" +
                       "Content-Length:0\r\n\r\n";
	return str;
}

/**
 * 180Ringing�𐶐�����B
 */
function create180Ringing() {
	var TO_TAG = "tag=dk204jei210uejkdl";
	jsEngine.setVar("TO_TAG", TO_TAG);

	var str = "SIP/2.0 180 Ringing\r\n" +
                       "{CALL-ID}" +
                       "{CSEQ}" +
                       "{VIA}" +
                       "{FROM}" +
                       "{TO};{TO_TAG}" +
                       "Contact:<sip:{LOCAL_IP}:{LOCAL_PORT}>\r\n" +
                       "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS,MESSAGE\r\n" +
                       "Max-Forwards:70\r\n" +
                       "Content-Type: application/sdp\r\n" +
                       "Content-Length:0\r\n\r\n";
	return str;
}

/**
 * 200OK�𐶐�����B
 */
function create200OK() {
	var TO_TAG = "tag=dk204jei210uejkdl";
	jsEngine.setVar("TO_TAG", TO_TAG);

	var str = "SIP/2.0 200 OK\r\n" +
                       "{CALL-ID}" +
                       "{CSEQ}" +
                       "{VIA}" +
                       "{FROM}" +
                       "{TO};{TO_TAG}" +
                       "Contact:<sip:{LOCAL_IP}:{LOCAL_PORT}>\r\n" +
                       "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS,MESSAGE\r\n" +
                       "Max-Forwards:70\r\n" +
                       "Content-Type: application/sdp\r\n" +
                       "Content-Length:{CONTENT_LENGTH}\r\n\r\n" +
                       "{STANDARD_SDP}";
	return str;
}



