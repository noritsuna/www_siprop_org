/**
 * 基本的なパラメータを設定するスクリプト。
 */


/**
 * Request-URI
 */
var REQUEST_URI = "sip:to@siprop.org";
jsEngine.setVar("REQUEST_URI", REQUEST_URI);
/**
 * TO-URI
 */
var TO_URI = "sip:to@siprop.org";
jsEngine.setVar("TO_URI", TO_URI);
/**
 * FROM-URI
 */
var FROM_URI = "sip:from@siprop.org";
jsEngine.setVar("FROM_URI", FROM_URI);
/**
 * TOディスプレイネーム
 */
var TO_DISPLAYNAME = "toname";
jsEngine.setVar("TO_DISPLAYNAME", TO_DISPLAYNAME);
/**
 * FROMディスプレイネーム
 */
var FROM_DISPLAYNAME = "fromname";
jsEngine.setVar("FROM_DISPLAYNAME", FROM_DISPLAYNAME);
/**
 * Call-ID
 */
var CALL_ID = "7bc369dcaa5e4be3a887ae4072db7a6b";
jsEngine.setVar("CALL_ID", CALL_ID);
/**
 * FROM-TAG
 */
var FROM_TAG = "c74a88b7f43a452d92f6362e6f9";
jsEngine.setVar("FROM_TAG", FROM_TAG);
/**
 * BRANCH
 */
var BRANCH = "z9hG4bK8e67a788a288465f9bc8d4";
jsEngine.setVar("BRANCH", BRANCH);
/**
 * CSeqナンバー
 */
var CSEQ_NUM = "1";
jsEngine.setVar("CSEQ_NUM", CSEQ_NUM);
/**
 * メソッド
 */
var METHOD = "INVITE";
jsEngine.setVar("METHOD", METHOD);
/**
 * ボディーの長さ
 */
var CONTENT_LENGTH = STANDARD_SDP.length;
jsEngine.setVar("CONTENT_LENGTH", CONTENT_LENGTH);

/**
 * SDP用のトランスポートタイプ
 */
var SDP_TRANS = "IP4";
jsEngine.setVar("SDP_TRANS", SDP_TRANS);
/**
 * SDP用のポート
 */
var SDP_PORT = "11156";
jsEngine.setVar("SDP_PORT", SDP_PORT);
/**
 * SDPバージョン番号
 */
var SDP_VER = "3336324688";
jsEngine.setVar("SDP_VER", SDP_VER);

/**
 * レスポンスコード
 */
var RESPONSE_CODE = "200";
jsEngine.setVar("RESPONSE_CODE", RESPONSE_CODE);
/**
 * レスポンス理由
 */
var RESPONSE_REASON = "OK";
jsEngine.setVar("RESPONSE_REASON", RESPONSE_REASON);

