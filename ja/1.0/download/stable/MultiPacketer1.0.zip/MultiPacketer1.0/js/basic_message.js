/**
 * 基本的なメッセージを設定するスクリプト。
 */


/**
 * 標準リクエスト
 */
var STANDARD_REQUEST = "{METHOD} {REQUEST_URI} SIP/2.0\r\n" +
                       "Call-ID:{CALL_ID}\r\n" +
                       "CSeq:{CSEQ_NUM} {METHOD}\r\n" +
                       "VIA:SIP/2.0/{TRANSPORT_TYPE} {LOCAL_IP}:{LOCAL_PORT};branch={BRANCH}\r\n" +
                       "From:\"{FROM_DISPLAYNAME}\" <{FROM_URI}>;tag={FROM_TAG}\r\n" +
                       "To:\"{TO_DISPLAYNAME}\" <{TO_URI}>\r\n" +
                       "Contact:<sip:{LOCAL_IP}:{LOCAL_PORT}>\r\n" +
                       "{AUTH}" +
                       "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS,MESSAGE\r\n" +
                       "Max-Forwards:70\r\n" +
                       "Content-Type: application/sdp\r\n" +
                       "Content-Length:{CONTENT_LENGTH}\r\n\r\n" +
                       "{STANDARD_SDP}";

/**
 * 標準レスポンス
 */
var STANDARD_RESPONSEE = "SIP/2.0 {RESPONSE_CODE} {RESPONSE_REASON}\r\n" +
                         "{CALL-ID}" +
                         "{CSEQ}" +
                         "{VIA}" +
                         "{FROM}" +
                         "{TO}" +
                         "Contact:<sip:{LOCAL_IP}:{LOCAL_PORT}>\r\n" +
                         "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS,MESSAGE\r\n" +
                         "Max-Forwards:70\r\n" +
                         "Content-Type: application/sdp\r\n" +
                         "Content-Length:{CONTENT_LENGTH}\r\n\r\n" +
                         "{STANDARD_SDP}";

/**
 * 標準SDP
 */
var STANDARD_SDP = "v=0\r\n" +
                   "o=- {SDP_VER} 3336324688 IN {SDP_TRANS} {LOCAL_IP}\r\n" +
                   "s=-\r\n" +
                   "c=IN {SDP_TRANS} {LOCAL_IP}\r\n" +
                   "t=0 0\r\n" +
                   "m=audio {SDP_PORT} RTP/AVP 0\r\n" +
                   "a=sendrecv\r\n" +
                   "a=rtpmap:0 PCMU/8000\r\n" +
                   "a=ptime:20\r\n\r\n";

jsEngine.setVar("STANDARD_SDP", STANDARD_SDP);

