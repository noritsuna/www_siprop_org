#!/bin/sh
PROJECT_HOME=/siprop/MultiPacketer

mvn install:install-file -Dfile=%PROJECT_HOME%/lib/JainSipApi1.1.jar -DgroupId=javax.sip -DartifactId=JainSipApi -Dversion=1.1 -Dpackaging=jar -DgeneratePom=true

mvn install:install-file -Dfile=%PROJECT_HOME%/lib/nist-sdp-1.0.jar -DgroupId=gov.nist.javax.sdp -DartifactId=nist-sdp -Dversion=1.0 -Dpackaging=jar -DgeneratePom=true

mvn install:install-file -Dfile=%PROJECT_HOME%/lib/nist-sip-1.2.jar -DgroupId=gov.nist.javax.sip -DartifactId=nist-sip -Dversion=1.2 -Dpackaging=jar -DgeneratePom=true

