/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.ua.util;

/**
 * RTPのdstとsrcを保持するためのクラス
 * @author masaxmasa
 *
 */
public class RTPPair {
	
	private String dstSDPMessage = null;
	private String srcSDPMessage = null;
	

	
	/**
	 * destのSDP情報を取得する。
	 * @return
	 */
	public String getDstSDPMessage() {
		return dstSDPMessage;
	}
	/**
	 * destのSDP情報をセットする。
	 * @param dstSDPMessage
	 */
	public void setDstSDPMessage(String dstSDPMessage) {
		this.dstSDPMessage = dstSDPMessage;
	}
	/**
	 * srcのSDP情報を取得する。
	 * @return
	 */
	public String getSrcSDPMessage() {
		return srcSDPMessage;
	}
	/**
	 * srcのSDP情報をセットする。
	 * @param
	 */
	public void setSrcSDPMessage(String srcSDPMessage) {
		this.srcSDPMessage = srcSDPMessage;
	}
	/**
	 * srcのSDPが作成済みかどうか？
	 * @return
	 */
	public boolean isSrcCreate() {
		if(srcSDPMessage == null) {
			return true;
		} else {
			return false;
		}
	}
	/**
	 * destのSDPが作成済みかどうか？
	 * @return
	 */
	public boolean isDstCreate() {
		if(dstSDPMessage == null) {
			return true;
		} else {
			return false;
		}
	}
}
