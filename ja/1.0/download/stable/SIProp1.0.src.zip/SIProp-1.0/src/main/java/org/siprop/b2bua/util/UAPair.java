/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.b2bua.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.siprop.core.ua.UA;
import org.siprop.message.impl.MessageContext;

/**
 * B2BUAとして、対となるUA(具体的には、UAManager)を保持するための構造体
 * @author noritsuna
 *
 */
public class UAPair {
	
	/**
	 * （便宜上の）内側UA<BR>
	 * 本プログラムにおいては、Resolverが、その存在を知っている。
	 */
	public UA innerUA;
	/**
	 * （便宜上の）外側UA<BR>
	 * 本プログラムにおいては、Resolverが、その存在を知っている。
	 */
	public UA outerUA;
	
	
	/**
	 * UAを保持するためのList。
	 * Keyは、Call-ID。
	 */
	private List uaList = Collections.synchronizedList(new ArrayList());
	/**
	 * UAを保持するためのMap。
	 * Keyは、Call-ID。
	 */
	private Map uaMap = Collections.synchronizedMap(new HashMap());
	
	/**
	 * UAMessageをセットする。
	 * @param key ContextDiscriminatorが知っているキー
	 * @param msgSet
	 */
	public void setUAMessage(String key, MessageContext msgSet) {
		MessageContext ua = (MessageContext)uaMap.get(key);
		if(ua != null) {
			uaList.remove(ua);
		}
		uaMap.put(key, msgSet);
		uaList.add(msgSet);
	}
	
	/**
	 * 対向UAのMessageContextを取得する
	 * 3つ以上を管理する場合は、Listなどを考慮。
	 * @param msgSet MessageContext
	 * @return
	 */
	public MessageContext getCounterUAMessage(MessageContext msgSet) {
		MessageContext ua = null;
		
		for(Iterator iter = uaList.iterator(); iter.hasNext();) {
			MessageContext msg = (MessageContext)iter.next();
			if(msg.getUniKey().equals(msgSet.getUniKey())) {
				continue;
			}
			ua = msg;
			break;
		}
		return ua;
	}

	/**
	 * 一つ前のMessageContextを取得する。
	 * @param msgSet MessageContext
	 * @return
	 */
	public MessageContext getPreUAMessage(MessageContext msgSet) {
		MessageContext ua = null;
		
		for(Iterator iter = uaList.iterator(); iter.hasNext();) {
			MessageContext msg = (MessageContext)iter.next();
			if(msg.getUniKey().equals(msgSet.getUniKey())) {
				ua = msg;
				break;
			}
		}
		return ua;
	}
	
	/**
	 * UAMessageを削除する。
	 * @param key ContextDiscriminatorが知っているキー
	 */
	public void removeUAMessge(String key) {
		MessageContext ua = (MessageContext)uaMap.get(key);
		if(ua != null) {
			uaList.remove(ua);
		}
		uaMap.remove(key);
	}
	

}
