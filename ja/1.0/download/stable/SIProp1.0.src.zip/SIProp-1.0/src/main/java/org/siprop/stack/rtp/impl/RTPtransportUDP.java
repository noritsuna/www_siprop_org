/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.rtp.impl;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import org.siprop.core.stack.rtp.RTPtransport;

/**
 * RTP用UDPTransportクラス
 * @author masaxmasa
 *
 */
public class RTPtransportUDP implements RTPtransport {
	private static DatagramSocket sock = null;
	private static byte[] recv_buf = new byte[RTPtransport.RTP_RCV_LEN];

	/**
	 * クローズする。
	 */
	public void close() {
		if (sock == null || sock.isClosed()) {
			return;
		}
		sock.close();
		return;
	}
	/**
	 * コネクションを張る。
	 */
	public void connect(InetAddress remoteAddress, int remotePort) {
		if (sock.isConnected()) {
			return;
		}

		sock.connect(remoteAddress, remotePort);
		return;
	}
	/**
	 * ソケットを作成する。
	 * @return 成功か否か？ 0が成功。
	 */
	public int create() {
		try {
			sock = new DatagramSocket();
			sock.setSoTimeout(RTPtransport.SOCKET_TIMEOUT);
			sock.setReceiveBufferSize(RTPtransport.RTP_RCV_LEN);
		}
		catch (SocketException e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}
	/**
	 * ソケットを作成する。
	 * @param 
	 * @return 成功か否か？ 0が成功。
	 */
	public int create(int port) {
		try {
			sock = new DatagramSocket(port);
			sock.setSoTimeout(RTPtransport.SOCKET_TIMEOUT);
			sock.setReceiveBufferSize(RTPtransport.RTP_RCV_LEN);
		} catch (SocketException e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}
	/**
	 * ソケットを作成する。
	 * @param localAddress
	 * @param localPort
	 * @return 成功か否か？ 0が成功。
	 */
	public int create(InetAddress localAddress, int localPort) {
		try {
			sock = new DatagramSocket(localPort, localAddress);
			sock.setSoTimeout(RTPtransport.SOCKET_TIMEOUT);
		} catch (SocketException e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}
	/**
	 * ローカルのIPアドレスを取得する。
	 * @return
	 */
	public InetAddress getLocalAddress() {
		return sock.getLocalAddress();
	}
	/**
	 * ローカルのポート番号を取得する。
	 * @return
	 */
	public int getLocalPort() {
		return sock.getLocalPort();
	}
	/**
	 * リモートのIPアドレスを取得する。
	 * @return
	 */
	public InetAddress getRemoteAddress() {
		return sock.getInetAddress();
	}
	/**
	 * リモートのポート番号を取得する。
	 * @return
	 */
	public int getRemotePort() {
		return sock.getPort();
	}
	/**
	 * 受信する。
	 * @return
	 */
	public byte[] receive() throws SocketException,IOException {
		DatagramPacket recvPkt = new DatagramPacket(recv_buf, recv_buf.length);
		sock.receive(recvPkt);
		byte[] buffer = new byte[recvPkt.getLength()];
		buffer = recvPkt.getData();
		return buffer;
	}
	/**
	 * 送信する。
	 * @param
	 * @return
	 */
	public int send(byte[] data) throws IOException {
		DatagramPacket sendPkt = new DatagramPacket(data, data.length);
		sock.send(sendPkt);
		return 0;
	}
}
