/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;

import java.io.IOException;
import java.util.Vector;

import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Transport;

/**
 * 接続されたTransportに対して、パケットの到着を監視するクラス<BR>
 * パケットが到着した場合には、TransportRouterに対して処理が引き渡される
 * @author sakukawa
 *
 */
public class TransportSelector
{
	private Vector tpList;
	private TransportRouter router;
	
	/**
	 * コンストラクタ
	 * @param tr
	 */
	public TransportSelector(TransportRouter tr)
	{
		tpList = new Vector();
		this.router = tr;
	}
	/**
	 * TransportRouterを取得する。
	 * @return
	 */
	public TransportRouter getTransportRouter()
	{
		return this.router;
	}
	
	/**
	 * 処理対象Transportを追加する
	 * J2ME-PPでは、1thread/Transportで受信処理を行う
	 * (J2SEでは、非同期IOを利用する)
	 * @param t 追加するTransport
	 */
	public void addTransport(Transport t)
	{
		tpList.addElement(t);
		Thread thr = new Thread(new ProcessThread(this, t));
		thr.start();
	}
	/**
	 * Transportを削除する。
	 * @param t
	 */
	public void removeTransport(Transport t)
	{
		tpList.removeElement(t);
	}
	/**
	 * 各RouterのためのThread用クラス<BR>
	 * 1待ち受けで、1Thread作成する。
	 * @author sakukawa
	 *
	 */
	private class ProcessThread implements Runnable
	{
		private Transport tp;
		private TransportSelector ts;
		
		public ProcessThread(TransportSelector ts, Transport tp)
		{
			this.tp = tp;
			this.ts = ts;
		}
		
		public void run()
		{
			while(true) {
				try {
					Packet p = tp.receive();
					if (p == null) break;
					router.doRoute(tp, p.getSourcePeer(), p);
				} catch(IOException ex) {
					ex.printStackTrace();

				}
			}
			ts.removeTransport(tp);
		}
	}
	
}
