/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;
import org.siprop.transport.util.J2MEPPPacketImpl;
import org.siprop.transport.util.PeerImpl;

/**
 * UDP用のTransportクラス
 * @author sakukawa
 *
 */
public class UDPTransport extends Transport
{
	private DatagramSocket ds = null;

	/**
	 * コンストラクタ
	 * @throws IOException
	 */
	public UDPTransport() throws IOException
	{
		ds = new DatagramSocket();
		Peer dest = new PeerImpl(Transport.PROTO_UDP, ds.getLocalAddress(), ds.getLocalPort());
		TransportManager.getInstance().addListenedTransport(dest, this);
		System.out.println("listenUDPTransport(). Port:" + ds.getLocalPort());
	}
	/**
	 * コンストラクタ
	 * @param ds
	 * @param host
	 * @param port
	 * @throws IOException
	 */
	public UDPTransport(DatagramSocket ds, String host, int port) throws IOException
	{
		this.ds = ds;
		Peer dest = new PeerImpl(Transport.PROTO_UDP, ds.getLocalAddress(), ds.getLocalPort());
		TransportManager.getInstance().addListenedTransport(dest, this);
		System.out.println("listenUDPTransport(DatagramSocket ds, String host, int port)." + ds.getLocalPort());
	}
	/**
	 * コンストラクタ
	 * @param host
	 * @param port
	 * @throws IOException
	 */
	public UDPTransport(String host, int port) throws IOException
	{
		if (host == null) {
			ds = new DatagramSocket(port);
		} else {
			InetAddress inetAddress = InetAddress.getByName(host);
			ds = new DatagramSocket(port, inetAddress);
		}

		Peer dest = new PeerImpl(Transport.PROTO_UDP, ds.getLocalAddress(), ds.getLocalPort());
		TransportManager.getInstance().addListenedTransport(dest, this);
		System.out.println("listenUDPTransport(String host, int port)." + ds.getLocalPort());
	}
	
	/**
	 * プロトコル名を取得する。
	 */
	public String getProtocolName()
	{
		return "UDP";
	}
	/**
	 * プロトコル番号を取得する。
	 */
	public int getProtocol()
	{
		return PROTO_UDP;
	}
	/**
	 * ローカルのIPアドレスを取得する。
	 */
	public String getLocalAddress()
	{
		InetAddress i = ds.getLocalAddress();
		return i.getHostName();
	}
	/**
	 * ローカルのポート番号を取得する。
	 */
	public int getLocalPort()
	{
		return ds.getLocalPort();
	}
	/**
	 * リモートのIPアドレスを取得する。
	 */
	public String getRemoteAddress()
	{
		return null;
	}
	/**
	 * リモートのポート番号を取得する。
	 */
	public int getRemotePort()
	{
		return -1;
	}
	/**
	 * ローカルのPeerを取得する。
	 */
	public Peer getLocalPeer()
	{
		return new PeerImpl(this.getProtocol(), ds.getLocalAddress(), ds.getLocalPort());
	}
	/**
	 * リモートのPeerを取得する。
	 */
	public Peer getRemotePeer()
	{
		return null;
	}

	
	/**
	 * send UDP Packet.
	 * @param b byte array to send.
	 * @param offset offset of byte array.
	 * @param length length of send data.
	 * @throws IOException
	 */
	public void send(String dest, int port, byte[] b, int offset, int length) throws IOException
	{
		super.send(dest, port, b, offset, length);
		DatagramPacket sendPacket = new DatagramPacket(b, offset, length); 
		sendPacket.setAddress(InetAddress.getByName(dest));
		sendPacket.setPort(port);
		ds.send(sendPacket);
		
		System.out.println("Create.ListenRoute().");
		try {
			TransportRouter.getInstance().addRoute(this);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * パケットを送信する。
	 */
	public void send(byte[] b, int offset, int length) throws IOException
	{
		throw new IllegalArgumentException("dest omission is not supported.");
//		DatagramPacket sendPacket = new DatagramPacket(b, offset, length); 
//		ds.send(sendPacket);
	}

	/**
	 * パケットを受信し、Packetクラスを返す。
	 * @return 
	 */
	public Packet receive() throws IOException
	{
		System.out.println("in receive UDP.");
		byte[] b = new byte[1500];
		DatagramPacket recvPacket = new DatagramPacket(b, b.length);
		ds.receive(recvPacket);
		Packet p = new J2MEPPPacketImpl(this, recvPacket);
		Peer src = new PeerImpl(Transport.PROTO_UDP, recvPacket.getAddress(), recvPacket.getPort());
		p.setSourcePeer(src);
		p.setDestPeer(this.getLocalPeer());
		System.out.println("in receive src."+ src.getAddress() + ":" + src.getPort());
		System.out.println("in receive dst."+ this.getLocalAddress() + ":" + this.getLocalPeer());
		TransportManager.getInstance().addSendTransport(src, this);
		return p;
	}

}
