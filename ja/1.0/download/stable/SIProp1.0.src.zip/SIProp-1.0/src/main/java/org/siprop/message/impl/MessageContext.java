/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.message.impl;

import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;
import gov.nist.javax.sip.stack.SIPTransaction;

import java.util.EventObject;

import org.siprop.core.message.ControlMessage;
import org.siprop.core.message.FlatSIPMessage;
import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;
import org.siprop.core.util.NotImplementedException;

/**
 * メッセージのセットの構造体<BR>
 * すべての層で、これを通信しあうかたちとなる。<BR>
 * これに保持されたメッセージやステータスにより、各層の動作が決定される。<BR>
 * しかし、Jain-SIPの実装の都合に合わせている。
 * @author noritsuna
 *
 */
public class MessageContext {

	/**
	 * コントロールメッセージ
	 */
	protected ControlMessage ctrlMessage;
	/**
	 * FlatSIPMessage
	 */
	protected FlatSIPMessage flatMessage;
	
	/**
	 * currentMessage
	 */
	private javax.sip.message.Message currentMessage;
	/**
	 * 受信Transport
	 */
	private Transport recvTransport;
	/**
	 * Jain-SIP用のEventObject
	 */
	private EventObject eventObj;
	/**
	 * Jain-SIP用のcurrentPacket
	 */
	private Packet currentPacket;

	/**
	 * 一つ前のMessageContext
	 */
	private MessageContext previousMessageContext;
	/**
	 * stackTypeの文字列
	 */
	private String stackType;
	
	/**
	 * Jain-SIP用のSIPTransaction
	 */
	private SIPTransaction txn;
	
	
	/**
	 * コンストラクタ
	 *
	 */
	public MessageContext()
	{
	}
	/**
	 * currentのMessageをセットする。
	 * @param msg
	 */
	public void setCurrentMessage(javax.sip.message.Message msg)
	{
		this.currentMessage = msg;
	}
	/**
	 * currentのMessageを取得する。
	 * @return
	 */
	public javax.sip.message.Message getCurrentMessage()
	{
		return this.currentMessage;
	}
	/**
	 * 受信用のTransportをセットする。<BR>
	 * Jain-SIPのために必要。
	 * @param tp
	 */
	public void setRecvTransport(Transport tp)
	{
		this.recvTransport = tp;
	}
	/**
	 * 受信用のTransportを取得する。<BR>
	 * Jain-SIPのために必要。
	 * @return
	 */
	public Transport getRecvTransport()
	{
		return recvTransport;
	}
	/**
	 * currentのPacketをセットする。<BR>
	 * Jain-SIPのために必要。
	 * @param p
	 */
	public void setCurrentPacket(Packet p)
	{
		this.currentPacket = p;
	}
	/**
	 * currentのPacketを取得する。<BR>
	 * Jain-SIPのために必要。
	 * @return
	 */
	public Packet getCurrentPacket()
	{
		return this.currentPacket;
	}
	/**
	 * EventObjectをセットする。<BR>
	 * Jain-SIPのために必要。
	 * @param p
	 */
	public void setEventObject(EventObject e)
	{
		this.eventObj = e;
	}
	/**
	 * EventObjectを取得する。<BR>
	 * Jain-SIPのために必要。
	 * @return
	 */
	public EventObject getEventObject()
	{
		return this.eventObj;
	}
	/**
	 * StackTypeをセットする。<BR>
	 * Jain-SIPのために必要。
	 * @param s
	 */
	public void setStackType(String s)
	{
		this.stackType = s;
	}
	/**
	 * StackTypeを取得する。<BR>
	 * Jain-SIPのために必要。
	 * @return
	 */
	public String getStackType()
	{
		return this.stackType;
	}
	/**
	 * 一つ前のMessageContextをセットする。
	 * @param mc
	 */
	public void setPreviousMessageContext(MessageContext mc)
	{
		this.previousMessageContext = mc;
	}
	/**
	 * 一つ前のMessageContextを取得する。
	 * @return
	 */
	public MessageContext getPreviousMessageContext()
	{
		return this.previousMessageContext;
	}
	/**
	 * 現在のSIPTransactionをセットする。<BR>
	 * Jain-SIPのために必要。
	 * @param txn
	 */
	public void setCurrentTransaction(SIPTransaction txn)
	{
		this.txn = txn;
	}
	/**
	 * 現在のSIPTransactionを取得する。<BR>
	 * Jain-SIPのために必要。
	 * @return
	 */
	public SIPTransaction getCurrentTransaction()
	{
		return this.txn;
	}
	

	/**
	 * コントロールメッセージを取得する。
	 * @return
	 */
	public ControlMessage getCtrlMessage() {
		return ctrlMessage;
	}
	/**
	 * コントロールメッセージをセットする。
	 * @param ctrlMessage
	 */
	public void setCtrlMessage(ControlMessage ctrlMessage) {
		this.ctrlMessage = ctrlMessage;
	}
	/**
	 * FlatSIPMessageを取得する。
	 * @return
	 */
	public FlatSIPMessage getFlatMessage() {
		if(flatMessage == null) {
			flatMessage = new FlatSIPMessageImpl();
		}
		return flatMessage;
	}
	/**
	 * FlatSIPMessageをセットする。
	 * @param flatMessage
	 */
	public void setFlatMessage(FlatSIPMessage flatMessage) {
		this.flatMessage = flatMessage;
	}
	
////////////////////////////////B2BUA,UA//////////////////////////////////////
		
	/**
	 * Moduleがどのように動作すべきかを指示するためのメッセージ
	 */
	private ControlMessage controlMessage;
	/**
	 * このMessageContextの識別キー
	 */
	private String uniKey = null;

	/**
	 * ControlMessageを取得する。
	 * @return
	 */
	public ControlMessage getControlMessage() {
		return controlMessage;
	}
	/**
	 * ControlMessageをセットする。
	 * @param controlMessage
	 */
	public void setControlMessage(ControlMessage controlMessage) {
		this.controlMessage = controlMessage;
	}

	/**
	 * 識別キーを取得する。<BR>
	 * Call-IDをベースに作成する。
	 * @return
	 */
	public String getUniKey() {
		if(uniKey != null) {
			return uniKey;
		}
		SIPMessage sipMsg = null;
		if(this.currentMessage != null) {
			sipMsg = (SIPMessage)this.currentMessage;
			this.uniKey = sipMsg.getCallId().getCallId();
		} else if(this.getPreviousMessageContext() != null) {
			if(this.getPreviousMessageContext().getCurrentMessage() != null) {
				sipMsg = (SIPMessage)this.getPreviousMessageContext().getCurrentMessage();
				this.uniKey = sipMsg.getCallId().getCallId();
			} else {
				this.uniKey = this.generateCallID("siprop.org");
			}
		} else {
			this.uniKey = this.generateCallID("siprop.org");
		}
		return uniKey;
	}
    /**
     * Call-IDを生成する
     * @param host ホスト名
     * @return
     **/
    private String generateCallID(String host) {
    	System.out.println("in generateCallID.");
    	StringBuffer sb = new StringBuffer();
    	sb.append(MessageContext.generateUniID());
    	sb.append("@");
    	sb.append(host);
    	System.out.println("generateCallID:" + sb.toString());
    	return sb.toString();
    }
    /**
     * 一意の文字列を作成する。
     * @return
     */
    static public synchronized String generateUniID() {
    	try {
			Thread.sleep(1);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    	return String.valueOf(System.currentTimeMillis());
    }
	/**
	 * 対向するUAのSIPメッセージ
	 */
	private javax.sip.message.Message counterSIPMessage;
	/**
	 * 対向するUAのMessageContext
	 */
	private MessageContext counterMessageContext;
	/**
	 * 対向するUAのSIPメッセージを取得する。
	 * @return
	 */
	public javax.sip.message.Message getCounterSIPMessage() {
		if(this.counterMessageContext == null) {
			return null;
		}
		return this.counterMessageContext.getCurrentMessage();
	}
	/**
	 * 対向するUAのMessageContextを取得する。
	 * @return
	 */
	public MessageContext getCounterMessageContext() {
		return this.counterMessageContext;
	}
	/**
	 * MessageContextをセットする。
	 * @param counterMessageContext
	 */
	public void setCounterMessageContext(MessageContext counterMessageContext) {
		this.counterMessageContext = counterMessageContext;
	}
	
	/**
	 * 送信先Peer
	 */
	private Peer outboundPeer;
	/**
	 * 待ち受けのPeer
	 */
	private Peer listenPeer;

	/**
	 * 待ち受けのPeerを取得する。
	 * @return
	 */
	public Peer getListenPeer() {
		return listenPeer;
	}
	/**
	 * 待ち受けのPeerをセットする。
	 * @param listenPeer
	 */
	public void setListenPeer(Peer listenPeer) {
		this.listenPeer = listenPeer;
	}
	/**
	 * 送信先Peerを取得する。
	 * @return
	 */
	public Peer getOutboundPeer() {
		return outboundPeer;
	}
	/**
	 * 送信先Peerの文字列を取得する。
	 * @return
	 */
	public String getOutboundPeerStr() {
		if(outboundPeer == null) {
			return null;
		}
		return outboundPeer.getAddress().getHostAddress() + ":" + String.valueOf(outboundPeer.getPort());
	}

	/**
	 * UAから見た送信先のIPとポート
	 * @param outboundPeer
	 */
	public void setOutboundPeer(Peer outboundPeer) {
		this.outboundPeer = outboundPeer;
	}
	/**
	 * 待ち受けのPeerの文字列をセットする。
	 * @return
	 */
	public String getListenPeerStr() {
		if(listenPeer == null) {
			return null;
		}
		return listenPeer.getAddress().getHostAddress() + ":" + String.valueOf(listenPeer.getPort());
	}
	
	/**
	 * ペアとなるUAを結びつけるためのキー
	 */
	private String pairKey = null;

	/**
	 * ペアとなるUAを結びつけるためのキーを取得する
	 * @return
	 */
	public String getPairKey() {
		return pairKey;
	}
	/**
	 * ペアとなるUAを結びつけるためのキーをセットする
	 * @param pairKey
	 */
	public void setPairKey(String pairKey) {
		this.pairKey = pairKey;
	}
	

	/**
	 * 必要なcontrolメッセージをセットする。
	 * @param controlMessage
	 * @param sipMessage
	 */
	public static void setControlMessage(ControlMessage controlMessage, SIPMessage sipMessage) {
		
		if(sipMessage instanceof SIPRequest) {
			MessageContext.setControlMessageByRequest(controlMessage, (SIPRequest)sipMessage);
		} else if(sipMessage instanceof SIPResponse) {
			MessageContext.setControlMessageByResponse(controlMessage, (SIPResponse)sipMessage);
		} else {
			throw new NotImplementedException();
		}
	}
	/**
	 * SIPRequestから、コントロールメッセージのメソッドフラグを立てる
	 * @param message
	 */
	public static void setControlMessageByRequest(ControlMessage controlMessage, SIPRequest sipRequest) {

		System.out.println("sipRequest.getMethod():" + sipRequest.getMethod());

		// メソッドチェック
		if(sipRequest.getMethod().equals(SIPRequest.INVITE)) {
			controlMessage.set(UAControlMessage.INIVITE);
		} else if(sipRequest.getMethod().equals(SIPRequest.ACK)) {
			controlMessage.set(UAControlMessage.ACK);
		} else if(sipRequest.getMethod().equals(SIPRequest.BYE)) {
			controlMessage.set(UAControlMessage.BYE);
		} else if(sipRequest.getMethod().equals(SIPRequest.CANCEL)) {
			controlMessage.set(UAControlMessage.CANCEL);
		} else if(sipRequest.getMethod().equals(SIPRequest.REGISTER)) {
			controlMessage.set(UAControlMessage.REGISTER);
		} else {
			throw new NotImplementedException();
		}
		controlMessage.set(UAControlMessage.IS_REQUEST);		
	}
	/**
	 * SIPRequestから、コントロールメッセージのメソッドフラグを立てる
	 * @param controlMessage
	 * @param response
	 */
	public static void setControlMessageByResponse(ControlMessage controlMessage, SIPResponse response) {
		
		System.out.println("response.getStatusCode():" + response.getStatusCode());
		
		// メソッドチェック
		if(response.getCSeq().getMethod().equals(SIPRequest.INVITE)) {
			controlMessage.set(UAControlMessage.INIVITE);
		} else if(response.getCSeq().getMethod().equals(SIPRequest.ACK)) {
			controlMessage.set(UAControlMessage.ACK);
		} else if(response.getCSeq().getMethod().equals(SIPRequest.BYE)) {
			controlMessage.set(UAControlMessage.BYE);
		} else if(response.getCSeq().getMethod().equals(SIPRequest.CANCEL)) {
			controlMessage.set(UAControlMessage.CANCEL);
		} else if(response.getCSeq().getMethod().equals(SIPRequest.REGISTER)) {
			controlMessage.set(UAControlMessage.REGISTER);
		} else {
			throw new NotImplementedException();
		}
		// レスポンスコード
		if(response.getStatusCode() == 100) {
			controlMessage.set(UAControlMessage.RESPONSE_100);
		} else if(response.getStatusCode() == 180) {
			controlMessage.set(UAControlMessage.RESPONSE_180);
		} else if(response.getStatusCode() / 100 == 1) {
			controlMessage.set(UAControlMessage.RESPONSE_183);
		} else if(response.getStatusCode() / 100 == 2) {
			controlMessage.set(UAControlMessage.RESPONSE_200);
		} else if(response.getStatusCode() / 100 == 3) {
			controlMessage.set(UAControlMessage.RESPONSE_300);
		} else if(response.getStatusCode() / 100 == 4) {
			controlMessage.set(UAControlMessage.RESPONSE_400);
		} else if(response.getStatusCode() / 100 == 5) {
			controlMessage.set(UAControlMessage.RESPONSE_500);
		} else if(response.getStatusCode() / 100 == 6) {
			controlMessage.set(UAControlMessage.RESPONSE_600);
		} else {
			throw new NotImplementedException();
		}		
		controlMessage.set(UAControlMessage.IS_RESPONSE);
	}
	
	private String forkingKey = null;
	/**
	 * Fokingのための識別キーをセットする。
	 * @param key
	 */
	public void setForkingKey(String key) {
		this.forkingKey = forkingKey;
	}
	/**
	 * Fokingのための識別キーを取得する。
	 * @return
	 */
	public String getForkingKey() {
		
		return forkingKey;
	}
	private String uaType = null;
	/**
	 * UA種別をセットする。
	 * @param uaType
	 */
	public void setUAType(String uaType) {
		this.uaType = uaType;
	}
	/**
	 * UA種別を取得する。
	 * @return
	 */
	public String getUAType() {
		return uaType;
	}
	
////////////////////////////////B2BUA,UA//////////////////////////////////////
	
	
	
}
