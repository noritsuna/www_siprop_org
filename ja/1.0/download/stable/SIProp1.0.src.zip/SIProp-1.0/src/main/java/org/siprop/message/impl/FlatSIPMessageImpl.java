/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.message.impl;

import gov.nist.javax.sip.address.AddressFactoryImpl;
import gov.nist.javax.sip.address.AddressImpl;
import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.header.CSeq;
import gov.nist.javax.sip.header.Contact;
import gov.nist.javax.sip.header.From;
import gov.nist.javax.sip.header.HeaderFactoryImpl;
import gov.nist.javax.sip.header.RecordRoute;
import gov.nist.javax.sip.header.RecordRouteList;
import gov.nist.javax.sip.header.RouteList;
import gov.nist.javax.sip.header.To;
import gov.nist.javax.sip.header.Via;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;
import gov.nist.javax.sip.parser.StringMsgParser;

import java.text.ParseException;
import java.util.Iterator;

import javax.sip.InvalidArgumentException;
import javax.sip.address.Address;
import javax.sip.header.ContactHeader;
import javax.sip.header.ContentTypeHeader;
import javax.sip.header.Header;
import javax.sip.header.HeaderFactory;
import javax.sip.header.RecordRouteHeader;

import org.siprop.SIPropException;
import org.siprop.core.message.FlatSIPMessage;
import org.siprop.core.transport.Peer;

/**
 * FlatMessageを定義したクラス
 * @author noritsuna
 *
 */
public class FlatSIPMessageImpl extends FlatSIPMessage {

	
	/**
	 * Jain-SIP用のメッセージパーサー
	 */
	protected StringMsgParser sipParser = new StringMsgParser();
	/**
	 * Headerのファクトリー
	 */
	protected HeaderFactory headerFactory = new HeaderFactoryImpl();
	


	
	/**
	 * パケットを生成する。
	 */
	public byte[] createPacket() {
		return null;
	}

	/**
	 * Routingキーを取得する。
	 * @return キー
	 */
	public String getRoutingKey() {
		return null;
	}
	

	
	/**
	 * 一つ前のレスポンスをセットする。
	 * @param sipResponse
	 */
	public void setPrevResponse(SIPResponse sipResponse) {
		System.out.println("UAModule before prevResponse:" + this.prevResponse);
		System.out.println("UAModule set prevRequest:." + sipResponse);
    	this.prevResponse = (SIPResponse)sipResponse.clone();
		System.out.println("UAModule after prevResponse:." + this.prevResponse);
    }
    /**
     * 一つ前のリクエストをセットする。
     * @param sipRequest
     */
	public void setPrevRequest(SIPRequest sipRequest) {
		System.out.println("UAModule before prevRequest:" + this.prevRequest);
		System.out.println("UAModule set prevRequest:." + sipRequest);
    	this.prevRequest = (SIPRequest)sipRequest.clone();
		System.out.println("UAModule after prevRequest:" + this.prevRequest);
    }
    /**
     * 一番最初のメッセージをセットする。
     * @param sipRequest
     */
	public void setOrigRequest(SIPRequest sipRequest) {
		System.out.println("UAModule set origRequest:." + sipRequest);
    	this.origRequest = (SIPRequest)sipRequest.clone();
		System.out.println("UAModule after origRequest:" + this.origRequest);
    }
	
	/**
	 * 一つ前のレスポンスを取得する。
	 * @return
	 */
	public SIPResponse getPrevResponse() {
		return this.prevResponse;
	}
	/**
	 * 一つ前のリクエストを取得する。
	 * @return
	 */
	public SIPRequest getPrevRequest() {
		return this.prevRequest;
	}
	/**
	 * 一番最初のメッセージを取得する。
	 * @return
	 */
	public SIPRequest getOrigRequest() {
		return this.origRequest;
	}
	
    /**
     * タグを生成する
     **/
	protected String generateTag() {
    	return MessageContext.generateUniID();
    }
	

	/**
	 * RouteSetを生成する。
	 * @param origRequest
	 */
	public void createRouteSet(SIPRequest origRequest) {
		
		this.recordRouteList = origRequest.getRecordRouteHeaders();
		if(this.recordRouteList != null) {
			// contactを保持
			ContactHeader contact = (Contact)origRequest.getContactHeaders().getFirst();
			this.contactURI = (SipUri)contact.getAddress().getURI();
    		System.out.println("contact.getAddress();" + contact.getAddress());
    		System.out.println("this.contactURI;" + this.contactURI);
    		
    		// Routeヘッダーを生成
    		this.routeList = new RouteList();
    		for(Iterator iter = this.recordRouteList.iterator(); iter.hasNext();) {
    			RecordRouteHeader record = (RecordRoute)iter.next();
        		System.out.println("RecordRouteHeader;" + record);
        		this.routeList.addFirst(headerFactory.createRouteHeader(record.getAddress()));
    		}
			this.isUAC = false;
    		
		}
	}
	/**
	 * RouteSetを生成する。
	 * @param response
	 */
	public void createRouteSet(SIPResponse response) {
		this.recordRouteList = response.getRecordRouteHeaders();
		if(this.recordRouteList != null) {
			// contactを保持
			ContactHeader contact = (Contact)response.getContactHeaders().getFirst();
			this.contactURI = (SipUri)contact.getAddress().getURI();
    		System.out.println("contact.getAddress();" + contact.getAddress());
    		System.out.println("this.contactURI;" + this.contactURI);
    		
    		// Routeヘッダーを生成
    		this.routeList = new RouteList();
    		for(Iterator iter = this.recordRouteList.iterator(); iter.hasNext();) {
    			RecordRouteHeader record = (RecordRoute)iter.next();
        		System.out.println("RecordRouteHeader;" + record);
        		this.routeList.add(headerFactory.createRouteHeader(record.getAddress()));
        		System.out.println("RouteHeader;" + headerFactory.createRouteHeader(record.getAddress()));
    		}
    		
			this.isUAC = true;
		}
	}


	/**
	 * REGSITERリクエストを生成する。
	 * @param requestURI
	 * @param callID
	 * @param from
	 * @param to
	 * @param branchid
	 * @param contact
	 * @param auth
	 * @param listenPeerStr
	 * @return
	 * @throws SIPropException
	 */
	public SIPRequest createNewREGISTERRequest(String requestURI, 
			String callID, 
			String from, 
			String to, 
			String branchid, 
			String contact, 
			String auth, 
			String listenPeerStr) throws SIPropException {
		// 新規のSIPメッセージを作成する。
		StringBuffer sb = new StringBuffer();

		sb.append("REGISTER ").append(requestURI).append(" SIP/2.0\r\n");
		sb.append("Call-ID: ").append(callID).append("\r\n");
		sb.append("Cseq: ").append(++cseq).append(" REGISTER\r\n");
		sb.append("Via: SIP/2.0/UDP ").append(listenPeerStr)
//		  .append(";received=").append(messageContext.getListenPeerStr())
		  .append(";branch=").append(branchid)
		  .append("\r\n");
		
		sb.append(from);
		sb.append(to);
		
		sb.append(contact);

		// 認証
		if(auth != null && !auth.equals("")) {
			sb.append(auth);
		}
		
		//sb.append("Allow: ").append("INVITE,ACK,CANCEL,BYE\r\n");
		sb.append("Max-Forwards: 70\r\n");
		//sb.append("Content-Type: application/sdp\r\n");
		sb.append("Content-Length: ").append("0\r\n\r\n");
		
		try {
			return (SIPRequest)sipParser.parseSIPMessage(sb.toString());
		} catch (ParseException e) {
			throw new SIPropException(e);
		}
		
	}

	
	/**
	 * INVITEリクエストを生成する。
	 * @param requestURI
	 * @param callID
	 * @param from
	 * @param to
	 * @param branchid
	 * @param contact
	 * @param auth
	 * @param listenPeerStr
	 * @param sdp
	 * @return
	 * @throws SIPropException
	 */
	public SIPRequest createNewINVITERequest(String requestURI, 
			String callID, 
			String from, 
			String to, 
			String branchid, 
			String contact, 
			String auth, 
			String listenPeerStr,
			String sdp) throws SIPropException {
		StringBuffer sb = new StringBuffer();
		
		
		sb.append("INVITE ").append(requestURI).append(" SIP/2.0\r\n");
		sb.append("Call-ID: ").append(callID).append("\r\n");
		sb.append("Cseq: ").append(++cseq).append(" INVITE\r\n");
		sb.append("Via: SIP/2.0/UDP ").append(listenPeerStr)
		  .append(";branch=").append(branchid)
		  .append("\r\n");

		
		sb.append(from);
		sb.append(to);

		sb.append(contact);

		// 認証
		if(auth != null && !auth.equals("")) {
			sb.append(auth);
		}

		
		sb.append("Allow: ").append("INVITE,ACK,CANCEL,BYE\r\n");
		sb.append("Max-Forwards: 70\r\n");
		sb.append("Content-Type: application/sdp\r\n");
		sb.append(sdp);
		
		
		try {
			return (SIPRequest)sipParser.parseSIPMessage(sb.toString());
		} catch (ParseException e) {
			throw new SIPropException(e);
		}		
	}

	/**
	 * ACKリクエストを生成する。
	 * @return
	 * @throws SIPropException
	 */
	public SIPRequest createACKRequest() throws SIPropException {
		// RouteSetから、RequestURIを作成する
		SipUri newSipUri = null;
		if(this.isRoute()) {
			newSipUri = contactURI;
			newSipUri.setMethod(SIPRequest.ACK);
		} else {
			newSipUri = (SipUri) this.prevRequest.getRequestURI();
			newSipUri.setMethod(SIPRequest.ACK);
		}
		CSeq cseq = (CSeq) this.prevRequest.getCSeq();
		try {
			cseq.setMethod(SIPRequest.ACK);
		} catch (ParseException e) {
			throw new SIPropException(e);
		}
		
		SIPRequest sipRequest = this.prevResponse.createRequest(newSipUri, (Via)this.prevRequest.getViaHeaders().getFirst(), cseq);
		//sipRequest.setContent("", headerFactory.createContentTypeHeader("application", "sdp"));
		if(this.routeList != null) {
			sipRequest.setHeader(this.routeList);
			System.out.println("set Route.");
		}		
		try {
			sipRequest.setContentLength(this.headerFactory.createContentLengthHeader(0));
		} catch (InvalidArgumentException e) {
			throw new SIPropException(e);
		}
		
		return sipRequest;
	}
	/**
	 * CANCELリクエストを生成する。
	 * @return
	 * @throws SIPropException
	 */
	public SIPRequest createCANCLERequest() throws SIPropException {
		SipUri sipUri = (SipUri) this.prevRequest.getRequestURI();
		sipUri.setMethod(SIPRequest.CANCEL);
		CSeq cseq = (CSeq) this.prevRequest.getCSeq();
		try {
			cseq.setMethod(SIPRequest.CANCEL);
		} catch (ParseException e) {
			throw new SIPropException(e);
		}
		
		SIPRequest sipRequest = this.prevResponse.createRequest(sipUri, (Via)this.prevRequest.getViaHeaders().getFirst(), cseq);
		try {
			sipRequest.setContentLength(this.headerFactory.createContentLengthHeader(0));
		} catch (InvalidArgumentException e) {
			throw new SIPropException(e);
		}
		sipRequest.getTo().removeParameter("tag");
		
		return sipRequest;
	}
	/**
	 * BYEリクエストを生成する。
	 * @param isUAC
	 * @param listenPeer
	 * @param outboundPeerStr
	 * @param branchID
	 * @return
	 * @throws SIPropException
	 */
	public SIPRequest createBYERequest(boolean isUAC, 
			Peer listenPeer, 
			String outboundPeerStr, 
			String branchID) throws SIPropException {
		// UAS発呼かどうかを判定する必要あり。
		CSeq cseq = (CSeq) this.prevRequest.getCSeq();
		try {
			cseq.setMethod(SIPRequest.BYE);
		} catch (ParseException e) {
			throw new SIPropException(e);
		}
		System.out.println("before cseq.getSequenceNumber():" + cseq.getSequenceNumber());
		try {
			cseq.setSequenceNumber(cseq.getSequenceNumber()+1);
		} catch (InvalidArgumentException e) {
			throw new SIPropException(e);
		}
		System.out.println("after cseq.getSequenceNumber():" + cseq.getSequenceNumber());
		
		SIPRequest sipRequest = null;
		
		// RouteSetから、RequestURIを作成する
		SipUri newSipUri = null;
		if(this.routeList != null) {
			newSipUri = contactURI;
			newSipUri.setMethod(SIPRequest.BYE);
		}
				
		if(isUAC) {
			System.out.println("Route UAC.");
			if(newSipUri == null) {
				newSipUri = (SipUri) this.prevRequest.getRequestURI();
				newSipUri.setMethod(SIPRequest.BYE);
			}
			sipRequest = this.prevResponse.createRequest(newSipUri, (Via)this.prevRequest.getViaHeaders().getFirst(), cseq);
		} else {
			System.out.println("Route UAS.");
			To origTo = (To) this.prevRequest.getTo();
			From origFrom = (From) this.prevRequest.getFrom();

			To newTo;
			try {
				newTo = (To) this.headerFactory.createToHeader(origFrom.getAddress(), origFrom.getTag());
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
			From newFrom;
			try {
				newFrom = (From) this.headerFactory.createFromHeader(origTo.getAddress(), origTo.getTag());
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
			Via newVia;
			try {
				newVia = (Via) this.headerFactory.createViaHeader(listenPeer.getAddress().getHostAddress(),
																		listenPeer.getPort(),
																		"UDP",
																		branchID);
			} catch (ParseException e) {
				throw new SIPropException(e);
			} catch (InvalidArgumentException e) {
				throw new SIPropException(e);
			}
			if(newSipUri == null) {
				newSipUri = new SipUri();
				try {
					newSipUri.setHost(outboundPeerStr);
				} catch (ParseException e) {
					throw new SIPropException(e);
				}
				newSipUri.setMethod(SIPRequest.BYE);
			}

			sipRequest = this.prevResponse.createRequest(newSipUri, newVia, cseq);
			sipRequest.setTo(newTo);
			sipRequest.setFrom(newFrom);
			
		}
		if(this.routeList != null) {
			sipRequest.setHeader(this.routeList);
		}
		try {
			sipRequest.setContentLength(this.headerFactory.createContentLengthHeader(0));
		} catch (InvalidArgumentException e) {
			throw new SIPropException(e);
		}
		
		return sipRequest;
	}
	
	/**
	 * 100レスポンスを生成する。
	 * @return
	 * @throws SIPropException
	 */
	public SIPResponse create100Renponse() throws SIPropException {
		return this.prevRequest.createResponse(100, "Trying");
	}
	/**
	 * 1xxレスポンスを生成する。
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param sdpBody
	 * @return
	 * @throws SIPropException
	 */
	public SIPResponse create1xxRenponse(int rensponseCode, 
			String reasonPhrase,
			String sdpBody) throws SIPropException {
		SIPResponse sipResponse = this.prevRequest.createResponse(rensponseCode, reasonPhrase);
		
		if(sipResponse.getToTag() == null) {
			if(this.toTag == null) {
				this.toTag = this.generateTag();
			}
			try {
				sipResponse.getTo().setTag(this.toTag);
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
		} else {
			this.toTag = sipResponse.getToTag();
		}
		// SDP処理
		if(sdpBody != null) {
			ContentTypeHeader contentType;
			try {
				contentType = headerFactory.createContentTypeHeader("application", "sdp");
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
			try {
				sipResponse.setContent(sdpBody, contentType);
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
		}
		return sipResponse;
	}
	/**
	 * 2xxレスポンスを生成する。
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param sdpBody
	 * @param listenPeerStr
	 * @param origRecoudRouteList
	 * @param origContact
	 * @return
	 * @throws SIPropException
	 */
	public SIPResponse create2xxRenponse(int rensponseCode, 
			String reasonPhrase,
			String sdpBody, 
			String listenPeerStr,
			RecordRouteList origRecoudRouteList,
			Contact origContact) throws SIPropException {
		SIPResponse sipResponse = this.prevRequest.createResponse(rensponseCode, reasonPhrase);
		
		if(sipResponse.getToTag() == null) {
			if(this.toTag == null) {
				this.toTag = this.generateTag();
			}
			try {
				sipResponse.getTo().setTag(this.toTag);
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
		} else {
			this.toTag = sipResponse.getToTag();
		}
		// SDP処理
		if(sdpBody != null) {
			ContentTypeHeader contentType;
			try {
				contentType = headerFactory.createContentTypeHeader("application", "sdp");
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
			try {
				sipResponse.setContent(sdpBody, contentType);
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
		}
		
		Address addr = new AddressImpl();
		try {
			addr.setURI(new AddressFactoryImpl().createURI("sip:" + listenPeerStr));
		} catch (ParseException e) {
			throw new SIPropException(e);
		}
		System.out.println("Address:" + addr.toString());
		
		ContactHeader contact = headerFactory.createContactHeader(addr);
		System.out.println("contact:" + contact.toString());
		
		sipResponse.setHeader(contact);
		
		
		// RouteSetの生成
		this.recordRouteList = origRecoudRouteList;
		if(this.recordRouteList != null) {
			// contactを保持
			this.contactURI = (SipUri)origContact.getAddress().getURI();
    		System.out.println("contact.getAddress();" + origContact.getAddress());
    		System.out.println("this.contactURI;" + this.contactURI);
    		
    		// Routeヘッダーを生成
    		this.routeList = new RouteList();
    		for(Iterator iter = this.recordRouteList.iterator(); iter.hasNext();) {
    			RecordRouteHeader record = (RecordRoute)iter.next();
        		System.out.println("RecordRouteHeader;" + record);
        		this.routeList.add(headerFactory.createRouteHeader(record.getAddress()));
    		}
    		
			this.isUAC = true;
		}

		return sipResponse;
	}
	/**
	 * 4xxレスポンスを生成する。
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param auth
	 * @return
	 * @throws SIPropException
	 */
	public SIPResponse create4xxRenponse(int rensponseCode, 
			String reasonPhrase,
			Header auth) throws SIPropException {
		SIPResponse sipResponse = this.prevRequest.createResponse(rensponseCode, reasonPhrase);
		System.out.println("create sipResponse." + sipResponse);
		if(sipResponse.getToTag() == null) {
			if(this.toTag == null) {
				this.toTag = this.generateTag();
			}
			try {
				sipResponse.getTo().setTag(this.toTag);
			} catch (ParseException e) {
				throw new SIPropException(e);
			}
		} else {
			this.toTag = sipResponse.getToTag();
		}
		
		
		sipResponse.addHeader(auth);

		
		try {
			sipResponse.setContentLength(this.headerFactory.createContentLengthHeader(0));
		} catch (InvalidArgumentException e) {
			throw new SIPropException(e);
		}
		
		return sipResponse;
	}


}
