/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.message.impl;

import org.siprop.core.message.ControlMessage;

/**
 * UAをコントロールするためのフラグを保持するクラス
 * @author noritsuna
 *
 */
public class UAControlMessage extends ControlMessage {

	// SIPメソッド
	static public int IS_REQUEST = 10;
	static public int INIVITE = 11;
	static public int CANCEL = 12;
	static public int BYE = 13;
	static public int ACK = 14;
	static public int REGISTER = 15;
	static public int INFO = 16;
	static public int UPDATE = 17;
	static public int NOTIFY = 18;
	static public int SUBSCRIBE = 19;
	static public int PUBLISH = 20;
	
	// SIPレスポンス
	static public int IS_RESPONSE = 30;
	static public int RESPONSE_100 = 31;
	static public int RESPONSE_180 = 32;
	static public int RESPONSE_183 = 33;
	static public int RESPONSE_200 = 34;
	static public int RESPONSE_300 = 35;
	static public int RESPONSE_400 = 36;
	static public int RESPONSE_500 = 37;
	static public int RESPONSE_600 = 38;
	
	// 状態
	static public int INIT = 40;
	static public int TRYING = 41;
	static public int RINGING = 42;
	static public int CALLING = 43;
	static public int COMFIRM = 44;
	static public int TERMINATED = 45;
	static public int HOLD = 46;
	
	
	/**
	 * UAの種類名。クラス名が入ることを想定している。
	 */
	private String uaType;
	/**
	 * 自分のUAの種類を取得する。
	 * @return
	 */
	public String getUAType() {
		return this.uaType;
	}
	/**
	 * 自分のUAの種類をセットする。
	 * @param uaType
	 */
	public void setUAType(String uaType) {
		this.uaType = uaType;
	}
}
