/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.b2bua.impl;

import gov.nist.javax.sip.message.SIPMessage;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.siprop.b2bua.util.UAPair;
import org.siprop.core.Repository;
import org.siprop.core.Resolver;
import org.siprop.core.Router;
import org.siprop.core.b2bua.B2BUA;
import org.siprop.core.message.ContextDiscriminator;
import org.siprop.core.message.ControlMessage;
import org.siprop.core.transport.Peer;
import org.siprop.core.util.NotImplementedException;
import org.siprop.message.impl.DefaultContextDiscriminator;
import org.siprop.message.impl.MessageContext;
import org.siprop.message.impl.UAControlMessage;
import org.siprop.resolver.impl.ListenResolverImpl;
import org.siprop.resolver.impl.TransportResolverImpl;


/**
 * B2BUAとして、動作させるためのコントロール用クラスの基底クラス<BR>
 * 全体で1つのみ存在し、inner,outerの2つのUAを管理する存在となる。
 * @author noritsuna
 *
 */
public class B2BUAImpl implements B2BUA {
	
	/**
	 * 下位層であるUARouter
	 */
	private Router uaRouter;
	/**
	 * Transportから、名前解決するためのリゾルバ
	 */
	private Resolver transportResolver;
	/**
	 * 待ち受けしているpeerから、名前解決するためのリゾルバ
	 */
	private Resolver listenResolver;
	/**
	 * リゾルバのリスト
	 */
	private List resolverList;
	
	/**
	 * KeyとUAPairを保持する。CallIDでUAPairを保持する。(そのため、通常一つのUAPairが2つ以上登録されている。)
	 */
	private Map uaPairTable = Collections.synchronizedMap(new HashMap());
	
	
	/**
	 * Key生成用
	 */
	private ContextDiscriminator descriminator = new DefaultContextDiscriminator();

	/**
	 * TransportやStackから、コールバックされるメソッド
	 */
	public void doDispatch(MessageContext msgSet) {
		this.start(msgSet);
	}
	
	/**
	 * 具体的な処理開始するメソッド
	 *
	 */
	private void start(MessageContext msgSet){
		
		UAPair uaPair = this.getUAPair(msgSet);
		
		// 新規メッセージの場合
		if(uaPair == null) {
			System.out.println("in new UAPair");
			uaPair = new UAPair();
			// MessageContextを、UAPairの inner に保持する。
			this.setUAPair(msgSet,uaPair);
			
			// MessageContextを、新規に作成する。 
			MessageContext newMessageContext = new MessageContext();
			//newMessageContext.setPreviousMessageContext(newMessageContext);
			
			// 対抗メッセージをセットする。stackに引っ張られた実装。本来はあり得ない。
			newMessageContext.setCounterMessageContext(msgSet);
			msgSet.setCounterMessageContext(newMessageContext);
			
			// outerUARouter用のコントロールメッセージを追加
			UAControlMessage newUACtrl = new UAControlMessage();
			newUACtrl.set(ControlMessage.TO_LOWER);
			newUACtrl.set(UAControlMessage.INIT);

			// リクエストやレスポンスの種類をセットする。
	    	MessageContext.setControlMessage(newUACtrl, (SIPMessage)msgSet.getCurrentMessage());
			newMessageContext.setControlMessage(newUACtrl);

	    	// dst,src IPをセットする。
	    	newMessageContext.setListenPeer(this.listenResolver.resolve(msgSet));
	    	newMessageContext.setOutboundPeer(this.transportResolver.resolve(msgSet));
	    	newMessageContext.setPairKey(String.valueOf(uaPair.hashCode()));

			// UAPairに、outer 用 として、保持する。 
			this.setUAPair(newMessageContext,uaPair);

			// UARouterに、送信する。
			this.send(newMessageContext);
			return;
		} else {
		// 既存メッセージの場合
			System.out.println("in existence UAPair");
			// 一つ前の対向MessageContextをUAPairから、取得する。
			MessageContext counterMessageContext = uaPair.getCounterUAMessage(msgSet);
			// MessageContextを、新規に作成する。 
			MessageContext newMessageContext = new MessageContext();
			// 対抗メッセージをセットする。stackに引っ張られた実装。本来はあり得ない。
			newMessageContext.setCounterMessageContext(msgSet);
			newMessageContext.setPreviousMessageContext(counterMessageContext);
			msgSet.setCounterMessageContext(newMessageContext);
			msgSet.setPreviousMessageContext(uaPair.getPreUAMessage(msgSet));
			
			// MessageContextを、UAPairの inner に保持する。
			this.setUAPair(msgSet,uaPair);
			
			// 必要な コントロールメッセージを付加する。
			UAControlMessage newUACtrl = new UAControlMessage();
			newUACtrl.set(ControlMessage.TO_LOWER);
			SIPMessage sipMessage = (SIPMessage)msgSet.getCurrentMessage();

			// リクエストやレスポンスの種類をセットする。
	    	MessageContext.setControlMessage(newUACtrl, sipMessage);
			newMessageContext.setControlMessage(newUACtrl);

	    	// dst,src IPをセットする。
			Peer listenPeer = newMessageContext.getPreviousMessageContext().getListenPeer();
			if(listenPeer == null) {
				newMessageContext.getPreviousMessageContext().setListenPeer(
						this.listenResolver.resolve(
								newMessageContext.getCounterMessageContext().getPreviousMessageContext()));
				listenPeer = newMessageContext.getPreviousMessageContext().getListenPeer();
			}
			Peer outboundPeer = newMessageContext.getPreviousMessageContext().getOutboundPeer();
			if(outboundPeer == null) {
				newMessageContext.getPreviousMessageContext().setOutboundPeer(
						this.transportResolver.resolve(
								newMessageContext.getCounterMessageContext().getPreviousMessageContext()));
				outboundPeer = newMessageContext.getPreviousMessageContext().getOutboundPeer();
			}
			newMessageContext.setListenPeer(listenPeer);
			newMessageContext.setOutboundPeer(outboundPeer);
	    	newMessageContext.setPairKey(String.valueOf(uaPair.hashCode()));

			System.out.println("Send UA isInner:" + newMessageContext.getOutboundPeer().isInner());
			System.out.println("Send counterMessageContext:" + counterMessageContext);
			System.out.println("Send newMessageContext:" + newMessageContext);
			
	    	
			// UAPairに、outer 用 として、保持する。 
			this.setUAPair(newMessageContext,uaPair);
	    	
			// UARouterに、送信する。
			this.send(newMessageContext);
			
		}
		// UAPairを削除する。
		this.removeUAPair(msgSet);
				
	}

	

	/**
	 * メッセージを下位層に送信する。
	 * @param msgContext
	 */
	public void send(MessageContext msgContext) {
		uaRouter.doDispatch(msgContext);
	}
	
	/**
	 * UAPairを取得する。
	 * @param key
	 * @return
	 */
	public UAPair getUAPair(MessageContext msgContext) {
		return (UAPair)uaPairTable.get(msgContext.getUniKey());
	}
	/**
	 * UAPairをセットする。
	 * @param key
	 * @param uaSet
	 */
	public void setUAPair(MessageContext msgContext, UAPair uaSet){
		uaPairTable.put(msgContext.getUniKey(), uaSet);
		uaSet.setUAMessage(msgContext.getUniKey(), msgContext);
	}
	/**
	 * UAPairを削除する。
	 * @param msgSet
	 */
	public void removeUAPair(MessageContext msgSet) {
		ControlMessage ctrlMsg = msgSet.getControlMessage();
		if(ctrlMsg != null && ctrlMsg.get(ControlMessage.DELETE)) {
			UAPair uaPair = this.getUAPair(msgSet);
			this.uaPairTable.remove(msgSet.getUniKey());
			uaPair = null;
		}
	}
	
	/**
	 * ControlMessageを作成する。
	 * @param message
	 * @return
	 */
	public ControlMessage createControlMessage(MessageContext message) {
		ControlMessage controlMessage = new UAControlMessage();
		return controlMessage;
	}
	
	
// Routerとしてのメソッド。使用しない。
	
	public void addRoute(Router router) {
		this.uaRouter = router;
	}

	public void removeRoute(Router router) {
		throw new NotImplementedException();
	}

	public void doRoute(MessageContext message) {
		throw new NotImplementedException();
	}

	public void doProcessMessage(Object obj) {
		throw new NotImplementedException();
	}

	public void setRepository(Repository repository) {
		throw new NotImplementedException();
	}

	public Repository getRepository() {
		throw new NotImplementedException();
	}

	public void setResolvers(List resolverList) {
		this.resolverList = resolverList;
		for(Iterator iter = resolverList.iterator(); iter.hasNext();) {
			Resolver resolver = (Resolver)iter.next();
			if(resolver instanceof TransportResolverImpl) {
				this.transportResolver = resolver;
			} else if(resolver instanceof ListenResolverImpl) {
				this.listenResolver = resolver;
			}
		}
	}

	public List getResolvers() {
		return resolverList;
	}

	public Resolver getResolver() {
		return null;
	}
	
}
