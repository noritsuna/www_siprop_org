/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.resolver.impl;

import gov.nist.javax.sip.header.Via;
import gov.nist.javax.sip.message.SIPMessage;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import org.siprop.core.Resolver;
import org.siprop.core.transport.Peer;
import org.siprop.core.util.PropertiesDepot;
import org.siprop.message.impl.MessageContext;
import org.siprop.transport.util.PeerImpl;

/**
 * TransportResolverの実装クラス
 * @author noritsuna
 *
 */
public class TransportResolverImpl implements Resolver {
	
	private PropertiesDepot prop;
	/**
	 * 内向きのPeerのMap
	 */
	private Map innerMap = new HashMap();
	/**
	 * 外向きのPeerのMap
	 */
	private Map outerMap = new HashMap();
	
	/**
	 * デフォルトのキー
	 */
	private String defaultKey;
	
	/**
	 * コンストラクタ
	 * @param obj
	 */
	public TransportResolverImpl(Object obj) {
		this.prop = (PropertiesDepot)obj;
		
		InetAddress innerInet = null;
		try {
			innerInet = InetAddress.getByName(prop.getProperty("resolver.transport.inner.outbound.ip"));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		Peer innerPeer = new PeerImpl(2, innerInet, Integer.parseInt(prop.getProperty("resolver.transport.inner.outbound.port")));
		innerPeer.setInner(false);

		
		InetAddress outerInet = null;
		try {
			outerInet = InetAddress.getByName(prop.getProperty("resolver.transport.outer.outbound.ip"));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		Peer outerPeer = new PeerImpl(2, outerInet, Integer.parseInt(prop.getProperty("resolver.transport.outer.outbound.port")));
		outerPeer.setInner(true);
		
		String innerKey = "sip:" + prop.getProperty("resolver.transport.inner.outbound.ip") + ":" + prop.getProperty("resolver.transport.inner.outbound.port");
		defaultKey = innerKey;
		innerMap.put(innerKey, outerPeer);
		innerMap.put(prop.getProperty("resolver.transport.inner.outbound.ip"), outerPeer);
		String outerKey = "sip:" + prop.getProperty("resolver.transport.outer.outbound.ip") + ":" + prop.getProperty("resolver.transport.outer.outbound.port");
		outerMap.put(outerKey, innerPeer);
		outerMap.put(prop.getProperty("resolver.transport.outer.outbound.ip"), innerPeer);
		//prop.getProperty("resolver.transport.inner.outbound.ip")
		
		
	}
	/**
	 * 名前解決を行う。<BR>
	 * MessageContextのgetOutboundPeer()とSIPMessageのViaにより、判定を行う。
	 * @param message
	 * @return
	 */
	public Peer resolve(MessageContext message) {
		
		String mapKey;
		if(message.getOutboundPeer() != null) {
			System.out.println("TransportResolver resolve message.getOutboundPeerStr():" +"sip:" +  message.getOutboundPeerStr());
			return getPeer("sip:" + message.getOutboundPeerStr());
		}
		
		SIPMessage sipMsg = (SIPMessage)message.getCurrentMessage();
		if(sipMsg == null) {
			System.out.println("TransportResolver resolve sipMsg Null!!!");
			return null;
		}
		
		System.out.println("sipMsg:" + sipMsg.toString());
		
		Via via = (Via)sipMsg.getViaHeaders().getFirst();
		if(via == null) {
			System.out.println("TransportResolver resolve Via Null!!!");
			return null;
		}
		int port = via.getPort();
		if(port <= 0) {
			port = 5060;
		}
		
		mapKey = "sip:" + via.getHost() + ":" + String.valueOf(port);
		System.out.println("TransportResolver resolve Key:" + mapKey);
		
		
		return getPeer(mapKey);
	}
	/**
	 * デフォルトとなるPeerを取得する。
	 * @param mapKey
	 * @return
	 */
	private Peer getPeer(String mapKey) {
		Peer peer = (Peer)innerMap.get(mapKey);		
		if(peer==null) {
			peer  = (Peer)outerMap.get(mapKey);
		}
		// これでも引っかからなければ、デフォルトルートを使用する。
		if(peer==null) {
			System.out.println("TransportResolver get DefaultRoute:");
			peer = (Peer)innerMap.get(defaultKey);
		}
		return peer;
	}

}
