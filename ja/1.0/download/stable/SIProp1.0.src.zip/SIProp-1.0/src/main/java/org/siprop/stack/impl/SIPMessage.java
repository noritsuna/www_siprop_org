/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.impl;

import org.siprop.core.message.Message;
/**
 * Stackの都合により、存在するクラス<BR>
 * 新Stack時には削除予定。
 * @author noritsuna
 *
 */
public class SIPMessage implements Message
{
	public static final int MESSAGE_REQUEST = 1;
	public static final int MESSAGE_RESPONSE = 2;

	private javax.sip.message.Message msg;

	/**
	 * コンストラクタ
	 * @param msg
	 */
	public SIPMessage(javax.sip.message.Message msg)
	{
		this.msg = msg;
	}
	/**
	 * メッセージを取得する。
	 * @return
	 */
	public javax.sip.message.Message getMessage()
	{
		return msg;
	}
}
