/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core;

/**
 * Filterのcomposerパターン用抽象クラス
 * @author noritsuna
 *
 */
public abstract class FilterComposer implements Filter {

	/**
	 * Filterを実行する。
	 * @param obj
	 * @return
	 */
	public abstract Object exec(Object obj);
	
    /**
     * Filterを追加する. 
     * @param filter 
     **/
    public abstract void add(Filter filter);
    /**
     * Filterを削除する. 
     * @param filter 
     **/
    public abstract void remove(Filter filter);
}