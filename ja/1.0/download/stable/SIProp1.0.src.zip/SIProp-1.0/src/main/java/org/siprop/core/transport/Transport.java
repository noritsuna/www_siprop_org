/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.transport;


import java.io.IOException;


/**
 * Transport for Java2 Microedition.
 * @author sakukawa
 *
 */
public abstract class Transport {
	private int sendBufSize = 1500;
	private int recvBufSize = 1500;
	
	
	public static final int PROTO_UNKNOWN = 0;
	public static final int PROTO_TCP = 1;
	public static final int PROTO_UDP = 2;
	public static final int PROTO_PSEUDO = 3;

	private static final String[] PROTOCOL_NAME = {
		"UNKNOWN",
		"TCP",
		"UDP",
		"PSEUDO"
	};
	
	/**
	 * constructor.
	 *
	 */
	protected Transport() {
	}

	/**
	 * プロトコル名を取得する。
	 * @return
	 */
	public abstract String getProtocolName();
	/**
	 * プロトコル番号を取得する。
	 * @return
	 */
	public abstract int getProtocol();
	/**
	 * ローカルのIPアドレスを取得する。
	 * @return
	 */
	public abstract String getLocalAddress();
	/**
	 * ローカルのポートを取得する。
	 * @return
	 */
	public abstract int getLocalPort();
	/**
	 * リモートのIPアドレスを取得する。
	 * @return
	 */
	public abstract String getRemoteAddress();
	/**
	 * リモートのポートを取得する。
	 * @return
	 */
	public abstract int getRemotePort();
	/**
	 * ローカルのPeerを取得する。
	 * @return
	 */
	public abstract Peer getLocalPeer();
	/**
	 * リモートのPeerを取得する。
	 * @return
	 */
	public abstract Peer getRemotePeer();
	/**
	 * プロトコル名からプロトコル番号を取得する。
	 * @param s
	 * @return
	 */
	public static int getProtocolIdByName(String s) {
		if ("TCP".equalsIgnoreCase(s)) return Transport.PROTO_TCP;
		else if ("UDP".equalsIgnoreCase(s)) return Transport.PROTO_UDP;
		throw new IllegalArgumentException("unknown protocol name : " + s);
	}
	/**
	 * 送信バッファサイズを取得する。
	 * @return
	 */
	public int getSendBufferSize()
	{
		return sendBufSize;
	}
	/**
	 * 送信バッファサイズをセットする。
	 * @param n
	 */
	public void setSendBufferSize(int n)
	{
		this.sendBufSize = n;
	}
	/**
	 * 受信バッファサイズを取得する。
	 * @return
	 */
	public int getRecvBufferSize()
	{
		return recvBufSize;
	}
	/**
	 * 受信バッファサイズをセットする。
	 * @param n
	 */
	public void setRecvBufferSize(int n)
	{
		this.recvBufSize = n;
	}
	/**
	 * 送信する。
	 * @param b
	 * @param offset
	 * @param length
	 * @throws IOException
	 */
	public void send(byte[] b, int offset, int length) throws IOException
	{
		System.out.println("===========================");
		System.out.write(b, offset, length);
		System.out.println("===========================");
	}
	/**
	 * 送信する。
	 * @param dest
	 * @param port
	 * @param b
	 * @param offset
	 * @param length
	 * @throws IOException
	 */
	public void send(String dest, int port, byte[] b, int offset, int length) throws IOException
	{
		System.out.println("===========================");
		System.out.println("dest : " + dest + ", port : " + port);
		System.out.write(b, offset, length);
		System.out.println("===========================");
	}
	

	/**
	 * 受信する。
	 * @return
	 * @throws IOException
	 */
	public abstract Packet receive() throws IOException;

	/**
	 * 文字列にする。
	 */
	public String toString()
	{
		final String[] PSTR = { "UNKNOWN", "TCP", "UDP", "PSEUDO" };
		
		StringBuffer buf = new StringBuffer();
		buf.append("{ proto=").append(getProtocolName()).append(", ");
		buf.append("local_host=").append(getLocalAddress()).append(", ");
		buf.append("local_port=").append(getLocalPort()).append(", ");
		buf.append("sendBufSize=").append(getSendBufferSize()).append(", ");
		buf.append("recvBufSize=").append(getRecvBufferSize()).append(" }");
		return buf.toString();
	}
}
