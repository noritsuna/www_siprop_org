/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.util;

import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;

import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;

/**
 * J2ME-PPに合わせたTransportクラス
 * @author sakukawa
 *
 */
public class J2MEPPPacketImpl implements Packet
{
	private byte[] buf;
	private int offset;
	private int length;
	private Transport tp;
	private Peer sourcePeer;
	private Peer destPeer;
	
	/**
	 * コンストラクタ
	 * @param dg
	 */
	public J2MEPPPacketImpl(Transport tp, DatagramPacket dg)
	{
		this.tp = tp;
		this.buf = dg.getData();
		this.offset = 0;
		this.length = this.buf.length;
	}

	/**
	 * コンストラクタ
	 * @param buf
	 * @param offset
	 * @param length
	 */
	public J2MEPPPacketImpl(/* Transport tp, */byte[] buf, int offset, int length)
	{
//		this.tp = tp;
		this.buf = buf;
		this.offset = offset;
		this.length = length;
	}

	
	/**
	 * データを取得する。
	 * @return データ
	 */
	public byte[] getData() {
		return this.buf;
	}
	/**
	 * offset値を取得する。
	 * @return offset値
	 */
	public int getOffset() {
		return offset;
	}
	/**
	 * データ長を取得する。
	 * @return データ長
	 */
	public int getLength() {
		return length;
	}

	/**
	 * 文字列に変換する。
	 * @return パケット文字列
	 */
	public String toString()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(tp.toString()).append("\r\n");
	
		String data = null;
		try {
			data = new String(this.buf, "utf-8");
		} catch(UnsupportedEncodingException ex) {}
		buf.append(data);
		return buf.toString();
	}
	/**
	 * sourceのPeerを取得する。
	 * @return sourceのPeer
	 */
	public Peer getSourcePeer()
	{
		return sourcePeer;
	}
	/**
	 * destのPeerを取得する。
	 * @return destのPeer
	 */
	public Peer getDestPeer()
	{
		return destPeer;
	}
	/**
	 * sourceのPeerをセットする。
	 * @param p sourceのPeerを
	 */
	public void setSourcePeer(Peer p)
	{
		this.sourcePeer = p;
	}
	/**
	 * destのPeerをセットする。
	 * @param p destのPeer
	 */
	public void setDestPeer(Peer p)
	{
		this.destPeer = p;
	}
	

}
