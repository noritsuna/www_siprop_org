/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.message.impl;

import org.siprop.core.message.ContextDiscriminator;

/**
 * 一番基本となる識別キーを生成するクラス
 * @author noritsuna
 *
 */
public class DefaultContextDiscriminator implements ContextDiscriminator {

	/**
	 * 識別キーを生成する。
	 * @param msg MessageContext
	 * @return 識別キー
	 */
	public String generateKey(MessageContext msg) {
		return msg.getUniKey();
	}

}
