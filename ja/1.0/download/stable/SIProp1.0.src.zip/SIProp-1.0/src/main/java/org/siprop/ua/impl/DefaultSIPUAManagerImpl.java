/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.ua.impl;

import org.siprop.core.Provider;
import org.siprop.core.message.ControlMessage;
import org.siprop.core.ua.BaseSIPUAManager;
import org.siprop.core.ua.UA;
import org.siprop.core.ua.util.UAModuleList;
import org.siprop.message.impl.MessageContext;
import org.siprop.message.impl.UAControlMessage;

/**
 * デフォルトのSIPUAManager実装クラス
 * @author noritsuna
 *
 */
public class DefaultSIPUAManagerImpl extends BaseSIPUAManager {
	
	/**
	 * コンストラクタ
	 * @param provider
	 * @param ua
	 */
	public DefaultSIPUAManagerImpl(Provider provider, UA ua) {
		super(provider, ua);
	}

	
	/**
	 * メッセージの処理を開始する。
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext) {
		
		if(this.uaList == null) {
			System.out.println("create new SIPUAModule");
			this.uaList = new UAModuleList();
			
			UA ua = new DefaultSIPUAModuleImpl(provider, this);
			this.uaList.addUA(messageContext, ua);
			
		} else if(this.uaList.isForkMessage(messageContext)) {
			// Foringされたメッセージである場合.
			UA ua = new DefaultSIPUAModuleImpl(provider, this);
			this.uaList.addUA(messageContext, ua);
		}
		
		// controlMessageが無いor自分(UA)用のコントロールメッセージではない場合は、
		// 初期化する。
		ControlMessage controlMessage = messageContext.getControlMessage();
		if(controlMessage == null || !(controlMessage instanceof UAControlMessage)) {
			System.out.println("init controlMessage.");
			controlMessage = new UAControlMessage();
			messageContext.setControlMessage(controlMessage);
		}
		if(controlMessage.getRouteMode() == ControlMessage.NO_ROUTE) {
			// この場合は、初回メッセージなので、B2BUAへ。
			System.out.println("set TO_UPPER Route.");
			controlMessage.set(UAControlMessage.TO_UPPER);
		}
		this.doControlCommand(messageContext);
		super.doProcessMessage(messageContext);		
	}
	
	/**
	 * Command処理を行う。
	 * @param messageContext
	 */
	public void doControlCommand(MessageContext messageContext) {
				
	}
	
	
	/**
	 * UAの種類を特定する識別子を取得する。
	 * @return key 識別子
	 */
	public String getUAType() {
		return this.getClass().getName();
	}


	/**
	 * stateによる処理を行う。
	 * @param messageContext
	 */
	public void doState(MessageContext messageContext) {
		
	}

}
