/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.Socket;

import org.siprop.core.transport.Packet;
import org.siprop.transport.util.J2MEPPPacketImpl;

/**
 * SIPのTCP用のTransportクラス<BR>
 * SIP上のContent-Lengthヘッダを確認する必要があるため、特別に作成されている。
 * @author sakukawa
 *
 */
public class SIPTCPTransport extends TCPTransport
{
	private BufferedReader reader = null;
	private StringBuffer buf;
	private StringBuffer resultBuffer;
	private int contentLength;
	
	/**
	 * コンストラクタ
	 * @param s
	 * @param host
	 * @param port
	 * @throws IOException
	 */
	public SIPTCPTransport(Socket s, String host, int port) throws IOException
	{
		super(s, host, port);
		reader = new BufferedReader(new InputStreamReader(this.in, "utf-8"));
		buf = new StringBuffer();
		resultBuffer = new StringBuffer();
		contentLength = -1;
	}
	/**
	 * コンストラクタ
	 * @param host
	 * @param port
	 * @throws IOException
	 */
	public SIPTCPTransport(String host, int port) throws IOException
	{
		super(host, port);
		reader = new BufferedReader(new InputStreamReader(this.in, "utf-8"));
		buf = new StringBuffer();
		resultBuffer = new StringBuffer();
		contentLength = -1;
	}

	/**
	 * SIPのパケットを受信する。
	 * @return 受信したパケット
	 */
	public synchronized Packet receive() throws IOException
	{
		try{
			char[] recvBuf = new char[getRecvBufferSize()];
			while(true) {
				Packet p = parseBuffer();
				if (p != null) return p;

				int n = reader.read(recvBuf);

				if (n < 0) return null;
				buf.append(recvBuf);

			}
		} catch(java.text.ParseException ex) {
			ex.printStackTrace();
			return null;
		}
	}
	/**
	 * 	Content-Lengthの確認を行い、その処理をするためのメソッド。
	 * @return Content-Lengthチェック済みのパケット
	 * @throws java.text.ParseException
	 */
	private Packet parseBuffer() throws java.text.ParseException
	{
		final String STR = "Content-Length: ";

		if (contentLength < 0) {
			int contentLengthPtr = buf.indexOf(STR);
			int crlfPtr = buf.indexOf("\r\n\r\n");

			if (crlfPtr < 0) return null;
			else if (contentLengthPtr > crlfPtr) {
				// 不正なパケットのため、削除して次のパケットにうつる
				System.out.println("illegal packet");
				buf.replace(0, crlfPtr+4, "");
				return null;
			}

			contentLength = Integer.parseInt(buf.substring(contentLengthPtr + STR.length(),
											buf.indexOf("\r\n", contentLengthPtr))); 

			resultBuffer.append(buf.substring(0, crlfPtr+4));
			buf.replace(0, crlfPtr+4, "");
		}
		
		if (buf.length() >= contentLength) {
			resultBuffer.append(buf.substring(0, contentLength));
			buf.replace(0, contentLength, "");
			contentLength = -1;
			try {
				byte[] b = resultBuffer.toString().getBytes("utf-8");
				Packet p = new J2MEPPPacketImpl(/*this,*/ b, 0, b.length);
				return p;
			} catch(UnsupportedEncodingException ex) {}
		}
		return null;
	}
	
}
