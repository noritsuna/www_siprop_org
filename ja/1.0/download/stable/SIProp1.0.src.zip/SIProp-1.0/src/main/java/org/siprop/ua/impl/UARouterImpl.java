/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.ua.impl;

import java.util.HashMap;
import java.util.Map;

import org.siprop.core.Repository;
import org.siprop.core.Router;
import org.siprop.core.ua.UARouter;
import org.siprop.message.impl.MessageContext;
import org.siprop.ua.util.UAType;

/**
 * UARouterの実装クラス<BR>
 * SIPのみを捌く
 * @author noritsuna
 *
 */
public class UARouterImpl implements UARouter {

	/**
	 * 処理すべきRouterのリスト
	 */
	private Map routingTable = new HashMap();
	
	/**
	 * UAの種類
	 */
	private String uaKey;
	
	
	/**
	 * Repository
	 */
	private Repository repository;
	
	/**
	 * コンストラクタ
	 * @param repository
	 */
	public UARouterImpl(Repository repository) {
		this.repository = repository;
	}

	
	/**
	 * 外部からディスパッチされるメソッド
	 * @param message
	 */
	public void doDispatch(MessageContext message) {
		this.doRoute(message);
	}
	/**
	 * Routerを追加する。
	 * @param router
	 */
	public void addRoute(Router router) {
		UARouter keyRouter = (UARouter)router;
		routingTable.put(keyRouter.getRoutingKey(), router);
	}
	/**
	 * Routerを削除する。
	 * @param router
	 */
	public void removeRoute(Router router) {
		UARouter keyRouter = (UARouter)router;
		routingTable.remove(keyRouter.getRoutingKey());
	}
	/**
	 * Routingを実行する。
	 * @param message
	 */
	public void doRoute(MessageContext message) {

		System.out.println("UARouterImpl.doRoute() called : " + message);
		
		// とても単純なルーティングのみを行う。
		UARouter router = (UARouter)routingTable.get(UAType.SIP);
		if(router != null) {
			router.doDispatch(message);
		}
	}
	/**
	 * RoutingKeyを取得する。
	 * @return UAの種類
	 */
	public String getRoutingKey() {
		return uaKey;
	}

	/**
	 * Repositoryをセットする。
	 * @param repository
	 */
	public void setRepository(Repository repository) {
		this.repository = repository;
	}
	/**
	 * Repositoryを取得する。
	 * @return
	 */
	public Repository getRepository() {
		return repository;
	}

}
