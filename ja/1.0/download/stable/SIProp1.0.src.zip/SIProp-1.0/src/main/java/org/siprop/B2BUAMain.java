/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop;

import org.siprop.b2bua.impl.B2BUAProviderImpl;
import org.siprop.core.Provider;

/**
 * 起動用クラス
 * @author noritsuna
 *
 */
public class B2BUAMain {

	/**
	 * メインメソッド
	 * @param args
	 */
	public static void main(String[] args) {
		
		Provider prov = new B2BUAProviderImpl();
		prov.setup();

	}

}
