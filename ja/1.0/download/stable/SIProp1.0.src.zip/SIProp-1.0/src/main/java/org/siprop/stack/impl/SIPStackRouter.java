/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.impl;

import java.util.HashMap;
import java.util.Map;

import org.siprop.core.Repository;
import org.siprop.core.Router;
import org.siprop.core.stack.Stack;
import org.siprop.core.transport.Packet;
import org.siprop.core.transport.PacketProcessor;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;
import org.siprop.core.util.RouteType;
import org.siprop.message.impl.MessageContext;

/**
 * Transport情報から、使用するstackを判別するクラス
 * @author sakukawa <sakukawa@siprop.org>
 *
 */
public class SIPStackRouter implements PacketProcessor
{
	/**
	 * RoutingTable
	 */
	private Map routingTable;
//	private Stack defaultStack;
	/**
	 * 上位層へのRouter
	 */
	private Router upperRouter;
	/**
	 * 下位層へのRouter
	 */
	private Router lowerRouter;

	/**
	 * コンストラクタ
	 *
	 */
	public SIPStackRouter(/*Stack defaultStack*/)
	{
		routingTable = new HashMap();
//		this.defaultStack = defaultStack;
	}
	
	
	
	public void addRoute(Router router) {
	}
	public void doDispatch(MessageContext message) {
	}
	public Repository getRepository() {
		return null;
	}
	public void removeRoute(Router router) {
	}
	public void setRepository(Repository repository) {
	}


	/**
	 * 外向きのメッセージ送信を処理する
	 * @param
	 */
	public void doRoute(MessageContext message) {
		// 1. MessageContextのStackTypeを確認して、
		//    Stackを取得する。
		// 2. Stackのsend()を呼ぶ
		try {
			System.out.println("StackRouter#doRoute() called : " + message);
			MessageContext ctx = message.getPreviousMessageContext();
			SIPStack dest = null;
			dest = new SIPStack();
			dest.send(message);
		} catch(Throwable ex) {
			ex.printStackTrace();
		}
	}


	/**
	 * 外部からディスパッチされるメソッド
	 * @param tp
	 * @param hop
	 * @param p
	 */
	public void doDispatch(Transport tp, Peer hop, Packet p)
	{
		doRoute(tp, hop, p);
	}
	
	/**
	 * Transportをキーとして、Routerを追加する。
	 * @param tp
	 * @param pp
	 */
	public void addRoute(Transport tp, PacketProcessor pp)
	{
		routingTable.put(tp, pp);
	}
	
	/**
	 * Routerを削除する。
	 * @param tp
	 */
	public void removeRoute(Transport tp)
	{
		routingTable.remove(tp);
	}
	
	/**
	 * Routingを実行する。
	 * @param tp
	 * @param hop
	 * @param p
	 */
	public void doRoute(Transport tp, Peer hop, Packet p)
	{
		//new SIPStack().doDispatch(tp, p);
	
		Stack dest = (Stack)routingTable.get(tp);
		if (dest == null) {
			dest = new SIPStack();//defaultStack;
		}
		dest.doDispatch(tp, p, upperRouter);
	}

	/**
	 * Routerをセットする。
	 * @param routeType
	 * @param router
	 */
	public void setRouter(RouteType routeType, Router router) {
		if(RouteType.UPPER_LAYER.equals(routeType)) {
			upperRouter = router;
			// currentRouter.setDispatcher(router);
		} else if(RouteType.LOWER_LAYER.equals(routeType)) {
			lowerRouter = router;
			// currentRouter.setDispatcher(router);
		}		
	}

}
