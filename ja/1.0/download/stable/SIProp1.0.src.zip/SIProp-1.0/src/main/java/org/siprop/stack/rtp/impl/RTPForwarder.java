/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.rtp.impl;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

import org.siprop.message.impl.MessageContext;

/**
 * RTPを送受信するためのクラス
 * @author noritsuna
 *
 */
public class RTPForwarder {
	/**
	 * RTPの接続先セット
	 */
	private RTPpairs rtpPairs = null;
	/**
	 * 
	 */
	private LinkedList insideRTPUAList = null;
	private LinkedList outsideRTPUAList = null;
	
	/**
	 * コンストラクタ
	 * @param msg
	 */
	public RTPForwarder (MessageContext msg) {
		rtpPairs = new RTPpairs();
		insideRTPUAList = new LinkedList();
		outsideRTPUAList = new LinkedList();
		
		RTPUAModule rtp = new RTPUAModule(msg, this);
		if (msg.getOutboundPeer().isInner()) {
			insideRTPUAList.addLast(rtp);
		}
		else {
			outsideRTPUAList.addLast(rtp);
		}
		
		return;
	}
	
	/**
	 * RTPの送信先を振り分ける。
	 * @return
	 */
	public boolean select () {
		Iterator itr0 = null;
		Iterator itr1 = null;
		Iterator itr2 = null;
		RTPUAModule rtp0 = null;
		RTPUAModule rtp1 = null;
		byte buffer[] = null;

		if (rtpPairs.isEmpty()) {
			return false;
		}

		for (itr0 = rtpPairs.iterator(); itr0.hasNext(); ) {
			LinkedList pair = (LinkedList)itr0.next();
			for (itr1 = pair.iterator(); itr1.hasNext(); ) {
				rtp0 = (RTPUAModule)itr1.next();

				/* forward RTP packets */
				if ((buffer = rtp0.receive(RTPUAModule.TYPE_RTP)) == null) {
					continue;
				}
				for (itr2 = pair.iterator(); itr2.hasNext(); ) {
					rtp1 = (RTPUAModule)itr2.next();
					if (rtp0.equals(rtp1)) {
						continue;
					}
					try {
						rtp1.send(buffer, 0);
					}
					catch (IOException e) {
						// e.printStackTrace();
					}
				}

				/* forward RTCP packets */
				if ((buffer = rtp0.receive(RTPUAModule.TYPE_RTCP)) == null) {
					continue;
				}

				for (itr2 = pair.iterator(); itr2.hasNext();) {
					rtp1 = (RTPUAModule)itr2.next();
					if (rtp0.equals(rtp1)) {
						continue;
					}
					try {
						rtp1.send(buffer, 1);
					} catch (IOException e) {
						// e.printStackTrace();
					}
				}
			}
		}
		return true;
	}
	
	/**
	 * 終了処理をする。
	 *
	 */
	public synchronized void destroy() {
		Iterator itr = null;
		RTPUAModule rtp = null;
		
		/* delete RTP Pair */
		for (int i = 0; i < rtpPairs.length(); i++) {
			rtpPairs.deletePair(i);
		}
		
		/* clear inside RTPUAModule list */
		for (itr = insideRTPUAList.iterator(); itr.hasNext(); ) {
			rtp = (RTPUAModule)itr.next();
			rtp.close();
		}
		insideRTPUAList.clear();
		
		/* clear outside RTPUAModule list */
		for (itr = outsideRTPUAList.iterator(); itr.hasNext(); ) {
			rtp = (RTPUAModule)itr.next();
			rtp.close();
		}
		outsideRTPUAList.clear();
		
		return;
	}

	/**
	 * RTPUAを追加する。
	 * @param msg
	 */
	public void addRTPUA(MessageContext msg) {
		LinkedList list = null;
		if (msg.getOutboundPeer().isInner()) {
			list = insideRTPUAList;
		}
		else {
			list = outsideRTPUAList;
		}
		
		RTPUAModule rtp = new RTPUAModule(msg, this);
		list.addLast(rtp);
		return;
	}
}