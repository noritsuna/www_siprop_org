/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.ua.impl;


import java.util.Iterator;
import java.util.List;

import org.siprop.core.Provider;
import org.siprop.core.Repository;
import org.siprop.core.ua.UA;
import org.siprop.core.ua.UASetManager;
import org.siprop.core.ua.util.UAModuleList;
import org.siprop.core.util.NotImplementedException;
import org.siprop.core.util.RouteType;
import org.siprop.message.impl.MessageContext;
import org.siprop.message.impl.UAControlMessage;

/**
 * デフォルトのUASetManagerの実装クラス<BR>
 * すべてのUASetを起動し、操作を行う。
 * @author noritsuna
 *
 */
public class DefaultSIPUASetManagerImpl implements UASetManager {
	
	private Repository defaultRepository;
	private Provider provider;
	private DefaultSIPUASetImpl uaSet;
	private UA callbackUA;
	
	
	/**
	 * コンストラクタ
	 * @param provider
	 */
	public DefaultSIPUASetManagerImpl(Provider provider) {
		this.provider = provider;
		List repoList = provider.getRepositories();
		
		for(Iterator iter = repoList.iterator(); iter.hasNext();) {
			Repository repo = (Repository)iter.next();
			if(repo instanceof UARepositoryImpl) {
				this.defaultRepository = repo;
				break;
			}
		}
	}

	/**
	 * 実行する。スタートポイント。
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext) {
		if(uaSet == null) {
			uaSet = new DefaultSIPUASetImpl(provider, this);
		}
		uaSet.doProcessMessage(messageContext);
	}

	/**
	 * コールバック先のUAをセットする。
	 * @param callbackUP
	 */
	public void setCallbackUA(UA callbackUA) {
		this.callbackUA = callbackUA;
		
	}

	/**
	 * MessageContextを送信する。
	 * @param messageContext
	 */
	public void send(MessageContext messageContext) {
		if(messageContext.getControlMessage().get(UAControlMessage.TO_UPPER)) {
			System.out.println("send to UPPER.");
			defaultRepository.getRouter(RouteType.UPPER_LAYER).doDispatch(messageContext);
		} else {
			System.out.println("send to LOWER.");
			messageContext.setControlMessage(null);
			messageContext.setStackType("SIP");
			defaultRepository.getRouter(RouteType.LOWER_LAYER).doRoute(messageContext);
		}
	}

	/**
	 * Command処理を行う。
	 * @param messageContext
	 */
	public void doControlCommand(MessageContext messageContext) {
		// 今のところ、行う処理はない。		
	}
	
	/**
	 * UASetを削除する。
	 * @param messageContext
	 */
	private void removeUASet(MessageContext messageContext) {
		// 今のところ、行う処理はない。
	}
	
	/**
	 * UAの種類を特定する識別子を取得する。
	 * @return key 識別子
	 */
	public String getUAType() {
		
		return this.getClass().getName();
		
	}
	
	// UASetManagerとして、使用しないメソッド
	public void doCallBackFromUA(MessageContext messageContext, UA module) {
		throw new NotImplementedException();
	}
	public void dispatchUAModule(MessageContext messageContext, UAModuleList uaSet) {
		throw new NotImplementedException();
	}
	public void destroyModule(MessageContext messageContext) {
		throw new NotImplementedException();
	}
	public void doState(MessageContext messageContext) {
		throw new NotImplementedException();
	}
}
