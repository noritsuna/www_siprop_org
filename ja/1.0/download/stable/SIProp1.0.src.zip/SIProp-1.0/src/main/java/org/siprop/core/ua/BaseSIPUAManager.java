/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua;

import java.util.Iterator;
import java.util.List;

import org.siprop.core.Provider;
import org.siprop.core.Repository;
import org.siprop.core.message.ContextDiscriminator;
import org.siprop.core.message.ControlMessage;
import org.siprop.core.ua.util.UAModuleList;
import org.siprop.message.impl.DefaultContextDiscriminator;
import org.siprop.message.impl.MessageContext;
import org.siprop.message.impl.UAControlMessage;
import org.siprop.ua.impl.DefaultSIPUASetImpl;
import org.siprop.ua.impl.UARepositoryImpl;

/**
 * デフォルト動作するSIPUAManager抽象化クラス
 * @author noritsuna
 *
 */
public abstract class BaseSIPUAManager implements UAManager {

	/**
	 * Repository
	 */
	protected Repository defaultRepository;
	/**
	 * Provider
	 */
	protected Provider provider;
	/**
	 * コールバック先のUA
	 */
	protected UA callbackUA;

	/**
	 * UAModuleのListを管理する
	 */
	protected UAModuleList uaList = null;
	
	/**
	 * ContextDiscriminator
	 */
	protected ContextDiscriminator descriminator = new DefaultContextDiscriminator();

	/**
	 * コンストラクタ
	 * @param provider
	 * @param ua コールバック先のUA
	 */
	public BaseSIPUAManager(Provider provider, UA ua) {
		this.provider = provider;
		this.callbackUA = ua;
		List repoList = provider.getRepositories();
		
		for(Iterator iter = repoList.iterator(); iter.hasNext();) {
			Repository repo = (Repository)iter.next();
			if(repo instanceof UARepositoryImpl) {
				this.defaultRepository = repo;
				break;
			}
		}
	}

	
	/**
	 * メッセージの処理を開始する。
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext) {
		System.out.println("BaseSIPUAManagerImpl.doProcessMessage() called : " + messageContext);
		ControlMessage controlMessage = messageContext.getControlMessage();		
    	if(controlMessage.get(ControlMessage.TO_UPPER)) {
    		this.uaList.processUpperMessage(messageContext);
    	} else {
    		this.dispatchUAModule(messageContext,uaList);
    	}
	}
	
	/**
	 * コールバック先のUA
	 * @param
	 */
	public void setCallbackUA(UA callbackUA) {
		this.callbackUA = callbackUA;
	}
	/**
	 * メッセージを送信する。
	 * @param MessageContext
	 */
	public void send(MessageContext messageContext) {
		DefaultSIPUASetImpl uaSet = (DefaultSIPUASetImpl)callbackUA;
		uaSet.addRoute(messageContext, this);
		this.doControlCommand(messageContext);
		this.callbackUA.send(messageContext);
	}


	/**
	 * UAModuleにディスパッチする。
	 */
	public void dispatchUAModule(MessageContext messageContext, UAModuleList uaSet) {
		this.uaList.doProcessMessage(messageContext);
	}
	
	/**
	 * モジュールを終了する。
	 * @param messageContext
	 */
	public void destroyModule(MessageContext messageContext) {
		UAControlMessage uaCtrl = null;
		try {
			uaCtrl = (UAControlMessage)messageContext.getControlMessage();
		} catch(ClassCastException e) {
			return;
		}
		this.uaList.removeUA(messageContext);
	}


	/**
	 * UAModuleより、コールバックされるメソッド
	 * @param messageContext
	 * @param uaModule
	 */
	public void doCallBackFromUA(MessageContext messageContext, UA module) {
		this.doControlCommand(messageContext);
		this.doState(messageContext);
		this.destroyModule(messageContext);
		
	}
	


}
