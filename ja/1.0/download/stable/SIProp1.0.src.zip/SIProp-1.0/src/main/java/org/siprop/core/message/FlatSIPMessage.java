/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.message;

import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.header.Contact;
import gov.nist.javax.sip.header.RecordRouteList;
import gov.nist.javax.sip.header.RouteList;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import javax.sip.header.Header;

import org.siprop.SIPropException;
import org.siprop.core.transport.Peer;


/**
 * パケットを共通化したメッセージ
 * @author noritsuna
 *
 */
public abstract class FlatSIPMessage {
	
	
	/**
	 * TO-Tag
	 */
    protected String toTag = null;
    /**
     * CSeq値
     */
    protected int cseq = 0;

	
	/**
	 * RouteSet
	 */
	protected RecordRouteList recordRouteList = null;
	/**
	 * RouteのList
	 */
	protected RouteList routeList = null;
	/**
	 * ContactURI
	 */
	protected SipUri contactURI = null;
	

	/**
	 * UACかどうか？
	 */
	protected boolean isUAC = false;
	
    /**
	 * 一番最初のメッセージ
	 */
    protected SIPRequest origRequest;
    /**
     * 一つ前のリクエスト
     */
    protected SIPRequest prevRequest;
    /**
     * 一つ前のレスポンス
     */
    protected SIPResponse prevResponse;
    
    
    
	/**
	 * テキストタイプのメッセージ
	 */
	protected String messageStr;
	/**
	 * バイナリタイプのメッセージ
	 */
	protected byte[] messageByte;
	

	/**
	 * FlatSIPMessageから、具体的なPacketを生成する。
	 * @return
	 */
	public abstract byte[] createPacket();
	
	
	/**
	 * Routingするための識別キー
	 * @return
	 */
	public abstract String getRoutingKey();
	
	
	/**
	 * Requestから、RouteSetを作成する。
	 * @param request
	 */
	public abstract void createRouteSet(SIPRequest request);
	
	/**
	 * Responseから、RouteSetを作成する。
	 * @param response
	 */
	public abstract void createRouteSet(SIPResponse response);
	
	
	/**
	 * 一つ前のレスポンスをセットする。
	 * @param sipResponse
	 */
	public abstract void setPrevResponse(SIPResponse sipResponse);
	/**
	 * 一つ前のリクエストをセットする。
	 * @param sipRequest
	 */
	public abstract void setPrevRequest(SIPRequest sipRequest);
	/**
	 * 一番最初のメッセージをセットする。
	 * @param sipRequest
	 */
	public abstract void setOrigRequest(SIPRequest sipRequest);

	/**
	 * 一つ前のレスポンスを取得する。
	 * @return
	 */
	public abstract SIPResponse getPrevResponse();
	/**
	 * 一つ前のリクエストを取得する。
	 * @return
	 */
	public abstract SIPRequest getPrevRequest();
	/**
	 * 一番最初のリクエストを取得する。
	 * @return
	 */
	public abstract SIPRequest getOrigRequest();

	
	/**
	 * REGSITERリクエストを生成する。
	 * @param requestURI
	 * @param callID
	 * @param from
	 * @param to
	 * @param branchid
	 * @param contact
	 * @param auth
	 * @param listenPeerStr
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPRequest createNewREGISTERRequest(String requestURI, 
			String callID, 
			String from, 
			String to, 
			String branchid, 
			String contact, 
			String auth, 
			String listenPeerStr) throws SIPropException;
	
	/**
	 * INVITEリクエストを生成する。
	 * @param requestURI
	 * @param callID
	 * @param from
	 * @param to
	 * @param branchid
	 * @param contact
	 * @param auth
	 * @param listenPeerStr
	 * @param sdp
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPRequest createNewINVITERequest(String requestURI, 
			String callID, 
			String from, 
			String to, 
			String branchid, 
			String contact, 
			String auth, 
			String listenPeerStr,
			String sdp) throws SIPropException;
	
	/**
	 * ACKリクエストを生成する。
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPRequest createACKRequest() throws SIPropException;
	
	/**
	 * CANCELリクエストを生成する。
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPRequest createCANCLERequest() throws SIPropException;

	/**
	 * BYEリクエストを生成する。
	 * @param isUAC
	 * @param listenPeer
	 * @param outboundPeerStr
	 * @param branchID
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPRequest createBYERequest(boolean isUAC, 
			Peer listenPeer, 
			String outboundPeerStr, 
			String branchID) throws SIPropException;
	
	/**
	 * 100レスポンスを生成する。
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPResponse create100Renponse() throws SIPropException;
	/**
	 * 1xxレスポンスを生成する。
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param sdpBody
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPResponse create1xxRenponse(int rensponseCode, 
			String reasonPhrase,
			String sdpBody) throws SIPropException;
	/**
	 * 2xxレスポンスを生成する。
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param sdpBody
	 * @param listenPeerStr
	 * @param origRecoudRouteList
	 * @param origContact
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPResponse create2xxRenponse(int rensponseCode, 
			String reasonPhrase,
			String sdpBody,
			String listenPeerStr,
			RecordRouteList origRecoudRouteList,
			Contact origContact) throws SIPropException;
	/**
	 * 4xxレスポンスを生成する。
	 * @param rensponseCode
	 * @param reasonPhrase
	 * @param auth
	 * @return
	 * @throws SIPropException
	 */
	public abstract SIPResponse create4xxRenponse(int rensponseCode, 
			String reasonPhrase,
			Header auth) throws SIPropException;
	
	
	/**
	 * RecordRouteListを取得する。
	 * @return
	 */
	public RecordRouteList getRecordRouteList() {
		return this.recordRouteList;
	}
	
	/**
	 * Routeが設定されているか？
	 * @return
	 */
	public boolean isRoute() {
		if(recordRouteList == null) {
			return false;
		}
		return true;
	}
	/**
	 * UACかどうか？
	 * @return
	 */	
	public boolean isUAC() {
		return isUAC;
	}
	

}
