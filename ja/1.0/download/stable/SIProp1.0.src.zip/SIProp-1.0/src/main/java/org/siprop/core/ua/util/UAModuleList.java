/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.siprop.core.message.ContextDiscriminator;
import org.siprop.core.ua.BaseSIPUAModule;
import org.siprop.core.ua.UA;
import org.siprop.message.impl.FokingContextDescriminator;
import org.siprop.message.impl.MessageContext;

/**
 * 同一ダイアログ上で動作するUAModuleを保持するためのクラス<BR>
 * Forking時に使用する。
 * @author noritsuna
 *
 */
public class UAModuleList {
	
	/**
	 * UAのリスト
	 */
	protected List uaList = Collections.synchronizedList(new ArrayList());
	
	/**
	 * UAのMap
	 */
	protected Map uaMap = Collections.synchronizedMap(new HashMap());
	
	/**
	 * Key生成用
	 */
	private ContextDiscriminator descriminator = new FokingContextDescriminator();

	
	/**
	 * コンストラクタ
	 *
	 */
	public UAModuleList() {
	}
	

	/**
	 * UAを追加する。
	 * @param ua
	 */
	public void addUA(MessageContext messageContext, UA ua) {
		this.uaList.add(ua);
		this.uaMap.put(descriminator.generateKey(messageContext), ua);
	}
	/**
	 * UAを削除する。
	 * @param messageContext
	 */
	public void removeUA(MessageContext messageContext) {
		UA ua = (UA)this.uaMap.get(descriminator.generateKey(messageContext));
		this.uaMap.remove(descriminator.generateKey(messageContext));
		this.uaList.remove(ua);
	}


	/**
	 * メッセージの処理を開始する。
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext) {
		for(Iterator itor = this.uaList.iterator(); itor.hasNext();) {
			UA ua = (UA)itor.next();
			ua.doProcessMessage(messageContext);
		}
	}

	/**
	 * Forkingされたメッセージかどうかを判定する。
	 * @param messageContext
	 * @return Forkingされている：true
	 */
	public boolean isForkMessage(MessageContext messageContext) {
		if(this.uaMap.get(descriminator.generateKey(messageContext)) == null) {
			return true;
		}
		return false;
	}


	public void processUpperMessage(MessageContext messageContext) {
		for(Iterator itor = this.uaList.iterator(); itor.hasNext();) {
			BaseSIPUAModule ua = (BaseSIPUAModule)itor.next();
			ua.doIncomingMessage(messageContext);
		}
	}

}
