/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.util;

import java.net.InetAddress;

import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;

/**
 * Peerを示すクラス
 * @author sakukawa
 *
 */
public class PeerImpl implements Peer
{
	private int protocol;
	private InetAddress host;
	private int port;
	private boolean isInner;
	
	/**
	 * コンストラクタ
	 * @param protocol
	 * @param host
	 * @param port
	 */
	public PeerImpl(int protocol, InetAddress host, int port)
	{
		this.protocol = protocol;
		this.host = host;
		this.port = port;
	}
	/**
	 * ホスト名を取得する。
	 * @return
	 */
	public InetAddress getHost()
	{
		return host;
	}
	/**
	 * IPアドレスを取得する。
	 * @return
	 */
	public InetAddress getAddress()
	{
		return host;
	}
	/**
	 * ポートを取得する。
	 * @return
	 */
	public int getPort()
	{
		return port;
	}
	/**
	 * プロトコル番号を取得する。
	 * @return
	 */
	public int getProtocol()
	{
		return protocol;
	}
	/**
	 * コネクション指向のプロトコルかどうか？
	 * @return
	 */
	public boolean isConnectionOrientedProtocol()
	{
		switch(getProtocol()) {
		case Transport.PROTO_TCP : return true;
		}
		return false;
	}
	/**
	 * hash値を取得する。
	 * @return
	 */
	public int hashCode()
	{
		String host = "";
		if (getAddress() != null) host = getAddress().getHostAddress();
		
		String s = host
				+ String.valueOf(getPort())
				+ String.valueOf(getProtocol());
		return s.hashCode();
	}
	/**
	 * IPアドレスとポート番号、プロトコル番号が同じであるかを比較する。
	 * @return
	 */
	public boolean equals(Object obj)
	{
		if (obj == null || !(obj instanceof Peer)) return false;

		Peer p = (Peer)obj;
		try {
			if (getAddress() == null && p.getAddress() == null) {
				return (getPort() == p.getPort() & getProtocol() == p.getProtocol());
			} else {			
				return (getAddress().equals(p.getAddress()) &
						getPort() == p.getPort() & getProtocol() == p.getProtocol());
			}
		} catch(NullPointerException ex) {
			ex.printStackTrace();
		}
		return false;
	}
	/**
	 * 文字列にする。
	 * @return プロトコル文字列
	 */
	public String toString()
	{
		return "{ protocol : " + getProtocol() + ", host : " + getHost() + ", port : " + getPort() + "}";
	}
	/**
	 * 内向きかどうか？
	 * @return
	 */
	public boolean isInner() {
		return this.isInner;
	}
	/**
	 * 内向きかどうか？をセットする。
	 * @param
	 */
	public void setInner(boolean isInner) {
		this.isInner = isInner;
	}
}