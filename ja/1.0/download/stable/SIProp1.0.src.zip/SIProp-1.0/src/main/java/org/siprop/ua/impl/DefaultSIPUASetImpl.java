/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.ua.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.siprop.core.Provider;
import org.siprop.core.Repository;
import org.siprop.core.message.ContextDiscriminator;
import org.siprop.core.message.ControlMessage;
import org.siprop.core.ua.UA;
import org.siprop.core.ua.UAManager;
import org.siprop.core.ua.UASet;
import org.siprop.core.ua.util.UAManagerList;
import org.siprop.message.impl.DefaultContextDiscriminator;
import org.siprop.message.impl.MessageContext;

/**
 * デフォルトのSIPUASetの実装クラス<BR>
 * このクラスが、各UAManagerの動きを監視し、絞り込みを行う。
 * @author noritsuna
 *
 */
public class DefaultSIPUASetImpl implements UASet {
	
	/**
	 * Repository
	 */
	private Repository defaultRepository;
	/**
	 * Provider
	 */
	private Provider provider;
	/**
	 * コールバック先のUA
	 */
	private UA callbackUA;

	/**
	 * Key生成用
	 */
	private ContextDiscriminator descriminator = new DefaultContextDiscriminator();
	
	/**
	 * UAManagerのリスト
	 */
	private Map uaManagerList = Collections.synchronizedMap(new HashMap());
	
	
	
	/**
	 * コンストラクタ
	 * @param provider
	 * @param callbackUA コールバック先のUA
	 */
	public DefaultSIPUASetImpl(Provider provider, UA callbackUA) {
		this.provider = provider;
		this.callbackUA = callbackUA;
		List repoList = provider.getRepositories();
		
		for(Iterator iter = repoList.iterator(); iter.hasNext();) {
			Repository repo = (Repository)iter.next();
			if(repo instanceof UARepositoryImpl) {
				this.defaultRepository = repo;
				break;
			}
		}
	}
	/**
	 * 実行する。スタートポイント。
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext) {
		System.out.println("DefaultSIPUASetImpl.doProcessMessage() called : " + messageContext);
		
		UAManagerList managerList = 
			(UAManagerList)uaManagerList.get(descriminator.generateKey(messageContext));
		if(managerList == null) {
			System.out.println("create new SIPUAManager descriminator.generateKey(message) : "
					+ descriminator.generateKey(messageContext));
			
			this.createUAManagers(managerList, messageContext);
			
		}
		managerList.doProcessMessage(messageContext);
	}
	/**
	 * UAManagerを必要分、作成する。
	 * @param managerList
	 * @param messageContext
	 */
	private void createUAManagers(UAManagerList managerList, MessageContext messageContext) {
		//Repositoryから取得した作るべき、UA分だけ繰り返す。
		UAManager manager = new DefaultSIPUAManagerImpl(provider, this);
		managerList.addUAManager(messageContext, manager);
	}

	/**
	 * コールバック先のUAをセットする。
	 * @param callbackUA
	 */
	public void setCallbackUA(UA callbackUA) {
		this.callbackUA = callbackUA;
		
	}
	/**
	 * メッセージを送信する。
	 * @param messageContext
	 */
	public void send(MessageContext messageContext) {
		this.doControlCommand(messageContext);
		this.callbackUA.send(messageContext);
	}
	
	
	/**
	 * Command処理を行う。
	 * @param messageContext
	 */
	public void doControlCommand(MessageContext messageContext) {
		ControlMessage ctrlMsg = messageContext.getControlMessage();
		//絞り込みの削除。
		if(ctrlMsg.get(ControlMessage.DELETE)) {
			this.removeRoute(messageContext);
		}
	}
	
	/**
	 * UAManagerを削除する。
	 * @param messageContext
	 */
	public void removeRoute(MessageContext messageContext) {
		this.uaManagerList.remove(descriminator.generateKey(messageContext));
	}
	/**
	 * UAManagerを追加する。
	 * @param key
	 * @param UAManager
	 */
	public void addRoute(MessageContext messageContext, UAManager uaManager) {
		this.uaManagerList.put(descriminator.generateKey(messageContext), this);
	}

	/**
	 * UAの種類を特定する識別子を取得する。
	 * @return key 識別子
	 */
	public String getUAType() {
		
		return this.getClass().getName();
		
	}

}
