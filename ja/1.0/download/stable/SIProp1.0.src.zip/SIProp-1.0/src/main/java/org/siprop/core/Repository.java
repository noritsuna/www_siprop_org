/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core;

import org.siprop.core.util.RouteType;

/**
 * リポジトリを示すインタフェース
 * @author noritsuna
 *
 */
public interface Repository {

	/**
	 * Repositoryを作成する。
	 * @param prop
	 */
	public void create(Provider provider);
	/**
	 * Routerを取得する。
	 * @return
	 */
	public Router getRouter(RouteType routeType);
	/**
	 * Routerをセットする。
	 * @param routeType
	 * @param router
	 */
	public void setRouter(RouteType routeType, Router router);

}
