/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Vector;

import org.siprop.core.transport.Peer;
import org.siprop.core.transport.ServerTransportListener;
import org.siprop.core.transport.Transport;
import org.siprop.transport.util.PeerImpl;

/**
 * TCPServer用のTransportクラス
 * @author sakukawa
 *
 */
public class TCPServerTransport implements Runnable
{
	private ServerTransportListener l;
	private int port;
	private Vector thrList;
	private ServerSocket ss;
	private boolean isRunning;
	private Object obj;
	
	/**
	 * コンストラクタ
	 * @param port
	 * @param l
	 * @param obj
	 */
	public TCPServerTransport(int port, ServerTransportListener l, Object obj)
	{
		this.l = l;
		this.port = port;
		this.thrList = new Vector();
		this.ss = null;
		this.isRunning = true;
		this.obj = obj;
	}

	/**
	 * Threadを開始する。
	 *
	 */
	public void start()
	{
		// 1スレッドで待ちうけを行う
		// このスレッドは、接続を管理するためのスレッドで、
		// データの送受信は別のスレッドで行う。
		// そのためスレッド数は1で固定としている
		start(1);
	}
	/**
	 * Threadを開始する。
	 * @param n スレッド数
	 */
	public void start(int n)
	{
		for (int i = 0; i < n; i++) {
			Thread thr = new Thread(this);
			thr.start();
			thrList.addElement(thr);
		}
	}

	/**
	 * Threadのrun
	 */
	public void run()
	{
		try {
//			final String url = "socket://:" + port;
			ss = new ServerSocket(port, 5);
			while(isRunning) {
				synchronized(ss) {
					Socket s = ss.accept();
					
					// あとで、TransportFactoryを作って切り分け可能なようにする
//					l.onAccept(new TCPTransport(s, null, port));
					Transport t = new SIPTCPTransport(s, null, port);
					TransportManager tm = TransportManager.getInstance();

					Peer src = new PeerImpl(Transport.PROTO_TCP, s.getInetAddress(), s.getPort());
					Peer dest = new PeerImpl(Transport.PROTO_TCP, s.getLocalAddress(), s.getLocalPort());
					
					tm.addListenedTransport(dest, t);
					tm.addSendTransport(src, t);

					l.onAccept(t, obj);
				}
			}
			thrList.removeElement(Thread.currentThread());
		} catch(IOException ex) {		
			ex.printStackTrace();
		}
	}
	/**
	 * Threadを停止する。
	 *
	 */
	public void stop()
	{
		this.isRunning = false;
		try {
			Thread.sleep(500);
		} catch(InterruptedException ex) {}

		Enumeration e = thrList.elements();
		while(e.hasMoreElements()) {
			Thread thr = (Thread)e.nextElement();
			thr.interrupt();
		}
	}
	/**
	 * ThreadにJoinする。
	 *
	 */
	public void join()
	{
		Enumeration e = thrList.elements();
		while(e.hasMoreElements()) {
			try {
				Thread thr = (Thread)e.nextElement();
				thr.join();
			} catch(InterruptedException ex) {}
		}
	}
}
