/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.stack.rtp;

import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;

/**
 * RTPを専用に処理するためのインタフェース
 * @author masaxmasa
 *
 */
public interface RTPtransport {
		public static final int SOCKET_TIMEOUT = 1;
		public static final int RTP_RCV_LEN = 1500;
	
		/**
		 * トランスポートを作成する。
		 * @return
		 */
		public int create();
		/**
		 * トランスポートを作成する。
		 * @param port ポート番号
		 * @return
		 */
		public int create(int port);
		/**
		 * トランスポートを作成する。
		 * @param localAddress IPアドレス
		 * @param localPort ポート番号
		 * @return
		 */
		public int create(InetAddress localAddress, int localPort);
		/**
		 * コネクションを張る。
		 * @param remoteAddress IPアドレス
		 * @param remotePort ポート番号
		 */
		public void connect(InetAddress remoteAddress, int remotePort);
		/**
		 * コネクションをクローズする。
		 *
		 */
		public void close();
		
		/**
		 * データを送信する。
		 * @param data
		 * @return
		 * @throws IOException
		 */
		public int send(byte[] data) throws IOException;
		/**
		 * データを受信する。
		 * @return
		 * @throws SocketException
		 * @throws IOException
		 */
		public byte[] receive() throws SocketException,IOException;
		
		/**
		 * ローカルの受信ポートを取得する。
		 * @return
		 */
		public int getLocalPort();
		/**
		 * リモートの接続先ポートを取得する。
		 * @return
		 */
		public int getRemotePort();
		/**
		 * ローカルのIPアドレスを取得する。
		 * @return
		 */
		public InetAddress getLocalAddress();
		/**
		 * リモートのIPアドレスを取得する。
		 * @return
		 */
		public InetAddress getRemoteAddress();
}
