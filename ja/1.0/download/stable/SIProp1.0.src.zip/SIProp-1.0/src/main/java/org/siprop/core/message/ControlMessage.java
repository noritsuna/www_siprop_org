/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.message;

import java.util.BitSet;

import org.siprop.message.impl.UAControlMessage;

/**
 * FlatSIPMessageと共に使用して、Stackやモジュール間の制御を行うためのメッセージ<BR>
 * 相当実装に失敗したので、あとで、作り直し予定。
 * 
 * @author noritsuna
 *
 */
public abstract class ControlMessage extends BitSet {

	// Routing
	static public int NO_ROUTE = 0;
	static public int TO_UPPER = 1;
	static public int TO_LOWER = 2;
	static public int TO_CURRENT = 3;
	

	// Action
	static public int NO_ACTION = 4;
	static public int NO_SEND = 5;
	static public int DELETE = 6;
	
	// 
	private int action = ControlMessage.NO_ACTION;
	
	
	/**
	 * 動作モードを取得する。
	 * 
	 * @return
	 */
	public int getActionMode() {
		return action;
	}
	/**
	 * 動作モードをセットする。
	 * 
	 * @param action 動作モード
	 */
	public void setActionMode(int action) {
		this.action = action;
		this.set(action);
	}

	/**
	 * Routingモードを取得する。
	 * 
	 * @return Routingモード
	 */
	public int getRouteMode() {
		if(this.get(UAControlMessage.TO_UPPER)) {
			return ControlMessage.TO_UPPER;
		} else if(this.get(UAControlMessage.TO_LOWER)) {
			return ControlMessage.TO_LOWER;
		} else if(this.get(UAControlMessage.TO_CURRENT)) {
			return ControlMessage.TO_CURRENT;
		} else {
			return ControlMessage.NO_ROUTE;
		}
	}
	/**
	 * Routingモードをセットする。
	 * 
	 * @param route Routingモード
	 */
	public void setRouteMode(int route) {
		if(route == UAControlMessage.TO_UPPER) {
			this.clear(ControlMessage.TO_LOWER);
			this.clear(ControlMessage.TO_CURRENT);
			this.set(ControlMessage.TO_UPPER);
		} else if(route == UAControlMessage.TO_LOWER) {
			this.clear(ControlMessage.TO_UPPER);
			this.clear(ControlMessage.TO_CURRENT);
			this.set(ControlMessage.TO_LOWER);
		} else if(route == UAControlMessage.TO_CURRENT) {
			this.clear(ControlMessage.TO_UPPER);
			this.clear(ControlMessage.TO_LOWER);
			this.set(ControlMessage.TO_CURRENT);
		}
	}
}
