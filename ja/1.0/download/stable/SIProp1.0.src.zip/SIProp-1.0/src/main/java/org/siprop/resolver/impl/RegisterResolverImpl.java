/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.resolver.impl;

import gov.nist.javax.sip.address.AddressImpl;
import gov.nist.javax.sip.header.Contact;
import gov.nist.javax.sip.header.From;
import gov.nist.javax.sip.header.To;
import gov.nist.javax.sip.message.SIPRequest;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import org.siprop.SIPropException;
import org.siprop.core.Resolver;
import org.siprop.core.transport.Peer;
import org.siprop.core.util.PropertiesDepot;
import org.siprop.message.impl.MessageContext;
import org.siprop.transport.util.PeerImpl;
/**
 * REGISTERを識別キーとするResolverの実装クラス
 * EXPIRE時間は、チェックしていない。
 * Asteriskと組み合わせて使用することを想定している。
 * @author noritsuna
 *
 */
public class RegisterResolverImpl implements Resolver {
	
	
	private PropertiesDepot prop;
	/**
	 * 内向きのPeerのMap<BR>
	 * これに、REGISTERのFROMをキーとして、Contactを入れる
	 */
	private Map innerMap = new HashMap();
	/**
	 * 外向きのPeer<BR>
	 * ForAsterisk
	 */
	private Peer outerPeer = null;
	
	/**
	 * デフォルトのキー
	 */
	private String defaultKey;
	
	
	/**
	 * コンストラクタ
	 * @param obj
	 */
	public RegisterResolverImpl(Object obj) {
		this.prop = (PropertiesDepot)obj;
		
		try {
			outerPeer = new PeerImpl(Integer.parseInt(prop.getProperty("route.outer.protocol")),
										 InetAddress.getByName(prop.getProperty("route.outer.ip")),
										 Integer.parseInt(prop.getProperty("router.outer.port")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * REGISTERを解析して、Mapに追加する。
	 * @param message
	 */
	public void addREGISTER(MessageContext message) {
				
		SIPRequest register;
		try {
			register = this.getREGISTER(message);
		} catch (SIPropException e1) {
			return;
		}
		
		
		// keyを作成する
		String key = this.getKeyForREGISTER(register);
		
		// 最初の一つだけ
		Contact contactHeader = (Contact)register.getContactHeaders().getFirst();
		AddressImpl contactAddress = (AddressImpl)contactHeader.getAddress();
		
		// UDP決めうち。
		Peer contact;
		try {
			contact = new PeerImpl(2, InetAddress.getByName(contactAddress.getHost()), contactAddress.getPort());
		} catch (UnknownHostException e) {
			// ログを出す
			return;
		}
		
		// セットする。
		this.innerMap.put(key, contact);
		
	}
	
	public Peer resolve(MessageContext message) {
		if(message.getCurrentMessage() == null) {
			return null;
		}
		if(!(message.getCurrentMessage() instanceof SIPRequest)) {
			return null;
		}
		SIPRequest request = (SIPRequest)message.getCurrentMessage();
		Peer routePeer = (Peer)this.innerMap.get(getKeyForRoute(request));
		
		if(routePeer == null) {
			routePeer = outerPeer;
			this.addREGISTER(message);
		}		
		return routePeer;
	}
	
	
	
	private SIPRequest getREGISTER(MessageContext message) throws SIPropException {
		// 登録すべきメッセージかチェックする（REGISTERかどうか？）
		if(message.getCurrentMessage() == null) {
			throw new SIPropException();
		}
		if(!(message.getCurrentMessage() instanceof SIPRequest)) {
			throw new SIPropException();
		}
		SIPRequest register = (SIPRequest)message.getCurrentMessage();
		if(!register.getMethod().equals(SIPRequest.REGISTER)) {
			throw new SIPropException();
		}
		return register;
	}
	
	
	private String getKeyForREGISTER(SIPRequest register) {
		// keyを作成する
		From fromHeader = (From)register.getFrom();
		return fromHeader.getAddress().getURI().toString();
	}

	private String getKeyForRoute(SIPRequest pipRequest) {
		// keyを作成する
		To toHeader = (To)pipRequest.getTo();
		return toHeader.getAddress().getURI().toString();
	}
}
