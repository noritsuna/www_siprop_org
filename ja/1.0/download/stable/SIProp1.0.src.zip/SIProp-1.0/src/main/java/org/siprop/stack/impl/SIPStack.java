/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.impl;

import gov.nist.javax.sip.SipProviderImpl;
import gov.nist.javax.sip.SipStackImpl;
import gov.nist.javax.sip.header.Via;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;
import gov.nist.javax.sip.parser.StringMsgParser;
import gov.nist.javax.sip.stack.HopImpl;
import gov.nist.javax.sip.stack.SIPMessageStack;
import gov.nist.javax.sip.stack.SIPServerTransaction;
import gov.nist.javax.sip.stack.SIPTransaction;
import gov.nist.javax.sip.stack.ServerRequestInterface;
import gov.nist.javax.sip.stack.ServerResponseInterface;

import java.net.UnknownHostException;

import javax.sip.ClientTransaction;
import javax.sip.Dialog;
import javax.sip.RequestEvent;
import javax.sip.ResponseEvent;
import javax.sip.ServerTransaction;
import javax.sip.TimeoutEvent;
import javax.sip.TransactionAlreadyExistsException;
import javax.sip.TransactionUnavailableException;
import javax.sip.address.Hop;
import javax.sip.header.ToHeader;
import javax.sip.message.Request;
import javax.sip.message.Response;

import org.siprop.core.Router;
import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Transport;
import org.siprop.message.impl.MessageContext;

/**
 * Jain-SIPをラップするためのクラス<BR>
 * 新Stack時には全面書き換え予定。
 * 
 * @author sakukawa
 *
 */
public class SIPStack implements org.siprop.core.stack.Stack
{
	private StringMsgParser parser;
	private static SIPMessageStack stack = null;
	private static javax.sip.SipProvider mySipProvider = null;
	private static SipropSipListener sipListener;

	/**
	 * Jain-SIPの起動に必要なものを初期化する
	 */
	static {
		try {
			sipListener = new SipropSipListener();
			stack = new SipStackImpl(null);
			mySipProvider = ((SipStackImpl)stack).createSipProvider();
			mySipProvider.addSipListener(sipListener);
		} catch(Throwable ex) {
			ex.printStackTrace();
		}
	}
	
	/**
	 * コンストラクタ
	 *
	 */
	public SIPStack()
	{
		parser = new StringMsgParser();
	}
	
	/**
	 * Jain-SIP用メソッド
	 * @return
	 */
	public javax.sip.SipProvider getSipProvider()
	{
		return this.mySipProvider;
	}
	
	/**
	 * 外部よりディスパッチされるメソッド
	 * @param tp
	 * @param p
	 * @param upperRouter
	 */
	public void doDispatch(Transport tp, Packet p, Router upperRouter)
	{
		System.out.println("doDispatch()");

		sipListener.upperRouter = upperRouter;
		
		// first, parse packet.
		byte[] data = p.getData();
		try {
			
			javax.sip.message.Message msg = parser.parseSIPMessage(data);
			MessageContext mc = new MessageContext();
			msg.setUserObject(mc);
			mc.setCurrentMessage(msg);
			mc.setRecvTransport(tp);
			mc.setCurrentPacket(p);

			System.out.println();
			System.out.println();
			System.out.println("mc : " + mc);
			System.out.println("BBBBB : " + mc.getCurrentMessage());
			System.out.println("BBBBB : " + mc.getEventObject());
			System.out.println("BBBBB : " + mc.getOutboundPeer());
			System.out.println();
			System.out.println();
			
			doProcessMessage(mc);
		} catch(java.text.ParseException ex) {
			ex.printStackTrace();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * パケットを送信する
	 * @param mc
	 */
	public void send(MessageContext mc) throws Exception
	{
		System.out.println();
		System.out.println();
		System.out.println("mc : " + mc);
		System.out.println("SSSSS : " + mc.getCurrentMessage());
		System.out.println("SSSSS : " + mc.getCurrentTransaction());
		System.out.println("SSSSS : " + mc.getEventObject());
		System.out.println("SSSSS : " + mc.getOutboundPeer());
		System.out.println();
		System.out.println();

		
		
//		MessageContext incomingContext = mc.getPreviousMessageContext();
		MessageContext incomingContext = mc.getPreviousMessageContext();
		SipProviderImpl sp = (SipProviderImpl)this.getSipProvider();
		if (incomingContext == null) {
			System.out.println("incomingContext == null");
			// 新規リクエスト?
			if (mc.getCurrentMessage() instanceof SIPRequest) {
				ClientTransaction c = sp.getNewClientTransaction((SIPRequest)mc.getCurrentMessage());
				mc.setCurrentTransaction((SIPTransaction)c);
				c.sendRequest();
			} else {
				//1個前のMessageContextのServerTransactionを利用する
				ServerTransaction s = (ServerTransaction)((SipStackImpl)stack).findTransaction((gov.nist.javax.sip.message.SIPMessage)mc.getCurrentMessage(), true);
				System.out.println("ServerTransaction : " + s);
				s.sendResponse((Response)mc.getCurrentMessage());
			}
		} else {
			// レスポンス, ACK, re-INVITE, etc.
//			Object o = incomingContext.getEventObject().getSource();
//			System.out.println("o.class : " + o.getClass().getName());

			System.out.println();
			System.out.println();
			System.out.println("mc : " + incomingContext);
			System.out.println("_____ : " + incomingContext.getCurrentMessage());
			System.out.println("_____ : " + incomingContext.getCurrentTransaction());
			System.out.println("_____ : " + incomingContext.getEventObject());
			System.out.println("_____ : " + incomingContext.getOutboundPeer());
			System.out.println();
			System.out.println();
			
			
			gov.nist.javax.sip.message.SIPMessage msg = (gov.nist.javax.sip.message.SIPMessage)mc.getCurrentMessage();

			
//			SIPTransaction txn = ((SipStackImpl)stack).findTransaction((gov.nist.javax.sip.message.SIPMessage)mc.getCurrentMessage(), (msg instanceof Response));

			SIPTransaction txn = incomingContext.getCurrentTransaction();
			mc.setCurrentTransaction(txn);
			if (txn instanceof ServerTransaction) {
				
				System.out.println("server transaction");
				ServerTransaction serverTxn = (ServerTransaction)txn;
				if (msg instanceof Response) {
					// リクエストに対するレスポンス
					if (txn == null) {
						System.out.println("SIPStack.send() : server transaction not found.");
						return;
					}
					serverTxn.sendResponse((Response)msg);
				} else if (msg instanceof Request) {
					// リクエストに対するリクエスト(UASからのBYE,etc.)
					ClientTransaction c = sp.getNewClientTransaction((SIPRequest)mc.getCurrentMessage());
					serverTxn.getDialog().sendRequest(c);
//					mc.setCurrentTransaction((SIPTransaction)c);
//					c.sendRequest();
//					throw new Exception("send request as response? : " + msg);
				} else {
					throw new Exception("unknown message type : " + msg);
				}
			} else if (txn instanceof ClientTransaction) {

				System.out.println("client transaction");

				if (msg instanceof Request) {
					
					System.out.println("message is Request");
					// レスポンスに対するリクエスト(ACK, re-INVITE(?), etc.)
					gov.nist.javax.sip.message.SIPRequest req = (gov.nist.javax.sip.message.SIPRequest)msg;
					String method = req.getCSeq().getMethod();
					ClientTransaction clientTxn = (ClientTransaction)txn;
					Dialog dlg = txn.getDialog();
					if ("ACK".equalsIgnoreCase(method)) {
						if (dlg == null) throw new Exception("sending ack... but dialog is not exists.");
						dlg.sendAck((Request)mc.getCurrentMessage());
					} else if ("CANCEL".equalsIgnoreCase(method)) {
						ClientTransaction newTxn = sp.getNewClientTransaction(req);
						newTxn.sendRequest();
//						dlg.sendRequest(newTxn);
					} else {
						// ACK,CANCEL以外のRequest(re-INVITE, CANCEL?, MESSAGE?, etc.)
						ClientTransaction newTxn = sp.getNewClientTransaction(req);
						if (dlg != null) dlg.sendRequest(newTxn);
						else newTxn.sendRequest(); 
					}
				} else if (msg instanceof Response) {
					// レスポンスに対するレスポンス?
					
					System.out.println("message is Response");
					throw new Exception("send response as response? : " + msg);
				} else {
					throw new Exception("unknown message type : " + msg);
				}

			} else {
				System.out.println("transaction not found.");
			}
		}
	}
	
	/**
	 * メッセージのパースなどを行う
	 * @param mc
	 */
	public synchronized void doProcessMessage(MessageContext mc)
	{
//		System.out.println("className : " + msg.getClass().getName());
//		System.out.println("msg : " + msg);

		SipStackImpl si = ((SipStackImpl)stack);
		
		javax.sip.message.Message msg = mc.getCurrentMessage();


	    if (msg instanceof SIPRequest) {
	        SIPRequest sipRequest = (SIPRequest) msg;

	        System.out.println("doProcessMessage : " + sipRequest.getMethod());
	        
	        // SIPRequestから接続先情報を取得する。
	        int port;
	        String host;
	        {
	        	Via via = sipRequest.getTopmostVia();
	        if (via == null)
	            throw new RuntimeException("No via header in response!");
//	            throw new SipException("No via header in response!");
	        port = via.getPort();
	        String transport = via.getTransport();
	        //Bug report by Shanti Kadiyala
	        //check to see if Via has "received paramaeter". If so
	        //set the host to the via parameter. Else set it to the
	        //Via host.
	        host = via.getReceived();

	        if (host == null)
	            host = via.getHost();

	        //TODO Need to check for transport before setting port.
	        if (port == -1)
	            port = 5060;
	        Hop hop = new HopImpl(host + ":" + port + "/" + transport);
	        }	        
	        
	        
	        java.net.InetAddress hostAddress = null;
	        try {
	        	hostAddress = java.net.InetAddress.getByName(host);
	        } catch(UnknownHostException ex) {
	        	ex.printStackTrace();
	        }

	        SipropMessageChannel msgChannel = new SipropMessageChannel((SipStackImpl)stack, mySipProvider, mc.getRecvTransport(), mc.getCurrentPacket().getSourcePeer());

	        // This is a request - process it.
	        ServerRequestInterface sipServerRequest =
	        	stack.newSIPServerRequest(sipRequest, msgChannel);

	        System.out.println("sipServerRequest : " + sipServerRequest);

	        sipServerRequest.processRequest(sipRequest, msgChannel);

	        System.out.println("processRequest done");
		    
	    } else if (msg instanceof SIPResponse) {
	        SIPResponse sipResponse = (SIPResponse) msg;
            // Handle a SIP Reply message.

	        
	        System.out.println("MMMMMMMMMM : " + msg);
	        
	        
	        
	        
	        
	        SipropMessageChannel msgChannel = new SipropMessageChannel((SipStackImpl)stack, mySipProvider, mc.getRecvTransport(), mc.getCurrentPacket().getSourcePeer());
	        
	        ServerResponseInterface sipServerResponse = stack.newSIPServerResponse(sipResponse, msgChannel);
	        
	        if (sipServerResponse != null) {
                sipServerResponse.processResponse(sipResponse, msgChannel);
                // Normal processing of message.
            } else {
            	System.out.println("null sipServerResponse");
//                if (LogWriter.needsLogging) {
//                    this.stack.logWriter.logMessage(
//                    "null sipServerResponse!");
//                }
            }

	    } else {
	    	System.out.println("unknown class : " + msg.getClass().getName());
	    }
	
	}


    /**
     * A random generator we use to generate tags.
     */
    private static java.util.Random localTagGenerator = new java.util.Random();

    
    /**
     * Generate a tag for a FROM header or TO header. Just return a random 4
     * digit integer (should be enough to avoid any clashes!) Tags only need to
     * be unique within a call.
     *
     * @return a string that can be used as a tag parameter.
     *
     * synchronized: needed for access to 'rand', else risk to generate same tag
     * twice
     */
    public static synchronized String generateLocalTag()
    {
            return Integer.toHexString(localTagGenerator.nextInt());
    }


    /**
     * Jain-SIP用に必要となってしまったinnerクラス<BR>
     * メッセージの振り分けなどを行う
     * @author noritsuna
     *
     */
    public static class SipropSipListener implements javax.sip.SipListener
    {
    	private Router upperRouter;

    	public synchronized void processRequest(RequestEvent requestEvent)
        {
        	System.out.println("SipListener.processRequest()");

        	MessageContext mc = (MessageContext)requestEvent.getRequest().getUserObject();
        	
        	SipProviderImpl sp = (SipProviderImpl)requestEvent.getSource();
        	gov.nist.javax.sip.message.SIPRequest req = (gov.nist.javax.sip.message.SIPRequest)requestEvent.getRequest();
        	Object obj = requestEvent.getSource();
        	System.out.println("obj : " + obj);
        	System.out.println("obj(class) : " + obj.getClass().getName());

        	
        	String method = req.getMethod();

        	System.out.println("method : " + method);

    		// トランザクションが存在しなかった場合、生成する
    		SIPServerTransaction txn = (SIPServerTransaction)requestEvent.getServerTransaction();
    		if (txn == null) {
    			System.out.println("transaction is not found.");
    			try {
    				txn = (SIPServerTransaction)sp.getNewServerTransaction(req);
    			} catch (TransactionAlreadyExistsException ex) {
    				ex.printStackTrace();
    				return;
    			} catch (TransactionUnavailableException ex) {
    				ex.printStackTrace();
    				return;
    			}
    		}
			mc.setCurrentTransaction(txn);

    		System.out.println("txn : " + txn);
        	
        	if (method.equals(Request.INVITE)) {

        		// ここで時間をおくと、自動的に100 Trying が送出される
        		// 180 Ringing 送出すると、状態が遷移し、
        		// 100 Trying は送出されない
/*
        		try {
        			Thread.sleep(500);
        		} catch(InterruptedException ex) {}
*/
        		// ここでB2BUAに処理を移す
        		
    /*    		
        		// 180 Ringingを送出する
        		javax.sip.message.Response resp = req.createResponse(180);
        		try {
        			txn.sendResponse(resp);
        		} catch(Throwable ex) {
        			ex.printStackTrace();
        		}

        		resp = req.createResponse(200);
        		try {
        			((SIPResponse)resp).getTo().setTag("hogehogetag");
        		} catch(java.text.ParseException ex) {
        			ex.printStackTrace();
        		}

        		// 200 OK を送る
        		try {
        			//    		sp.createDialog(txn);
        			gov.nist.javax.sip.header.Contact c = new gov.nist.javax.sip.header.Contact();
        			javax.sip.address.Address a = new gov.nist.javax.sip.address.AddressImpl();
        			gov.nist.javax.sip.address.SipUri uri = new gov.nist.javax.sip.address.SipUri(); 
        			uri.setHost("192.168.11.195");
        			uri.setUser("sakukawa");
        			a.setURI(uri);
        			c.setAddress(a);
        			resp.addHeader(c);
        			txn.sendResponse(resp);
        		} catch(java.text.ParseException ex) {
        			ex.printStackTrace();
        		} catch(SipException ex) {
        			ex.printStackTrace();
        		}
        		
        		System.out.println("req : " + req);
        		System.out.println("txn : " + txn);
        		System.out.println("obj : " + obj.getClass().getName());
    */

        	} else if (method.equals(Request.ACK)) {
        		System.out.println("ACK received");
        	} else if (method.equals(Request.BYE)) {
        		System.out.println("BYE received");
        	} else if (method.equals(Request.REGISTER)) {
        		System.out.println("BYE received");

        		// 100 Tryingを送出する
        		javax.sip.message.Response resp = req.createResponse(100);
        		try {
        			sp.sendResponse(resp);
        		} catch(Throwable ex) {
        			ex.printStackTrace();
        		}

        	} else if (method.equals(Request.CANCEL)) {
        		System.out.println("cancel catched");

        		// send 200 OK.
                try {
                	Response ok = req.createResponse(Response.OK);
                    attachToTag(ok, txn.getDialog());
                    txn.sendResponse(ok);
                } catch(Throwable ex) {
                	ex.printStackTrace();
                }
        		
        		// send 487 OK.
                try {
                	Response ok = txn.getOriginalRequest().createResponse(Response.REQUEST_TERMINATED);
                	SIPServerTransaction __txn = (SIPServerTransaction)txn.getOriginalRequest().getTransaction();
//                	Response ok = protocolProvider.getMessageFactory().createResponse(
//                        Response.OK, req);

//                    attachToTag(ok, txn.getDialog());
//                    ok.setHeader(protocolProvider.getSipCommUserAgentHeader());

                	__txn.sendResponse(ok);

//                    logger.debug("sent an ok response to a CANCEL request:\n" + ok);
//                } catch (ParseException ex) {
//                	ex.printStackTrace();
                } catch (Exception ex) {
                	ex.printStackTrace();
                }
       		
        	}
    		mc.setEventObject(requestEvent);
    		this.upperRouter.doDispatch(mc);
        }
        
        public synchronized void processResponse(ResponseEvent responseEvent)
        {
        	System.out.println("SipListener.processResponse()");
        	System.out.println("event : " + responseEvent);

        	MessageContext mc = (MessageContext)responseEvent.getResponse().getUserObject();

        	SIPResponse resp = (SIPResponse)responseEvent.getResponse();
        	if (resp.getStatusLine().getStatusCode() == 100) return;
        	
        	// ここでB2BUAに処理を移す
    		mc.setCurrentTransaction((SIPTransaction)responseEvent.getClientTransaction());
    		mc.setEventObject(responseEvent);

    		System.out.println();
    		System.out.println();
    		System.out.println("mc : " + mc);
    		System.out.println("PPPPP : " + mc.getCurrentMessage());
    		System.out.println("PPPPP : " + mc.getCurrentTransaction());
    		System.out.println("PPPPP : " + mc.getEventObject());
    		System.out.println("PPPPP : " + mc.getOutboundPeer());
    		System.out.println();
    		System.out.println();
    		
    		
    		this.upperRouter.doDispatch(mc);
        	
    /*    	
        	if (resp.getStatusLine().getStatusCode() == 200) {
        		ClientTransaction txn = responseEvent.getClientTransaction();
        		System.out.println("txn  : " + txn);
        		try {
            		txn.getDialog().sendAck(txn.createAck());
        		} catch(SipException ex) {
        			ex.printStackTrace();
        		}
        	}
    */
        }
        
        public synchronized void processTimeout(TimeoutEvent timeoutEvent)
        {
        	System.out.println("SipListener.processTimeout()");
        	System.out.println("event : " + timeoutEvent);

        	MessageContext mc = null;
        	if (timeoutEvent.getClientTransaction() != null) {
        		mc = (MessageContext)timeoutEvent.getClientTransaction().getRequest().getUserObject();
        		mc.setCurrentTransaction((SIPTransaction)timeoutEvent.getClientTransaction());
        	} else if (timeoutEvent.getServerTransaction() != null) {
        		mc = (MessageContext)timeoutEvent.getServerTransaction().getRequest().getUserObject();
        		mc.setCurrentTransaction((SIPTransaction)timeoutEvent.getServerTransaction());
        	} else {
        		System.out.println("transaction is not exists!!!");
        		return;
        	}
        	
    		// ここでB2BUAに処理を移す
    		mc.setEventObject(timeoutEvent);
    		this.upperRouter.doDispatch(mc);

        }

        
        /**
         * Generates a ToTag and attaches it to the to header of <tt>response</tt>.
         *
         * @param response the response that is to get the ToTag.
         * @param containingDialog the Dialog instance that is to extract a unique
         * Tag value (containingDialog.hashCode())
         */
        public void attachToTag(Response response, Dialog containingDialog)
        {
            ToHeader to = (ToHeader) response.getHeader(ToHeader.NAME);
            if (to == null) {
//                logger.debug("Strange ... no to tag in response:" + response);
                return;
            }

            if(containingDialog.getLocalTag() != null) {
//                logger.debug("We seem to already have a tag in this dialog. "
//                             +"Returning");
                return;
            }

            try {
                if (to.getTag() == null || to.getTag().trim().length() == 0) {

                    String toTag = generateLocalTag();

//                    logger.debug("generated to tag: " + toTag);
//                    to.setTag(toTag);
                }
//            } catch (ParseException ex) {
//                //a parse exception here mean an internal error so we can only log
////                logger.error("Failed to attach a to tag to an outgoing response."
////                             , ex);
            } finally {
            }
        }

        
    }
    

}




