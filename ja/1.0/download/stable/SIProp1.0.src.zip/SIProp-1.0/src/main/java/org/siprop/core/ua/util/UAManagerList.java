/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.siprop.core.message.ContextDiscriminator;
import org.siprop.core.ua.UAManager;
import org.siprop.message.impl.MessageContext;
import org.siprop.message.impl.UASetContextDiscriminataor;

/**
 * 同一ダイアログ上で動作するUAManagerを保持するためのクラス<BR>
 * 篩い分けモード時に使用する。UASet内で使用されることを想定している。
 * @author noritsuna
 *
 */
public class UAManagerList {
	/**
	 * UAのリスト
	 */
	protected List uaList = Collections.synchronizedList(new ArrayList());
	
	/**
	 * UAのMap
	 */
	protected Map uaMap = Collections.synchronizedMap(new HashMap());
	
	/**
	 * Key生成用
	 */
	private ContextDiscriminator descriminator = new UASetContextDiscriminataor();

	
	/**
	 * コンストラクタ
	 *
	 */
	public UAManagerList() {
	}
	

	/**
	 * UAManagerを追加する。
	 * @param ua
	 */
	public void addUAManager(MessageContext messageContext, UAManager uaManager) {
		this.uaList.add(uaManager);
		this.uaMap.put(descriminator.generateKey(messageContext), uaManager);
	}
	/**
	 * UAManagerを削除する。
	 * @param messageContext
	 */
	public void removeUAManager(MessageContext messageContext, UAManager uaManager) {
		this.uaList.remove(uaManager);
		this.uaMap.remove(descriminator.generateKey(messageContext));
	}


	/**
	 * メッセージの処理を開始する。
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext) {
		for(Iterator itor = this.uaList.iterator(); itor.hasNext();) {
			UAManager uaManager = (UAManager)itor.next();
			uaManager.doProcessMessage(messageContext);
		}
	}

}
