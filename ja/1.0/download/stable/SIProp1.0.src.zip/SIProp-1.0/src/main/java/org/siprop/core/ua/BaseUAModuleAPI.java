/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua;

import org.siprop.message.impl.MessageContext;


/**
 * UA用のAPIを定義した抽象化クラス
 * @author noritsuna
 *
 */
public abstract class BaseUAModuleAPI implements UA {


	/**
	 * CALL系イベント
	 */
	public abstract void onNewSession(MessageContext msgSet);
	public abstract void onFailure(MessageContext msgSet);
	public abstract void onEarlyMedia(MessageContext msgSet);
	public abstract void onProvisional(MessageContext msgSet);
	public abstract void onConnected(MessageContext msgSet);
	public abstract void onConnectedConfirmed(MessageContext msgSet);
	public abstract void onStaleCallTimeout(MessageContext msgSet);
	public abstract void terminate(MessageContext msgSet);
	public abstract void onTerminated(MessageContext msgSet);


	/**
	 * FORK系イベント
	 * @param msgSet
	 */
	public abstract void onForkDestroyed(MessageContext msgSet);
	public abstract void onRedirected(MessageContext msgSet);

	
	public abstract void onAckNotReceived(MessageContext msgSet);
	public abstract void onIllegalNegotiation(MessageContext msgSet);
	public abstract void onSessionExpired(MessageContext msgSet);

	
	
	/**
	 * SDP系イベント
	 * @param msgSet
	 */
	public abstract void onReadyToSend(MessageContext msgSet);
	public abstract void onAnswer(MessageContext msgSet);
	public abstract void onOffer(MessageContext msgSet);
	public abstract void onRemoteSdpChanged(MessageContext msgSet);
	public abstract void onOfferRequestRejected(MessageContext msgSet);
	public abstract void onOfferRequired(MessageContext msgSet);
	public abstract void onOfferRejected(MessageContext msgSet);


	/**
	 * INFO系イベント
	 * @param msgSet
	 */
	public abstract void onInfo(MessageContext msgSet);
	public abstract void onInfoSuccess(MessageContext msgSet);
	public abstract void onInfoFailure(MessageContext msgSet);

	
	/**
	 * REFER系イベント
	 * @param msgSet
	 */
	public abstract void onRefer(MessageContext msgSet);
	public abstract void onReferNoSub(MessageContext msgSet);
	public abstract void onReferRejected(MessageContext msgSet);
	public abstract void onReferAccepted(MessageContext msgSet);

	

}
