/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;
import org.siprop.transport.util.J2MEPPPacketImpl;
import org.siprop.transport.util.PeerImpl;

/**
 * TCP用のTransport
 * @author sakukawa
 *
 */
public class TCPTransport extends Transport
{
	protected Socket s = null;
	protected OutputStream out = null;
	protected InputStream in = null;

	/**
	 * コンストラクタ
	 * @param s
	 * @param host
	 * @param port
	 * @throws IOException
	 */
	public TCPTransport(Socket s, String host, int port) throws IOException
	{
		this.s = s;
		this.out = s.getOutputStream();
		this.in = s.getInputStream();
	}
	/**
	 * コンストラクタ
	 * @param host
	 * @param port
	 * @throws IOException
	 */
	public TCPTransport(String host, int port) throws IOException
	{
		this.s = new Socket(host, port);
		this.out = s.getOutputStream();
		this.in = s.getInputStream();
	}
	/**
	 * プロトコル名を取得する。
	 * @return
	 */
	public String getProtocolName()
	{
		return "TCP";
	}
	/**
	 * プロトコル番号を取得する。
	 * @return
	 */
	public int getProtocol()
	{
		return PROTO_TCP;
	}
	/**
	 * ローカルのIPアドレスを取得する。
	 * @return
	 */
	public String getLocalAddress()
	{
		InetAddress i = s.getLocalAddress();
		return i.getHostName();
	}
	/**
	 * ローカルのポート番号を取得する。
	 * @return
	 */
	public int getLocalPort()
	{
		return s.getLocalPort();
	}
	/**
	 * リモートのIPアドレスを取得する。
	 * @return
	 */
	public String getRemoteAddress()
	{
		InetAddress i = s.getInetAddress();
		return i.getHostName();
	}
	/**
	 * リモートのポート番号を取得する。
	 * @return
	 */
	public int getRemotePort()
	{
		return s.getPort();
	}
	/**
	 * ローカルのPeerを取得する。
	 * @return
	 */
	public Peer getLocalPeer()
	{
		return new PeerImpl(this.getProtocol(), s.getLocalAddress(), s.getLocalPort());
	}
	/**
	 * リモートのPeerを取得する。
	 * @return
	 */
	public Peer getRemotePeer()
	{
		return new PeerImpl(this.getProtocol(), s.getInetAddress(), s.getPort());
	}

	
	
	
	/**
	 * Socketオプションを取得する。
	 * @param option
	 * @return
	 * @throws IOException
	 */
	public int getSocketOption(byte option) throws IOException
	{
		return -1;
	}
	/**
	 * Socketオプションをセットする。
	 * @param option
	 * @param value
	 * @throws IOException
	 */
	public void setSocketOption(byte option, int value) throws IOException
	{
	}
	/**
	 * クローズする。
	 *
	 */
	public void close()
	{
		try { if (out != null) out.close(); } catch(IOException ex) {}
		try { if (in != null) in.close(); } catch(IOException ex) {}
		try { if (s != null) s.close(); } catch(IOException ex) {}
	}
	/**
	 * 受信バッファサイズをセットする。
	 * @param n
	 */
	public void setRecvBufferSize(int n)
	{
		super.setRecvBufferSize(n);
	}

	
	/**
	 * パケットを送信する。
	 * @param dest send to addr.
	 * @param b byte array to send.
	 * @param offset offset of byte array.
	 * @param length length of send data.
	 * @throws IOException
	 */
	public void send(String dest, byte[] b, int offset, int length) throws IOException
	{
		synchronized(out) {
			out.write(b, offset, length);
			out.flush();
		}
	}

	/**
	 * パケットを送信する。
	 * @param b byte array to send.
	 * @param offset offset of byte array.
	 * @param length length of send data.
	 * @throws IOException
	 */
	public void send(byte[] b, int offset, int length) throws IOException
	{
		synchronized(out) {
			out.write(b, offset, length);
			out.flush();
		}
	}

	/**
	 * Transportから、パケットを受信し、Packetクラスに変更する。
	 * @param
	 */
	public synchronized Packet receive() throws IOException
	{
		synchronized(in) {
			byte[] recvBuf = new byte[getRecvBufferSize()];
			int n = in.read(recvBuf);
			if (n < 0) {
				System.out.println("disconnected...");
				close();
				return null;
			}
			Packet p = new J2MEPPPacketImpl(/*this,*/ recvBuf, 0, n);
			p.setSourcePeer(this.getRemotePeer());
			p.setDestPeer(this.getLocalPeer());
			return p;
		}
	}
}
