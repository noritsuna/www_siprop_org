/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.resolver.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.siprop.core.Resolver;
import org.siprop.core.transport.Peer;
import org.siprop.core.util.PropertiesDepot;
import org.siprop.message.impl.MessageContext;
import org.siprop.transport.util.PeerImpl;

/**
 * ListenしているIPによる、Resolverクラス
 * @author noritsuna
 *
 */
public class ListenResolverImpl implements Resolver {
	
	/**
	 * Property
	 */
	private PropertiesDepot prop;
	
	/**
	 * ListenしているPeer
	 */
	private Peer listenPeer;
	
	/**
	 * コンストラクタ
	 * @param obj
	 */
	public ListenResolverImpl(Object obj) {
		this.prop = (PropertiesDepot)obj;
		
		try {
			listenPeer = new PeerImpl(Integer.parseInt(prop.getProperty("transport.listen.protocol")),
										 InetAddress.getByName(prop.getProperty("transport.listen.ip")),
										 Integer.parseInt(prop.getProperty("transport.listen.port")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Peerの解決を行う。
	 * @param message
	 * @return
	 */
	public Peer resolve(MessageContext message) {
		return listenPeer;
	}

}
