/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.b2bua.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import org.siprop.core.Provider;
import org.siprop.core.Repository;
import org.siprop.core.Resolver;
import org.siprop.core.b2bua.B2BUA;
import org.siprop.core.b2bua.B2BUAProvider;
import org.siprop.core.stack.StackRepository;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.TransportRepository;
import org.siprop.core.ua.UARepository;
import org.siprop.core.util.PropertiesDepot;
import org.siprop.core.util.RouteType;
import org.siprop.resolver.impl.ListenResolverImpl;
import org.siprop.resolver.impl.TransportResolverImpl;
import org.siprop.stack.impl.StackRepositoryImpl;
import org.siprop.transport.impl.TransportRepositoryImpl;
import org.siprop.transport.util.PeerImpl;
import org.siprop.ua.impl.UARepositoryImpl;
import org.siprop.util.impl.PropertiesDepotProp;

/**
 * B2BUAの初期化処理を行うクラスの実装
 * @author noritsuna
 *
 */
public class B2BUAProviderImpl implements B2BUAProvider {

	/**
	 * トランスポートリポジトリ
	 */
	TransportRepository transRepository;
	/**
	 * スタックリポジトリ
	 */
	StackRepository stackRepository;
	/**
	 * UAリポジトリ
	 */
	UARepository uaRepository;
	
	/**
	 * リポジトリのリスト
	 */
	List repositoryList = new ArrayList();
	
	/**
	 * リゾルバーのリスト
	 */
	List resolverList = new ArrayList();
	
	/**
	 * プロパティー
	 */
	PropertiesDepot prop;
	
	
	/**
	 * 待ち受けPeer
	 */
	Peer listenPeer;
	
	/**
	 * B2BUA
	 */
	B2BUA b2bua;
	
	public void setup() {
		this.setup("siprop.properties");
	}
	/**
	 * 各層を初期化し、B2BUAを起動する。
	 * @param filePath
	 */
	public void setup(String propPath) {
		// プロパティーを読み出す
		prop = this.createProperty(propPath);
		this.createResolver(this);

		// Routerなどへの登録は、また、それぞれの中で行う。
		this.createRepository(this);	
		
	}
	/**
	 * Resolverを作成する。
	 * 現在は、一つだけ作成している。
	 */
	public Resolver createResolver(Provider provider) {
		Resolver transportResolver = new TransportResolverImpl(prop);
		resolverList.add(transportResolver);
		
		Resolver listenResolver = new ListenResolverImpl(prop);
		resolverList.add(listenResolver);
		
		return transportResolver;
	}
	/**
	 * トランスポートを作成する。
	 */
	public Repository createTransports() {
		TransportRepository repo = new TransportRepositoryImpl();
		repo.create(this);
		return repo;
	}
	/**
	 * スタックを作成する。
	 */
	public Repository createStacks() {
		StackRepository repo = new StackRepositoryImpl();
		repo.create(this);
		return repo;
	}
	/**
	 * UAを作成する。
	 */
	public Repository createUAs() {
		UARepository repo = new UARepositoryImpl();
		repo.create(this);
		return repo;
	}

	/**
	 * コンフィグ情報から、PropertiesDepotを作成する。
	 */
	public PropertiesDepot createProperty(String filePath) {
		PropertiesDepot proppertiy = new PropertiesDepotProp();
		proppertiy.loadProperties(filePath);
		return proppertiy;
	}


	/**
	 * Provider情報から、Repositoryを作成する。
	 */
	public Repository createRepository(Provider provider) {
		// 各リポジトリに設定を登録する
		// 各層Routerに上位のRouterをセットする。
		this.b2bua = new B2BUAImpl();
		this.b2bua.setResolvers(resolverList);
		
		
		// Transport
		this.transRepository = (TransportRepository)createTransports();

		// Stack
		this.stackRepository = (StackRepository)createStacks();

		// UA
		this.uaRepository = (UARepository)createUAs();
		
		
		// 下位のRouterすべてにセットする。
		PeerImpl peer = null;
		try {
			peer = new PeerImpl(Integer.parseInt(prop.getProperty("transport.listen.protocol")),
										 InetAddress.getByName(prop.getProperty("transport.listen.ip")),
										 Integer.parseInt(prop.getProperty("transport.listen.port")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		listenPeer = (Peer)peer;
	
		this.transRepository.setRouter(RouteType.UPPER_LAYER, peer, stackRepository.getRouter(RouteType.CURRENT_LAYER));
		
		this.stackRepository.setRouter(RouteType.UPPER_LAYER, uaRepository.getRouter(RouteType.CURRENT_LAYER));
		this.uaRepository.setRouter(RouteType.UPPER_LAYER, b2bua);
		this.uaRepository.setRouter(RouteType.LOWER_LAYER, stackRepository.getRouter(RouteType.CURRENT_LAYER));
		this.b2bua.addRoute(uaRepository.getRouter(RouteType.CURRENT_LAYER));
		
		repositoryList.add(uaRepository);
		repositoryList.add(stackRepository);
		repositoryList.add(transRepository);
		
			
		return null;
	}
	/**
	 * Repositoryのリストを取得する。
	 */
	public List getRepositories() {
		return repositoryList;
	}
	/**
	 * Resolverのリストを取得する。
	 */
	public List getResolvers() {
		return resolverList;
	}
	/**
	 * Propertyを取得する。
	 */
	public PropertiesDepot getProperty() {
		return prop;
	}

}
