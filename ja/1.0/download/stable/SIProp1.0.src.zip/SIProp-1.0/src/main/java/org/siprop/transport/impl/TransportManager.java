/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;

import java.util.HashMap;
import java.util.Map;

import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;

/**
 * 存在する全Transportを管理するクラス
 * @author sakukawa
 *
 */
public class TransportManager
{
	private Map listenedTransportMap = null;
	private Map sendTransportMap = null;

	private static TransportManager tm = null;

	/**
	 * インスタンスを取得する。
	 * @return
	 */
	public static TransportManager getInstance()
	{
		if (tm == null) tm = new TransportManager();
		return tm;
	}

	/**
	 * コンストラクタ
	 *
	 */
	private TransportManager()
	{
		listenedTransportMap = new HashMap();
		sendTransportMap = new HashMap();
	}

	/**
	 * パケット送信先Peer情報から、送信用トランスポートを取得する。
	 * @param dest
	 * @return
	 */
	public Transport getSendTransport(Peer dest)
	{
		return (Transport)sendTransportMap.get(dest);
	}

	/**
	 * 現在listenしているトランスポートを取得する。
	 * @param p 
	 * @return
	 */
	public Transport getListenedTransport(Peer p) 
	{
		return (Transport)listenedTransportMap.get(p);
	}

	/**
	 * destへ送信するためのTransportを追加する。
	 * @param dest
	 */
	public void addSendTransport(Peer dest, Transport tp)
	{
		sendTransportMap.put(dest, tp);
	}

	/**
	 * 現在listenしているトランスポートを追加する。
	 * @param p
	 */
	public void addListenedTransport(Peer p, Transport tp)
	{
		listenedTransportMap.put(p, tp);
	}
}
