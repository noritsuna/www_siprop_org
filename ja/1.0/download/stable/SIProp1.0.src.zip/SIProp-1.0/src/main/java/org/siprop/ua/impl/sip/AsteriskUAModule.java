/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.ua.impl.sip;

import gov.nist.javax.sip.address.SipUri;
import gov.nist.javax.sip.header.Authorization;
import gov.nist.javax.sip.header.Contact;
import gov.nist.javax.sip.header.ProxyAuthenticate;
import gov.nist.javax.sip.header.ProxyAuthorization;
import gov.nist.javax.sip.header.WWWAuthenticate;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;

import javax.sip.header.Header;

import org.siprop.SIPropException;
import org.siprop.core.Provider;
import org.siprop.core.message.ControlMessage;
import org.siprop.core.ua.BaseSIPUAModule;
import org.siprop.core.ua.UA;
import org.siprop.core.util.NotImplementedException;
import org.siprop.message.impl.MessageContext;
import org.siprop.message.impl.UAControlMessage;
import org.siprop.ua.util.RTPPair;

/**
 * Asterisk用のUAModule
 * @author noritsuna
 *
 */
public class AsteriskUAModule extends BaseSIPUAModule {

	public AsteriskUAModule(Provider provider, UA callbackUA) {
		super(provider, callbackUA);
	}

	// リクエスト
    protected void processREGISTER(MessageContext messageContext) throws SIPropException {
		System.out.println("in processREGISTER.");
//    	if(this.state == BaseSIPUAModule.INIT) {
    		SIPRequest counterMessage = (SIPRequest)messageContext.getCounterSIPMessage();
    		
    		String requestUri = "sip:" + messageContext.getOutboundPeerStr();

    		
    		String listenPeerStr = messageContext.getListenPeerStr();

    		SipUri fromUri = (SipUri)counterMessage.getFrom().getAddress().getURI();
    		String fromName = fromUri.getUser();
    		StringBuffer contactHeader = new StringBuffer();
    		if(fromName == null) {
    			contactHeader.append("Contact: <sip:").append(messageContext.getListenPeerStr()).append(">\r\n");
    		} else {
    			contactHeader.append("Contact: <sip:").append(fromName).append("@").append(messageContext.getListenPeerStr()).append(">\r\n");
    		}
    		
    		StringBuffer fromHeader = new StringBuffer();
    		fromHeader.append(counterMessage.getFrom().toString());
    		
    		StringBuffer toHeader = new StringBuffer();
    		toHeader.append(counterMessage.getTo().toString());

    		
    		// 認証
    		StringBuffer authHeader = new StringBuffer();
    		if(counterMessage.getHeader("Proxy-Authorization") != null) {    			
    			if(this.userName != null && !this.userName.equals("")) {
    				org.siprop.util.impl.DigestAuthentication calAuth = new org.siprop.util.impl.DigestAuthentication();
    				ProxyAuthorization newAuth;
    				try {
    					newAuth = calAuth.getProxyAuthorization((ProxyAuthorization)counterMessage.getHeader("Proxy-Authorization"), userName, password, requestUri, "REGISTER");
    				} catch (ParseException e) {
    					throw new SIPropException(e);
    				}
    				authHeader.append(newAuth);
            		System.out.println("newAuth:" + newAuth.toString());
    			} else {
        			String auth = counterMessage.getHeader("Proxy-Authorization").toString();
        			authHeader.append(auth);
            		System.out.println("copyAuth:" + auth.toString());
    			}
    			
    		}
    		if(counterMessage.getHeader("Authorization") != null) {
    			if(this.userName != null && !this.userName.equals("")) {
    				org.siprop.util.impl.DigestAuthentication calAuth = new org.siprop.util.impl.DigestAuthentication();
    				Authorization newAuth;
    				try {
    					newAuth = calAuth.getAuthorization((Authorization)counterMessage.getHeader("Authorization"), userName, password, requestUri, "REGISTER");
    				} catch (ParseException e) {
    					throw new SIPropException(e);
    				}
    				authHeader.append(newAuth);
            		System.out.println("newAuth:" + newAuth.toString());
    			} else {
        			String auth = counterMessage.getHeader("Authorization").toString();
        			authHeader.append(auth);
            		System.out.println("copyAuth:" + auth.toString());
    			}
    		}
    		StringBuffer callIDHeader = new StringBuffer();
    		callIDHeader.append(this.generateCallID(messageContext));
    		
    		
    		StringBuffer branchID = new StringBuffer();
    		branchID.append(this.generateBranch(counterMessage));

    		
    		
    		SIPRequest sipRequest = this.flatSIPMessage.createNewREGISTERRequest(requestUri,
    				callIDHeader.toString(), 
    				fromHeader.toString(), 
    				toHeader.toString(), 
    				branchID.toString(), 
    				contactHeader.toString(), 
    				authHeader.toString(), 
    				listenPeerStr);
    		sipRequest.setUserObject(messageContext);
    		this.flatSIPMessage.setOrigRequest(sipRequest);
    		this.flatSIPMessage.setPrevRequest(sipRequest);
    		messageContext.setCurrentMessage(sipRequest);
    		
    		//System.out.println("create SIPRequest:" + sipRequest.toString());
    		
//   	}
	}


    protected void processINVITE(MessageContext messageContext) throws SIPropException {
		System.out.println("in processINVITE.");
    	if(this.state == BaseSIPUAModule.INIT) {
    		SIPRequest counterMessage = (SIPRequest)messageContext.getCounterSIPMessage();
    		
    		System.out.println("messageContext.getOutboundPeer():" + messageContext.getOutboundPeerStr());
    		System.out.println("messageContext.getListenPeerStr():" + messageContext.getListenPeerStr());
    		
    		
    		// 新規のSIPメッセージを作成する。
    		// 必要であれば、Authヘッダーを追加する。
    		SipUri sipUri = (SipUri)counterMessage.getRequestURI();
    		String name = sipUri.getUser();
    		if(name == null) {
    			try {
    				sipUri = (SipUri)counterMessage.getTo().getAddress().getURI();
    				name = sipUri.getUser();
    			} catch(ClassCastException e) {
    				;
    			}
    		}
    		String listenPeerStr = messageContext.getListenPeerStr();
    		String requestUri = null;
    		if(name == null) {
    			requestUri = "sip:" + messageContext.getOutboundPeerStr();
    		} else {
    			// もう少し、まともに混ぜるべき。
        		if(name.startsWith("184")) {
        			name = name.substring(3);
        		}
    			requestUri = "sip:" + name + "@" + messageContext.getOutboundPeerStr();
    		}
    		
    		SipUri fromUri = (SipUri)counterMessage.getFrom().getAddress().getURI();
    		String fromName = fromUri.getUser();
    		
    		SipUri toUri = (SipUri)counterMessage.getTo().getAddress().getURI();
    		String toName = toUri.getUser();
    		
    		StringBuffer contactHeader = new StringBuffer();
    		if(fromName == null) {
    			contactHeader.append("Contact: <sip:").append(messageContext.getListenPeerStr()).append(">\r\n");
    		} else {
    			contactHeader.append("Contact: <sip:").append(fromName).append("@").append(messageContext.getListenPeerStr()).append(">\r\n");        		

    		}
    		// 184チェック。内線184とかで、死にます。
    		System.out.println("in 184 mode check. toName:" + toName);
    		StringBuffer fromHeader = new StringBuffer();
    		if(toName != null && toName.startsWith("184")) {
        		System.out.println("in 184 mode.");
        		fromHeader.append("From: Anonymous <sip:anonymous@anonymous.invalid>;tag=").append(counterMessage.getFrom().getTag()).append("\r\n");
    			fromHeader.append("Privacy: id \r\n");
    			fromHeader.append("P-Preferrd-Identity: ").append(fromUri.toString()).append("\r\n");
    			toName = toName.substring(3);
    		} else {
        		fromHeader.append(counterMessage.getFrom().toString());
    		}
    		StringBuffer toHeader = new StringBuffer();
    		if(counterMessage.getTo().getTag() != null) {
    			toHeader.append(counterMessage.getTo().toString());
    		} else {
    			toHeader.append(counterMessage.getTo().toString());
    		}
    		
    		// 認証
    		StringBuffer authHeader = new StringBuffer();
    		if(counterMessage.getHeader("Proxy-Authorization") != null) {    			
    			if(this.userName != null && !this.userName.equals("")) {
    				org.siprop.util.impl.DigestAuthentication calAuth = new org.siprop.util.impl.DigestAuthentication();
    				ProxyAuthorization newAuth;
					try {
						newAuth = calAuth.getProxyAuthorization((ProxyAuthorization)counterMessage.getHeader("Proxy-Authorization"), userName, password, requestUri, "INVITE");
					} catch (ParseException e) {
						throw new SIPropException(e);
					}
					authHeader.append(newAuth);
            		System.out.println("newAuth:" + newAuth.toString());
    			} else {
        			String auth = counterMessage.getHeader("Proxy-Authorization").toString();
        			//auth = Pattern.compile("202.180.34.244",Pattern.CASE_INSENSITIVE).matcher(auth).replaceFirst("61.195.146.123");    			
        			//auth.replace("202.180.34.244","61.195.146.123");
        			authHeader.append(auth);
            		System.out.println("copyAuth:" + auth.toString());
    			}
    			
    		}
    		if(counterMessage.getHeader("Authorization") != null) {
    			if(this.userName != null && !this.userName.equals("")) {
    				org.siprop.util.impl.DigestAuthentication calAuth = new org.siprop.util.impl.DigestAuthentication();
    				Authorization newAuth;
					try {
						newAuth = calAuth.getAuthorization((Authorization)counterMessage.getHeader("Authorization"), userName, password, requestUri, "INVITE");
					} catch (ParseException e) {
						throw new SIPropException(e);
					}
					authHeader.append(newAuth);
            		System.out.println("newAuth:" + newAuth.toString());
    			} else {
	    			String auth = counterMessage.getHeader("Authorization").toString();
	    			//auth = Pattern.compile("202.180.34.244",Pattern.CASE_INSENSITIVE).matcher(auth).replaceFirst("61.195.146.123");    			
	    			//auth.replace("202.180.34.244","61.195.146.123");
	    			authHeader.append(auth);
            		System.out.println("copyAuth:" + auth.toString());
    			}
    		}
    		StringBuffer callIDHeader = new StringBuffer();
    		callIDHeader.append(this.generateCallID(messageContext));
    		
    		
    		StringBuffer branchID = new StringBuffer();
    		branchID.append(this.generateBranch(counterMessage));
    		

    		
    		// SDP処理
    		// System.out.println("counterMessage.getContent() is ClassType:" + counterMessage.getContent());
    		//byte[] sdpBodyBytes = (byte[])counterMessage.getContent();
    		String sdpBody;
			try {
				sdpBody = counterMessage.getMessageContent();
			} catch (UnsupportedEncodingException e) {
				throw new SIPropException(e);
			}
    		System.out.println("sdpBody:" + sdpBody);
    		StringBuffer sdpSB = new StringBuffer();
    		sdpSB.append("Content-Length: ").append(sdpBody.length()).append("\r\n\r\n");
    		sdpSB.append(sdpBody);
    		//	private SDPParser sdpParser = new AtteributeParser; 
    		// などとラインごとに作る必要がある模様。Factoryがあるので、それ経由で作成する。

    		SIPRequest sipRequest = this.flatSIPMessage.createNewINVITERequest(requestUri,
    				callIDHeader.toString(), 
    				fromHeader.toString(), 
    				toHeader.toString(), 
    				branchID.toString(), 
    				contactHeader.toString(), 
    				authHeader.toString(), 
    				listenPeerStr,
    				sdpSB.toString());
    		
    		sipRequest.setUserObject(messageContext);
    		
    		
    		
    		// 本来ならRe-INVITEチェックが必要。
    		this.flatSIPMessage.setOrigRequest(sipRequest);
    		this.flatSIPMessage.setPrevRequest(sipRequest);
    		
    		System.out.println("messageContext.getPreviousMessageContext();" + messageContext.getPreviousMessageContext());
    		messageContext.setPreviousMessageContext(null);
    		messageContext.setCurrentMessage(sipRequest);

    		// RouteSetの生成
    		this.flatSIPMessage.createRouteSet(this.flatSIPMessage.getOrigRequest());
    		
    		
    		// RTP用
    		if(this.rtpPair == null) {
    			this.rtpPair = new RTPPair();
    		}
    		this.rtpPair.setDstSDPMessage(sdpBody);

    		
			this.state = BaseSIPUAModule.TRYING;
    	}
    	    	
    }
    protected void processACK(MessageContext messageContext) throws SIPropException {
		System.out.println("in processACK.");
		
		SIPRequest sipRequest = this.flatSIPMessage.createACKRequest();
		sipRequest.setUserObject(messageContext);
		messageContext.setCurrentMessage(sipRequest);
		this.flatSIPMessage.setPrevRequest(sipRequest);

		if(this.state == BaseSIPUAModule.AUTH || this.state == BaseSIPUAModule.INIT) {
			this.state = BaseSIPUAModule.INIT;
		} else {
			this.state = BaseSIPUAModule.CALL;
		}
    }
    
	protected void processCANCEL(MessageContext messageContext) throws SIPropException {
		System.out.println("in processCANCEL.");
		// 新規のCANCELメッセージを作成する。
		SIPRequest sipRequest = this.flatSIPMessage.createCANCLERequest();
		sipRequest.setUserObject(messageContext);
		messageContext.setCurrentMessage(sipRequest);
		this.flatSIPMessage.setPrevRequest(sipRequest);
		
    	this.state = BaseSIPUAModule.CANCEL;
	}

	protected void processBYE(MessageContext messageContext) throws SIPropException {
		System.out.println("in processBYE.");
		System.out.println("Counter From:" + messageContext.getCounterSIPMessage().getHeader("From"));
		//System.out.println("Original From:" + this.origRequest.getFrom());
		// 新規のBYEメッセージを作成する。
		
		boolean isUAC = false;
		if(this.flatSIPMessage.getOrigRequest().getFrom().equals(messageContext.getCounterSIPMessage().getHeader("From"))) {
			isUAC = true;
		}
		
		SIPRequest sipRequest = this.flatSIPMessage.createBYERequest(isUAC, 
				messageContext.getListenPeer(),
				messageContext.getOutboundPeerStr(),
				this.generateBranch(this.flatSIPMessage.getPrevRequest()));
		sipRequest.setUserObject(messageContext);		
		this.flatSIPMessage.setPrevRequest(sipRequest);
		messageContext.setCurrentMessage(sipRequest);
		
    	this.state = BaseSIPUAModule.TERMINATED;
	}
    
	
	

	
	// レスポンス
	protected void process100ByINVITE(MessageContext messageContext) throws SIPropException {
		System.out.println("in process100Response.");		
		if(this.state > BaseSIPUAModule.TRYING) {
			System.out.println("resending packet.");
			return;
		}
		// 新規の100メッセージを作成する。		
		SIPResponse sipResponse = this.flatSIPMessage.create100Renponse();
		sipResponse.setUserObject(messageContext);
		this.flatSIPMessage.setPrevResponse(sipResponse);
		messageContext.setCurrentMessage(sipResponse);

    	this.state = BaseSIPUAModule.TRYING;
	}
	protected void process1xxByINVITE(MessageContext messageContext) throws SIPropException {
		ControlMessage controlMessage = messageContext.getControlMessage();
		if(controlMessage.get(UAControlMessage.RESPONSE_183)) {
			this.process183Response(messageContext);
		} else {
			this.process180Response(messageContext);
		}
	}
	protected void process180Response(MessageContext messageContext)  throws SIPropException {
		System.out.println("in process180Response.");
		SIPResponse counterMessage = (SIPResponse)messageContext.getCounterSIPMessage();
		// SDP処理
		String sdpBody;
		try {
			sdpBody = counterMessage.getMessageContent();
		} catch (UnsupportedEncodingException e) {
			throw new SIPropException(e);
		}
		if(sdpBody != null) {
    		// RTP用
    		if(this.rtpPair == null) {
    			this.rtpPair = new RTPPair();
    		}
    		this.rtpPair.setDstSDPMessage(sdpBody);
		}

		// 新規の180メッセージを作成する。
		SIPResponse res = (SIPResponse)messageContext.getCounterMessageContext().getCurrentMessage();

		
		SIPResponse sipResponse = this.flatSIPMessage.create1xxRenponse(res.getStatusCode(), res.getReasonPhrase(), sdpBody);
		sipResponse.setUserObject(messageContext);

		
		this.flatSIPMessage.setPrevResponse(sipResponse);
		messageContext.setCurrentMessage(sipResponse);

    	this.state = BaseSIPUAModule.RINGING;
	}
	protected void process183Response(MessageContext messageContext) throws SIPropException {
		System.out.println("in process183Response.");
		
		this.process180Response(messageContext);
		
    	this.state = BaseSIPUAModule.RINGING;
	}



	
    
	protected void process2xxByINVITE(MessageContext messageContext) throws SIPropException {
		// BYE,CANCELなどのメソッドを考慮する必要あり。
//		if(this.state >= BaseSIPUAModule.CONFORMED) {
//			System.out.println("resending message.");
//			message.setCurrentMessage(message.getPreviousMessageContext().getCurrentMessage());
//		}
		SIPResponse counterMessage = (SIPResponse)messageContext.getCounterSIPMessage();
		// SDP処理
		String sdpBody;
		try {
			sdpBody = counterMessage.getMessageContent();
		} catch (UnsupportedEncodingException e) {
			throw new SIPropException(e);
		}
		if(sdpBody != null) {
    		// RTP用
    		if(this.rtpPair == null) {
    			this.rtpPair = new RTPPair();
    		}
    		this.rtpPair.setDstSDPMessage(sdpBody);
		}

		// 新規の200メッセージを作成する。
		SIPResponse orig_resp = (SIPResponse)messageContext.getCounterMessageContext().getCurrentMessage();		
		SIPResponse newSipResponse = this.flatSIPMessage.create2xxRenponse(orig_resp.getStatusCode(), 
				orig_resp.getReasonPhrase(), 
				sdpBody,
				messageContext.getListenPeerStr(),
				orig_resp.getRecordRouteHeaders(),
				(Contact)orig_resp.getContactHeaders().getFirst());

		newSipResponse.setUserObject(messageContext);		
				
		this.flatSIPMessage.setPrevResponse(newSipResponse);
		messageContext.setCurrentMessage(newSipResponse);
				
		if( orig_resp.getCSeq().getMethod().equals(SIPRequest.CANCEL) ) {
	    	this.state = BaseSIPUAModule.CANCEL_CONFORMED;
		} else {
			this.state = BaseSIPUAModule.CONFORMED;
		}
	}
	protected void process2xxByREGISTER(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}
	protected void process2xxByCANCEL(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}
	protected void process2xxByBYE(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}
	
	

	protected void process4xxByINVITE(MessageContext messageContext) throws SIPropException {
		System.out.println("in process4xxResponse.");
		System.out.println("this:" + this);
		// 新規の400メッセージを作成する。
		SIPResponse res = (SIPResponse)messageContext.getCounterMessageContext().getCurrentMessage();
		System.out.println("get res." + res);
		System.out.println("get this.prevRequest." + this.flatSIPMessage.getPrevRequest());

		Header auth = null;
		if(res.getHeader("Proxy-Authenticate") != null) {
			ProxyAuthenticate authTemp = (ProxyAuthenticate)res.getHeader("Proxy-Authenticate");
			authTemp.setStale(false);
			auth = authTemp;
		}
		if(res.getHeader("WWW-Authenticate") != null) {
			auth = (WWWAuthenticate)res.getHeader("WWW-Authenticate");
		}
		SIPResponse sipResponse = this.flatSIPMessage.create4xxRenponse(res.getStatusCode(), res.getReasonPhrase(), auth);

		sipResponse.setUserObject(messageContext);
		this.flatSIPMessage.setPrevResponse(sipResponse);
		messageContext.setCurrentMessage(sipResponse);

		if(res.getStatusCode() == 407 || res.getStatusCode() == 401) {
//			this.state = BaseSIPUAModule.AUTH;
			this.state = BaseSIPUAModule.INIT;
    	} else {
			this.state = BaseSIPUAModule.ERROR;
    	}
	}
	protected void process4xxByREGISTER(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}

	protected void process3xxByINVITE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}	
	

	
	
	

	/**
	 * タイムアウトイベントを処理する。
	 * @param messaget
	 */
	protected void processTimeout(MessageContext messaget) {
    	System.out.println("SipListener.processTimeout()");
    	//System.out.println("event : " + timeoutEvent);
    }

	
	
	
    
	/**
	 * UAの種類を特定する識別子を取得する。
	 * @return key 識別子
	 */
	public String getUAType() {
		
		return this.getClass().getName();
		
	}
	public String getForkingKey() {
		return "1";
	}

	
	
	
	
	public void destroyModule() {
	}

	public void doState(MessageContext messageContext) {
	}

	

	//未実装のメソッド群
	protected void processINFO(MessageContext messageContext) throws SIPropException {
		throw new NotImplementedException();
	}

	protected void processUPDATE(MessageContext messageContext) throws SIPropException {
		throw new NotImplementedException();
	}

	protected void processREFER(MessageContext messageContext) throws SIPropException {
		throw new NotImplementedException();
	}

	protected void processNOTIFY(MessageContext messageContext) throws SIPropException {
		throw new NotImplementedException();
	}

	protected void processSUBSCRIBE(MessageContext messageContext) throws SIPropException {
		throw new NotImplementedException();
	}

	protected void processPUBLISH(MessageContext messageContext) throws SIPropException {
		throw new NotImplementedException();
	}

	

	// 100応答
	protected void process100ByCANCEL(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}
	protected void process100ByBYE(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}
	protected void process100ByREGISTER(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}
	protected void process100ByINFO(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}
	protected void process100ByUPDATE(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}
	protected void process100ByNOTIFY(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}
	protected void process100BySUBSCRIBE(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}
	protected void process100ByPUBLISH(MessageContext messageContext) throws SIPropException {
		this.process100ByINVITE(messageContext);		
	}

	// 1xx応答
	protected void process1xxByCANCEL(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}
	protected void process1xxByBYE(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}
	protected void process1xxByREGISTER(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}
	protected void process1xxByINFO(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}
	protected void process1xxByUPDATE(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}
	protected void process1xxByNOTIFY(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}
	protected void process1xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}
	protected void process1xxByPUBLISH(MessageContext messageContext) throws SIPropException {
		this.process1xxByINVITE(messageContext);
	}

	// 2xx応答
	protected void process2xxByINFO(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}
	protected void process2xxByUPDATE(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}
	protected void process2xxByNOTIFY(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}
	protected void process2xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}
	protected void process2xxByPUBLISH(MessageContext messageContext) throws SIPropException {
		this.process2xxByINVITE(messageContext);
	}

	// 3xx応答
	protected void process3xxByCANCEL(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}
	protected void process3xxByBYE(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}
	protected void process3xxByREGISTER(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}
	protected void process3xxByINFO(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}
	protected void process3xxByUPDATE(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}
	protected void process3xxByNOTIFY(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}
	protected void process3xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}
	protected void process3xxByPUBLISH(MessageContext messageContext) throws SIPropException {
		this.process3xxByINVITE(messageContext);
	}

	// 4xx応答
	protected void process4xxByCANCEL(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process4xxByBYE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process4xxByINFO(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process4xxByUPDATE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process4xxByNOTIFY(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process4xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process4xxByPUBLISH(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}


	// 5xx応答
	protected void process5xxByINVITE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxByCANCEL(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxByBYE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxByREGISTER(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxByINFO(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxByUPDATE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxByNOTIFY(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process5xxByPUBLISH(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}

	// 6xx応答
	protected void process6xxByINVITE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxByCANCEL(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxByBYE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxByREGISTER(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxByINFO(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxByUPDATE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxByNOTIFY(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}
	protected void process6xxByPUBLISH(MessageContext messageContext) throws SIPropException {
		this.process4xxByINVITE(messageContext);
	}

}
