/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.rtp.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

import org.siprop.message.impl.MessageContext;

/**
 * RTPUAを管理するためのクラス
 * @author masaxmasa
 *
 */
public class RTPManager implements Runnable {
	private Thread thread = null;
	private static RTPManager instance = null;
	private LinkedList rtpFwdList = null;		/* RTPForwader linked list */
	private Map rtpFwdMap = null;
	private boolean seen_term = false;
	
	/*
	 * コンストラクタ
	 */
	private RTPManager() {
		rtpFwdList = (LinkedList)Collections.synchronizedList(new LinkedList());
		rtpFwdMap = new HashMap();
		thread = new Thread(this);
	}
	
	/**
	 * インスタンスを取得する。
	 * @return
	 */
	public static RTPManager getInstance() {
		if (instance == null) {
			instance = new RTPManager();
		}
		return instance;
	}
	/**
	 * Threadのrunメソッド。
	 */
	public void run() {
		Iterator itr = null;
		RTPForwarder fwd = null;
		
		while (true) {
			if (seen_term == true) {
				break;
			}
			if (rtpFwdList.isEmpty()) {
				try {
					rtpFwdList.wait();
				} catch (InterruptedException e) {
					// e.printStackTrace();
					continue;
				}
			}
			
			for (itr = rtpFwdList.iterator(); itr.hasNext(); ) {
				fwd = (RTPForwarder)itr.next();
				fwd.select();
			}
		}
		
		// shutdown process
		for (itr = rtpFwdList.iterator(); itr.hasNext(); ) {
			fwd = (RTPForwarder)itr.next();
			fwd.destroy();
		}
		rtpFwdList.clear();
	}
	/**
	 * スレッドを開始する。
	 *
	 */
	public void start() {
		thread.start();
	}
	/**
	 * スレッドを停止する。
	 *
	 */
	public void stop() {
		seen_term = true;
		rtpFwdList.notifyAll();
	}
	/**
	 * RTPを作成する。
	 * @param msg
	 * @return
	 */
	public int createRTP(MessageContext msg) {
		/* need more identifier */

		if (msg.getOutboundPeer() == null) {
			return -1;
		}
		
		RTPForwarder forwarder = searchRTPForwarder(msg);
		if (forwarder == null) {
			/*
			 *  this is new entry, create new entry and register it.
			 */
			forwarder = new RTPForwarder(msg);
			
			/* add forwarder to LinedList and Map */
			addRTPForwarder(forwarder, msg);
		}
		else {
			/*
			 * forwarder is already exist. create new RTPUAModule
			 */
			forwarder.addRTPUA(msg);
			rtpFwdMap.put(forwarder, msg.getUniKey());
		}

		return 0;
	}
	/**
	 * RTPを削除する。
	 * @param msg
	 */
	public void deleteRTP(MessageContext msg) {
		/* need more identifier */
		
		RTPForwarder forwarder = searchRTPForwarder(msg);
		if (forwarder == null) {
			/* no such entry */
			return;
		}
		
		deleteRTPForwarder(forwarder);
		forwarder.destroy();
		return;
	}
	/**
	 * RTPの接続のつなぎ替えを行う。
	 * @return
	 */
	public int switchRTP() {
		/* need more identifier */
		return 0;
	}
	

	/**
	 * RTPForwarderを取得する。
	 * @param msg
	 * @return
	 */
	private RTPForwarder searchRTPForwarder(MessageContext msg) {
		RTPForwarder fwd = null;
		
		if (msg.getUniKey() == null) {
			return null;
		}
		
		fwd = (RTPForwarder)rtpFwdMap.get(msg.getUniKey());
		
		return fwd;
	}
	/**
	 * RTPForwarderを追加する。
	 * @param fwd
	 * @param msg
	 * @return
	 */
	private int addRTPForwarder(RTPForwarder fwd, MessageContext msg) {
		rtpFwdMap.put(fwd, msg.getUniKey());
		rtpFwdList.addLast(fwd);
		return 0;
	}
	/**
	 * RTPForwarderを削除する。
	 * @param fwd
	 */
	private void deleteRTPForwarder(RTPForwarder fwd) {
		rtpFwdMap.remove(fwd);
		rtpFwdList.remove(fwd);
		return;
	}
}