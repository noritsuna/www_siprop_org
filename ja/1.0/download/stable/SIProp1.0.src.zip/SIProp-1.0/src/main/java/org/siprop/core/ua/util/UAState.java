/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua.util;

/**
 * シーケンスなどのステートマシーン用抽象化クラス<BR>
 * まだ、明確な位置付けを決定していない。<BR>
 * <BR>
 * ステートというよりは、call(),forward()などを用意して、Factory Methodパターン的な使い方になりそう。<BR>
 * <BR>
 * UAContoroller用とUAModule用を共通化する必要がある。<BR>
 * 
 * @author noritsuna
 *
 */
public abstract class UAState {

		public static int NON_INIT = 0;
		
		
		protected int state;
		/**
		 * ステートを取得する。
		 * @return
		 */
		public int getState() {
			return state;
		}
}