/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.rtp.impl;

import java.io.IOException;
import java.net.SocketException;

import org.siprop.core.codec.Codec;
import org.siprop.core.stack.rtp.RTPtransport;
import org.siprop.message.impl.MessageContext;

/**
 * RTP用のUAモジュールクラス<BR>
 * 通常のUAモジュール内から、呼び出されることを想定している。<BR>
 * RTPに関するクラスは、速度の問題上、B2BUAやStackを介さない特別な経路で動作している。
 * @author noritsuna
 *
 */
public class RTPUAModule {
	public static final int TYPE_RTP = 0;
	public static final int TYPE_RTCP = 1;
	private Codec codec = null;
	private RTPtransport rtp = null;
	private RTPtransport rtcp = null;
	private String uniKey = null;
	private RTPForwarder parent = null;
	
	/**
	 * コンストラクタ
	 * @param msg
	 * @param fwd
	 */
	public RTPUAModule (MessageContext msg, RTPForwarder fwd) {
		parent = fwd;
		uniKey = msg.getUniKey();
		
		return;
	}
	/**
	 * クローズする。
	 *
	 */
	public void close() {
		if (rtp != null) {
			rtp.close();
			rtp = null;
		}
		
		if (rtcp != null) {
			rtcp.close();
			rtcp = null;
		}
		
		if (codec != null) {
			codec = null;
		}
		
		parent = null;
		return;
	}
	/**
	 * コーデックの種類を取得する。
	 * @return
	 */
	public String getCodecDesc () {
		return codec.getName();
	}
	/**
	 * 識別キーを取得する。
	 * @return
	 */
	public String getUniKey() {
		return uniKey;
	}
	
	/**
	 * 受信する。
	 * @param type
	 * @return
	 */
	public byte[] receive (int type) {
		RTPtransport transPtr = null;
		byte buffer[] = null;
		
		switch (type) {
		case RTPUAModule.TYPE_RTP:
			transPtr = rtp;
			break;
		case RTPUAModule.TYPE_RTCP:
			transPtr = rtcp;
			break;
		default:
			return null;
		}
		
		if (transPtr == null) {
			return null;
		}
		
		try {
			buffer = transPtr.receive();
			if (buffer.length == 0) {
				return null;
			}
			
			if (type == RTPUAModule.TYPE_RTP) {
				buffer = codec.decode(buffer);
			}
		}
		catch (SocketException se) {
			/* do nothing */
		}
		catch (IOException ie) {
			/* do nothing */
		}
		
		return buffer;
	}
	
	/**
	 * 送信する。
	 * @param buffer
	 * @param type
	 * @return
	 * @throws IOException
	 */
	public int send(byte[] buffer, int type) throws IOException {
		RTPtransport transPtr = null;
		
		if (buffer.length == 0) {
			return -1;
		}
		
		switch (type) {
		case RTPUAModule.TYPE_RTP:
			transPtr = rtp;
			buffer = codec.encode(buffer);
			break;
		case RTPUAModule.TYPE_RTCP:
			transPtr = rtcp;
			break;
		default:
			return -1;
		}
		
		return(transPtr.send(buffer));
	}
}