/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import org.siprop.core.transport.Packet;
import org.siprop.core.transport.PacketProcessor;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.ServerTransportListener;
import org.siprop.core.transport.Transport;
import org.siprop.transport.util.PeerImpl;

/**
 * パケットの処理内容を判定するクラス
 * パケットの処理内容は、
 * 
 *  - パケットが届いたTransportによる判定
 *  - 次の送り先(next hop)による判定
 *  
 *  2種類ある。
 *  
 * @author sakukawa
 *
 */
public class TransportRouter implements ServerTransportListener
{
	/**
	 * RoutingTable
	 */
	private Map routingTable;

	/**
	 * 上位層へのRouter
	 */
	private PacketProcessor upperRouter;
	/**
	 * 下位層へのRouter
	 */
	private PacketProcessor lowerRouter;
	private TransportSelector ts;
	
	/**
	 * インスタンス
	 */
	private static TransportRouter r = null;

	/**
	 * インスタンスを取得する。
	 * @return
	 */
	public static TransportRouter getInstance()
	{
		if (r == null) r = new TransportRouter();
		return r;
	}
	/**
	 * コンストラクタ
	 *
	 */
	private TransportRouter()
	{
		routingTable = new HashMap();
		ts = new TransportSelector(this);
//		sendRoutingTable = new HashMap();
//		lowerRouter = new OutbaundPacketProcessor();
	}
	/**
	 * 上位層へのRouterをセットする。
	 * @param upperRouter
	 */
	public void setUpperRouter(PacketProcessor upperRouter)
	{
		this.upperRouter = upperRouter;
	}
	/**
	 * 下位層へのRouterをセットする。
	 * @param lowerRouter
	 */
	public void setLowerRouter(PacketProcessor lowerRouter)
	{
		this.lowerRouter = lowerRouter;
	}
	/**
	 * Peerをキーとして、Routerを追加する。<BR>
	 * @param p
	 * @param pp
	 * @throws java.io.IOException
	 */
	public void addRoute(Peer p, PacketProcessor pp) throws java.io.IOException
	{
		if (!routingTable.containsKey(p)) {
			switch(p.getProtocol()) {
			case Transport.PROTO_TCP:
				TCPServerTransport tcps = new TCPServerTransport(p.getPort(), this, pp);
				tcps.start();
				break;
			case Transport.PROTO_UDP:
				UDPServerTransport udps = new UDPServerTransport(p.getPort(), this, pp);
				udps.start();
				break;
			default:
				throw new IllegalArgumentException("unknown peer : " + p);
			}
		}

	}
	/**
	 * Transportに対して、自分自身をRouterとして追加する。
	 * @param p
	 * @throws java.io.IOException
	 */
	public void addRoute(Transport p) throws java.io.IOException
	{
		this.onAccept(p, this.upperRouter);
	}
	/**
	 * TransportのPeerから、Routerを追加する。
	 * @param tp
	 * @param pp
	 */
	public void addRoute(Transport tp, PacketProcessor pp)
	{
		routingTable.put(tp.getLocalPeer(), pp);
	}

	/**
	 * Routerを削除する。
	 * @param tp
	 */
	public void removeRecvRoute(Transport tp)
	{
		routingTable.remove(tp.getLocalPeer());
	}

	/**
	 * 内向きのルーティングを行う
	 * @param direction
	 * @param tp
	 * @param p
	 */
	public void doRoute(Transport tp, Peer hop, Packet p)
	{
		PacketProcessor dest = (PacketProcessor)routingTable.get(tp);
		if (dest == null) {
			dest = upperRouter;
		}
		dest.doDispatch(tp, hop, p);
	}

	/**
	 * 外向きのルーティングを行う
	 * @param hop 送り先
	 * @param p パケット
	 */
	public void doRoute(Peer hop, Packet p)
	{
		PacketProcessor dest = (PacketProcessor)routingTable.get(hop);
		if (dest == null) {
			dest = lowerRouter;
		}

		TransportManager tm = TransportManager.getInstance();
		Transport tp = tm.getSendTransport(hop);
		
		if (tp == null && !hop.isConnectionOrientedProtocol()) {
			// listenされているポートを探し(defaultの送信用ポート)、それを送信用ポートとして使用する
			// さらに、sendTransportとして登録する
			// defaultの送信用ポート情報は、Stackから取得する必要あり。
			try {
				Peer listen = new PeerImpl(hop.getProtocol(), InetAddress.getByName("192.168.11.195"), 5060);
				tp = tm.getListenedTransport(listen);
				if (tp != null) tm.addSendTransport(hop, tp);
			} catch(UnknownHostException ex) {
				ex.printStackTrace();
			}
		}
		
		if (tp == null) {
			System.out.println("hop : " + hop);
			
			try {
				tp = new UDPTransport();
				tm.addSendTransport(hop, tp);
			} catch(java.io.IOException ex) {
				ex.printStackTrace();
				System.out.println("Transport create failed");
				System.out.println("protocol : " + Transport.PROTO_UDP);
				System.out.println("host : " + hop.getAddress());
				System.out.println("port : " + hop.getPort());
				return;
			}
		}
		dest.doDispatch(tp, hop, p);
	}
	
	/**
	 * コネクションが張られると呼び出されるメソッド。<BR>
	 * そのコネクションをRouterに追加する。
	 * @param p
	 * @param arg
	 */
	public void onAccept(Transport p, Object arg)
	{
		String str = "connected : " + p.getClass().getName();
		this.addRoute(p, (PacketProcessor)arg);
		ts.addTransport(p);
		
	}

}
