/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.rtp.impl;

import java.util.Iterator;
import java.util.LinkedList;
/**
 * RTPの接続先(SDPのオファーとアンサー)のセットを表すクラス
 * @author masaxmasa
 *
 */
public class RTPpairs {
	private static int len = 0;
	private LinkedList listPairs = null;
	
	/**
	 * コンストラクタ
	 *
	 */
	public RTPpairs () {
		listPairs = new LinkedList();
		return;
	}
	/**
	 * Pairの数を取得する。
	 * @return
	 */
	public int length () {
		return len;
	}
	/**
	 * 空かどうか？
	 * @return
	 */
	public boolean isEmpty () {
		if (len == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * Pairを追加する。
	 * @param ua0
	 * @param ua1
	 * @return
	 */
	public int addPair(RTPUAModule ua0, RTPUAModule ua1) {
		LinkedList newPair = new LinkedList();
		newPair.addLast(ua0);
		newPair.addLast(ua1);
		listPairs.addLast(newPair);
		len++;
		return(listPairs.indexOf(newPair));
	}
	/**
	 * Pairを追加する。
	 * @param index
	 * @param ua
	 * @return
	 */
	public int addPair(int index, RTPUAModule ua) {
		LinkedList pair = null;
		if ((pair = (LinkedList)listPairs.get(index)) == null) {
			return -1;
		}
		
		pair.addLast(ua);
		return 0;
	}
	
	/**
	 * Pairを削除する。
	 * @param index
	 */
	public void deletePair(int index) {
		LinkedList pair = null;
		if ((pair = (LinkedList)listPairs.get(index)) == null) {
			return;
		}
		
		listPairs.remove(pair);
		pair.clear();
		
		len--;
		return;
	}
	/**
	 * Pairを削除する。
	 * @param index
	 * @param ua
	 */
	public void deletePair(int index, RTPUAModule ua) {
		LinkedList pair = null;
		if ((pair = (LinkedList)listPairs.get(index)) == null) {
			return;
		}
		
		if (pair.contains(ua) == false) {
			return;
		}
		
		pair.remove(ua);
		
		if (pair.isEmpty()) {
			listPairs.remove(pair);
			len--;
		}
		return;
	}
	
	/**
	 * PairのIndexを取得する。
	 * @param ua
	 * @return
	 */
	public int searchPairIndex(RTPUAModule ua) {
		LinkedList pair = null;
		
		for (Iterator itr0 = listPairs.iterator(); itr0.hasNext();) {
			pair = (LinkedList)itr0.next();
			for (Iterator itr1 = pair.iterator(); itr1.hasNext();) {
				RTPUAModule ptr = (RTPUAModule)itr1.next();
				if (ua.equals(ptr)) {
					return(listPairs.indexOf(pair));
				}
			}
		}
		return(-1);
	}
	

	public Iterator iterator() {
		return listPairs.iterator();
	}
	
	public Iterator pair_iterator(int index) {
		LinkedList pair = (LinkedList)listPairs.get(index);
		return pair.iterator();
	}
}
