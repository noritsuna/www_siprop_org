/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.util.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.siprop.core.util.PropertiesDepot;

/**
 * Propertiesクラスを利用したPropertiesDepotの実装クラス
 * @author noritsuna
 *
 */
public class PropertiesDepotProp extends PropertiesDepot {
	
	
	/**
	 * Propertyファイル名
	 */
    private final static String DEFAULT_CONFIGFILE = "siprop.properties";
    
    /**
     * Property値
     */
    private static Properties DEFAULT_PROP = new Properties();   
  
	
    /**
     * プロパティーファイルの設定を読み出す
     * @param propertyPath
     */
	public void loadProperties(String propertyPath) {
        File configfile = new File(System.getProperty(propertyPath, DEFAULT_CONFIGFILE));

//        if (configfile.canRead()) {
            try {
            	// propertiesの読み出し
                DEFAULT_PROP.load(new FileInputStream(configfile));
            } catch(IOException e) {
//                LOG.warn("Not load config file: " + DEFAULT_CONFIGFILE, e);
            }
//        } else {
//            LOG.warn("Not read config file: " + DEFAULT_CONFIGFILE);
//        }
		
	}
    

    /**
     * Propertyを取得する
     * @param property Property名
     * @return Property値
     */
	public String getProperty(String property) {
    	return DEFAULT_PROP.getProperty(property, null);
	}

	/**
	 * propertyをセットする
	 * @param propertyName
	 * @param propertyValue
	 */
	public void setProperty(String propertyName, String propertyValue) {
		DEFAULT_PROP.setProperty(propertyName, propertyValue);		
	}
	
	/**
	 * Propertyをクリアする。
	 */
	public void storeProperties() {
		DEFAULT_PROP.clear();	
	}

	/**
	 * Propertyを新規に作成し直す。
	 * @param propertyPath
	 */
	public void processNewProperties(String propertyPath) {
		this.storeProperties();
		this.loadProperties(propertyPath);		
	}
	
}
