/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.impl;

import org.siprop.core.Provider;
import org.siprop.core.Router;
import org.siprop.core.stack.StackRepository;
import org.siprop.core.util.RouteType;

/**
 * Stack用のリポジトリクラスの実装<BR>
 * 現在は、Jain-SIPの構造に合わせて変更されている
 * @author noritsuna
 *
 */
public class StackRepositoryImpl implements StackRepository {

	/**
	 * 同じ層にあるRouter
	 */
	private SIPStackRouter currentRouter;
	/**
	 * 上位層へのRouter
	 */
	private Router upperRouter;
	/**
	 * 下位層へのRouter
	 */
	private Router lowerRouter;
	/**
	 * Provider
	 */
	private Provider provider;
	
	
	/**
	 * Repositoryを作成する。
	 * @param provider
	 */
	public void create(Provider provider) {
		// PropertiesDepotより、対象となるRouter用スクリプト, Manager, 本体を取得する
		// 構造にあわせて、Managerのインスタンス化などを行う
		// Routerへの登録などを行う。
		
		this.provider = provider;
		this.currentRouter =  new SIPStackRouter();	
		
	}
	/**
	 * Routerを取得する。
	 * @param routeType
	 * @return
	 */
	public Router getRouter(RouteType routeType) {
		
		if(RouteType.UPPER_LAYER.equals(routeType)) {
			return upperRouter;
		} else if(RouteType.LOWER_LAYER.equals(routeType)) {
			return lowerRouter;
		} else {
			return (Router)currentRouter;
		}
		
	}
	/**
	 * Routerをセットする。
	 * @param routeType
	 * @param router
	 */
	public void setRouter(RouteType routeType, Router router) {
		if(RouteType.UPPER_LAYER.equals(routeType)) {
			upperRouter = router;
		} else if(RouteType.LOWER_LAYER.equals(routeType)) {
			lowerRouter = router;
		} else {
			currentRouter = (SIPStackRouter)router;
		}		
		this.currentRouter.setRouter(routeType, router);
	}

}
