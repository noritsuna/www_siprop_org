/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua;

import org.siprop.message.impl.MessageContext;


/**
 * 制御モジュールを示すインタフェース<BR>
 * 純粋なUAとしての動作のみを記述する。
 * @author noritsuna
 *
 */
public interface UA {
	
	/**
	 * 外部より、ディスパッチされるメソッド
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext);

	/**
	 * コールバックされるUAをセットする。
	 * @param callbackUA
	 */
	public void setCallbackUA(UA callbackUA);
	/**
	 * 送信する。
	 * @param messageContext
	 */
	public void send(MessageContext messageContext);
	
	/**
	 * UAの種類を特定する識別子を取得する。
	 * @return
	 */
	public String getUAType();
	
	

}
