/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core;

import java.util.List;

import org.siprop.core.util.PropertiesDepot;

/**
 * 初期化処理を行うためのクラスを示すインタフェース
 * @author noritsuna
 *
 */
public interface Provider {
	
	/**
	 * セットアップをする。
	 *
	 */
	public void setup();
	/**
	 * コンフィグ情報から、PropertiesDepotを作成する。
	 */	
	public PropertiesDepot createProperty(String propatyPath);
	/**
	 * Repositoryを作成する。
	 */
	public Repository createRepository(Provider provider);

	/**
	 * Resolverを作成する。
	 */
	public Resolver createResolver(Provider provider);

	/**
	 * Repositoryを取得する。
	 */
	public List getRepositories();
	/**
	 * Resolverのリストを取得する。
	 */
	public List getResolvers();
	
	/**
	 * Propertyを取得する。
	 */
	public PropertiesDepot getProperty();
}
