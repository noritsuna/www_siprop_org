/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.util;

/**
 * 各層で相対的に見たRouterのタイプを保持するための構造体
 * @author noritsuna
 *
 */
public class RouteType {

	
	static public RouteType UPPER_LAYER = new RouteType("UPPER_LAYER");
	static public RouteType LOWER_LAYER = new RouteType("LOWER_LAYER");
	static public RouteType CURRENT_LAYER = new RouteType("CURRENT_LAYER");
	
	
	private String myType;
	
	/**
	 * Routerのタイプを取得する。
	 * @param type
	 */
	private RouteType(String type) {
		myType = type;
	}
	/**
	 * 文字列にする。
	 */
	public String toString() {
		return myType;
	}
	/**
	 * 同値のものであるかをチェックする。
	 * @param arg0
	 * @return
	 */
	public boolean equals(RouteType arg0) {
		return this.toString().equals(arg0.toString());
	}
}
