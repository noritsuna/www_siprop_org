/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.util;

import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Peer;

/**
 * RawPacketを示すクラス<BR>
 * byte[] を、取得する。
 * @author sakukawa
 *
 */
public class RawPacket implements Packet
{
	private byte[] buf;
	private Peer sourcePeer = null;
	private Peer destPeer = null;
	
	/**
	 * コンストラクタ
	 * @param buf
	 */
	public RawPacket(byte[] buf)
	{
		this.buf = buf;
	}
	/**
	 * データを取得する。
	 * @return
	 */
	public byte[] getData() {
		return buf;
	}
	/**
	 * sourceのPeerを取得する。
	 * @return
	 */
	public Peer getSourcePeer()
	{
		return sourcePeer;
	}
	/**
	 * destのPeerを取得する。
	 * @return
	 */
	public Peer getDestPeer()
	{
		return destPeer;
	}
	/**
	 * sourceのPeerをセットする。
	 * @param p
	 */
	public void setSourcePeer(Peer p)
	{
		this.sourcePeer = p;
	}
	/**
	 * destのPeerをセットする。
	 * @param p
	 */
	public void setDestPeer(Peer p)
	{
		this.destPeer = p;
	}

}
