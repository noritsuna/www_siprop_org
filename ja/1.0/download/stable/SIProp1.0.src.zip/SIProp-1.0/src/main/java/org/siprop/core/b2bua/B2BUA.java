/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.b2bua;

import java.util.List;

import org.siprop.core.Resolver;
import org.siprop.core.Router;
import org.siprop.core.message.ControlMessage;
import org.siprop.message.impl.MessageContext;

/**
 * B2BUAのインタフェース<BR>
 * 現在は、Routerとして、実装している。
 * @author noritsuna
 *
 */
public interface B2BUA extends Router {

	/**
	 * ControlMessageを作成する。
	 * @param message MessageContext
	 * @return ControlMessage
	 */
	public ControlMessage createControlMessage(MessageContext message);
	/**
	 * Resolverのリストをセットする。
	 * @param resolverLst リゾルバのリスト
	 */
	public void setResolvers(List resolverLst);
	/**
	 * Resolverを取得する。
	 * @return Resolver
	 */
	public Resolver getResolver();
	
}
