/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.util;

/**
 * Propertyを操作するための抽象化クラス
 * @author noritsuna
 *
 */
public abstract class PropertiesDepot {
	
	
	/**
	 * Propertyをロードする。
	 * @param propertyPath
	 */
	public abstract void loadProperties(String propertyPath);

	/**
	 * Propertyをセットする。
	 * @param propertyName
	 * @param propertyValue
	 */
	public abstract void setProperty(String propertyName, String propertyValue);
	/**
	 * Propertyを取得する。
	 * @param property
	 * @return
	 */
	public abstract String getProperty(String property);
	
	/**
	 * Propertyを削除する。
	 *
	 */
	public abstract void storeProperties();

	/**
	 * Propertyを再度読み込む。
	 * @param propertyPath
	 */
	public abstract void processNewProperties(String propertyPath);
}
