/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua;

import org.siprop.core.ua.util.UAModuleList;
import org.siprop.message.impl.MessageContext;

/**
 * UAを管理し、操作するためのインタフェース<BR>
 * Dialog単位のUA実体を管理する。また、B2BUA的な操作が必要な場合の判断などを行う。
 * @author noritsuna
 *
 */
public interface UAManager extends UA {

	
	/**
	 * Controlコマンドを実行する。<BR>
	 * これに、ほかのUAや層からの実行すべき内容が記述されている。
	 * @param messageContext
	 */
	public void doControlCommand(MessageContext messageContext);

	/**
	 * UAModuleから、コールバックされるメソッド
	 * @param messageContext
	 * @param module UA
	 */
	public void doCallBackFromUA(MessageContext messageContext, UA module);

	/**
	 * UAModuleSetのUAModuleすべてへDispatchする。
	 * @param messageContext
	 * @param uaSet
	 */
	public void dispatchUAModule(MessageContext messageContext, UAModuleList uaSet);
	
	/**
	 * モジュールを終了する。
	 * @param messageContext
	 */
	public void destroyModule(MessageContext messageContext);	
	
	/**
	 * State状態に合わせて、必要な処理を行う。
	 */
	public void doState(MessageContext messageContext);

}
