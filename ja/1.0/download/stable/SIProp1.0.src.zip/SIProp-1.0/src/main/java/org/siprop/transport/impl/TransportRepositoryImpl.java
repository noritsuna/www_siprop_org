/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;

import java.io.IOException;

import org.siprop.core.Provider;
import org.siprop.core.Repository;
import org.siprop.core.Router;
import org.siprop.core.transport.Packet;
import org.siprop.core.transport.PacketProcessor;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;
import org.siprop.core.transport.TransportRepository;
import org.siprop.core.util.RouteType;
import org.siprop.message.impl.MessageContext;
import org.siprop.transport.util.PeerImpl;

/**
 * Transport用リポジトリクラスの実装
 * @author noritsuna
 *
 */
public class TransportRepositoryImpl implements TransportRepository {

	/**
	 * 相対的に見た同じ層のRouter。
	 */
	private TransportRouter currentRouter;

	/**
	 * 相対的に見た上位層のRouter。
	 */
	private PacketProcessor upperRouter;				// StackRouterのインスタンスが入ってくる
	/**
	 * 相対的に見た下位層のRouter。
	 */
	private PacketProcessor lowerRouter;				// 外部向けパケット送信用処理クラス

	/**
	 * TransportSelector
	 */
	private TransportSelector ts;
	/**
	 * TransportCreator
	 */
	private TransportCreator transportCreator;
	
	
	private Provider provider;
	private static String BIND_PORT = "transport.bind.port";
	
	/**
	 * TransportRepositoryを作成する。
	 * @param provider Providerクラス
	 */
	public void create(Provider provider) {
		// PropertiesDepotより、対象となるRouter用スクリプト, Manager, 本体を取得する
		// 構造にあわせて、Managerのインスタンス化などを行う
		// Routerへの登録などを行う。

		this.lowerRouter = new OutbaundPacketProcessor();
		this.provider = provider;

		this.currentRouter = TransportRouter.getInstance();
		this.currentRouter.setLowerRouter(this.lowerRouter); 
		
		this.ts = new TransportSelector(this.currentRouter);

		transportCreator = new TransportCreator();
		transportCreator.setTransportSelector(ts);

	}

	/**
	 * Routerを取得する。
	 * @param routeType
	 * @return
	 */
	public Router getRouter(RouteType routeType) {
		
		if(RouteType.UPPER_LAYER.equals(routeType)) {
			return (Router)upperRouter;
		} else if(RouteType.LOWER_LAYER.equals(routeType)) {
			return (Router)lowerRouter;
		} else {
			return (Router)currentRouter;
		}
		
	}
	/**
	 * Routerをセットする。
	 * @param routeType
	 * @param router
	 */
	public void setRouter(RouteType routeType, Router router) {
		if(RouteType.UPPER_LAYER.equals(routeType)) {
			upperRouter = (PacketProcessor)router;
			this.currentRouter.setUpperRouter(this.upperRouter);
		} else if(RouteType.LOWER_LAYER.equals(routeType)) {
			lowerRouter = (PacketProcessor)router;
			this.currentRouter.setLowerRouter(this.lowerRouter);
		} else {
			currentRouter = (TransportRouter)router;
		}		
	}
	/**
	 * Routerをセットする。
	 * @param routeType
	 * @param peer
	 * @param router
	 */
	public void setRouter(RouteType routeType, PeerImpl peer, Router router) {
		if(RouteType.UPPER_LAYER.equals(routeType)) {
			upperRouter = (PacketProcessor)router;
			this.currentRouter.setUpperRouter(this.upperRouter);
			try {
				this.currentRouter.addRoute(peer, this.upperRouter);
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if(RouteType.LOWER_LAYER.equals(routeType)) {
			lowerRouter = (PacketProcessor)router;
			this.currentRouter.setLowerRouter(this.lowerRouter);
		} else {
			currentRouter = (TransportRouter)router;
		}		
	}
	/**
	 * Packetを操作するためのクラス
	 * @author sakukawa
	 *
	 */
	public class OutbaundPacketProcessor implements PacketProcessor
	{
		public void addRoute(Router router) {
		}
		public void doDispatch(MessageContext message) {
		}
		public void doRoute(MessageContext message) {
		}
		public Repository getRepository() {
			return null;
		}
		public void removeRoute(Router router) {
		}
		public void setRepository(Repository repository) {
		}

		public void doDispatch(Transport tp, Peer hop, Packet p)
		{
			try {
				byte[] buf = p.getData();
				tp.send(hop.getAddress().getHostName(), hop.getPort(), buf, 0, buf.length);
			} catch(java.io.IOException ex) {
				ex.printStackTrace();
			}
		}
	}
}


