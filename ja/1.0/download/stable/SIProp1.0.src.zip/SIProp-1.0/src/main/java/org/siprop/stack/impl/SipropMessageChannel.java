/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.stack.impl;

import gov.nist.javax.sip.SipStackImpl;
import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.stack.MessageChannel;
import gov.nist.javax.sip.stack.SIPMessageStack;

import java.io.IOException;
import java.net.InetAddress;

import javax.sip.SipProvider;

import org.siprop.core.transport.Packet;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.Transport;
import org.siprop.message.impl.MessageContext;
import org.siprop.transport.impl.TransportRouter;
import org.siprop.transport.util.PeerImpl;
import org.siprop.transport.util.RawPacket;

/**
 * Jain-SIPの都合により、存在するクラス<BR>
 * 新Stack時には削除予定。
 * @author sakukawa
 *
 */
public class SipropMessageChannel extends MessageChannel
{
	/**
	 * SIPStack
	 */
	private SipStackImpl sipStackImpl;
	/**
	 * Transport
	 */
	private org.siprop.core.transport.Transport transport;
	/**
	 * Jain-SIP用のSIPProvider
	 */
	private SipProvider p;
	/**
	 * Trnasport
	 */
	private Transport tp;
	/**
	 * リモートのPeer
	 */
	private Peer remotePeer;
	
	/**
	 * コンストラクタ
	 * @param sipStackImpl
	 * @param p
	 * @param tp
	 * @param remotePeer
	 */
	public SipropMessageChannel(SipStackImpl sipStackImpl, SipProvider p, Transport tp, Peer remotePeer) 
	{
		this.sipStackImpl = sipStackImpl;
		this.p = p;
		this.tp = tp;
		this.remotePeer = remotePeer;
	}
	
	/**
	 * クローズする。
	 */
	public void close() {
		System.out.println("close() called");
		throw new UnsupportedOperationException();
	}
	
	/**
	 * 識別キーを取得する。
	 * @return
	 */
	public String getKey() {
		System.out.println("getKey() called");
		throw new UnsupportedOperationException();
	}
	/**
	 * リモートのPeerを取得する。
	 * @return
	 */
	public String getPeerAddress() {
		System.out.println("getPeerAddress() called");
		return remotePeer.getAddress().getHostName();
	}
	/**
	 * リモートのIPアドレスを取得する。
	 * @return
	 */
	protected InetAddress getPeerInetAddress() {
		System.out.println("getPeerInetAddress() called");
		return remotePeer.getAddress();
	}
	/**
	 * リモートのポート番号を取得する。
	 * @return
	 */
	public int getPeerPort() {
		System.out.println("getPeerPort() called");
		return remotePeer.getPort();
	}
	/**
	 * リモートのプロトコル名を取得する。
	 * @return
	 */
	protected String getPeerProtocol() {
		System.out.println("getPeerProtocol() called");

		int p = remotePeer.getProtocol();
		if (p == Transport.PROTO_TCP) return "TCP";
		else if (p == Transport.PROTO_UDP) return "UDP";
		return "";
	}
	/**
	 * SIPMessageStackを取得する。
	 * @return
	 */
	public SIPMessageStack getSIPStack() {
		System.out.println("getSIPStack() called");
		return sipStackImpl;
		
	}
	/**
	 * Transportを取得する。
	 * @return
	 */
	public String getTransport() {
		System.out.println("getTransport() called");
		return null;
	}
	/**
	 * Viaのホスト名を取得する。
	 * @return
	 */
	public String getViaHost() {
		System.out.println("getViaHost() called");
		throw new UnsupportedOperationException();
	}
	/**
	 * Viaのポートを取得する。
	 * @return
	 */
	public int getViaPort() {
		System.out.println("getViaPort() called");
		return getPeerPort();
	}
	/**
	 * UDPであるかどうか？
	 * @return
	 */
	public boolean isReliable() {
		int p = remotePeer.getProtocol();
		return (p != Transport.PROTO_UDP);
	}
	/**
	 * セキュアモードかどうか？
	 * @return
	 */
	public boolean isSecure() {
		System.out.println("isSecure() called");
		return false;
	}
	/**
	 * メッセージを送信する。
	 * @param
	 */
	public void sendMessage(SIPMessage sipMessage) throws IOException {
		System.out.println("sendMessage() called");
		System.out.println("sendMessage() called");
		System.out.println("-----");
		System.out.println(sipMessage);
		System.out.println("-----");
		throw new UnsupportedOperationException();
	}

	/**
	 * Send a message given SIP message.
	 * @param sipMessage is the messge to send.
	 * @param receiverAddress is the address to which we want to send
	 * @param receiverPort is the port to which we want to send
	 */
	public void sendMessage(SIPMessage sipMessage, InetAddress receiverAddress, int receiverPort)	throws IOException
	{
		long time = System.currentTimeMillis();
		byte[] bytes = sipMessage.encodeAsBytes();

		MessageContext mc = (MessageContext)sipMessage.getUserObject();
		if (mc != null) {
			Peer p = (Peer)mc.getOutboundPeer();
			if (p != null) {
				receiverAddress = p.getAddress();
				receiverPort = p.getPort();
			}
		}
		
		sendMessage(
			bytes,
			receiverAddress,
			receiverPort,
			sipMessage instanceof SIPRequest);
	//	logMessage(sipMessage, receiverAddress, receiverPort, time);
	}
	
	/**
	 * メッセージを送信する。
	 * @param message
	 * @param receiverAddress
	 * @param receiverPort
	 * @param reconnectFlag
	 */
	protected void sendMessage(byte[] message, InetAddress receiverAddress,
			int receiverPort, boolean reconnectFlag) throws IOException {
		TransportRouter r = TransportRouter.getInstance();

		Peer p = new PeerImpl(Transport.PROTO_UDP, receiverAddress, receiverPort);

		Packet pkt = new RawPacket(message);
		r.doRoute(p, pkt);
/*
		System.out.println("sendMessage() called");
		System.out.println("receiverAddress : " + receiverAddress);
		System.out.println("receiverPort : " + receiverPort);
		System.out.println("reconnectFlag : " + reconnectFlag);
		System.out.println("-----");
		System.out.println(new String(message, "utf-8"));
		System.out.println("-----");
*/
	}
	/**
	 * SipProviderを取得する。
	 * @return
	 */
	public SipProvider getSipProvider()
	{
		return p;
	}
	
}
