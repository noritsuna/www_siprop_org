/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core;

import org.siprop.message.impl.MessageContext;


/**
 * StaticなRouting情報を保持し、実行するためのインタフェース
 * 
 * @author noritsuna
 *
 */
public interface Router {
	
	/**
	 * コールバック用メソッド
	 * @param router
	 */
	public void doDispatch(MessageContext message);
	
	/**
	 * Repositoryをセットする
	 * @param router
	 */
	public void setRepository(Repository repository);
	
	/**
	 * Repositoryを取得する
	 * @return
	 */
	public Repository getRepository();
	
	/**
	 * Routing情報を追加する
	 * @param router
	 */	
	public void addRoute(Router router);
	
	/**
	 * Routing情報を削除する
	 * @param router
	 */
	public void removeRoute(Router router);
	
	/**
	 * Routingを実行する
	 * @param obj
	 */
	public void doRoute(MessageContext message);

}
