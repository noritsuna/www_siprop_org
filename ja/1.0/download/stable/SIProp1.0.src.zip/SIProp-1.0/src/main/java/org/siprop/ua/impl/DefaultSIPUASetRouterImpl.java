/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.ua.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.siprop.core.Provider;
import org.siprop.core.Repository;
import org.siprop.core.Router;
import org.siprop.core.message.ContextDiscriminator;
import org.siprop.core.ua.UASetRouter;
import org.siprop.core.util.NotImplementedException;
import org.siprop.message.impl.DefaultContextDiscriminator;
import org.siprop.message.impl.MessageContext;
import org.siprop.ua.util.UAType;



/**
 * デフォルトのUASet用のRouterの実装クラス<BR>
 * UAの集合体を表す。
 * @author noritsuna
 *
 */
public class DefaultSIPUASetRouterImpl implements UASetRouter {

	/**
	 * UASetManagerのリスト
	 */
	private Map routingTable = Collections.synchronizedMap(new HashMap());
	
	/**
	 * UAの種類
	 */
	private String uaKey = UAType.SIP;

	/**
	 * Key生成用
	 */
	private ContextDiscriminator descriminator = new DefaultContextDiscriminator();

	
	/**
	 * Repository
	 */
	private Repository defaultRepository;
	/**
	 * Provider
	 */
	private Provider provider;
	
	/**
	 * コンストラクタ
	 * @param provider
	 */
	public DefaultSIPUASetRouterImpl(Provider provider) {
		this.provider = provider;
	}

	
	/**
	 * 外部からディスパッチされるメソッド
	 * @param message
	 */
	public void doDispatch(MessageContext message) {
		this.doRoute(message);
	}

	/**
	 * Routerを追加する。<BR>
	 * ただし、この層ではRouterは使用されないため、このメソッドは使用不可能である。
	 */
	public void addRoute(Router router) {
		throw new NotImplementedException();
	}

	/**
	 * Routerを削除する。<BR>
	 * ただし、この層ではRouterは使用されないため、このメソッドは使用不可能である。
	 * @param router
	 */
	public void removeRoute(Router router) {
		throw new NotImplementedException();
	}

	/**
	 * Routingを実装する。
	 * @param message
	 */
	public void doRoute(MessageContext message) {
		
		System.out.println("DefaultSIPUASetRouterImpl.doRoute() called : " + message);

		DefaultSIPUASetManagerImpl manager = 
			(DefaultSIPUASetManagerImpl)routingTable.get(descriminator.generateKey(message));
		if(manager == null) {
			System.out.println("create new SIPUASetManager descriminator.generateKey(message) : "
					+ descriminator.generateKey(message));
			manager = new DefaultSIPUASetManagerImpl(provider);
			routingTable.put(descriminator.generateKey(message), manager);
		}
		manager.doProcessMessage(message);

	}
	/**
	 * RoutingKeyを取得する。
	 * @return UAの種類
	 */
	public String getRoutingKey() {
		return uaKey;
	}
	/**
	 * Repositoryをセットする。
	 * @param repository
	 */
	public void setRepository(Repository repository) {
		this.defaultRepository = repository;
	}
	/**
	 * Repositoryを取得する。
	 * @return
	 */
	public Repository getRepository() {
		return defaultRepository;
	}

}
