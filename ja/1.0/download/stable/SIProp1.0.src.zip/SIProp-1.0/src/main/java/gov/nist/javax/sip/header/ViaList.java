/*******************************************************************************
 * Product of NIST/ITL Advanced Networking Technologies Division (ANTD).       *
 ******************************************************************************/
package gov.nist.javax.sip.header;

import java.util.ListIterator;

import javax.sip.header.ViaHeader;

/**
 * Keeps a list and a hashtable of via header functions.
 *
 * @version JAIN-SIP-1.1 $Revision: 1.2 $ $Date: 2004/01/22 13:26:30 $
 *
 * @author M. Ranganathan <mranga@nist.gov>  <br/>
 *
 * <a href="{@docRoot}/uncopyright.html">This code is in the public domain.</a>
 *
 */
public final class ViaList extends SIPHeaderList {

	private String stringRep;

	/**
	 * Constructor.
	 * @param hl SIPObjectList to set
	 */
	public ViaList(SIPObjectList hl) {
		super(hl, VIA);
	}

	/**
	 * Default Constructor.
	 */
	public ViaList() {
		super(Via.class, ViaHeader.NAME);
	}

	/**
	 * make a clone of this header list. This supercedes the parent
	 * function of the same signature - here for speed. Cloning based
	 * on introspection is slower.
	 *
	 * @return clone of this Header list.
	 */
	public Object clone() {
		ViaList vlist = new ViaList();
		ListIterator it = this.listIterator();
		while (it.hasNext()) {
			Via v = (Via) ((Via) it.next()).clone();
			vlist.add(v);
		}
		return (Object) vlist;
	}

}
/*
 * $Log: ViaList.java,v $
 * Revision 1.2  2004/01/22 13:26:30  sverker
 * Issue number:
 * Obtained from:
 * Submitted by:  sverker
 * Reviewed by:   mranga
 *
 * Major reformat of code to conform with style guide. Resolved compiler and javadoc warnings. Added CVS tags.
 *
 * CVS: ----------------------------------------------------------------------
 * CVS: Issue number:
 * CVS:   If this change addresses one or more issues,
 * CVS:   then enter the issue number(s) here.
 * CVS: Obtained from:
 * CVS:   If this change has been taken from another system,
 * CVS:   then name the system in this line, otherwise delete it.
 * CVS: Submitted by:
 * CVS:   If this code has been contributed to the project by someone else; i.e.,
 * CVS:   they sent us a patch or a set of diffs, then include their name/email
 * CVS:   address here. If this is your work then delete this line.
 * CVS: Reviewed by:
 * CVS:   If we are doing pre-commit code reviews and someone else has
 * CVS:   reviewed your changes, include their name(s) here.
 * CVS:   If you have not had it reviewed then delete this line.
 *
 */
