/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.transport;

import java.net.InetAddress;

/**
 * 接続先情報を保持する構造体
 * @author noritsuna
 *
 */
public interface Peer {
	
    /**
     * 接続先のアドレスを取得する。<BR>
     * IPアドレスやRequestURIなどを想定。
     */
    public InetAddress getAddress();
    /**
     * 接続先のポート番号を取得する。
     */
    public int getPort();	
    /**
     * プロトコル番号を取得する。
     * @return
     */
    public int getProtocol();
    /**
     * コネクション指向プロトコルかどうか？
     * @return
     */
    public boolean isConnectionOrientedProtocol();
    /**
     * B2BUA的に、内向きか？
     * @return
     */
    public boolean isInner();
    /**
     * 内向きであることをセットする。
     * @param isInner
     */
    public void setInner(boolean isInner);

}
