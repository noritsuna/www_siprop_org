/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.core.ua;

import gov.nist.javax.sip.message.SIPRequest;
import gov.nist.javax.sip.message.SIPResponse;

import java.util.EventObject;
import java.util.Iterator;

import javax.sip.RequestEvent;
import javax.sip.ResponseEvent;
import javax.sip.TimeoutEvent;

import org.siprop.SIPropException;
import org.siprop.core.Provider;
import org.siprop.core.Repository;
import org.siprop.core.Resolver;
import org.siprop.core.message.ControlMessage;
import org.siprop.core.message.FlatSIPMessage;
import org.siprop.core.util.NotImplementedException;
import org.siprop.message.impl.FlatSIPMessageImpl;
import org.siprop.message.impl.MessageContext;
import org.siprop.message.impl.UAControlMessage;
import org.siprop.resolver.impl.TransportResolverImpl;
import org.siprop.ua.impl.UARepositoryImpl;
import org.siprop.ua.util.RTPPair;


/**
 * SIPUAとして、動作するための基本動作を定義した抽象化UA<BR>
 * SIPMethod単位で、メソッドを定義している。
 * @author noritsuna
 *
 */
public abstract class BaseSIPUAModule implements UA {
	
	

	/**
	 * FlatSIPMessage
	 */
	protected FlatSIPMessage flatSIPMessage = new FlatSIPMessageImpl();
	
	
	
	/**
	 * コンストラクタ<BR>
	 * prividerから、必要な情報を取り出す。
	 * @param provider
	 * @param callbackUA
	 */
	public BaseSIPUAModule(Provider provider, UA callbackUA) {
		this.provider = provider;
		this.callbackUA = callbackUA;
		for(Iterator iter = provider.getRepositories().iterator(); iter.hasNext();) {
			Repository repo = (Repository)iter.next();
			if(repo instanceof UARepositoryImpl) {
				this.defaultRepository = repo;
				break;
			}
		}
		for(Iterator iter = provider.getResolvers().iterator(); iter.hasNext();) {
			Resolver reso = (Resolver)iter.next();
			if(reso instanceof TransportResolverImpl) {
				this.transportResolver = reso;
				break;
			}
		}
		this.userName = provider.getProperty().getProperty("ua.username");
		this.password = provider.getProperty().getProperty("ua.password");
	}

	

	/**
	 * UACとしてメソッドを処理する。
	 * @param messageContext
	 * @throws SIPropException 
	 */
	protected abstract void processINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void processACK(MessageContext messageContext) throws SIPropException;
	protected abstract void processCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void processBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void processREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void processINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void processUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void processREFER(MessageContext messageContext) throws SIPropException;
	protected abstract void processNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void processSUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void processPUBLISH(MessageContext messageContext) throws SIPropException;


	/**
	 * UACとしてレスポンスを処理する
	 * @param messageContext
	 * @throws SIPropException 
	 */
	protected abstract void process100ByINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void process100ByCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void process100ByBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void process100ByREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void process100ByINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void process100ByUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void process100ByNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void process100BySUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void process100ByPUBLISH(MessageContext messageContext) throws SIPropException;
	
	protected abstract void process1xxByINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxByCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxByBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxByREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxByINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxByUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxByNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void process1xxByPUBLISH(MessageContext messageContext) throws SIPropException;
	
	protected abstract void process2xxByINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxByCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxByBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxByREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxByINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxByUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxByNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void process2xxByPUBLISH(MessageContext messageContext) throws SIPropException;

	protected abstract void process3xxByINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxByCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxByBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxByREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxByINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxByUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxByNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void process3xxByPUBLISH(MessageContext messageContext) throws SIPropException;

	protected abstract void process4xxByINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxByCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxByBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxByREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxByINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxByUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxByNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void process4xxByPUBLISH(MessageContext messageContext) throws SIPropException;

	protected abstract void process5xxByINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxByCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxByBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxByREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxByINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxByUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxByNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void process5xxByPUBLISH(MessageContext messageContext) throws SIPropException;

	protected abstract void process6xxByINVITE(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxByCANCEL(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxByBYE(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxByREGISTER(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxByINFO(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxByUPDATE(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxByNOTIFY(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxBySUBSCRIBE(MessageContext messageContext) throws SIPropException;
	protected abstract void process6xxByPUBLISH(MessageContext messageContext) throws SIPropException;
	
	
	/**
	 * UASとしてのMessageに対する処理を行う
	 * @param messageContext
	 * @throws SIPropException
	 */
	public void doIncomingMessage(MessageContext messageContext) {
		ControlMessage controlMessage = messageContext.getControlMessage();		
		if(this.flatSIPMessage == null) {
			this.flatSIPMessage = messageContext.getFlatMessage();
		} else {
			messageContext.setFlatMessage(this.flatSIPMessage);
		}
		try {
			// EventObjectがあれば、それを元に、リクエストかどうかを判定する。
			if(messageContext.getEventObject() == null) {
				if(controlMessage.get(UAControlMessage.IS_REQUEST)) {
					this.doIncomingRequest(messageContext);
				} else if(controlMessage.get(UAControlMessage.IS_RESPONSE)) {
					this.doIncomingResponse(messageContext);
				} else {
					throw new NotImplementedException();
				}
			} else {
				this.doIncomingEvent(messageContext);
			}		
		} catch (SIPropException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * UASとしてのRequestに対する処理を行う
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingRequest(MessageContext messageContext) throws SIPropException {
		System.out.println("in processUpperRequest.");
		
		ControlMessage controlMessage = messageContext.getControlMessage();
		// メソッドチェック
		if(controlMessage.get(UAControlMessage.INIVITE)) {
			this.doIncomingINVITE(messageContext);
		} else if(controlMessage.get(UAControlMessage.ACK)) {
			this.doIncomingACK(messageContext);
		} else if(controlMessage.get(UAControlMessage.BYE)) {
			this.doIncomingBYE(messageContext);
		} else if(controlMessage.get(UAControlMessage.CANCEL)) {
			this.doIncomingCANCEL(messageContext);
		} else if(controlMessage.get(UAControlMessage.REGISTER)) {
			this.doIncomingREGISTER(messageContext);
		} else {
			throw new NotImplementedException();
		}		
	}
	/**
	 * UASとしてのINVITEに対する処理を行う
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingINVITE(MessageContext messageContext) throws SIPropException {
		//イニシャル状態
		if(this.state == BaseSIPUAModule.INIT){
			this.state = BaseSIPUAModule.TRYING;
    		System.out.println("messageContext.getPreviousMessageContext();" + messageContext.getPreviousMessageContext());
    		messageContext.setPreviousMessageContext(null);
    		this.flatSIPMessage.setOrigRequest((SIPRequest)messageContext.getCurrentMessage());
    		this.flatSIPMessage.setPrevRequest(this.flatSIPMessage.getOrigRequest());
    		
    		// RouteSetの生成
    		this.flatSIPMessage.createRouteSet((SIPRequest)messageContext.getCurrentMessage());

			return;
		}
	}	
	/**
	 * UASとしてのBYEに対する処理を行う
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingBYE(MessageContext messageContext) throws SIPropException {
		this.state = BaseSIPUAModule.TERMINATED;
		this.flatSIPMessage.setPrevRequest((SIPRequest)messageContext.getCurrentMessage());
	}	
	/**
	 * UASとしてのACKに対する処理を行う
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingACK(MessageContext messageContext) throws SIPropException {
		if(this.state == BaseSIPUAModule.AUTH || this.state == BaseSIPUAModule.INIT) {
			this.state = BaseSIPUAModule.INIT;
		} else {
			this.state = BaseSIPUAModule.CALL;
		}
		this.flatSIPMessage.setPrevRequest((SIPRequest)messageContext.getCurrentMessage());
		return;
	}	
	/**
	 * UASとしてのCANCELに対する処理を行う
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingCANCEL(MessageContext messageContext) throws SIPropException {
		this.state = BaseSIPUAModule.CANCEL;
		this.flatSIPMessage.setPrevRequest((SIPRequest)messageContext.getCurrentMessage());
	}	
	/**
	 * UASとしてのREGISTERに対する処理を行う
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingREGISTER(MessageContext messageContext) throws SIPropException {
		this.flatSIPMessage.setOrigRequest((SIPRequest)messageContext.getCurrentMessage());
		this.flatSIPMessage.setPrevRequest(this.flatSIPMessage.getOrigRequest());
	}	
	
	
	
	/**
	 * UASとしてのResnponseに対する処理を行う。
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingResponse(MessageContext messageContext) throws SIPropException {
		// レスポンスチェックチェック
		ControlMessage controlMessage = messageContext.getControlMessage();
		if(controlMessage.get(UAControlMessage.RESPONSE_100)) {
			this.doIncoming100Response(messageContext);
		} else if(controlMessage.get(UAControlMessage.RESPONSE_180) || controlMessage.get(UAControlMessage.RESPONSE_183)) {
			// メソッドチェック
			this.doIncoming180Response(messageContext);
		} else if(controlMessage.get(UAControlMessage.RESPONSE_200)) {			
			// メソッドチェック
			this.doIncoming200Response(messageContext);
		} else if(controlMessage.get(UAControlMessage.RESPONSE_300)) {
			// メソッドチェック
			this.doIncoming4xxResponse(messageContext);
		} else if(controlMessage.get(UAControlMessage.RESPONSE_400)) {
			// メソッドチェック
			this.doIncoming4xxResponse(messageContext);
		} else if(controlMessage.get(UAControlMessage.RESPONSE_500)) {
			// メソッドチェック
			this.doIncoming4xxResponse(messageContext);
		} else if(controlMessage.get(UAControlMessage.RESPONSE_600)) {
			// メソッドチェック
			this.doIncoming4xxResponse(messageContext);
		} else {
			throw new NotImplementedException();
		}		
	}
	
	
	protected void doIncoming100Response(MessageContext messageContext) throws SIPropException {
		this.state = BaseSIPUAModule.TRYING;
		this.flatSIPMessage.setPrevResponse((SIPResponse)messageContext.getCurrentMessage());
	}
	protected void doIncoming180Response(MessageContext messageContext) throws SIPropException {
		this.state = BaseSIPUAModule.RINGING;
		this.flatSIPMessage.setPrevResponse( (SIPResponse)messageContext.getCurrentMessage());
	}
	protected void doIncoming200Response(MessageContext messageContext) throws SIPropException {
		// BYE,CANCELなどのメソッドを考慮する必要あり。
		this.state = BaseSIPUAModule.CONFORMED;
		SIPResponse resp = (SIPResponse)messageContext.getCurrentMessage();
		this.flatSIPMessage.setPrevResponse(resp);
		// RouteSetの生成
		this.flatSIPMessage.createRouteSet(resp);
		
	}
	protected void doIncoming4xxResponse(MessageContext messageContext) throws SIPropException {
		SIPResponse res = (SIPResponse)messageContext.getCurrentMessage();
		if(res.getStatusCode() == 401) {
// 			this.state = BaseSIPUAModule.AUTH;
			this.state = BaseSIPUAModule.INIT;
    		
		} else if(res.getStatusCode() == 407) {
// 			this.state = BaseSIPUAModule.AUTH;
			this.state = BaseSIPUAModule.INIT;
    	} else {
			this.state = BaseSIPUAModule.ERROR;
    	}
		this.flatSIPMessage.setPrevResponse(res);
	}
	
	
	
	
	/**
	 * UASとしてのEventに対する処理を行う。
	 * @param messageContext
	 * @throws SIPropException
	 */
	protected void doIncomingEvent(MessageContext messageContext) throws SIPropException {
		EventObject eventObj = messageContext.getEventObject();
    	// メッセージから、Contorolメッセージを生成する。
	    if (eventObj instanceof RequestEvent) {
	    	MessageContext.setControlMessageByRequest(messageContext.getControlMessage(), (SIPRequest)messageContext.getCurrentMessage());
	        this.doIncomingRequest(messageContext);
	    } else if(eventObj instanceof ResponseEvent) {	    	
	    	MessageContext.setControlMessageByResponse(messageContext.getControlMessage(), (SIPResponse)messageContext.getCurrentMessage());
	    	this.doIncomingResponse(messageContext);
	    } else if(eventObj instanceof TimeoutEvent){
	    	this.doIncomingTimeout(messageContext);
	    } else {
	    	//その他エラー
	    }
	}
	/**
	 * UASとしてのTimeoutに対する処理を行う。
	 * @param messaget
	 */
	protected void doIncomingTimeout(MessageContext messaget) {
		
	}
	
	
	
	/**
	 * UACとしてのタイムアウトイベントを処理する。
	 * @param messaget
	 */
	protected abstract void processTimeout(MessageContext messaget);


	/**
	 * Forking時の識別子を取得する。
	 * @return
	 */
	public abstract String getForkingKey();
	
	
	/**
	 * 現在のステート状態。Ringing,Callなど。
	 */
	protected int state = BaseSIPUAModule.INIT;	
	static protected int INIT = 0;
	static protected int TRYING = 1;
	static protected int REGISTE = 2;
	static protected int RINGING = 3;
	static protected int CANCEL = 4;
	static protected int CALL = 5;
	static protected int TERMINATED = 6;
	static protected int CONFORMED = 7;
	static protected int ERROR = 8;
	static protected int CANCEL_CONFORMED = 9;
	static protected int AUTH = 10;

	/**
	 * 一番最初のメッセージ
	 */
	public MessageContext messageOrig;
	/**
	 * 最後に送信したメッセージ
	 */
	public MessageContext messageLastSend;
	/**
	 * 最後に受信したメッセージ
	 */
	public MessageContext messageLastReceive;
	
	/**
	 * Regository
	 */
	protected Repository defaultRepository;
	/**
	 * Provider
	 */
	protected Provider provider;
	
	/**
	 * Resolver
	 */
	protected Resolver transportResolver;
	
	/**
	 * コールバック先のUA
	 */
	protected UA callbackUA;

    


    
    
    
    /**
     * 認証用のUserName
     */
    protected String userName = null;
    /**
     * 認証用のパスワード
     */
    protected String password = null;
    
    
	/**
	 * RTP用のPairを保持するもの
	 */
    protected RTPPair rtpPair = null;
	

    /**
     * Call-ID
     */
    protected String callID = null;
    
	/**
	 * CallIDを生成する<BR>
	 * MultiUA対応にするには、Managerで作らないとだめな気がするが。。。
	 * @param messageContext
	 * @return CallID
	 */
	protected String generateCallID(MessageContext messageContext) {
		if(callID == null) {
			this.callID = messageContext.getUniKey();
		}
		return this.callID;
	}

    /**
     * ブランチIDを生成する 
     **/
    protected String generateBranch(SIPRequest sipMessage) {
    	
    	
        StringBuffer sb = new StringBuffer(256);
        sb.append(sipMessage.getFrom().toString());
        sb.append("/");
        sb.append(sipMessage.getTo().toString());
        sb.append("/");
        sb.append(sipMessage.getCallId().getCallId());
        sb.append("/");
//        sb.append(sipMessage.getCSeq().toString());
//        sb.append("/");
        sb.append(sipMessage.getRequestURI().toString());

        String hash = Integer.toHexString(sb.toString().hashCode());
        
        sb = new StringBuffer(256);
        sb.append("z9hG4bK");
        sb.append(hash);
        return sb.toString();
        
    }    



	
	/**
	 * UACとしてのメッセージの処理を開始する。
	 * @param messageContext
	 */
	public void doProcessMessage(MessageContext messageContext) {
		System.out.println("in BaseSIPUAModuleImpl.doProcessMessage() : " + messageContext);
		
		ControlMessage controlMessage = messageContext.getControlMessage();		
		if(this.flatSIPMessage == null) {
			this.flatSIPMessage = messageContext.getFlatMessage();
		} else {
			messageContext.setFlatMessage(this.flatSIPMessage);
		}
		try {
			// EventObjectがあれば、それを元に、リクエストかどうかを判定する。
			if(messageContext.getEventObject() == null) {
				if(controlMessage.get(UAControlMessage.IS_REQUEST)) {
					this.processRequest(messageContext);
				} else if(controlMessage.get(UAControlMessage.IS_RESPONSE)) {
					this.processRESPONSE(messageContext);
				} else {
					throw new NotImplementedException();
				}
			} else {
				this.processEvent(messageContext);
			}		
		} catch (SIPropException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("UAModule send SIPMessage:" + messageContext.getCurrentMessage());
		System.out.println("UAModule send OutboundPeer:" + messageContext.getOutboundPeerStr());
		System.out.println("UAModule send ListenPeer:" + messageContext.getListenPeerStr());
		System.out.println("this:" + this);
		if(this.state == BaseSIPUAModule.CANCEL_CONFORMED) {
			return;
		}
		this.send(messageContext);
	}
	/**
	 * UACとしてのEventを処理する。
	 * @param message
	 * @throws SIPropException 
	 */
	protected void processEvent(MessageContext message) throws SIPropException {
		System.out.println("in  processEvent.");
		EventObject eventObj = message.getEventObject();
		
    	System.out.println("EventObject : " + eventObj);
    	System.out.println("EventObject(class) : " + eventObj.getClass().getName());

    	// メッセージから、Contorolメッセージを生成する。
	    if (eventObj instanceof RequestEvent) {
	    	MessageContext.setControlMessageByRequest(message.getControlMessage(), (SIPRequest)message.getCurrentMessage());
	        this.processRequest(message);
	    } else if(eventObj instanceof ResponseEvent) {	    	
	    	MessageContext.setControlMessageByResponse(message.getControlMessage(), (SIPResponse)message.getCurrentMessage());
	    	this.processRESPONSE(message);
	    } else if(eventObj instanceof TimeoutEvent){
	    	this.processTimeout(message);
	    } else {
	    	//その他エラー
	    }
	}
	
	
	/**
	 * UACとしてのリクエストをメソッドごとに処理する
	 * @param message
	 * @throws SIPropException 
	 */
    protected void processRequest(MessageContext message) throws SIPropException {
		System.out.println("in processRequest()");

		ControlMessage controlMessage = message.getControlMessage();
		// メソッドチェック
		if(controlMessage.get(UAControlMessage.INIVITE)) {
			this.processINVITE(message);
		} else if(controlMessage.get(UAControlMessage.ACK)) {
			this.processACK(message);
		} else if(controlMessage.get(UAControlMessage.BYE)) {
			this.processBYE(message);
		} else if(controlMessage.get(UAControlMessage.CANCEL)) {
			this.processCANCEL(message);
		} else if(controlMessage.get(UAControlMessage.REGISTER)) {
			this.processREGISTER(message);
		} else {
			throw new NotImplementedException();
		}
    }

	/**
	 * UACとしてのレスポンスをコードごとに処理する。
	 * @param message
	 * @throws SIPropException 
	 */
    protected void processRESPONSE(MessageContext message) throws SIPropException {
		System.out.println("in processResponse()");
		ControlMessage controlMessage = message.getControlMessage();
		
		// レスポンスチェックチェック
		if(controlMessage.get(UAControlMessage.RESPONSE_100)) {
			// メソッドチェック
			if(controlMessage.get(UAControlMessage.INIVITE)) {
				this.process100ByINVITE(message);
			} else if(controlMessage.get(UAControlMessage.BYE)) {
				this.process100ByBYE(message);
			} else if(controlMessage.get(UAControlMessage.CANCEL)) {
				this.process100ByCANCEL(message);
			} else if(controlMessage.get(UAControlMessage.REGISTER)) {
				this.process100ByREGISTER(message);
			} else if(controlMessage.get(UAControlMessage.INFO)) {
				this.process100ByINFO(message);
			} else if(controlMessage.get(UAControlMessage.UPDATE)) {
				this.process100ByUPDATE(message);
			} else if(controlMessage.get(UAControlMessage.NOTIFY)) {
				this.process100ByNOTIFY(message);
			} else if(controlMessage.get(UAControlMessage.SUBSCRIBE)) {
				this.process100BySUBSCRIBE(message);
			} else if(controlMessage.get(UAControlMessage.PUBLISH)) {
				this.process100ByPUBLISH(message);
			} else {
				throw new NotImplementedException();
			}
		} else if(controlMessage.get(UAControlMessage.RESPONSE_180) || controlMessage.get(UAControlMessage.RESPONSE_183)) {
			// メソッドチェック
			if(controlMessage.get(UAControlMessage.INIVITE)) {
				this.process1xxByINVITE(message);
			} else if(controlMessage.get(UAControlMessage.BYE)) {
				this.process1xxByBYE(message);
			} else if(controlMessage.get(UAControlMessage.CANCEL)) {
				this.process1xxByCANCEL(message);
			} else if(controlMessage.get(UAControlMessage.REGISTER)) {
				this.process1xxByREGISTER(message);
			} else if(controlMessage.get(UAControlMessage.INFO)) {
				this.process1xxByINFO(message);
			} else if(controlMessage.get(UAControlMessage.UPDATE)) {
				this.process1xxByUPDATE(message);
			} else if(controlMessage.get(UAControlMessage.NOTIFY)) {
				this.process1xxByNOTIFY(message);
			} else if(controlMessage.get(UAControlMessage.SUBSCRIBE)) {
				this.process1xxBySUBSCRIBE(message);
			} else if(controlMessage.get(UAControlMessage.PUBLISH)) {
				this.process1xxByPUBLISH(message);
			} else {
				throw new NotImplementedException();
			}
		} else if(controlMessage.get(UAControlMessage.RESPONSE_200)) {			
			// メソッドチェック
			if(controlMessage.get(UAControlMessage.INIVITE)) {
				this.process2xxByINVITE(message);
			} else if(controlMessage.get(UAControlMessage.BYE)) {
				this.process2xxByBYE(message);
			} else if(controlMessage.get(UAControlMessage.CANCEL)) {
				this.process2xxByCANCEL(message);
			} else if(controlMessage.get(UAControlMessage.REGISTER)) {
				this.process2xxByREGISTER(message);
			} else if(controlMessage.get(UAControlMessage.INFO)) {
				this.process2xxByINFO(message);
			} else if(controlMessage.get(UAControlMessage.UPDATE)) {
				this.process2xxByUPDATE(message);
			} else if(controlMessage.get(UAControlMessage.NOTIFY)) {
				this.process2xxByNOTIFY(message);
			} else if(controlMessage.get(UAControlMessage.SUBSCRIBE)) {
				this.process2xxBySUBSCRIBE(message);
			} else if(controlMessage.get(UAControlMessage.PUBLISH)) {
				this.process2xxByPUBLISH(message);
			} else {
				throw new NotImplementedException();
			}
		} else if(controlMessage.get(UAControlMessage.RESPONSE_300)) {
			// メソッドチェック
			if(controlMessage.get(UAControlMessage.INIVITE)) {
				this.process3xxByINVITE(message);
			} else if(controlMessage.get(UAControlMessage.BYE)) {
				this.process3xxByBYE(message);
			} else if(controlMessage.get(UAControlMessage.CANCEL)) {
				this.process3xxByCANCEL(message);
			} else if(controlMessage.get(UAControlMessage.REGISTER)) {
				this.process3xxByREGISTER(message);
			} else if(controlMessage.get(UAControlMessage.INFO)) {
				this.process3xxByINFO(message);
			} else if(controlMessage.get(UAControlMessage.UPDATE)) {
				this.process3xxByUPDATE(message);
			} else if(controlMessage.get(UAControlMessage.NOTIFY)) {
				this.process3xxByNOTIFY(message);
			} else if(controlMessage.get(UAControlMessage.SUBSCRIBE)) {
				this.process3xxBySUBSCRIBE(message);
			} else if(controlMessage.get(UAControlMessage.PUBLISH)) {
				this.process3xxByPUBLISH(message);
			} else {
				throw new NotImplementedException();
			}
		} else if(controlMessage.get(UAControlMessage.RESPONSE_400)) {
			// メソッドチェック
			if(controlMessage.get(UAControlMessage.INIVITE)) {
				this.process4xxByINVITE(message);
			} else if(controlMessage.get(UAControlMessage.BYE)) {
				this.process4xxByBYE(message);
			} else if(controlMessage.get(UAControlMessage.CANCEL)) {
				this.process4xxByCANCEL(message);
			} else if(controlMessage.get(UAControlMessage.REGISTER)) {
				this.process4xxByREGISTER(message);
			} else if(controlMessage.get(UAControlMessage.INFO)) {
				this.process4xxByINFO(message);
			} else if(controlMessage.get(UAControlMessage.UPDATE)) {
				this.process4xxByUPDATE(message);
			} else if(controlMessage.get(UAControlMessage.NOTIFY)) {
				this.process4xxByNOTIFY(message);
			} else if(controlMessage.get(UAControlMessage.SUBSCRIBE)) {
				this.process4xxBySUBSCRIBE(message);
			} else if(controlMessage.get(UAControlMessage.PUBLISH)) {
				this.process4xxByPUBLISH(message);
			} else {
				throw new NotImplementedException();
			}
		} else if(controlMessage.get(UAControlMessage.RESPONSE_500)) {
			// メソッドチェック
			if(controlMessage.get(UAControlMessage.INIVITE)) {
				this.process5xxByINVITE(message);
			} else if(controlMessage.get(UAControlMessage.BYE)) {
				this.process5xxByBYE(message);
			} else if(controlMessage.get(UAControlMessage.CANCEL)) {
				this.process5xxByCANCEL(message);
			} else if(controlMessage.get(UAControlMessage.REGISTER)) {
				this.process5xxByREGISTER(message);
			} else if(controlMessage.get(UAControlMessage.INFO)) {
				this.process5xxByINFO(message);
			} else if(controlMessage.get(UAControlMessage.UPDATE)) {
				this.process5xxByUPDATE(message);
			} else if(controlMessage.get(UAControlMessage.NOTIFY)) {
				this.process5xxByNOTIFY(message);
			} else if(controlMessage.get(UAControlMessage.SUBSCRIBE)) {
				this.process5xxBySUBSCRIBE(message);
			} else if(controlMessage.get(UAControlMessage.PUBLISH)) {
				this.process5xxByPUBLISH(message);
			} else {
				throw new NotImplementedException();
			}
		} else if(controlMessage.get(UAControlMessage.RESPONSE_600)) {
			// メソッドチェック
			if(controlMessage.get(UAControlMessage.INIVITE)) {
				this.process6xxByINVITE(message);
			} else if(controlMessage.get(UAControlMessage.BYE)) {
				this.process6xxByBYE(message);
			} else if(controlMessage.get(UAControlMessage.CANCEL)) {
				this.process6xxByCANCEL(message);
			} else if(controlMessage.get(UAControlMessage.REGISTER)) {
				this.process6xxByREGISTER(message);
			} else if(controlMessage.get(UAControlMessage.INFO)) {
				this.process6xxByINFO(message);
			} else if(controlMessage.get(UAControlMessage.UPDATE)) {
				this.process6xxByUPDATE(message);
			} else if(controlMessage.get(UAControlMessage.NOTIFY)) {
				this.process6xxByNOTIFY(message);
			} else if(controlMessage.get(UAControlMessage.SUBSCRIBE)) {
				this.process6xxBySUBSCRIBE(message);
			} else if(controlMessage.get(UAControlMessage.PUBLISH)) {
				this.process6xxByPUBLISH(message);
			} else {
				throw new NotImplementedException();
			}
		} else {
			throw new NotImplementedException();
		}		
    }    
    
    ///////TOOLS//////
	/**
	 * ここでは、まず、B2BUAに投げるべきかどうかを判断する？？？
	 * @param messageContest
	 */
	public void send(MessageContext messageContext) {
		this.callbackUA.send(messageContext);	
	}

	/**
	 * コールバック先UAをセットする。
	 * @param callbackUA
	 */
	public void setCallbackUA(UA callbackUA) {
		this.callbackUA = callbackUA;
	}
	
    /**
     * RTPPairを取得する
     * @return
     */
	public RTPPair getRtpPair() {
		return rtpPair;
	}
	/**
	 * RTPPairをセットする
	 * @param rtpPair
	 */
	public void setRtpPair(RTPPair rtpPair) {
		this.rtpPair = rtpPair;
	}

}
