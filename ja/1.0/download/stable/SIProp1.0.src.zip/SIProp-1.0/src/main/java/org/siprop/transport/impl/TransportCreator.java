/*
 * Copyright 2007 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.transport.impl;

import org.siprop.core.Repository;
import org.siprop.core.Router;
import org.siprop.core.transport.Packet;
import org.siprop.core.transport.PacketProcessor;
import org.siprop.core.transport.Peer;
import org.siprop.core.transport.ServerTransportListener;
import org.siprop.core.transport.Transport;
import org.siprop.message.impl.MessageContext;

/**
 * Transportを作成するためのクラス<BR>
 * Jain-SIPに依存するクラス
 * @author sakukawa
 *
 */
public class TransportCreator implements ServerTransportListener,
		PacketProcessor {

	private TransportSelector ts;
	
	/**
	 * TransportSelectorをセットする。
	 * @param ts
	 */
	public void setTransportSelector(TransportSelector ts) {
		this.ts = ts;
	}
	
	

	/**
	 * 外部よりディスパッチされるメソッド。
	 * @param tp
	 * @param p
	 */
	public void doDispatch(Transport tp, Packet p)
	{
		System.out.println("onPacketReceived()");
		System.out.println("-------------------------------------");
		System.out.println(p.toString());
		System.out.println("-------------------------------------");
	}
	/**
	 * コネクション時に呼び出されるメソッド。
	 * @param p
	 */
	public void onAccept(Transport p)
	{
		String str = "connected : " + p.getClass().getName();
		System.out.println("onAccept()");
		System.out.println("-------------------------------------");
		System.out.println(str);
		System.out.println("-------------------------------------");
		System.out.println(str);
		ts.addTransport(p);
	}

	// Jain-SIPにおいては、不要のメソッド。
	public void addRoute(Router router) {
	}
	public void doDispatch(MessageContext message) {
	}
	public void doRoute(MessageContext message) {
	}
	public Repository getRepository() {
		return null;
	}
	public void removeRoute(Router router) {
	}
	public void setRepository(Repository repository) {
	}
	public void doDispatch(Transport tp, Peer hop, Packet p) {
	}
	public void onAccept(Transport p, Object arg) {
	}	
	

}
