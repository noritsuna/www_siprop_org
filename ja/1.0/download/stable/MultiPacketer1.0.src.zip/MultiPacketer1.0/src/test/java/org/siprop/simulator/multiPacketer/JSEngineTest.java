/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer;

import junit.framework.TestCase;

/**
 * JSController用のテストクラス。
 * ちょっと、手抜き状態。
 * @author noritsuna
 * $Id$
 */
public class JSEngineTest extends TestCase {

    public JSEngineTest(String name) {
        super(name);
    }
    
    protected void setUp() throws Exception {
    	super.setUp();
    }
    
    protected  void tearDown() {
    }
    

    /**
     * {[VAR]}が、正常に変換されるかどうか。
     */
    public void testReplaceVariables() {
    	
    	JSEngine jsEngine = new JSEngine();
    	
    	String origMsg = "INVITE sip:to@siprop.org SIP/2.0\r\n" +
        "Call-ID:7bc369dcaa5e4be3a887ae4072db7a6b\r\n" +
        "CSeq:1 INVITE\r\n" +
        "From:\"fromname\" <sip:from@siprop.org>;tag=c74a88b7f43a452d92f6362e6f9\r\n" +
        "To:\"toname\" <sip:to@siprop.org>\r\n" +
        "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS\r\n" +
        "Max-Forwards:70\r\n" +
        "Content-Type: application/sdp\r\n";
    	
    	String varMsg = "{METHOD} {TO_URI} SIP/2.0\r\n" +
        "Call-ID:{CALL_ID}\r\n" +
        "CSeq:{CSEQ_NUM} {METHOD}\r\n" +
        "From:\"{FROM_DISPLAYNAME}\" <{FROM_URI}>;tag={FROM_TAG}\r\n" +
        "To:\"{TO_DISPLAYNAME}\" <{TO_URI}>\r\n" +
        "Allow: INVITE,ACK,CANCEL,BYE,NOTIFY,REFER,OPTIONS\r\n" +
        "Max-Forwards:70\r\n" +
        "Content-Type: application/sdp\r\n";
        
    	/**
    	 * TO-URI
    	 */
    	String TO_URI = "sip:to@siprop.org";
    	jsEngine.jsFunction_setVar("TO_URI", TO_URI);
    	/**
    	 * FROM-URI
    	 */
    	String FROM_URI = "sip:from@siprop.org";
    	jsEngine.jsFunction_setVar("FROM_URI", FROM_URI);
    	/**
    	 * TOディスプレイネーム
    	 */
    	String TO_DISPLAYNAME = "toname";
    	jsEngine.jsFunction_setVar("TO_DISPLAYNAME", TO_DISPLAYNAME);
    	/**
    	 * FROMディスプレイネーム
    	 */
    	String FROM_DISPLAYNAME = "fromname";
    	jsEngine.jsFunction_setVar("FROM_DISPLAYNAME", FROM_DISPLAYNAME);
    	/**
    	 * Call-ID
    	 */
    	String CALL_ID = "7bc369dcaa5e4be3a887ae4072db7a6b";
    	jsEngine.jsFunction_setVar("CALL_ID", CALL_ID);
    	/**
    	 * FROM-TAG
    	 */
    	String FROM_TAG = "c74a88b7f43a452d92f6362e6f9";
    	jsEngine.jsFunction_setVar("FROM_TAG", FROM_TAG);
    	/**
    	 * CSeqナンバー
    	 */
    	String CSEQ_NUM = "1";
    	jsEngine.jsFunction_setVar("CSEQ_NUM", CSEQ_NUM);
    	/**
    	 * メソッド
    	 */
    	String METHOD = "INVITE";
    	jsEngine.jsFunction_setVar("METHOD", METHOD);
    	
    	
    	String checkStr = jsEngine.jsFunction_replaceVariables(varMsg);
    	
    	assertEquals(checkStr, origMsg);
    	
    }

    /**
     * 変数が正常にセットされ、取得できるか？
     */
    public void testSetVar() {
    	
    	JSEngine jsEngine = new JSEngine();
    	        
    	/**
    	 * TO-URI
    	 */
    	String TO_URI = "sip:to@siprop.org";
    	jsEngine.jsFunction_setVar("TO_URI", TO_URI);
    	/**
    	 * FROM-URI
    	 */
    	String FROM_URI = "sip:from@siprop.org";
    	jsEngine.jsFunction_setVar("FROM_URI", FROM_URI);
    	
    	
    	
    	String checkStr = jsEngine.jsFunction_getVar("TO_URI");
    	
    	assertEquals(checkStr, TO_URI);
    	
    }
    
}
