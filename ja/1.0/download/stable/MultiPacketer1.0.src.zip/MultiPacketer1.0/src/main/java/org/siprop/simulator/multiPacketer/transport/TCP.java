/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer.transport;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
/**
 * TCPTransportの実装。
 * @author noritsuna
 *
 */
public class TCP implements Transport {

    static final int DEFAULT_BUFFER_SIZE = 65536;

	ServerSocket serverSocket;
	Socket clientSocket;
	InetSocketAddress receiveAddr;
	
	public TCP() throws IOException {
		clientSocket = new Socket();
		serverSocket = new ServerSocket();
		this.setSocketParam();
	}
	/**
	 * Socketにパラメータを設定する。
	 * @throws SocketException
	 */
	private void setSocketParam() throws SocketException {
		clientSocket.setReuseAddress(true);
		serverSocket.setReuseAddress(true);
	}
	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#connect(InetSocketAddress)
	 */
	public void connect(InetSocketAddress remoteAddr) throws IOException {
		if(!clientSocket.isConnected()) {
			clientSocket.connect(remoteAddr);
		}
	}
	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#bind(InetSocketAddress)
	 */
	public void bind(InetSocketAddress localAddr) throws IOException {
		if(!serverSocket.isBound()) {
			serverSocket.bind(localAddr);
		}
	}

	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#close()
	 */
	public void close() {
		if(clientSocket != null) {
			try {
				clientSocket.close();
			} catch (IOException e) {
				;
			}
		}
		if(serverSocket != null) {
			try {
				serverSocket.close();
			} catch (IOException e) {
				;
			}
		}
	}

	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#send(InetSocketAddress, String)
	 */
	public void send(InetSocketAddress addr, String packetStr) throws IOException {
		clientSocket = new Socket(addr.getAddress(), addr.getPort());
		
		PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
		out.print(packetStr);

	}

	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#receive()
	 */
	public String receive() throws IOException {
		clientSocket = serverSocket.accept();
		
		BufferedReader in = new BufferedReader(
		                          new InputStreamReader(
		                        		  clientSocket.getInputStream()));
		
		String inputLine;
		StringBuffer sb = new StringBuffer();
		while ((inputLine = in.readLine()) != null) {
			sb.append(inputLine);
		}
		in.close();
		return sb.toString();
	}

	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#setSoTimeout(int)
	 */
	public void setSoTimeout(int timeout) throws SocketException {
		clientSocket.setSoTimeout(timeout);
	}
	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#getReceivePort()
	 */
	public int getReceivePort() {
		if(clientSocket == null) {
			return 5060;
		} else {
			return clientSocket.getLocalPort();
		}
	}
}
