/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer;

/**
 * システム変数を示すEnum。
 * @author noritsuna
 * $Id$
 */
public enum SystemVariables {
	/**
	 * 最初に送受信したパケット
	 */
	ORIGINAL_PACKET,
	/**
	 * 現在の送受信したパケット
	 */
	CURRENT_PACKET,
	/**
	 * 最後に受信したパケット
	 */
	RECEIVE_PACKET,
	/**
	 * 最後に送信したパケット
	 */
	SEND_PACKET,
	/**
	 * ローカルIP
	 */
	LOCAL_IP,
	/**
	 * ローカルポート
	 */
	LOCAL_PORT,
	/**
	 * リモートIP
	 */
	REMOTE_IP,
	/**
	 * リモートポート
	 */
	REMOTE_PORT,
	/**
	 * VIAのsent-by相当のIP
	 */
	RECEIVE_IP,
	/**
	 * VIAのsent-by相当のポート
	 */
	RECEIVE_PORT,
	/**
	 * トランスポートタイプ
	 */
	TRANSPORT_TYPE,
	/**
	 * ローカルIPを使用するかsent-byを使用するか
	 */
	IS_RECEIVE_MODE,
	/**
	 * Socketの待ち受けタイムアウト時間(ms)
	 */
	TIMEOUT	
}
