/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer.transport;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.SocketException;

/**
 * Transport用のインターフェース。
 * ServiceMixとの統合を考えているため、現在は、最低限のメソッドのみを実装している。
 * @author noritsuna
 *
 */
public interface Transport {

	/**
	 * connectする。
	 * @param remoteAddr リモートホストのSocketアドレス
	 * @throws IOException
	 */
	public void connect(InetSocketAddress remoteAddr) throws IOException;
	/**
	 * bindする。
	 * @param localAddr ローカルホストのSocketアドレス
	 * @throws IOException
	 */
	public void bind(InetSocketAddress localAddr) throws IOException;
	/**
	 * bindする。<BR>
	 * 送信用トランスポートから、bindすべきポートを取得する。
	 * @param sendTrans 送信用トランスポート
	 * @throws IOException
	 */
//	public void bind(Transport sendTrans) throws IOException;
	
	/**
	 * cleseする。
	 *
	 */
    public void close();

    /**
     * 送信する。
	 * @param remoteAddr リモートホストのSocketアドレス
     * @param packetStr 送信するパケット
     * @throws IOException
     */
    public void send(InetSocketAddress remoteAddr, String packetStr) throws IOException;    
    /**
     * 受信する。
     * @return 受信したパケット
     * @throws IOException
     */
    public String receive() throws IOException;
    
    /**
     * 受信するポートを取得する。
     * @return 受信するポート
     */
	public int getReceivePort();
	/**
	 * 受信時のタイムアウト時間を設定する。
	 * @param timeout タイムアウト時間(ms)
	 * @throws SocketException
	 */
    public void setSoTimeout(int timeout) throws SocketException;
    

}
