/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer;

import java.io.File;

import org.siprop.simulator.multiPacketer.tracer.ConsoleTracer;
import org.siprop.simulator.multiPacketer.tracer.Tracer;

/**
 * コンソール操作用のクラス
 * @author noritsuna
 * $Id$
 */
public class ConsoleMain {
    
    
	public static Tracer tracer = new ConsoleTracer();
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		if(args.length != 1 && args.length != 7) {
			System.out.print("java org.siprop.simulator.multiPackter.ConsoleMain JavaScriptファイル名 [ローカルIP] [ローカルポート] [リモートIP] [リモートポート] [トランスポートタイプ:TCP|UDP] [IPタイプ:IP4|IP6]\n\n" +
					     "例：java org.siprop.simulator.multiPacketer.ConsoleMain test.js\n" +
					     "    java org.siprop.simulator.multiPacketer.ConsoleMain test.js 192.168.0.1 5060 192.168.0.2 5060 UDP IP4\n");
		}
		
		// JavaScriptファイルの設定
		String fileName = args[0];
		
		// 初期化パラメータの設定。
		InitStructure init = new InitStructure(tracer);
		if(args.length == 7) {			
			// ローカルエンドポイントの設定
			init.setLocalIP(args[1]);
			try {
				init.setLocalPort(Integer.parseInt(args[2]));
			} catch(NumberFormatException e) {
				init.setLocalPort(5060);
			}
			
			// リモートエンドポイントの設定
			init.setRemoteIP(args[3]);
			try {
				init.setRemotePort(Integer.parseInt(args[4]));
			} catch(NumberFormatException e) {
				init.setRemotePort(5060);
			}
			
			// トランスポートタイプの設定
			init.setTransportType(args[5]);
			
			// IPタイプの設定
			init.setIpType(args[6]);
			
		}
		// 実行。
		JSController engine = new JSController(tracer);
		File initFile = new File(fileName);
		engine.execByFile(initFile, init);

	}

}
