/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer;

import gov.nist.javax.sip.header.AuthenticationHeader;
import gov.nist.javax.sip.header.ProxyAuthenticate;
import gov.nist.javax.sip.header.WWWAuthenticate;
import gov.nist.javax.sip.message.SIPMessage;
import gov.nist.javax.sip.parser.StringMsgParser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.UnsupportedEncodingException;
import java.net.BindException;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.ListIterator;
import java.util.Map;
import java.util.regex.Pattern;

import javax.sip.header.Header;

import org.apache.log4j.Category;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.ScriptableObject;
import org.siprop.simulator.multiPacketer.tracer.Tracer;
import org.siprop.simulator.multiPacketer.tracer.TracerCode;
import org.siprop.simulator.multiPacketer.transport.TCP;
import org.siprop.simulator.multiPacketer.transport.Transport;
import org.siprop.simulator.multiPacketer.transport.UDP;

/**
 * JavaScript側で動作するクラス。
 * パケットの送受信や変数の保持を行う。
 * @author noritsuna
 * $Id$
 */
public class JSEngine extends ScriptableObject {

    /**
	 * シリアライズ用ID
	 */
	private static final long serialVersionUID = -8484132647667058016L;
	/**
     * log4j アクセスポイント。
     */
    protected static Category LOG = Category.getInstance(JSEngine.class);
    /**
     * パケットログ表示用
     */
    private Tracer tracer;

	/**
	 * 変数保持用
	 */
	private Map<String, String> varMap = new HashMap<String, String> ();
	/**
	 * 初期パラメータ
	 */
	private InitStructure param = null;
	/**
	 * メッセージパーサー
	 */
    private StringMsgParser sipParser = new StringMsgParser();
	
    /**
     * 送信用Transport
     */
	private Transport sendTransport;
	/**
	 * ローカル受信用Transport
	 */
	private Transport localTransport;
	/**
	 * VIAの受信用Transport
	 */
	private Transport receiveTransport;
  
	
	/**
	 * コンストラクター
	 */
	public JSEngine() { }
	
	// JavaScript用のFunction群
	/**
	 * JavaScript側で呼び出された時用のコンストラクター
	 */
	public void jsConstructor(InitStructure init) {
		this.param = init;
		this.tracer = this.param.getTracer();
		if(this.param.getContext() == null) {
			throw new JSException("Not Found context.");
		}
		if(this.param.getScope() == null) {
			throw new JSException("Not Found scope.");
		}
		
		// システム変数を設定する。
		varMap.put(SystemVariables.TIMEOUT.toString(), "32000");
		varMap.put(SystemVariables.LOCAL_IP.toString(), param.getLocalIP());
		varMap.put(SystemVariables.LOCAL_PORT.toString(), String.valueOf(param.getLocalPort()));
		varMap.put(SystemVariables.REMOTE_IP.toString(), param.getRemoteIP());
		varMap.put(SystemVariables.REMOTE_PORT.toString(), String.valueOf(param.getRemotePort()));
		varMap.put(SystemVariables.TRANSPORT_TYPE.toString(), param.getTransportType());
		varMap.put(SystemVariables.IS_RECEIVE_MODE.toString(), "FALSE");
		
		this.createTransports();
	}
	/**
	 * ScriptableObjectに必要なメソッドで、クラスの名称を返す。
	 */
	public String getClassName() {
		return "JSEngine";
	}
	/**
	 * スクリプトファイルをスクリプト内でインポートする
	 * @param scriptName スクリプトファイルへ絶対パスor相対パス
	 * @throws IOException
	 */
	public void jsFunction_importScript(String scriptName) throws IOException {
		File scriptFile = new File(scriptName);
		if(scriptFile == null) {
			throw new FileNotFoundException("Script not found.:" + scriptName);
		}
		
		Script script = JSController.loadScript(scriptFile, param.getContext());
		script.exec(param.getContext(), param.getScope());
	}
	/**
	 * 渡された文字列を送信する。
	 * @param packet パケット列
	 */
	public void jsFunction_send(String sendStr) {
		try {
			String packetStr = new String(new String(this.jsFunction_replaceVariables(sendStr).getBytes(), "UTF-8"));			
			tracer.println(TracerCode.INFO, "send packet.\n" + packetStr);
			this.setPacket(packetStr, true);
			sendTransport.send(param.getRemoteSocket(), packetStr);
		} catch (SocketException e) {
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
		} catch (IOException e) {
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
		}
	}
	/**
	 * パケットを受信する。
	 */
	public String jsFunction_receive() {
		String packet = null;
		try {
			// Viaのsent-byで待ち受けする場合
			String mode = varMap.get(SystemVariables.IS_RECEIVE_MODE.toString());
			if(Boolean.valueOf(mode).booleanValue()) {
				tracer.println(TracerCode.INFO, "receivePortt:" + receiveTransport.getReceivePort());
				packet = receiveTransport.receive();
			} else {
				packet = localTransport.receive();
			}
		} catch (SocketTimeoutException e) {
			tracer.println(TracerCode.ERROR, "timeout socket.");
			LOG.error("Exception", e);
			return null;
		} catch (InterruptedIOException e) {
			tracer.println(TracerCode.ERROR, "timeout socket.");
			LOG.error("Exception", e);
			return null;
		} catch (IOException e) {
			tracer.println(TracerCode.ERROR, "error socket." + e.toString());
			LOG.error("Exception", e);
			return null;
		}
		try {
			String packetStr = new String(new String(packet.getBytes(), "UTF-8"));
			tracer.println(TracerCode.INFO, "reveice packet.\n" + packetStr);
			this.setPacket(packetStr, true);
			return packetStr;
		} catch (UnsupportedEncodingException e) {
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
			return null;
		}
	}
	/**
	 * 変数をセットする。
	 * ヘッダーの保持などに使用する。
	 * @param key 変数名
	 * @param variable 変数値
	 */
	public void jsFunction_setVar(String key, String variable) {
		varMap.put(key, variable);
	}
	/**
	 * 変数を取得する。
	 * ヘッダーの保持などに使用する。
	 * @param key 変数名
	 * @return 変数値
	 */
	public String jsFunction_getVar(String key) {
		return varMap.get(key);
	}
    /**
	 * Packetから、変数Mapへセットする。
     * @param packetStr パケット
     */
    public void jsFunction_setVariablesForSIPByPacket(String packetStr) {
        SIPMessage sipMessage = null;
        try {
        	// パケットのパースを行う
			sipMessage = sipParser.parseSIPMessage(packetStr);
		} catch (ParseException e) {
			tracer.println(TracerCode.ERROR, "parse error.");
			LOG.error("Exception", e);
			return;
		}
		// パースしたパケットをヘッダー単位で、varMapに保持する
		StringBuilder sb = new StringBuilder();
		for(ListIterator headers = sipMessage.getHeaders(); headers.hasNext();) {
			Header header = (Header)headers.next();
			varMap.put(header.getName().toUpperCase(), header.toString());
			if(sb.length() == 0) {
				sb.append(header.getName().toUpperCase());
			} else {
				sb.append( "," + header.getName().toUpperCase());
			}
		}
		tracer.println(TracerCode.INFO, "parse headers:" + sb.toString());
	}
	/**
	 * 変数Mapから、Packetを生成する。
	 * @param value
	 * @return 生成されたパケット文字列
	 */
	public String jsFunction_replaceVariables(String value) {
		StringBuilder result = new StringBuilder(value.length() * 4);
		int index = 0;
		
		for (;;) {
			
			int start = value.indexOf('{', index);
			if (start < 0) {
				if(index == 0)
					break;
				
				result.append(value, index, value.length());
				value = result.toString();
				result = new StringBuilder(value.length() * 4);
				index = 0;
				continue;
			}

			int end = value.indexOf('}', start + 1);
			if (end < 0) {
				start++;
				result.append(value, index, start);
				index = start;
				continue;
			}

			result.append(value, index, start);
			start++;
			String name = value.substring(start, end);
			String var = this.jsFunction_getVar(name);
			if(var != null && !var.equals("")) {
				result.append(var);
			}

			index = end + 1;
		}

		result.append(value, index, value.length());
		return result.toString();
	}	
	/**
	 * 指定したミリ秒数 停止する。
	 * @param militime ミリ秒数
	 */
	public void jsFunction_sleep(double militime) {
		try {
			Thread.sleep((long)militime);
		} catch (InterruptedException e) {
			tracer.println(TracerCode.ERROR, "Sleep Thread error.");
			LOG.error("Exception", e);
		}
	}
	/**
	 * 文字列を出力する。
	 * @param str 出力文字列
	 */
	public void jsFunction_print(String str) {
		tracer.print(TracerCode.INFO, str);
	}
	/**
	 * Authに関する値を計算して、返す。<BR>
	 * Digest認証のみ対応。
	 * @param authResponse 認証レスポンス
	 * @param requestUri Request-URI
	 * @param username ユーザ名
	 * @param password パスワード
	 * @return 計算されたAuthヘッダー
	 */
	public String jsFunction_calcAuth(String authResponse, String requestUri, String username, String password) {
    	SIPMessage msg;
		try {
			msg = sipParser.parseSIPMessage(authResponse);
			AuthenticationHeader auth = null;
			boolean isProxy = false;
			for(ListIterator headers = msg.getHeaders(); headers.hasNext();) {
				Header header = (Header)headers.next();
				if(header.getName().toUpperCase().equals("PROXY-AUTHENTICATE")) {
					auth = (ProxyAuthenticate)msg.getHeader("PROXY-AUTHENTICATE");
					isProxy =true;
					break;
				} else if(header.getName().toUpperCase().equals("WWW-AUTHENTICATE")) {
					auth = (WWWAuthenticate)msg.getHeader("WWW-AUTHENTICATE");
					isProxy = false;
					break;
				}
			}
			// Authヘッダーが見つからない。
			if(auth == null) {
				return null;
			}

			DigestAuthentication calAuth = new DigestAuthentication();
			calAuth.calcAuthHeader(auth, username, password, requestUri, msg.getCSeq().getMethod());
			
			String authStr = auth.toString();
			// Authenticateを、Authorizationに置換する。
			if(isProxy) {
				authStr = Pattern.compile("Proxy-Authenticate",Pattern.CASE_INSENSITIVE).matcher(authStr).replaceFirst("Proxy-Authorization");
			} else {
				authStr = Pattern.compile("WWW-Authenticate",Pattern.CASE_INSENSITIVE).matcher(authStr).replaceFirst("Authorization");
			}
			return authStr;
		} catch (ParseException e) {
			tracer.println(TracerCode.ERROR, "Auth cal error.");
			LOG.error("Auth cal error.", e);
			return null;
		}
	}
	/**
	 * trueをセットするとjsEngine.receive()がsent-byのポートで待ち受け、<BR>
	 * falseにするとjsEngine.receive()がLocalポートで待ち受ける動作モードとなる。
	 * @param b true:sent-by false:local
	 */
	public void jsFunction_setReceiveMode(Boolean b) {
		varMap.put(SystemVariables.IS_RECEIVE_MODE.toString(), Boolean.valueOf(b).toString().toUpperCase());
		if(Boolean.valueOf(b)) {
			tracer.println(TracerCode.INFO, "Receive mode.");
		} else {
			tracer.println(TracerCode.INFO, "Local mode.");
		}
	}
	
	/**
	 * 必要なTransportを作成する
	 */
	private void createTransports() {
		sendTransport = this.createTransport();
		localTransport = this.createTransport();
		receiveTransport = this.createTransport();
		this.connectTransport();
	}
	/**
	 * Transportを作成する
	 * @return 作成されたTransport 
	 */
	private Transport createTransport() {
		Transport trans = null;
		if(param.getTransportType().equals("UDP")) {
			try {
				trans = new UDP();
				trans.setSoTimeout(Integer.parseInt(varMap.get(SystemVariables.TIMEOUT.toString())));
			} catch (SocketException e) {
				tracer.println(TracerCode.ERROR, "Create Socket error.");
				LOG.error("Exception", e);
			}
		} else {
			try {
				trans = new TCP();
				trans.setSoTimeout(Integer.parseInt(varMap.get(SystemVariables.TIMEOUT.toString())));
			} catch (SocketException e) {
				tracer.println(TracerCode.ERROR, "Create Socket error.");
				LOG.error("Exception", e);
			} catch (IOException e) {
				tracer.println(TracerCode.ERROR, "Create Socket error.");
				LOG.error("Exception", e);
			}
		}
		return trans;
	}
	/**
	 * Transportをコネクトする。
	 */
	private void connectTransport() {
		try {
			sendTransport.connect(param.getRemoteSocket());
			this.bindTransport();
		} catch (IOException e) {
			tracer.println(TracerCode.ERROR, "Connection error.");
			LOG.error("Exception", e);
		}
	}
	/**
	 * bindを行う。
	 * @throws IOException
	 */
	private void bindTransport() throws IOException {
		InetSocketAddress iSock = new InetSocketAddress(param.getLocalIP(), sendTransport.getReceivePort());
		localTransport.bind(param.getLocalSocket());
		try {
			receiveTransport.bind(iSock);
		} catch( BindException e) {
			receiveTransport = sendTransport;
		}
	}
	/**
	 * Transportをクローズする。
	 */
	private void closeTransport() {
		if(sendTransport != null) {
			sendTransport.close();
		}
		if(localTransport != null) {
			localTransport.close();
		}
		if(receiveTransport != null) {
			receiveTransport.close();
		}
	}
	/**
	 * 終了時に、Transportのクローズする。
	 */
	protected void finalize() throws Throwable {
		this.closeTransport();
	}
	
	/**
	 * パケットをシステム変数に保持する。
	 * @param packet パケット
	 * @param isReceive 受信か？
	 */
	private void setPacket(String packet, boolean isReceive) {
		if(isReceive) {
			varMap.put(SystemVariables.RECEIVE_PACKET.toString(), packet);
		} else {
			varMap.put(SystemVariables.SEND_PACKET.toString(), packet);			
		}
		// ORIGINAL_PACKETがNULLであれば、保持する。
		if(varMap.get(SystemVariables.ORIGINAL_PACKET.toString())  == null) {
			varMap.put(SystemVariables.ORIGINAL_PACKET.toString(), packet);
		}
		varMap.put(SystemVariables.CURRENT_PACKET.toString(), packet);
	}

}
