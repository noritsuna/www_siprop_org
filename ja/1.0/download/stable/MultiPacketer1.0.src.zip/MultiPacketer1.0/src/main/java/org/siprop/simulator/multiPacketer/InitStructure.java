/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

import org.apache.log4j.Category;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.siprop.simulator.multiPacketer.tracer.ConsoleTracer;
import org.siprop.simulator.multiPacketer.tracer.Tracer;

/**
 * 初期化パラメータを保持するための構造体クラス。
 * @author noritsuna
 * $Id$
 */
public class InitStructure extends ScriptableObject {

    /**
	 * シリアライズ用ID
	 */
	private static final long serialVersionUID = 5228392200890640699L;


	/**
     * log4j アクセスポイント。
     */
    protected static Category LOG = Category.getInstance(InitStructure.class);
    
    
    /**
     * パケットログ表示用
     */
	private Tracer tracer;
	
	/**
	 * リモートIP文字列
	 */
	private String remoteIPStr = "";
	/**
	 * リモートポート
	 */
	private int remotePort;
	/**
	 * リモートSocketAddress
	 */
	private InetSocketAddress remoteSocket;
	/**
	 * リモートIP
	 */
	private InetAddress remoteIP;
	
	/**
	 * ローカルIP文字列
	 */
	private String localIPStr = "";
	/**
	 * ローカルポート
	 */
	private int localPort;
	/**
	 * ローカルSocketAddress
	 */
	private InetSocketAddress localSocket;
	/**
	 * ローカルIP
	 */
	private InetAddress localIP;
	
	/**
	 * トランスポートタイプ
	 */
	private String transportType = "";

	/**
	 * IP種別
	 */
	private String ipType = "";
	/**
	 * IPv6か？
	 */
	private boolean isV6;
	

	/**
	 * JSEngineが使用する Scriptableのスコープ<BR>
	 * マルチスコープには非対応。
	 */
	private Scriptable scope;
	/**
	 * JSEngineが使用する Context<BR>
	 * マルチContextには非対応。
	 */
	private Context context;


	/**
	 * コンストラクター
	 */
	public InitStructure() { }
	public InitStructure(Tracer tracer) {
		this.tracer = tracer;
	}
	/**
	 * JavaScript側で呼び出された時用のコンストラクター
	 */	
	public void jsConstructor() { }
	/**
	 * ScriptableObjectに必要なメソッドで、クラスの名称を返す。
	 */
	public String getClassName() {
		return "InitStructure";
	}
	
	/**
	 * IP種別を取得する
	 * @return IP種別
	 */
	public String getIpType() {
		return ipType;
	}
	/**
	 * IP種別をセットする
	 * @param ipType IP種別
	 */
	public void setIpType(String ipType) {
		this.ipType = ipType;
	}

	/**
	 * ローカルIPを取得する
	 * @return ローカルIP文字列
	 */
	public String getLocalIP() {
		return localIPStr;
	}
	/**
	 * ローカルIPをセットする
	 * @param localIP ローカルIP文字列
	 */
	public void setLocalIP(String localIP) {
		this.localIPStr = localIP;
	}
	
	/**
	 * ローカルポートを取得する
	 * @return ローカルポート
	 */
	public int getLocalPort() {
		return localPort;
	}
	/**
	 * ローカルポートをセットする
	 * @param localPort ローカルポート
	 */
	public void setLocalPort(int localPort) {
		this.localPort = localPort;
	}
	/**
	 * リモートIPを取得する
	 * @return リモートIP文字列
	 */
	public String getRemoteIP() {
		return remoteIPStr;
	}
	/**
	 * リモートIPをセットする
	 * @param remoteIP リモートIP文字列
	 */
	public void setRemoteIP(String remoteIP) {
		this.remoteIPStr = remoteIP;
	}
	/**
	 * リモートポートを取得する
	 * @return リモートポート
	 */
	public int getRemotePort() {
		return remotePort;
	}
	/**
	 * リモートポートをセットする
	 * @param remotePort リモートポート
	 */
	public void setRemotePort(int remotePort) {
		this.remotePort = remotePort;
	}
	/**
	 * トランスポートタイプを取得する
	 * @return トランスポートタイプ
	 */
	public String getTransportType() {
		return transportType;
	}
	/**
	 * トランスポートタイプをセットする
	 * @param transportType トランスポートタイプ
	 */
	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}
	/**
	 * ローカルSocketAddressを取得する
	 * @return ローカルSocketAddress
	 */
	public InetSocketAddress getLocalSocket() {
		return localSocket;
	}
	/**
	 * ローカルSocketAddressをセットする
	 * @param localSocket ローカルSocketAddress
	 */
	public void setLocalSocket(InetSocketAddress localSocket) {
		this.localSocket = localSocket;
	}
	/**
	 * リモートSocketAddressを取得する
	 * @return リモートSocketAddress
	 */
	public InetSocketAddress getRemoteSocket() {
		return remoteSocket;
	}
	/**
	 * リモートSocketAddressをセットする
	 * @param remoteSocket リモートSocketAddress
	 */
	public void setRemoteSocket(InetSocketAddress remoteSocket) {
		this.remoteSocket = remoteSocket;
	}
	
	/**
	 * IPv6かどうか？
	 * @return IPv6=true
	 */
	public boolean isV6() {
		return isV6;
	}
	/**
	 * Tracer を取得する
	 * @return Tracer
	 */
	public Tracer getTracer() {
		if(tracer == null) {
			tracer = new ConsoleTracer();
		}
		return tracer;
	}
	/**
	 * JSEngineが使用する Contextを取得する
	 * @return Context
	 */
	public Context getContext() {
		return context;
	}
	/**
	 * JSEngineが使用する Contextをセットする
	 * @param context Context
	 */
	public void setContext(Context context) {
		this.context = context;
	}
	/**
	 * JSEngineが使用する Scriptableのスコープを取得する
	 * @return Scriptableのスコープ
	 */
	public Scriptable getScope() {
		return scope;
	}
	/**
	 * JSEngineが使用する Scriptableのスコープをセットする
	 * @param context Context
	 */
	public void setScope(Scriptable scope) {
		this.scope = scope;
	}
	
	
	/**
	 * セットされた各パラメータが正当かどうかチェックする
	 * @return 正しい=true
	 */
	public boolean validator() {
		//[トランスポートタイプ:TCP|UDP] [IPタイプ:IP4|IP6]
		
		// IPv4かIPv6かのチェック
		if(ipType.equals("IP4") || ipType.equals("IP6")) {
			if(ipType.equals("IP6")) {
				this.isV6 = true;
			}
		} else {
			return false;
		}
		
		// FQDNまたはIPが、正当であるかチェック
		try {
			if(this.isV6) {
				localIP = Inet6Address.getByName(localIPStr);
			} else {
				localIP = Inet4Address.getByName(localIPStr);				
			}
			localSocket = new InetSocketAddress(localIP, localPort);
		} catch(Exception e) {
			return false;
		}
			
		try {
			if(this.isV6) {
				remoteIP = Inet6Address.getByName(remoteIPStr);
			} else {
				remoteIP = Inet4Address.getByName(remoteIPStr);				
			}
			remoteSocket = new InetSocketAddress(remoteIP, remotePort);
		} catch (UnknownHostException e) {
			return false;
		}

		// トランスポートタイプが正当であるかチェック
		if(!transportType.equals("TCP") && !transportType.equals("UDP")) {
			return false;
		}
		
		return true;
	}

}
