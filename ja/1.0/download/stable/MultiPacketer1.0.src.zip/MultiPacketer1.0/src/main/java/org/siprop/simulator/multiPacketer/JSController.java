/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

import org.apache.log4j.Category;
import org.apache.log4j.PropertyConfigurator;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;
import org.mozilla.javascript.ScriptableObject;
import org.siprop.simulator.multiPacketer.tracer.ConsoleTracer;
import org.siprop.simulator.multiPacketer.tracer.Tracer;
import org.siprop.simulator.multiPacketer.tracer.TracerCode;

/**
 * JavaScriptを操作するためのクラス
 * @author noritsuna
 * $Id$
 */
public class JSController {

    /**
     * log4j アクセスポイント。
     */
    protected static Category LOG = Category.getInstance(JSController.class);
    
    /**
     * パケットログ表示用
     */
	private Tracer tracer;
	
	/**
	 * Propertyファイル名
	 */
    private final static String DEFAULT_CONFIGFILE = "multipacket.properties";
    
    /**
     * Property値
     */
    private static Properties DEFAULT_PROP = new Properties();   
    
    /**
     * コンストラクター
     */
	public JSController() {
		this.tracer = new ConsoleTracer();
	}
    /**
     * コンストラクター
     * @param tracer トレーサー
     */
	public JSController(Tracer tracer) {
		this.tracer = tracer;
	}
	/**
	 * スクリプトを直接渡して実行するメソッド
	 * @param js 実行するスクリプト
	 * @return 実行結果
	 */
	public ExecCode execByText(String js) {
		return this.execByText(js, new InitStructure(this.tracer));		
	}
	/**
	 * スクリプトを直接渡して実行するメソッド
	 * @param js 実行するスクリプト
	 * @param init 初期化用パラメータ
	 * @return 実行結果
	 */
	public ExecCode execByText(String js, InitStructure init) {
		return this.exec(js, init, ExecMode.TEXT);		
	}
	/**
	 * スクリプトファイルを指定して実行するメソッド
	 * @param js 実行するスクリプトファイル
	 * @return 実行結果
	 */
	public ExecCode execByFile(File js) {
		return this.execByFile(js, new InitStructure(this.tracer));		
	}
	/**
	 * スクリプトファイルを指定して実行するメソッド
	 * @param js 実行するスクリプトファイル
	 * @param init 初期化用パラメータ
	 * @return 実行結果
	 */
	public ExecCode execByFile(File js, InitStructure init) {
		return this.exec(js, init, ExecMode.FILE);		
	}
	/**
	 * 実行用メソッド
	 * @param obj 実行するスクリプト
	 * @param init 初期化用パラメータ
	 * @param mode 実行モード
	 * @return 実行結果
	 */
	private ExecCode exec(Object obj, InitStructure init, ExecMode mode) {
		// プロパティーの読み出し
		this.loadProperties();
		
		// 初期化用のパラメータを設定する
		if(!init.validator()) {
			File initFile = new File(DEFAULT_PROP.getProperty("js.init", "./js/init.js"));
			if(initFile != null) {				
				init = this.getInitStructureByJS(initFile);
				
				if(!init.validator()) {
					tracer.println(TracerCode.ERROR, "Not Load Init Parameters.");
					return ExecCode.ERROR;
				}
			}
		}

		Context cx = Context.enter();
		try {

			Scriptable scope = cx.initStandardObjects();

			// JSEngineを初期化する
			init.setContext(cx);
			init.setScope(scope);
			ScriptableObject.defineClass(scope, InitStructure.class);
			ScriptableObject.defineClass(scope, JSEngine.class);
			Object[] arg = { init };
			Scriptable jsEngine = cx.newObject(scope, "JSEngine", arg);
			scope.put("jsEngine", scope, jsEngine);
			
			
			// 実行
			Object result = null;
			switch(mode) {
				case FILE :
					result = this.runByFile((File)obj, init, cx, scope);
					break;
				case TEXT:
					result = this.runByText((String)obj, init, cx, scope);
					break;
				default:
					return ExecCode.ERROR;
			}
		
		} catch (ClassCastException e) {
			e.printStackTrace();
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
			return ExecCode.ERROR;
		} catch (IOException e) {
			e.printStackTrace();
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
			return ExecCode.ERROR;
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
			return ExecCode.ERROR;
		} catch (InstantiationException e) {
			e.printStackTrace();
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
			return ExecCode.ERROR;
		} catch (InvocationTargetException e) {
			e.printStackTrace();
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
			return ExecCode.ERROR;
		} catch (Exception e) {
			e.printStackTrace();
			tracer.println(TracerCode.ERROR, e.toString());
			LOG.error("Exception", e);
			return ExecCode.ERROR;
		} finally {
			Context.exit();
		}
		return ExecCode.OK;
	}
	/**
	 * スクリプトを直接渡して実行する
	 * @param js 実行するスクリプト
	 * @param init 初期化用パラメータ
	 */
	private Object runByText(String js, InitStructure init, Context cx, Scriptable scope) {
			
		// 実行。
        return cx.evaluateString(scope, js, "<cmd>", 1, null);
			
	}
	/**
	 * スクリプトファイルを指定して実行する
	 * @param file 実行するスクリプトファイル
	 * @param init 初期化用パラメータ
	 * @throws IOException 
	 */
	private Object runByFile(File file, InitStructure init, Context cx, Scriptable scope) throws IOException {
		// JavaScriptファイルを読み込む
		Script baseScript = JSController.loadScript(file, cx);
		// 実行。
		return baseScript.exec(cx, scope);		
	}
	
	/**
	 * スクリプトファイルのロード
	 * @param file スクリプトファイル
	 * @param cx コンテキスト
	 * @return コンパイルされたスクリプト
	 * @throws IOException
	 */
	public static Script loadScript(File file, Context cx) throws IOException {
		InputStream is = new FileInputStream(file);
		try {
			return loadScript(is, file.getName(), cx);
		} finally {
			is.close();
		}
	}

	/**
	 * スクリプトファイルのロード
	 * @param is スクリプトファイルストリーム
	 * @param scriptName スクリプトファイル名
	 * @param cx コンテキスト
	 * @return コンパイルされたスクリプト
	 * @throws IOException
	 */
	public static Script loadScript(InputStream is, String scriptName, Context cx) throws IOException {
		BufferedReader reader;
		reader = new BufferedReader(new InputStreamReader(is));
		return cx.compileReader(reader, scriptName, 1, null);
	}

	/**
	 * JavaScriptファイルから、初期化用のパラメータを取得する。
	 * @param scriptFile スクリプトファイル
	 * @return 初期化パラメータ
	 */
	private InitStructure getInitStructureByJS(File scriptFile) {
		InitStructure init = new InitStructure(this.tracer);
	    Context cx = Context.enter();
	    try {

			Script baseScript = JSController.loadScript(scriptFile, cx);
			Scriptable scope = cx.initStandardObjects();
			baseScript.exec(cx, scope);

			// 各パラメータの取得と設定
			Object remoteIP = scope.get("remoteIP", scope);
	        if (remoteIP != Scriptable.NOT_FOUND) {
	        	init.setRemoteIP(Context.toString(remoteIP));
	        }	        
			Object remotePort = scope.get("remotePort", scope);
	        if (remotePort != Scriptable.NOT_FOUND) {
	        	init.setRemotePort((int)Context.toNumber(remotePort));
	        }
	        
			Object localIP = scope.get("localIP", scope);
	        if (localIP != Scriptable.NOT_FOUND) {
	        	init.setLocalIP(Context.toString(localIP));
	        }
			Object localPort = scope.get("localPort", scope);
	        if (localPort != Scriptable.NOT_FOUND) {
	        	init.setLocalPort((int)Context.toNumber(localPort));
	        }
	        
			Object transportType = scope.get("transportType", scope);
	        if (transportType != Scriptable.NOT_FOUND) {
	        	init.setTransportType(Context.toString(transportType));
	        }

			Object ipType = scope.get("ipType", scope);
	        if (ipType != Scriptable.NOT_FOUND) {
	        	init.setIpType(Context.toString(ipType));
	        }	        

		} catch (IOException e) {
        	tracer.println(TracerCode.WARNING, "InitStructure Load Error.\n" + e.toString());
        	LOG.warn("InitStructure Load Error.", e);
	    } finally {
	        Context.exit();
	    }
	    return init;
	}
	
    /**
     * プロパティーファイルの設定を読み出す
     */
    private void loadProperties() {
        File configfile = new File(System.getProperty("multipacket.config", DEFAULT_CONFIGFILE));

        if (configfile.canRead()) {
            try {
            	// propertiesの読み出し
                DEFAULT_PROP.load(new FileInputStream(configfile));

                // log4jの設定
                String log4j = DEFAULT_PROP.getProperty("multipacket.log4j", "true");
                if (Boolean.valueOf(log4j).booleanValue()){
                    PropertyConfigurator.configure(DEFAULT_PROP);
                }
                
            } catch(IOException e) {
            	tracer.println(TracerCode.WARNING, "Not load config file.\n" + e.toString());
                LOG.warn("Not load config file: " + DEFAULT_CONFIGFILE, e);
            }
        } else {
        	tracer.println(TracerCode.WARNING, "Not read config file.\n");
            LOG.warn("Not read config file: " + DEFAULT_CONFIGFILE);
        }
    }

}
