/*
 * Copyright 2006 SIProp Project and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.siprop.simulator.multiPacketer.transport;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
/**
 * UDPTransportの実装。
 * @author noritsuna
 *
 */
public class UDP implements Transport {
	
    static final int DEFAULT_BUFFER_SIZE = 65536;

	DatagramSocket socket;
	int timeout = 32000;
	
	public UDP() throws SocketException {
		socket = new DatagramSocket();
		this.setSocketParam();
	}
	/**
	 * Socketにパラメータを設定する。
	 * @throws SocketException
	 */
	private void setSocketParam() throws SocketException {
		socket.setSendBufferSize(DEFAULT_BUFFER_SIZE);
		socket.setReuseAddress(true);
	}
	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#setSoTimeout(int)
	 */
	public void setSoTimeout(int timuout) throws SocketException {
		socket.setSoTimeout(timuout);
		this.timeout = timuout;
	}


	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#close()
	 */
	public void close() {
		if(socket != null) {
			socket.close();
		}
	}

	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#send(InetSocketAddress,String)
	 */
	public void send(InetSocketAddress addr, String packetStr) throws IOException {
		DatagramPacket sendPacket = new DatagramPacket(packetStr.getBytes(), packetStr.length(), addr);
		socket.send(sendPacket);
	}

	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#receive()
	 */
	public String receive() throws IOException {
		DatagramPacket receivePacket = new DatagramPacket(new byte[DEFAULT_BUFFER_SIZE], DEFAULT_BUFFER_SIZE);
		socket.receive(receivePacket);
		return new String(receivePacket.getData(), 0, receivePacket.getLength());
	}
	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#connect(InetSocketAddress)
	 */
	public void connect(InetSocketAddress remoteAddr) throws IOException {
		//socket.connect(remoteAddr);
	}

	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#bind(InetSocketAddress)
	 */
	public void bind(InetSocketAddress localAddr) throws IOException {
		this.close();
		socket = new DatagramSocket(localAddr);
		this.setSocketParam();
		this.setSoTimeout(timeout);
	}
	/**
	 * @see org.siprop.simulator.multiPacketer.transport.Transport#getReceivePort()
	 */
	public int getReceivePort() {
		if(socket == null) {
			return 5060;
		} else {
			return socket.getLocalPort();
		}
	}
}
