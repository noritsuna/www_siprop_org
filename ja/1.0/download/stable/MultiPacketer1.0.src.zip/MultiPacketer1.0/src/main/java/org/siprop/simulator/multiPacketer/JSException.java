package org.siprop.simulator.multiPacketer;

import org.mozilla.javascript.EvaluatorException;

/**
 * 本アプリ用Exception
 * @author noritsuna
 *
 */
public class JSException extends EvaluatorException {

	    /**
		 * シリアライズ用ID
		 */
		private static final long serialVersionUID = 762971038725257482L;

		public JSException(String detail) {
	        super(detail);
	    }
}
