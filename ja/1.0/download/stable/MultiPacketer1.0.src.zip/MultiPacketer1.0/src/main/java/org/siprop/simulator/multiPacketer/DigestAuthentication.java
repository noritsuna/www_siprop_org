package org.siprop.simulator.multiPacketer;

import gov.nist.javax.sip.address.GenericURI;
import gov.nist.javax.sip.header.AuthenticationHeader;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;

import javax.sip.address.URI;

import org.apache.log4j.Category;

/**
 * Digest認証用クラス<BR>
 * 非常に簡易的な実装のみ行っている。
 * @author noritsuna
 *
 */
public class DigestAuthentication {
	
    /**
     * log4j アクセスポイント。
     */
    protected static Category LOG = Category.getInstance(DigestAuthentication.class);
    
    /**
     * 生成されるダイジェスト (または「ハッシュ」) 長さ.
     **/
    private final static int HASHLEN =16;

    /**
     * 生成されるダイジェスト (または「ハッシュ」) を16進文字列表現する場合の長さ.
     **/
    private final static int HASHHEXLEN = 32;

    /**
     * responseを計算して、Authヘッダーを返す。
     * @param auth AuthenticationHeader
     * @param username ユーザ名
     * @param password パスワード
     * @param uriStr Request-URI
     * @param method メソッド名
     * @return responseパラメータ付きのAuthヘッダー
     * @throws ParseException
     */
    public AuthenticationHeader calcAuthHeader(AuthenticationHeader auth, String username, String password, String uriStr, String method) throws ParseException {
		String nc = this.createNc();
		String cnonce = this.createCnonce();
		URI uri = new GenericURI(uriStr);
		
		String resp = this.createResponse(username, password, auth.getRealm(), 
				                           method, uri, 
				                           auth.getNonce(), nc, cnonce, auth.getQop());
		auth.setURI(uri);
		auth.setUsername(username);
        if(auth.getQop() != null && !auth.getQop().equals("")) {
			auth.setParameter("nc", nc);
			auth.setCNonce(cnonce);
        }
		auth.setResponse(resp);
    	return auth;
    }

    /**
     * 各パラメータからResponseを生成する。
     * @param username ユーザ名
     * @param password パスワード
     * @param realm realm
     * @param method メソッド名
     * @param uri Request-URI
     * @param nonce nonce値：サーバが生成するランダム値
     * @param nc nc値：認証回数
     * @param cnonce cnonce値：クライアントが生成するランダム値
     * @param qop qop
     * @return
     */
    private String createResponse(String username, String password, String realm,
                                   String method, URI uri,
                                   String nonce, String nc, String cnonce, String qop) {

        byte[] ha1 = new byte[HASHLEN];
        byte[] ha1hex = new byte[HASHHEXLEN];
        byte[] ha2 = new byte[HASHLEN];
        byte[] ha2hex = new byte[HASHHEXLEN];
        byte[] response = new byte[HASHLEN];
        byte[] responsehex = new byte[HASHHEXLEN];
        
        try {
        	// H(A1)
            MessageDigest md5 = MessageDigest.getInstance("md5");
            md5.update(username.getBytes());
            md5.update(":".getBytes());
            md5.update(realm.getBytes());
            md5.update(":".getBytes());
            md5.update(password.getBytes());
            ha1 = md5.digest();
            ha1hex = convertHex(ha1);
        	
            // H(A2)
            md5 = MessageDigest.getInstance("md5");
            md5.update(method.getBytes());
            md5.update(":".getBytes());
            md5.update(uri.toString().getBytes());
            ha2 = md5.digest();
            ha2hex = convertHex(ha2);

            // response
            md5 = MessageDigest.getInstance("md5");
            md5.update(ha1hex);
            md5.update(":".getBytes());
            md5.update(nonce.getBytes());
            md5.update(":".getBytes());
            if(qop != null && !qop.equals("")) {
                md5.update(nc.getBytes());
                md5.update(":".getBytes());
                md5.update(cnonce.getBytes());
	            md5.update(qop.getBytes());
	            md5.update(":".getBytes());
            }
            md5.update(ha2hex);
            response = md5.digest();
            responsehex = convertHex(response);
            
        } catch (NoSuchAlgorithmException e) {
            LOG.error("Algorithm no such.", e);
            return null;
        }        
        return new String(responsehex);
    }
    /**
     * cnonceを生成する。
     * @return 生成されたcnonce
     */
    private String createCnonce() {
    	return String.valueOf(System.currentTimeMillis());
    }
    /**
     * nc値を生成する。
     * @return 生成されたnc
     */
    private String createNc() {
    	// 本来であれば、カウントアップするべき。
    	return "00000001";
    }
    /**
     * ハッシュ値をHexに変換する
     * @param bin ハッシュ値
     * @return Hexに変換された値
     */
    private byte[] convertHex(byte[] bin) {
        byte[] hex = new byte[HASHHEXLEN];
        for(int i = 0; i < HASHLEN; i++) {
            int j = ((bin[i] >> 4) & 0xf);
            
            if (j <= 9) {
                hex[i*2] = (byte)(j + 0x30);
            } else {
                hex[i*2] = (byte)(j + 0x61 - 10);
            }
            
            j = (bin[i] & 0xf);
            
            if (j <= 9) {
                hex[i*2+1] = (byte)(j + 0x30);
            } else {
                hex[i*2+1] = (byte)(j + 0x61 - 10);
            }
        }
        return hex;
    }
}
