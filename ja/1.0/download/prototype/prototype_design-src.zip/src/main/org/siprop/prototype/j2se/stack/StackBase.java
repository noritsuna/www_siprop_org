package org.siprop.prototype.j2se.stack;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.transport.Transport;

/**
 * Stackの基底クラス<BR>
 * これを継承して、Stackを実装する。
 * @author noritsuna
 *
 */
public abstract class StackBase implements Stack {

	
	public void doDispatch(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

	/**
	 * Transportを取得する。
	 * @return
	 */
	public abstract Transport getTransport();
	/**
	 * Transportをセットする。
	 * @param trans Transport
	 */
	public abstract void setTransport(Transport trans);
	/**
	 * Transportを作成する。
	 */
	public abstract Transport createTransport();
	
	/**
	 * 自Packetかを判定する。
	 * @param packet
	 * @return
	 */
	public abstract boolean isPacket(byte[] packet);
	
	/**
	 * Packetをparseする。
	 * @param packet
	 */
	public abstract void parse(byte[] packet);
	
	
}
