package org.siprop.prototype.j2se.ua;

import org.siprop.prototype.j2se.GBean;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.message.impl.SIPPacket;
import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * 制御モジュールを示すマーカークラス<BR>
 * @author noritsuna
 *
 */
public interface UA extends GBean {

}
