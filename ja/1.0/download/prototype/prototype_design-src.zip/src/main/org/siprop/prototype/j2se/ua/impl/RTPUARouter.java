package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.ua.UARouterBase;
import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * RTP用のRouterクラス。
 * 現在は、存在するだけで何もしない。コーデック変換やDTMF操作が導入されたときに必要となる。
 * @author noritsuna
 *
 */
public class RTPUARouter extends UARouterBase {

	public RTPUARouter(B2BUAManagerBase bean) {
		super(bean);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public UAState getState() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}
	
	
	
	
	

}
