package org.siprop.prototype.j2se.transport;

import java.net.InetAddress;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.UA;

/**
 * 外部ノードの送信先を管理するためのクラス<BR>
 * 下記の2点の機能がある。<BR>
 * ・StackやUAに対して、送信先を返す<BR>
 * ・B2BUAに対して、UAがinnerかouterかを返す
 * 
 * @author noritsuna
 *
 */
public interface Resolver {

	/**
	 * MessageContextより、innerであるかをチェックする
	 * @param msgContext
	 * @return
	 */
	public boolean isInner(MessageContext msgContext);
	/**
	 * UAクラスより、innerであるかをチェックする
	 * @param ua
	 * @return
	 */
	public boolean isInner(UA ua);
	
	/**
	 * MessageContextから、送信先情報を取得する。
	 * @param msgContext
	 * @return
	 */
	public Peer getPeer(MessageContext msgContext);
	/**
	/**
	 * RequestURIやContactから、送信先情報を取得する。
	 * @param uri
	 * @return
	 */
	public Peer getPeer(String uri);
}
