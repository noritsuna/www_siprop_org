package org.siprop.prototype.j2se.transport.impl;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.transport.Transport;

public class UDPTransport implements Transport {

	B2BUAManagerBase b2buaCtrl;
	
	public void send(MessageContext msgSet) {
		//TransportかB2BUAか
	}
	
	public void receive(MessageContext msgSet) { 
		b2buaCtrl.doDispatch(msgSet);
	}
}
