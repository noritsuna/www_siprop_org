package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.UAManagerBase;
import org.siprop.prototype.j2se.ua.UARouterBase;
import org.siprop.prototype.j2se.ua.UA;
import org.siprop.prototype.j2se.ua.UAModuleBase;
import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * XXX社製UAModule用モジュール
 * @author noritsuna
 *
 */
public class XXXUAModuleImpl extends UAModuleBase {



	public XXXUAModuleImpl(UAManagerBase bean) {
		super(bean);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public void doDispatch(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

	@Override
	public void incommingINVITE(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void incommingRESPONSE(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void outgoingINVITE(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void outgoingRESPONSE(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void call() {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void bye() {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void hold() {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void forward() {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public void etc() {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	public UAState getState() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
