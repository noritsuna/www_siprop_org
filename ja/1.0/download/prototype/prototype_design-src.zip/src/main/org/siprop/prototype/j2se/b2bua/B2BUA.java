package org.siprop.prototype.j2se.b2bua;

import org.siprop.prototype.j2se.GBean;

/**
 * B2BUAを示すマーカークラス
 * @author noritsuna
 *
 */
public interface B2BUA extends GBean {

}
