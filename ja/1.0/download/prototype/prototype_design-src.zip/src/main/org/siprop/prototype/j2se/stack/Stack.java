package org.siprop.prototype.j2se.stack;

import org.siprop.prototype.j2se.GBean;
import org.siprop.prototype.j2se.transport.Transport;

/**
 * Stackを示すマーカークラス
 * 
 * @author noritsuna
 *
 */
public interface Stack extends GBean {
	

}
