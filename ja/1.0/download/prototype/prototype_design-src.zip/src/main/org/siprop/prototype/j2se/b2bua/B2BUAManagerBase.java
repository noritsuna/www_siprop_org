package org.siprop.prototype.j2se.b2bua;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;

import org.siprop.prototype.j2se.GBean;
import org.siprop.prototype.j2se.b2bua.util.UAPair;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.transport.Resolver;
import org.siprop.prototype.j2se.ua.UARouter;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * B2BUAとして、動作させるためのコントロール用クラスの基底クラス<BR>
 * 全体で1つのみ存在し、inner,outerの2つのUAを管理する存在となる。
 * @author noritsuna
 *
 */
public class B2BUAManagerBase implements B2BUA {
	
	
	protected UARouter uaRouter;
	
	protected Resolver resolver;

	/**
	 * TransportやStackから、コールバックされるメソッド
	 */
	public void doDispatch(MessageContext msgSet) {
		this.start(msgSet);
	}
	
	/**
	 * 具体的な処理開始するメソッド
	 *
	 */
	protected void start(MessageContext msgSet) {
		// UAControlSet用のkeyを取得する。
		String key = this.createB2BUACode(msgSet);
		
		// UAPair を取得する。
		UAPair uaSet = this.getUAPair(key);
		
		// 新規であれば、作成する
		if(uaSet == null) {
			uaSet = this.createUAPair(msgSet);
		}
			
		// 処理をUARouter or UAManager に、委譲する。
		this.dispatchRouter(msgSet, uaSet);
	}
	
	/**
	 * KeyとUAPairを保持する。
	 */
	protected Hashtable<String, UAPair> uaPairTable;
	
	
	
	/**
	 * MessageSetから、本クラス内でUAPairを特定する一意のコードを生成する。
	 * @param msgSet
	 * @return
	 */
	public String createB2BUACode(MessageContext msgSet) {
		//TODO まだ、内容未定。DialogかBranchくらいしか使えないはず。
		//Strategyパターンとかで入れ替え可能にするべき。
		throw new NotImplementedException();
	}

	/**
	 * MessageContext から、適切なUAManagerを選定し、UAPairを作成する。
	 * @param msgSet
	 * @return
	 */
	protected UAPair createUAPair(MessageContext msgSet) {
		//TODO UAControl を作成する。
		
		//ここで、スクリプト処理を行う。どのUAControlを作成するべきかなど。
		//とても複雑な処理となるはず。
		//Strategyパターンとかで入れ替え可能にするべき。
		
		throw new NotImplementedException();		
	}
	
	/**
	 * UAPairを取得する
	 * @param key
	 * @return
	 */
	protected UAPair getUAPair(String key) {
		return uaPairTable.get(key);
	}
	/**
	 * UAPairをセットする。
	 * @param key
	 * @param uaSet
	 */
	protected void setUAPair(String key, UAPair uaSet) {
		uaPairTable.put(key, uaSet);
	}
	/**
	 * UAManagerPairとMessageSetから、適切なRouterへDispatchする。
	 * @param msgSet
	 * @param uaSet
	 */
	protected void dispatchRouter(MessageContext msgSet, UAPair uaSet) {
		//TODO 適切な判断条件。　まだ、未定。
		//Routerへ。

		//この渡された先でスクリプト処理を行う。どのUAManagerを作成するべきかなど。
		//それの結果により、changeUAManagerPair()などを用いて、コントロールを行う。
		//uaSet.innerUA.doDispatch(msgSet);
		
	}
	
	
	
	
	//転送などでは、Dialogをまたぐため、B2BUAのUAManagerPairコントロールするための外部用API.
	/**
	 * createB2BUACode(MessageContext msgSet)から、得たキーからUAManagerを取得する、外部用API
	 */
	public UARouter getUAManagerByCode(String code) {
		return null;
	}
	/**
	 * UAManagerPairの内容を変更する、外部用API。
	 * @param uaManager
	 */
	public void changeUAManagerPair(String code, UARouter uaCtrl) {
		
	}
	
}
