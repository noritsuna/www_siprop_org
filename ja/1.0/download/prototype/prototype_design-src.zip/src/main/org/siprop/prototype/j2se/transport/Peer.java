package org.siprop.prototype.j2se.transport;

import java.net.InetAddress;

/**
 * 接続先情報を保持する構造体
 * @author noritsuna
 *
 */
public interface Peer {
	
    /**
     * 接続先のアドレスを取得する。<BR>
     * IPアドレスやRequestURIなどを想定。
     */
    public String getAddress();
    /**
     * 接続先のポート番号を取得する。
     */
    public int getPort();	
    
    

}
