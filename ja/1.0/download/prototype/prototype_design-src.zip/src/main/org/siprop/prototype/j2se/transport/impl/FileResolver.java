package org.siprop.prototype.j2se.transport.impl;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.transport.Peer;
import org.siprop.prototype.j2se.transport.Resolver;
import org.siprop.prototype.j2se.ua.UA;

/**
 * 設定ファイルから、読み込むことを想定したResolver。
 * @author noritsuna
 *
 */
public class FileResolver implements Resolver {

	public boolean isInner(MessageContext msgContext) {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}

	public boolean isInner(UA ua) {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}

	public Peer getPeer(MessageContext msgContext) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public Peer getPeer(String uri) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
