package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * XXX社製UAState用モジュール
 * @author noritsuna
 *
 */
public class XXXUAStateImpl extends UAState {

}
