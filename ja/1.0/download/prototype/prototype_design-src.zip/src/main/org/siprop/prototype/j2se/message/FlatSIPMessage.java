package org.siprop.prototype.j2se.message;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * パケットを共通化したメッセージ
 * @author noritsuna
 *
 */
public abstract class FlatSIPMessage {
	
	/**
	 * テキストタイプのメッセージ
	 */
	protected String messageStr;
	/**
	 * バイナリタイプのメッセージ
	 */
	protected byte[] messageByte;
	

	/**
	 * FlatSIPMessageから、具体的なPacketを生成する。
	 * @return
	 */
	public abstract byte[] createPacket();
	
}
