package org.siprop.prototype.j2se.ua;

import org.siprop.prototype.j2se.Router;

/**
 * UARouterを示すマーカークラス
 * @author noritsuna
 *
 */
public interface UARouter extends UA, Router {

}
