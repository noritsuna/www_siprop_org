package org.siprop.prototype.j2se.stack.util;

import java.util.ArrayList;
import org.siprop.prototype.j2se.stack.Stack;

/**
 * 同一ダイアログ上で動作するStackを保持するためのクラス<BR>
 * Forking時に使用する。
 * @author noritsuna
 *
 */
public class StackList {
	
	/**
	 * インスタンス化したStackのリスト
	 */
	protected ArrayList<Stack> stackList;
	
	public StackList() {
		//Syncを忘れずに。
		this.stackList = new ArrayList<Stack>();
	}
	


	/**
	 * Stackのリストを取得する。
	 * @return
	 */
	public ArrayList<Stack> getStackList() {
		return stackList;
	}
	/**
	 * Stackを追加する。
	 * @param stack
	 */
	public void setStack(Stack stack) {
		stackList.add(stack);
	}

}
