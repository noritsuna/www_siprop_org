package org.siprop.prototype.j2se.ua;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import org.siprop.prototype.j2se.Filter;
import org.siprop.prototype.j2se.GBean;
import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.b2bua.util.UAPair;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.util.UAModuleList;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * 制御モジュール(UA)へのルーティングを行う基底クラス<BR>
 * 全体で1つのみ存在する。<BR>
 * 全体的な大枠のScript部に相当するものであるが、現在は、設定ファイルなどによる設定は不可能である。
 * @author noritsuna
 *
 */
public abstract class UARouterBase implements UARouter {
	
	protected B2BUAManagerBase b2bUACtrl;
	
	protected List<UASetRouterBase> uaSetList;
	
	protected List<Filter> filterList;
	
	
	public UARouterBase(B2BUAManagerBase bean) {
		this.b2bUACtrl = bean;
	}

	
	/**
	 * B2BUAManagerBase から、Dispatchされるメソッド
	 */
	public void doDispatch(MessageContext msgSet) {
		this.start(msgSet);
	}
	
	/**
	 * 具体的な処理開始するメソッド
	 * @param msgSet
	 */
	protected void start(MessageContext msgSet) {
		
		//MessageContextに、UAManagerがあるかどうかで動作をかえる？
		
	}		
		

}
