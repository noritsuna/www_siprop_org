package org.siprop.prototype.j2se.ua;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * 制御モジュールを複数個束ねたセットとしてルーティングを行う基底クラス<BR>
 * UAManagerとセットで用いられる。<BR>
 * UAModule間を制御するScript部に相当するものであるが、現在は、設定ファイルなどによる設定は不可能である。
 * 
 * @author noritsuna
 *
 */
public abstract class UASetRouterBase implements UARouter {
	
	
	protected UAManagerBase uaManager;
	

	public UASetRouterBase(B2BUAManagerBase bean) {
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public UAState getState() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
