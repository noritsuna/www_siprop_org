package org.siprop.prototype.j2se.message;

import org.siprop.prototype.j2se.stack.Stack;
import org.siprop.prototype.j2se.stack.StackBase;

/**
 * メッセージのセットの構造体<BR>
 * すべての層で、これを通信しあうかたちとなる。<BR>
 * これに保持されたメッセージやステータスにより、各層の動作が決定される。
 * @author noritsuna
 *
 */
public class MessageContext {

	protected ControlMessage ctrlMessage;
	protected FlatSIPMessage flatMessage;
	
	protected byte[] rawPacket;
	
	
	
	/**
	 * Stack。Transportは、本クラスの内部にある。
	 */
	protected StackBase stack;	
	
	
	
	public ControlMessage getCtrlMessage() {
		return ctrlMessage;
	}
	public void setCtrlMessage(ControlMessage ctrlMessage) {
		this.ctrlMessage = ctrlMessage;
	}
	public FlatSIPMessage getFlatMessage() {
		return flatMessage;
	}
	public void setFlatMessage(FlatSIPMessage flatMessage) {
		this.flatMessage = flatMessage;
	}
	public StackBase getStack() {
		return stack;
	}
	public void setStack(StackBase stack) {
		this.stack = stack;
	}
	public byte[] getRawPacket() {
		return rawPacket;
	}
	public void setRawPacket(byte[] rawPacket) {
		this.rawPacket = rawPacket;
	}
	
}
