package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.UAManagerBase;
import org.siprop.prototype.j2se.ua.UAModuleBase;
import org.siprop.prototype.j2se.ua.UARouterBase;
import org.siprop.prototype.j2se.ua.util.UAState;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class RTPUAModule extends UAModuleBase {

	
	
	public RTPUAModule(UAManagerBase bean) {
		super(bean);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	@Override
	public void incommingINVITE(MessageContext msgSet) {
		throw new NotImplementedException();

	}

	@Override
	public void incommingRESPONSE(MessageContext msgSet) {
		throw new NotImplementedException();

	}

	@Override
	public void outgoingINVITE(MessageContext msgSet) {
		throw new NotImplementedException();

	}

	@Override
	public void outgoingRESPONSE(MessageContext msgSet) {
		throw new NotImplementedException();

	}

	@Override
	public void call() {
		throw new NotImplementedException();

	}

	@Override
	public void bye() {
		throw new NotImplementedException();

	}

	@Override
	public void hold() {
		throw new NotImplementedException();

	}

	@Override
	public void forward() {
		throw new NotImplementedException();

	}

	@Override
	public void etc() {
		throw new NotImplementedException();

	}

	public UAState getState() {
		throw new NotImplementedException();
		
	}

}
