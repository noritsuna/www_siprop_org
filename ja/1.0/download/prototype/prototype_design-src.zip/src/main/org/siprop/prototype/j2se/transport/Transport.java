package org.siprop.prototype.j2se.transport;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.message.MessageContext;

/**
 * トランスポート層（メッセージ層）を表すインタフェース
 * Stackにより、保持される。
 * 
 * @author noritsuna
 *
 */
public interface Transport {
	
	public void send(MessageContext msgSet);
	
	public void receive(MessageContext msgSet);
}
