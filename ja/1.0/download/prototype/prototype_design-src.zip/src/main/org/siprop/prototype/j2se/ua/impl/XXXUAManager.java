package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.UAManagerBase;
import org.siprop.prototype.j2se.ua.UARouterBase;
import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * XXX社製UAコントロール用モジュール
 * @author noritsuna
 *
 */
public class XXXUAManager extends UAManagerBase {

	public XXXUAManager(B2BUAManagerBase bean) {
		super(bean);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public UAState getState() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public void doDispatch(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

}
