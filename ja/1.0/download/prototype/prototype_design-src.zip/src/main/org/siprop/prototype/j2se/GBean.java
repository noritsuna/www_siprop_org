package org.siprop.prototype.j2se;

import org.siprop.prototype.j2se.message.MessageContext;

/**
 * 各モジュールの基底となるインタフェース
 * @author noritsuna
 *
 */
public interface GBean {
	
	/**
	 * ディスパッチ用メソッド。
	 * このメソッドは、threadで動作することが前提。
	 * @param msgSet すべての層で使用されるメッセージ構造体。
	 */
	public void doDispatch(MessageContext msgSet);

}
