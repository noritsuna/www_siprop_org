package org.siprop.prototype.j2se.transport.impl;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.transport.DirectConnecter;
import org.siprop.prototype.j2se.transport.Transport;

/**
 * RTPをTransportで送受信するためのクラス
 * @author noritsuna
 *
 */
public class RTPConnecter implements DirectConnecter {
	
	protected Transport innerTrans;
	protected Transport outerTrans;
	
	public void send(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

	public void receive(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
