package org.siprop.prototype.j2se.message.impl;

import org.siprop.prototype.j2se.message.FlatSIPMessage;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;


/**
 * 具体的なSIPパケットを表すクラス
 * FlatSIP ←→ SIPパケット 変換などを行う。
 * @author noritsuna
 *
 */
public class SIPPacket extends FlatSIPMessage {
	
	public byte[] createPacket(){
		throw new NotImplementedException();
	};

}
