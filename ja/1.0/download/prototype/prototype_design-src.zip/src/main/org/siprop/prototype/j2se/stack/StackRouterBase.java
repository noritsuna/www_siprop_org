package org.siprop.prototype.j2se.stack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.message.MessageContext;

/**
 * Stackの判定を行うための基底クラス<BR>
 * パケットを解析し、どのStackManagerにDispatchすべきかを判断する。<BR>
 * inner,outerに対して、1つずつ存在する。
 * @author noritsuna
 *
 */
public abstract class StackRouterBase implements StackRouter {

	
	protected B2BUAManagerBase b2bua;
	

}
