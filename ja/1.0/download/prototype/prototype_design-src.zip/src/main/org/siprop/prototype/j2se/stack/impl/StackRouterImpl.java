package org.siprop.prototype.j2se.stack.impl;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.stack.Stack;
import org.siprop.prototype.j2se.stack.StackBase;
import org.siprop.prototype.j2se.stack.StackRouterBase;

/**
 * StackRouterの実装クラス
 * @author noritsuna
 *
 */
public class StackRouterImpl extends StackRouterBase {
	

	public void doDispatch(MessageContext msgSet) {
		//これで、Stack周りの処理は、終了する。
		msgSet.setStack(this.selectStack(msgSet.getRawPacket()));
		
		//上位層へ投げあげる。
		b2bua.doDispatch(msgSet);
	}

	/**
	 * Packetに適したStackを判定し、返す。
	 * @param packet
	 * @return
	 */
	protected StackBase selectStack(byte[] packet) {
		StackBase stack = new SIPStack();
		
		//パース可能かチェックする
		if(stack.isPacket(packet)) {
			//parseする。
			stack.parse(packet);
		}
		
		return stack;
		
	}
	
	protected void bindStack(MessageContext msgSet) {
		//すでに、Stackが生成されていれば、それにBindする。
	}

}
