package org.siprop.prototype.j2se.stack.impl;

import java.net.InetSocketAddress;

import org.siprop.prototype.j2se.stack.StackBase;
import org.siprop.prototype.j2se.transport.Transport;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * RTPStackの実装クラス
 * @author noritsuna
 *
 */
public class RTPStack extends StackBase {
	
	/**
	 * RTPの待ち受け用Socketを作成します。
	 * @return
	 */
	public InetSocketAddress createRtpSocket() {
		throw new NotImplementedException();
	}

	public Transport getTransport() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	public void setTransport(Transport trans) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public Transport createTransport() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public boolean isPacket(byte[] packet) {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}

	@Override
	public void parse(byte[] packet) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
	
	
	

}
