package org.siprop.prototype.j2se.ua.util;

/**
 * シーケンスなどのステートマシーン
 * まだ、明確な位置付けを決定していない。
 * 
 * ステートというよりは、call(),forward()などを用意して、Factory Methodパターン的な使い方になりそう。
 * 
 * UAContoroller用とUAModule用を共通化する必要がある。
 * 
 * @author noritsuna
 *
 */
public abstract class UAState {

		public static int NON_INIT = 0;
		
		
		protected int state;
		
		public int getState() {
			return state;
		}
}