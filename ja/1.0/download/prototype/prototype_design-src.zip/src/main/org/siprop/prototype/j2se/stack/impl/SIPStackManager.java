package org.siprop.prototype.j2se.stack.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.stack.StackBase;
import org.siprop.prototype.j2se.stack.StackManagerBase;
import org.siprop.prototype.j2se.stack.StackRouterBase;

/**
 * SIPStackの管理用クラス。
 * 
 * Transctionごとの振り分けとかを行う。(Jain-SIP自体にその機能があるので、実際には不要と思われる。)
 * @author noritsuna
 *
 */
public class SIPStackManager extends StackManagerBase {

	


	
	public void doDispatch(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
