package org.siprop.prototype.j2se.message;

/**
 * FlatSIPMessageと共に使用して、Stackやモジュール間の制御を行うためのメッセージ
 * 
 * @author noritsuna
 *
 */
public class ControlMessage {
	
	/**
	 * ControlCodeクラスの値を入れる。
	 */
	protected int controlCode;

}
