package org.siprop.prototype.j2se;

/**
 * Routerを示すマーカークラス
 * @author noritsuna
 *
 */
public interface Router extends GBean {

}
