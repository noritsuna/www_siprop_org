package org.siprop.prototype.j2se.b2bua.impl;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;

/**
 * B2BUAManagerの具体的な実装
 * @author noritsuna
 *
 */
public class B2BUAManagerImpl extends B2BUAManagerBase {

}
