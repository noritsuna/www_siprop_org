package org.siprop.prototype.j2se.stack;

import org.siprop.prototype.j2se.Router;

/**
 * StackRouterを示すマーカークラス
 * @author noritsuna
 *
 */
public interface StackRouter extends Stack, Router {

}
