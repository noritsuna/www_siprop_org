package org.siprop.prototype.j2se.stack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.siprop.prototype.j2se.message.MessageContext;

/**
 * Stackを管理するための基底クラス<BR>
 * Stackの種類ごとに1つインスタンス化される。
 * @author noritsuna
 *
 */
public class StackManagerBase implements Stack {

	/**
	 * Stackのリスト。
	 */
	protected List<StackBase> stackList = Collections.synchronizedList(new ArrayList<StackBase>());
	//Javaにおけるスレッドセーフの記述法。Collection系(Hashtableなどの配列など)は、すべて、これでいけます。

	
	public void doDispatch(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
