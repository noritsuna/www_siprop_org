package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.UAManagerBase;

/**
 * RTPMouduleを管理するためのクラス
 * @author noritsuna
 *
 */
public class RTPUAManager extends UAManagerBase {

	public RTPUAManager(B2BUAManagerBase bean) {
		super(bean);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public void doDispatch(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
