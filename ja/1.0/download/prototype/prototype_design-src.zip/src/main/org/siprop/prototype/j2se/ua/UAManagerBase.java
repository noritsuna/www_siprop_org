package org.siprop.prototype.j2se.ua;

import java.util.Hashtable;
import java.util.Iterator;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.util.UAModuleList;

/**
 * UAModuleを管理するための基底クラス。<BR>
 * UASetRouter1つに対して、1つ用意される。<BR>
 * @author noritsuna
 *
 */
public abstract class UAManagerBase implements UA {

	protected B2BUAManagerBase b2bUACtrl;

	/**
	 * UAModelSetを保持するテーブル。
	 * Forking時に、Dialogが複数になる点を考慮し、用意している。
	 */
	protected Hashtable<String, UAModuleList> uaModuleTable;
	

	
	public UAManagerBase(B2BUAManagerBase bean) {
		this.b2bUACtrl = bean;
	}
	
	
	/**
	 * UAModuleから、コールバックされるメソッド
	 * @param msgSet MessageContext
	 * @param module UA
	 */
	public void doCallBackFromUA(MessageContext msgSet, UA module) {
		//TODO UA の 状態をチェックし、UAModuleを殺したり操作する。
		
		//すべてのメッセージが戻ってきたら、その状態に合わせて必要な動作をする。
		this.doState(msgSet);
		
		//すべてのメッセージが戻ってきたら、メッセージをマージしてsendする。
		this.send(msgSet);
	}
	/**
	 * メッセージを送信する。
	 * @param msgSet
	 */
	protected void send(MessageContext msgSet) {
		//Transportへなげる。その先で、再度B2BUACtrlか実際にTransportかのルーティングがなされる。
		//判断材料は、MessageSetのどれかのパラメータ。まだ、未定。
		msgSet.getStack().getTransport().send(msgSet);
	}

	
	/**
	 * 具体的な処理開始するメソッド
	 * @param msgSet
	 */
	protected void start(MessageContext msgSet) {
		
		// UAModule用のkeyを取得する。
		
		// UAModuleList を取得する。
		
		// 新規であれば、作成する Forking対策
			
		// 処理をUAControl に、委譲する。
	}		

	/**
	 * UAModuleSetのUAModuleすべてへDispatchする。
	 * @param msgSet
	 * @param uaSet
	 */
	protected void dispatchUAModule(MessageContext msgSet, UAModuleList uaSet) {		
		Iterator<UA> iter = uaSet.getUAModuleList().iterator();
		while(iter.hasNext()) {
			UA module = iter.next();
			module.doDispatch(msgSet);
		}
	}

	/**
	 * State状態に合わせて、必要な処理を行う。
	 */
	protected void doState(MessageContext msgSet) {
		//TODO 処理のやり方を記述。
		this.forward();//転送状態だった場合。
	}
	
	/**
	 * 転送の動作イメージ。
	 *
	 */
	protected void forward() {
		
		//REFERのダイアログIDを取得する
		//refDialog = msgSet.getReferDialog();
		
		//ダイアログIDから、対象のUAControlerを取得する
		//refUACtrl = this.b2bUACtrl.getUACtrl(refDialog);
		
		//UAControlerの接続先を変更する。
		//refUACtrl.referTo(this.UA1);
		
	}

	
}
