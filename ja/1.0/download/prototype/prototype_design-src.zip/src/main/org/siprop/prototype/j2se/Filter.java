package org.siprop.prototype.j2se;

import org.siprop.prototype.j2se.message.MessageContext;

/**
 * IP制限やAuth制限をかけるためのFilterクラス<BR>
 * それぞれにマッチした場合、エラー応答などを返す。
 * @author noritsuna
 *
 */
public interface Filter {

	public String fileter(MessageContext msgContext);
}
