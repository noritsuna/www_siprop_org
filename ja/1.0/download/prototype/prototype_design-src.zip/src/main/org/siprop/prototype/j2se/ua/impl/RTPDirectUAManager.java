package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.transport.impl.RTPConnecter;
import org.siprop.prototype.j2se.ua.UA;
import org.siprop.prototype.j2se.ua.UAManagerBase;

/**
 * DirectConnecterを使用するRTP用クラス
 * @author noritsuna
 *
 */
public class RTPDirectUAManager extends UAManagerBase {
	
	protected RTPConnecter rtpCon;
	

	public RTPDirectUAManager(B2BUAManagerBase bean) {
		super(bean);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public void doDispatch(MessageContext msgSet) {
		// TODO 自動生成されたメソッド・スタブ

	}

}
