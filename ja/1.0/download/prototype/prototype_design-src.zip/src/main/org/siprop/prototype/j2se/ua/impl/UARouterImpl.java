package org.siprop.prototype.j2se.ua.impl;

import org.siprop.prototype.j2se.b2bua.B2BUAManagerBase;
import org.siprop.prototype.j2se.ua.UARouterBase;
import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * UAの振り分けを行う。
 * 本実装においては、RTP用とSIP用のUAを振り分けるのに使用する。
 * @author noritsuna
 *
 */
public class UARouterImpl extends UARouterBase {

	public UARouterImpl(B2BUAManagerBase bean) {
		super(bean);
		// TODO 自動生成されたコンストラクター・スタブ
	}

	public UAState getState() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
