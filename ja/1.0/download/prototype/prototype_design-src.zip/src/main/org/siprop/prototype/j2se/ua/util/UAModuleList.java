package org.siprop.prototype.j2se.ua.util;

import java.util.ArrayList;

import org.siprop.prototype.j2se.ua.UA;

/**
 * 同一ダイアログ上で動作するUAModuleを保持するためのクラス<BR>
 * Forking時に使用する。
 * @author noritsuna
 *
 */
public class UAModuleList {
	
	/**
	 * インスタンス化したUAModuleのリスト
	 */
	protected ArrayList<UA> uaList;
	
	public UAModuleList() {
		//Syncを忘れずに。
		this.uaList = new ArrayList<UA>();
	}
	


	/**
	 * UAModuleのリストを取得する。
	 * @return
	 */
	public ArrayList<UA> getUAModuleList() {
		return uaList;
	}
	/**
	 * UAModuleを追加する。
	 * @param uaModule
	 */
	public void setUAModule(UA uaModule) {
		uaList.add(uaModule);
	}

}
