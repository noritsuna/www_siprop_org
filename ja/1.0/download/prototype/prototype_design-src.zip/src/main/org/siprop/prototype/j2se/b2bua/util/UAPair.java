package org.siprop.prototype.j2se.b2bua.util;

import org.siprop.prototype.j2se.ua.UA;

/**
 * B2BUAとして、対となるUA(具体的には、UAManager)を保持するための構造体
 * @author noritsuna
 *
 */
public class UAPair {
	
	/**
	 * （便宜上の）内側UA<BR>
	 * 本プログラムにおいては、Resolverが、その存在を知っている。
	 */
	public UA innerUA;
	/**
	 * （便宜上の）外側UA<BR>
	 * 本プログラムにおいては、Resolverが、その存在を知っている。
	 */
	public UA outerUA;
	

}
