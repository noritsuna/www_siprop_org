package org.siprop.prototype.j2se.ua;

import org.siprop.prototype.j2se.message.MessageContext;
import org.siprop.prototype.j2se.ua.util.UAState;

/**
 * UAに相当する基底クラス。<BR>
 * 端末ごとに1つ用意されることになる予定である。
 * @author noritsuna
 *
 */
public abstract class UAModuleBase implements UA {

	
	protected UAManagerBase uaManager;
	
	public UAModuleBase(UAManagerBase bean) {
		this.uaManager = bean;
	}
	
	/**
	 * UARouterBase から、Dispatchされるメソッド
	 */
	public void doDispatch(MessageContext msgSet) {
		this.start(msgSet);
	}
	
	
	/**
	 * 具体的な処理開始するメソッド
	 * @param msgSet
	 */	
	protected void start(MessageContext msgSet) {
		
		//TODO MessageSetを元に、API候補メソッドを呼び出す。インタプリタのような動作を想定。
		
		
		
		// 処理が終了後、UAControllerにコールバックする。
		//uaManager.doCallBackFromUA(msgSet, this);		
	}	
	
	//TODO 必要となりそうなオブジェクト
	/**
	 * 現在のステート状態。Ringing,Callなど。
	 */
	protected UAState state;
	/**
	 * 一番最初のメッセージ
	 */
	protected MessageContext messageOrig;
	/**
	 * 最後に送信したメッセージ
	 */
	protected MessageContext messageLastSend;
	/**
	 * 最後に受信したメッセージ
	 */
	protected MessageContext messageLastReceive;
	
	
	
	//TODO これ以下は、API候補メソッド。（もっと、簡単に拡張できるようにするべきか？）
	//イメージがつかめる程度のみ記述。まだまだ、検討中。
	
	//メッセージを単位としたメソッド。メッセージの書き換えなどを想定。
	public abstract void incommingINVITE(MessageContext msgSet);
	public abstract void incommingRESPONSE(MessageContext msgSet);
	public abstract void outgoingINVITE(MessageContext msgSet);
	public abstract void outgoingRESPONSE(MessageContext msgSet);

	//TUを単位としたメソッド。シーケンスに対する動作記述を想定。
	public abstract void call();
	public abstract void bye();
	public abstract void hold();
	public abstract void forward();
	public abstract void etc();
	
}
