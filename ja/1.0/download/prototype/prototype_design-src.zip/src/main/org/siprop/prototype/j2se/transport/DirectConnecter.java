package org.siprop.prototype.j2se.transport;

/**
 * 2つ以上のTransportを直結するためのクラスのマーカークラス
 * @author noritsuna
 *
 */
public interface DirectConnecter extends Transport {

}
